-- 30-day trial accounts for the dealer workspace.
--
-- Trial accounts are ordinary APP_USERS rows whose EXPIRES_AT is set to a
-- future timestamp. A NULL EXPIRES_AT means the account never expires, so this
-- migration is safe for existing installations and leaves every current
-- operator permanent.
--
-- Run once against an existing installation (a fresh
-- `database/oracle-audit-install.sql` already contains EXPIRES_AT, and the
-- installer ignores ORA-01430 when the column is present):
--
--   ALTER TABLE APP_USERS ADD (EXPIRES_AT TIMESTAMP WITH TIME ZONE);
--
-- Redeem / grant a 30-day trial to an existing account (the admin UI does this
-- through `oracleOperations.setUserTrial`):
--
--   UPDATE APP_USERS SET EXPIRES_AT=SYSTIMESTAMP+NUMTODSINTERVAL(30,'DAY')
--    WHERE USERNAME='prospect';
--
-- Make an account permanent again:
--
--   UPDATE APP_USERS SET EXPIRES_AT=NULL WHERE USERNAME='prospect';

ALTER TABLE APP_USERS ADD (EXPIRES_AT TIMESTAMP WITH TIME ZONE)
/

-- Sessions of expired trial accounts are rejected by `actorFor`, and
-- `oracleOperations.login` refuses them outright; stale rows can be pruned any
-- time with:
DELETE FROM APP_SESSIONS
 WHERE USER_ID IN (
   SELECT ID FROM APP_USERS WHERE EXPIRES_AT IS NOT NULL AND EXPIRES_AT<=SYSTIMESTAMP
 )
/

COMMIT
/