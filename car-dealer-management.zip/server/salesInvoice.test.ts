import { describe, it, expect, vi } from "vitest";
import type { Connection } from "oracledb";
import { salesInvoiceInput } from "../shared/salesInvoice";
import { createSalesInvoice } from "./salesInvoice";
vi.mock("./oracleSession", () => ({ tagActor: vi.fn() }));
const actor = {
  ID: 1,
  USERNAME: "tester",
  DISPLAY_NAME: "Tester",
  ROLE: "editor" as const,
};
const input = {
  date: "2026-10-04",

  phone: "",
  branch: "",
  notes: "",
  accountId: 10,
  paymentAccountId: 20,
  vat: 15,
  lines: [{ purchaseId: 7, price: 115 }],
};
function connection(
  failLine = false,
  missingAccount = false,
  sold = false,
  status: string | null = "unposted"
) {
  const execute = vi.fn(async (sql: string) => {
    if (sql.includes("FROM APP_SALES_SETTINGS"))
      return { rows: [{ SALES_PARENT: 2001, PAYMENT_PARENT: 2006 }] };
    if (sql.includes("USER_OBJECTS")) return { rows: [{ N: 8 }] };
    if (sql.includes("FROM CLASSACT"))
      return {
        rows: [10, 20, ...(missingAccount ? [] : [3005, 3006])].map(
          SON_NUM => ({
            SON_NUM,
            SONNAM: "Account",
            BAR_NUM: SON_NUM === 20 ? 2006 : 2001,
            AC_NUM: 1,
          })
        ),
      };
    if (sql.startsWith("SELECT CP_ID"))
      return {
        rows: [
          {
            CP_ID: 7,
            CP_TYPE: "Car",
            CP_PANEL: "Plate",
            CP_MODEL: null,
            CP_COLOR: null,
            CP_HIKL: null,
            CP_CAR_LIST: null,
            CP_PURCH_PRICE: 80,
            CP_STATUS: status,
          },
        ],
      };
    if (sql.includes("COUNT(*) N FROM CAR_SALES_INV"))
      return { rows: [{ N: sold ? 1 : 0 }] };
    if (sql.startsWith("INSERT INTO SALES_INVOICE"))
      return { outBinds: { id: [42] } };
    if (sql.startsWith("INSERT INTO CAR_SALES_INV")) {
      if (failLine) throw new Error("line failed");
      return { outBinds: { id: [99] } };
    }
    return { rows: [{ N: 0 }] };
  });
  return {
    execute,
    commit: vi.fn(),
    rollback: vi.fn(),
  } as unknown as Connection;
}
describe("sales invoice creation", () => {
  it.each([null, "posted", "pending", "UNPOSTED"])(
    "rejects inventory status %s before creating an invoice",
    async status => {
      const c = connection(false, false, false, status);
      await expect(createSalesInvoice(c, actor, input)).rejects.toThrow(
        "unposted"
      );
      expect(
        vi
          .mocked(c.execute)
          .mock.calls.some(([sql]) => String(sql).startsWith("INSERT"))
      ).toBe(false);
      expect(c.commit).not.toHaveBeenCalled();
      expect(c.rollback).toHaveBeenCalledOnce();
    }
  );
  it("rejects an account outside its configured parent", async () => {
    const c = connection();
    const execute = vi.mocked(c.execute);
    const original = execute.getMockImplementation()!;
    execute.mockImplementation((...args: Parameters<Connection["execute"]>) => {
      if (String(args[0]).includes("FROM APP_SALES_SETTINGS"))
        return Promise.resolve({
          rows: [{ SALES_PARENT: 9999, PAYMENT_PARENT: 2006 }],
        }) as ReturnType<Connection["execute"]>;
      return original(...args);
    });
    await expect(createSalesInvoice(c, actor, input)).rejects.toThrow(
      "لا يتبع إعدادات"
    );
    expect(c.commit).not.toHaveBeenCalled();
    expect(c.rollback).toHaveBeenCalledOnce();
  });
  it("rejects a reserved car even when an old sales form submits it", async () => {
    const c = connection();
    const execute = vi.mocked(c.execute);
    const original = execute.getMockImplementation()!;
    execute.mockImplementation((...args: Parameters<Connection["execute"]>) => {
      if (String(args[0]).includes("COUNT(*) N FROM APP_DEALER_ACTIVITIES"))
        return Promise.resolve({ rows: [{ N: 1 }] }) as ReturnType<
          Connection["execute"]
        >;
      return original(...args);
    });
    await expect(createSalesInvoice(c, actor, input)).rejects.toThrow(
      "السيارة محجوزة"
    );
    expect(c.commit).not.toHaveBeenCalled();
    expect(
      execute.mock.calls.some(([sql]) =>
        String(sql).startsWith("INSERT INTO SALES_INVOICE")
      )
    ).toBe(false);
  });
  it("rejects duplicate vehicles, impossible dates, and negative prices", () => {
    expect(
      salesInvoiceInput.safeParse({
        ...input,
        lines: [input.lines[0], input.lines[0]],
      }).success
    ).toBe(false);
    expect(
      salesInvoiceInput.safeParse({ ...input, date: "2026-02-30" }).success
    ).toBe(false);
    expect(
      salesInvoiceInput.safeParse({
        ...input,
        lines: [{ purchaseId: 7, price: -1 }],
      }).success
    ).toBe(false);
  });
  it("links lines to the returned master ID and commits stock with the invoice", async () => {
    const c = connection();
    expect(await createSalesInvoice(c, actor, input)).toEqual({ id: 42 });
    const calls = vi.mocked(c.execute).mock.calls;
    const master = calls.find(([sql]) =>
      String(sql).startsWith("INSERT INTO SALES_INVOICE")
    )!;
    expect(master[1]).toMatchObject({
      customer: "Account",
      total: 115,
      vat: 15,
      cost: 80,
    });
    expect(
      calls.find(([sql]) =>
        String(sql).startsWith("INSERT INTO CAR_SALES_INV")
      )?.[1]
    ).toMatchObject({ invoice: 42, car: 7 });
    expect(
      calls.find(([sql]) =>
        String(sql).startsWith("INSERT INTO STOCK_LEDGER")
      )?.[1]
    ).toEqual({ id: 99 });
    expect(c.commit).toHaveBeenCalledOnce();
    expect(c.rollback).not.toHaveBeenCalled();
  });
  it("rolls back the master if a detail fails", async () => {
    const c = connection(true);
    await expect(createSalesInvoice(c, actor, input)).rejects.toThrow(
      "لم تُحفظ"
    );
    expect(c.commit).not.toHaveBeenCalled();
    expect(c.rollback).toHaveBeenCalledOnce();
  });
  it("prevents writes when posting accounts are absent or the vehicle is already sold", async () => {
    for (const c of [connection(false, true), connection(false, false, true)]) {
      await expect(createSalesInvoice(c, actor, input)).rejects.toThrow();
      expect(
        vi
          .mocked(c.execute)
          .mock.calls.some(([sql]) => String(sql).startsWith("INSERT"))
      ).toBe(false);
      expect(c.rollback).toHaveBeenCalledOnce();
    }
  });
});
