import oracledb, { type Connection } from "oracledb";
import { TRPCError } from "@trpc/server";
import type { z } from "zod";
import { oraclePurchaseInput } from "../shared/oraclePurchaseInvoice";
import { tagActor, type Actor } from "./oracleSession";
import { getPurchaseAccountSettings } from "./purchaseAccountSettings";
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
function reject(message: string): never {
  throw new TRPCError({ code: "BAD_REQUEST", message });
}
export async function purchaseInvoiceOptions(c: Connection) {
  const settings = await getPurchaseAccountSettings(c);
  const accounts =
    (
      await c.execute<{
        ID: number;
        NAME: string;
        BAR_NUM: number;
        MAIN_NUM: number;
      }>(
        "SELECT s.SON_NUM ID,s.AC_NAM NAME,s.BAR_NUM,b.AC_NUM MAIN_NUM FROM SON_ACT s JOIN BRANSH_ACT b ON b.BAR_NUM=s.BAR_NUM JOIN MAIN_ACT m ON m.AC_NUM=b.AC_NUM ORDER BY s.SON_NUM",
        [],
        o
      )
    ).rows ?? [];
  return {
    settings,
    accounts: accounts.filter(a => a.BAR_NUM === settings.stockParent),
    owners: accounts.filter(a => a.BAR_NUM === settings.ownerParent),
    suppliers: accounts.filter(a => a.BAR_NUM === settings.supplierParent),
  };
}
export async function createPurchaseInvoice(
  c: Connection,
  actor: Actor,
  input: z.infer<typeof oraclePurchaseInput>
) {
  input = oraclePurchaseInput.parse(input);
  try {
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    await c.execute(
      "LOCK TABLE PURCHASE_INVOICE,CAR_PURCHASE,STOCK_LEDGER,ACCOUNT_LEDGER,SON_ACT,BRANSH_ACT,MAIN_ACT IN EXCLUSIVE MODE NOWAIT"
    );
    const ready = (
      await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM USER_TRIGGERS t JOIN USER_OBJECTS o ON o.OBJECT_NAME=t.TRIGGER_NAME AND o.OBJECT_TYPE='TRIGGER' WHERE t.TRIGGER_NAME IN ('APP_AUD_PURCHASE_INVOICE','APP_AUD_CAR_PURCHASE','APP_AUD_STOCK_LEDGER','APP_AUD_ACCOUNT_LEDGER','CAR_PURCHASE_TRIGGER','CAR_PURCHASE_TOTAL_TRIGGER','PURCHASE_TO_STOCK_LEDGER','PURCHASE_INVOICE_ACC_LEDGER') AND t.STATUS='ENABLED' AND o.STATUS='VALID'",
        [],
        o
      )
    ).rows?.[0]?.N;
    if (ready !== 8) reject("مشغلات المشتريات وسجل التدقيق غير جاهزة للحفظ");
    const accounts =
      (
        await c.execute<{
          ID: number;
          NAME: string;
          BAR_NUM: number;
          MAIN_NUM: number;
        }>(
          "SELECT s.SON_NUM ID,s.AC_NAM NAME,s.BAR_NUM,b.AC_NUM MAIN_NUM FROM SON_ACT s JOIN BRANSH_ACT b ON b.BAR_NUM=s.BAR_NUM JOIN MAIN_ACT m ON m.AC_NUM=b.AC_NUM WHERE s.SON_NUM IN (:supplier,:payment,:owner)",
          {
            supplier: input.supplierId,
            payment: input.paymentId,
            owner: input.ownerId,
          },
          o
        )
      ).rows ?? [];
    const settings = await getPurchaseAccountSettings(c);
    const supplier = accounts.find(a => a.ID === input.supplierId),
      payment = accounts.find(a => a.ID === input.paymentId),
      owner = accounts.find(a => a.ID === input.ownerId);
    if (!supplier || supplier.BAR_NUM !== settings.supplierParent)
      reject(
        "اختر المورد من حسابات المستوى الثالث المحددة في إعدادات المشتريات"
      );
    if (!payment || payment.BAR_NUM !== settings.stockParent)
      reject("اختر مخزون المعرض من الحسابات المحددة في إعدادات المشتريات");
    if (!owner || owner.BAR_NUM !== settings.ownerParent)
      reject(
        "اختر المالك من حسابات المستوى الثالث المحددة في إعدادات المشتريات"
      );
    if (supplier.ID === payment.ID)
      reject("يجب أن يختلف حساب المورد عن الحساب المقابل");
    for (const [i, line] of input.lines.map((l, i) => [i, l] as const)) {
      const exists = (
        await c.execute<{ N: number }>(
          "SELECT COUNT(*) N FROM CAR_PURCHASE WHERE UPPER(TRIM(CP_PANEL))=:plate OR (:vin IS NOT NULL AND UPPER(TRIM(CP_HIKL))=:vin)",
          {
            plate: line.plate.toUpperCase(),
            vin: line.vin.toUpperCase() || null,
          },
          o
        )
      ).rows?.[0]?.N;
      if (exists)
        reject("السطر " + (i + 1) + ": اللوحة أو رقم الهيكل مسجل مسبقاً");
    }
    await tagActor(c, actor);
    const saved = await c.execute(
      "INSERT INTO PURCHASE_INVOICE(PUI_ID,PUI_DATE,PUI_TIME,PUI_ENTERED_BY,PUI_BRANSH,PUI_POST,PUI_TOTAL,PUI_NOTE,PUI_SUPPLIER,PUI_NUM,PUI_BAR_NUM,PUI_MAIN_NUM,BC_NUM,BC_BAR_NUM,BC_MAIN_NUM,BC_STORE_NAME,PUI_STATUS,PUI_OWNER_NUM,PUI_OWNER_NAME,PUI_OWNER_BAR_NUM,PUI_OWNER_MAIN_NUM) VALUES((SELECT NVL(MAX(PUI_ID),0)+1 FROM PURCHASE_INVOICE),TO_DATE(:d,'YYYY-MM-DD'),SYSTIMESTAMP,:actor,:branch,'UN POST',0,:notes,:supplier,:sid,:sbar,:smain,:pid,:pbar,:pmain,:pname,'المشتريات',:oid,:oname,:obar,:omain) RETURNING PUI_ID INTO :id",
      {
        d: input.date,
        actor: actor.USERNAME,
        branch: input.branch,
        notes: input.notes,
        supplier: supplier.NAME,
        sid: supplier.ID,
        sbar: supplier.BAR_NUM,
        smain: supplier.MAIN_NUM,
        pid: payment.ID,
        pbar: payment.BAR_NUM,
        pmain: payment.MAIN_NUM,
        pname: payment.NAME,
        oid: owner.ID,
        oname: owner.NAME,
        obar: owner.BAR_NUM,
        omain: owner.MAIN_NUM,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
      }
    );
    const id = Number((saved.outBinds as { id: number[] }).id[0]);
    const money = (v: number) => Math.round(v * 100) / 100;
    for (const line of input.lines)
      await c.execute(
        "INSERT INTO CAR_PURCHASE(CP_TYPE,CP_MODEL,CP_COLOR,CP_PANEL,CP_DATE_IN,CP_PURCH_PRICE,CP_CAR_NOTE,CP_INV_REF,CP_HIKL,CP_STATUS) VALUES(:car,:model,:color,:plate,TO_DATE(:d,'YYYY-MM-DD'),:price,:notes,:invoice,:vin,'unposted')",
        {
          car: line.car,
          model: line.model,
          color: line.color,
          plate: line.plate,
          d: input.date,
          price: money(line.price),
          notes: line.notes,
          invoice: id,
          vin: line.vin || null,
        }
      );
    const expected = money(input.lines.reduce((n, l) => n + money(l.price), 0));
    const actual = (
      await c.execute<{ TOTAL: number }>(
        "SELECT PUI_TOTAL TOTAL FROM PURCHASE_INVOICE WHERE PUI_ID=:id",
        { id },
        o
      )
    ).rows?.[0]?.TOTAL;
    if (actual == null || money(Number(actual)) !== expected)
      reject("لم تتطابق قيمة الفاتورة مع تفاصيلها؛ تم إلغاء الحفظ");
    await c.commit();
    return { id, total: expected };
  } catch (error) {
    await c.rollback();
    if (error instanceof TRPCError) throw error;
    const n = (error as { errorNum?: number }).errorNum;
    throw new TRPCError({
      code: n === 54 || n === 60 ? "CONFLICT" : "INTERNAL_SERVER_ERROR",
      message:
        n === 54 || n === 60
          ? "توجد عملية أخرى قيد التنفيذ؛ أعد المحاولة"
          : "لم تُحفظ الفاتورة؛ تراجعت جميع التغييرات.",
      cause: error,
    });
  }
}
