﻿import { describe, it, expect, vi } from "vitest";
import type { Connection } from "oracledb";
import { voucherInput } from "../shared/oracleVoucher";
import { createVoucher } from "./oracleVoucher";
vi.mock("./oracleSession", () => ({ tagActor: vi.fn() }));
const actor = {
  ID: 1,
  USERNAME: "test",
  DISPLAY_NAME: "Test",
  ROLE: "editor" as const,
};
const input = {
  kind: "receipts" as const,
  date: "2026-10-05",
  amount: 25.5,
  debitAccount: 10,
  creditAccount: 20,
  notes: "Receipt",
};
function connection(badPosting = false, missingAccount = false) {
  const execute = vi.fn(async (sql: string) => {
    if (sql.includes("USER_TRIGGERS")) return { rows: [{ N: 6 }] };
    if (sql.startsWith("SELECT s.SON_NUM"))
      return {
        rows: missingAccount
          ? []
          : [
              { ID: 10, NAME: "Debit", BAR_NUM: 100, MAIN_NUM: 1 },
              { ID: 20, NAME: "Credit", BAR_NUM: 200, MAIN_NUM: 2 },
            ],
      };
    if (sql.startsWith("INSERT INTO BB_ENT")) return { outBinds: { id: [3] } };
    if (sql.startsWith("SELECT AL_ACC_NO"))
      return {
        rows: [
          {
            AL_ACC_NO: 10,
            AL_DEPIT_MOUNT: badPosting ? 0 : 25.5,
            AL_CREDIT_MOUNT: 0,
            AL_BAR_NUM: 100,
            AL_MAIN_NUM: 1,
          },
          {
            AL_ACC_NO: 20,
            AL_DEPIT_MOUNT: 0,
            AL_CREDIT_MOUNT: 25.5,
            AL_BAR_NUM: 200,
            AL_MAIN_NUM: 2,
          },
        ],
      };
    if (sql.includes("FROM YOMIA_LEDGER")) return { rows: [{ N: 1 }] };
    return { rows: [] };
  });
  return {
    execute,
    commit: vi.fn(),
    rollback: vi.fn(),
  } as unknown as Connection;
}
describe("Oracle vouchers", () => {
  it("rejects same account, negative amounts, extra precision and invalid dates", () => {
    for (const change of [
      { creditAccount: 10 },
      { amount: -1 },
      { amount: 1.001 },
      { date: "2026-02-30" },
    ])
      expect(voucherInput.safeParse({ ...input, ...change }).success).toBe(
        false
      );
  });
  it("maps legacy fields to the actual debit and credit ledger accounts", async () => {
    const c = connection();
    expect(await createVoucher(c, actor, input)).toEqual({ id: 3 });
    const call = vi
      .mocked(c.execute)
      .mock.calls.find(([sql]) =>
        String(sql).startsWith("INSERT INTO BB_ENT")
      )!;
    expect(call[1]).toMatchObject({
      debitId: 10,
      creditId: 20,
      debitName: "Debit",
      creditName: "Credit",
      amount: 25.5,
    });
    expect(c.commit).toHaveBeenCalledOnce();
  });
  it("rolls back when accounting postings are wrong", async () => {
    const c = connection(true);
    await expect(createVoucher(c, actor, input)).rejects.toThrow("توازن");
    expect(c.commit).not.toHaveBeenCalled();
    expect(c.rollback).toHaveBeenCalledOnce();
  });
  it("rejects unlinked or nonexistent accounts before insertion", async () => {
    const c = connection(false, true);
    await expect(createVoucher(c, actor, input)).rejects.toThrow(
      "المستوى الثالث"
    );
    expect(
      vi
        .mocked(c.execute)
        .mock.calls.some(([sql]) => String(sql).startsWith("INSERT"))
    ).toBe(false);
    expect(c.rollback).toHaveBeenCalledOnce();
  });
  it("checks UTF-8 byte capacity of descriptions before writing", async () => {
    const c = connection();
    await expect(
      createVoucher(c, actor, { ...input, notes: "س".repeat(250) })
    ).rejects.toThrow("سعة الحقل");
    expect(c.execute).not.toHaveBeenCalled();
  });
});
