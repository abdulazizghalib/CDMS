import {
  createHash,
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual,
} from "node:crypto";
import { promisify } from "node:util";
import { parse } from "cookie";
import { TRPCError } from "@trpc/server";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "./oracle";
import type { TrpcContext } from "./_core/context";
const scrypt = promisify(scryptCallback);
export const sessionCookie = "dealer_oracle_session";
/**
 * Trial accounts are ordinary `APP_USERS` rows that carry a non-null
 * `EXPIRES_AT`. A null `EXPIRES_AT` means the account never expires.
 */
export type Actor = {
  ID: number;
  USERNAME: string;
  DISPLAY_NAME: string;
  ROLE: "admin" | "editor" | "viewer";
  /** Riyadh-local expiry date (`YYYY-MM-DD`) for trial accounts, else null. */
  EXPIRES_AT?: string | null;
};
export const sha256 = (value: string) =>
  createHash("sha256").update(value).digest("hex");
export async function passwordHash(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = (await scrypt(password, salt, 64)) as Buffer;
  return salt + ":" + hash.toString("hex");
}
export async function passwordMatches(password: string, stored: string) {
  const [salt, encoded] = stored.split(":");
  if (!salt || !encoded) return false;
  const actual = (await scrypt(password, salt, 64)) as Buffer;
  const expected = Buffer.from(encoded, "hex");
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
export async function oracleConnection<T>(run: (c: Connection) => Promise<T>) {
  const c = await oracledb.getConnection(getOracleConfig());
  try {
    return await run(c);
  } finally {
    await c.close();
  }
}
export async function actorFor(
  req: TrpcContext["req"],
  c: Connection
): Promise<Actor | null> {
  const token = parse(req.headers.cookie ?? "")[sessionCookie];
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const result = await c.execute<Actor>(
    "SELECT u.ID,u.USERNAME,u.DISPLAY_NAME,u.ROLE,TO_CHAR(u.EXPIRES_AT AT TIME ZONE '+03:00','YYYY-MM-DD') EXPIRES_AT FROM APP_USERS u JOIN APP_SESSIONS s ON s.USER_ID=u.ID WHERE s.TOKEN_HASH=:token AND s.EXPIRES_AT>SYSTIMESTAMP AND u.ACTIVE=1 AND (u.EXPIRES_AT IS NULL OR u.EXPIRES_AT>SYSTIMESTAMP)",
    { token: sha256(token) },
    { outFormat: oracledb.OUT_FORMAT_OBJECT }
  );
  return result.rows?.[0] ?? null;
}
export function requireSameOrigin(req: TrpcContext["req"]) {
  const origin = req.headers.origin;
  try {
    if (
      !origin ||
      new URL(origin).host !== req.headers.host ||
      req.headers["sec-fetch-site"] === "cross-site"
    )
      throw new Error();
  } catch {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "يجب تنفيذ العملية من واجهة النظام نفسها",
    });
  }
}
export async function requireActor(
  req: TrpcContext["req"],
  c: Connection,
  roles: Actor["ROLE"][] = ["admin", "editor"]
) {
  const actor = await actorFor(req, c);
  if (!actor)
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "سجل الدخول بحسابك أولاً",
    });
  if (!roles.includes(actor.ROLE))
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "لا تملك صلاحية هذه العملية",
    });
  return actor;
}
export async function tagActor(c: Connection, actor: Actor) {
  await c.execute(
    "BEGIN DBMS_SESSION.SET_IDENTIFIER(:actor); DBMS_APPLICATION_INFO.SET_MODULE('DEALER_WEB',:name); END;",
    { actor: String(actor.ID), name: actor.USERNAME.slice(0, 32) }
  );
}
export async function startSession(
  c: Connection,
  ctx: TrpcContext,
  actor: Actor
) {
  const token = randomBytes(32).toString("hex");
  await c.execute(
    "INSERT INTO APP_SESSIONS(TOKEN_HASH,USER_ID,EXPIRES_AT) VALUES(:token,:id,SYSTIMESTAMP+INTERVAL '8' HOUR)",
    { token: sha256(token), id: actor.ID }
  );
  ctx.res.cookie(sessionCookie, token, {
    httpOnly: true,
    sameSite: "strict",
    secure: ctx.req.secure,
    path: "/",
    maxAge: 8 * 3600 * 1000,
  });
}
