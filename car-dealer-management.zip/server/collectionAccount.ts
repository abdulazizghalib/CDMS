import { getPurchaseAccountSettings } from "./purchaseAccountSettings";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import oracledb, { type Connection } from "oracledb";
import { getSalesAccountSettings } from "./salesAccountSettings";
import { writeRecord } from "./oracleWrite";
import type { Actor } from "./oracleSession";
const text = (bytes: number) =>
  z
    .string()
    .trim()
    .refine(
      v => new TextEncoder().encode(v).length <= bytes,
      "النص أطول من سعة الحقل"
    );
export const collectionAccountInput = z.object({
  name: text(100).refine(v => v.length > 0, "اسم الحساب مطلوب"),
  phone: text(100).default(""),
  notes: text(200).default(""),
});
async function createAccount(
  c: Connection,
  actor: Actor,
  raw: z.infer<typeof collectionAccountInput>,
  kind: "collection" | "owner"
) {
  const input = collectionAccountInput.parse(raw);
  try {
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    await c.execute("LOCK TABLE SON_ACT IN EXCLUSIVE MODE NOWAIT");
    const parentId =
      kind === "owner"
        ? (await getPurchaseAccountSettings(c)).ownerParent
        : (await getSalesAccountSettings(c)).paymentParent;
    const parent = (
      await c.execute<{ BAR_NUM: number }>(
        "SELECT b.BAR_NUM FROM BRANSH_ACT b JOIN MAIN_ACT m ON m.AC_NUM=b.AC_NUM WHERE b.BAR_NUM=:parent",
        { parent: parentId },
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows?.[0];
    if (!parent)
      throw new TRPCError({
        code: "BAD_REQUEST",
        message:
          kind === "owner"
            ? "الحساب الأب للمالك غير صالح؛ راجع إعدادات المشتريات"
            : "الحساب الأب للتحصيل غير صالح؛ راجع إعدادات المبيعات",
      });
    const duplicate = (
      await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM SON_ACT WHERE BAR_NUM=:parent AND UPPER(TRIM(AC_NAM))=UPPER(:name)",
        { parent: parentId, name: input.name },
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows?.[0]?.N;
    if (duplicate)
      throw new TRPCError({
        code: "CONFLICT",
        message:
          "يوجد حساب بهذا الاسم ضمن الحساب الأب المحدد؛ اختره من القائمة",
      });
    const id = (
      await c.execute<{ ID: number }>(
        "SELECT NVL(MAX(SON_NUM),0)+1 ID FROM SON_ACT",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows![0].ID;
    const result = await writeRecord(c, actor, {
      dataset: "subAccounts",
      action: "insert",
      id,
      values: {
        BAR_NUM: parentId,
        AC_NAM: input.name,
        SON_PHONE: input.phone,
        NOTE: input.notes,
      },
    });
    return {
      ID: result.id ?? id,
      NAME: input.name,
      BAR_NUM: parentId,
      phone: input.phone,
    };
  } catch (error) {
    await c.rollback();
    if (error instanceof TRPCError) throw error;
    const n = (error as { errorNum?: number }).errorNum;
    throw new TRPCError({
      code: n === 54 || n === 60 ? "CONFLICT" : "INTERNAL_SERVER_ERROR",
      message:
        n === 54 || n === 60
          ? "توجد عملية أخرى قيد التنفيذ؛ أعد المحاولة"
          : "تعذر إنشاء الحساب؛ تراجعت تغييرات العملية",
      cause: error,
    });
  }
}

export function createCollectionAccount(
  c: Connection,
  actor: Actor,
  raw: z.infer<typeof collectionAccountInput>
) {
  return createAccount(c, actor, raw, "collection");
}
export function createOwnerAccount(
  c: Connection,
  actor: Actor,
  raw: z.infer<typeof collectionAccountInput>
) {
  return createAccount(c, actor, raw, "owner");
}
