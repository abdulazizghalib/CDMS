import { describe, expect, it } from "vitest";
import {
  allowsLocalOracleRead,
  buildTableQuery,
  tableInput,
} from "./oracleWorkspace";
const env = { NODE_ENV: "development", LOCAL_ORACLE_READONLY_UI: "true" };
const request = {
  socket: { remoteAddress: "127.0.0.1" },
  headers: { host: "localhost:3000", origin: "http://localhost:3000" },
};
describe("Oracle read-only workspace", () => {
  it("only permits explicit loopback preview with same origin", () => {
    expect(allowsLocalOracleRead(request, env)).toBe(true);
    expect(
      allowsLocalOracleRead(request, { ...env, NODE_ENV: "production" })
    ).toBe(false);
    expect(
      allowsLocalOracleRead(
        { ...request, socket: { remoteAddress: "192.168.1.5" } },
        env
      )
    ).toBe(false);
    expect(
      allowsLocalOracleRead(
        {
          ...request,
          headers: { ...request.headers, origin: "https://external.example" },
        },
        env
      )
    ).toBe(false);
    expect(
      allowsLocalOracleRead(
        { ...request, headers: { host: "external.example" } },
        env
      )
    ).toBe(false);
    expect(allowsLocalOracleRead(request, { NODE_ENV: "development" })).toBe(
      false
    );
  });
  it("requires a document reference for invoice details", () => {
    expect(tableInput.safeParse({ dataset: "salesLines" }).success).toBe(false);
    expect(
      tableInput.safeParse({ dataset: "purchaseLines", documentId: 1 }).success
    ).toBe(true);
    expect(
      tableInput.safeParse({ dataset: "inventory", page: 0 }).success
    ).toBe(false);
    expect(tableInput.safeParse({ dataset: "USERPASS" }).success).toBe(false);
  });
  it("binds search and invoice identifiers rather than injecting them into SQL", () => {
    const search = "\u0027 OR 1=1 --";
    const q = buildTableQuery(
      tableInput.parse({ dataset: "salesLines", documentId: 42, search })
    );
    expect(q.rows).toContain("CSI_INV_REF=:documentId");
    expect(q.rows).not.toContain(search);
    expect(q.binds).toEqual({ documentId: 42, search });
    expect(q.rows).toContain("OFFSET :skip ROWS FETCH NEXT :take ROWS ONLY");
  });
  it("reads inventory from purchased cars, not the entry number generator view", () => {
    const q = buildTableQuery(tableInput.parse({ dataset: "inventory" }));
    expect(q.rows).toContain("CAR_PURCHASE cp");
    expect(q.rows).not.toContain("CAR_ENTRY_VIEW");
  });
});

describe('Inventory brochure filters', () => {
 it('binds exact inventory identifiers and vehicle filters', () => {
 const vehicleType="' OR 1=1 --";
 const q=buildTableQuery(tableInput.parse({dataset:'inventory',vehicleType,model:'2020',posting:'posted',recordId:123,pageSize:8,inventorySort:'costAsc'}));
 expect(q.rows).not.toContain(vehicleType);
 expect(q.binds).toMatchObject({vehicleType,model:'2020',posting:'posted',recordId:123});
 expect(q.rows).toContain('ASC NULLS LAST');
 });
 it('rejects inventory filters on unrelated screens and unsafe sort values', () => {
 expect(tableInput.safeParse({dataset:'sales',recordId:123}).success).toBe(false);
 expect(tableInput.safeParse({dataset:'inventory',inventorySort:'DROP TABLE'}).success).toBe(false);
 });
});
