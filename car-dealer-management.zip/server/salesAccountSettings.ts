﻿import { z } from "zod";
import oracledb, { type Connection } from "oracledb";
import { TRPCError } from "@trpc/server";
import { tagActor, type Actor } from "./oracleSession";
export const salesAccountSettingsInput = z.object({
  salesParent: z.number().int().positive(),
  paymentParent: z.number().int().positive(),
});
export async function getSalesAccountSettings(c: Connection) {
  const row = (
    await c.execute<{ SALES_PARENT: number; PAYMENT_PARENT: number }>(
      "SELECT SALES_PARENT,PAYMENT_PARENT FROM APP_SALES_SETTINGS WHERE ID=1",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0];
  if (!row)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "إعدادات حسابات المبيعات غير مهيأة",
    });
  return { salesParent: row.SALES_PARENT, paymentParent: row.PAYMENT_PARENT };
}
export async function saveSalesAccountSettings(
  c: Connection,
  actor: Actor,
  input: z.infer<typeof salesAccountSettingsInput>
) {
  try {
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    const before = await getSalesAccountSettings(c);
    const parents =
      (
        await c.execute<{ BAR_NUM: number }>(
          "SELECT BAR_NUM FROM BRANSH_ACT WHERE BAR_NUM IN (:s,:p)",
          { s: input.salesParent, p: input.paymentParent },
          { outFormat: oracledb.OUT_FORMAT_OBJECT }
        )
      ).rows ?? [];
    if (
      !parents.some(a => a.BAR_NUM === input.salesParent) ||
      !parents.some(a => a.BAR_NUM === input.paymentParent)
    )
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "اختر حساباً أباً موجوداً في المستوى الثاني",
      });
    await tagActor(c, actor);
    await c.execute(
      "UPDATE APP_SALES_SETTINGS SET SALES_PARENT=:s,PAYMENT_PARENT=:p WHERE ID=1",
      { s: input.salesParent, p: input.paymentParent }
    );
    await c.execute(
      "INSERT INTO APP_AUDIT_LOG(ACTOR_ID,ACTOR_NAME,DB_USER,SOURCE,ACTION,TABLE_NAME,RECORD_ID,BEFORE_JSON,AFTER_JSON,TRANSACTION_ID) VALUES(:actor,:name,USER,'DEALER_WEB','UPDATE','APP_SALES_SETTINGS','1',:before,:after,DBMS_TRANSACTION.LOCAL_TRANSACTION_ID)",
      {
        actor: String(actor.ID),
        name: actor.DISPLAY_NAME,
        before: JSON.stringify(before),
        after: JSON.stringify(input),
      }
    );
    await c.commit();
    return input;
  } catch (error) {
    await c.rollback();
    throw error;
  }
}
