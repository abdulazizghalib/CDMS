import { TRPCError } from "@trpc/server";
import oracledb, { type Connection } from "oracledb";
import { z } from "zod";
import { editDefinitions, type EditDefinition } from "../shared/oracleMutation";
import { sha256, tagActor, type Actor } from "./oracleSession";
export const mutationInput = z.object({
  dataset: z.string(),
  action: z.enum(["insert", "update", "delete"]),
  id: z.number().int().positive().max(Number.MAX_SAFE_INTEGER).optional(),
  version: z.string().optional(),
  values: z
    .record(z.string(), z.union([z.string(), z.number(), z.null()]))
    .default({}),
});
const fail = (
  message: string,
  code: "BAD_REQUEST" | "CONFLICT" = "BAD_REQUEST"
) => {
  throw new TRPCError({ code, message });
};
export function definition(dataset: string) {
  const def = Object.hasOwn(editDefinitions, dataset)
    ? editDefinitions[dataset]
    : undefined;
  if (!def)
    fail("الحفظ غير متاح لهذه الشاشة حتى اكتمال قواعد المحاسبة والمخزون");
  return def!;
}
export function normalizeValues(
  def: EditDefinition,
  values: Record<string, string | number | null>
) {
  for (const key of Object.keys(values))
    if (!def.fields.some(f => f.key === key)) fail("حقل غير مسموح: " + key);
  const out: Record<string, string | number | null> = {};
  for (const f of def.fields) {
    let v = values[f.key] ?? null;
    if (typeof v === "string") v = v.trim();
    if (v === "") v = null;
    if (v === null) {
      if (f.required) fail("الحقل مطلوب: " + f.label);
      out[f.key] = null;
      continue;
    }
    if (f.type === "number") {
      const n = Number(v);
      if (
        !Number.isFinite(n) ||
        Math.abs(n) > Number.MAX_SAFE_INTEGER ||
        (f.integer && !Number.isInteger(n))
      )
        fail("قيمة رقمية غير صحيحة: " + f.label);
      out[f.key] = n;
    } else if (f.type === "date") {
      if (
        typeof v !== "string" ||
        !/^\d{4}-\d{2}-\d{2}$/.test(v) ||
        Number.isNaN(Date.parse(v)) ||
        new Date(v).toISOString().slice(0, 10) !== v
      )
        fail("تاريخ غير صحيح: " + f.label);
      out[f.key] = v;
    } else {
      v = String(v);
      if (Buffer.byteLength(v, "utf8") > (f.maxBytes ?? 200))
        fail("النص أطول من سعة الحقل: " + f.label);
      out[f.key] = v;
    }
  }
  return out;
}
export async function loadRecord(
  c: Connection,
  def: EditDefinition,
  id: number
) {
  const cols = [
    def.pk,
    ...def.fields.map(f =>
      f.type === "date" ? "TO_CHAR(" + f.key + ",'YYYY-MM-DD') " + f.key : f.key
    ),
  ];
  for (const f of def.fields.filter(f => f.type === "date"))
    cols.push(
      "TO_CHAR(" + f.key + ",'YYYY-MM-DD HH24:MI:SS') VERSION_" + f.key
    );
  // Include derived values in the version so concurrent changes cannot be silently overwritten.
  if (def.table === "CAR_SALES") cols.push("CS_CASH_REMAIN", "CS_ENTERED_BY");
  if (def.table === "CAR_ENTRY") cols.push("CE_STATUS");
  const result = await c.execute<Record<string, string | number | null>>(
    "SELECT " +
      cols.join(",") +
      " FROM " +
      def.table +
      " WHERE " +
      def.pk +
      "=:id",
    { id },
    { outFormat: oracledb.OUT_FORMAT_OBJECT }
  );
  const record = result.rows?.[0];
  if (!record)
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "السجل غير موجود أو حُذف",
    });
  return { record, version: sha256(JSON.stringify(record)) };
}
async function count(
  c: Connection,
  sql: string,
  binds: Record<string, unknown>
) {
  return Number(
    (
      await c.execute<{ N: number }>(sql, binds, {
        outFormat: oracledb.OUT_FORMAT_OBJECT,
      })
    ).rows?.[0]?.N ?? 0
  );
}
async function exists(c: Connection, table: string, pk: string, id: unknown) {
  if (
    id === null ||
    id === undefined ||
    (await count(
      c,
      "SELECT COUNT(*) N FROM " + table + " WHERE " + pk + "=:id",
      { id }
    )) !== 1
  )
    fail("الحساب الأب أو مرجع الدخول غير موجود");
}
export async function writeRecord(
  c: Connection,
  actor: Actor,
  input: z.infer<typeof mutationInput>
) {
  const def = definition(input.dataset);
  if (input.action !== "insert" && (!input.id || !input.version))
    fail("رقم السجل ونسخته مطلوبان للتعديل والحذف");
  if (def.manualId && input.action === "insert" && !input.id)
    fail("رقم الحساب مطلوب");
  const values =
    input.action === "delete" ? {} : normalizeValues(def, input.values);
  try {
    // Legacy triggers use MAX(id)+1. Short, ordered table locks also prevent external DML racing reference checks.
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    await c.execute(
      "LOCK TABLE ACCOUNT_LEDGER, BRANSH_ACT, CAR_ENTRY, CAR_OUT, CAR_SALES, CENTER_COST, MAIN_ACT, SON_ACT, TRAIL_BALANCE IN EXCLUSIVE MODE NOWAIT"
    );
    const auditedTables = [
      def.table,
      ...(def.table === "SON_ACT"
        ? ["TRAIL_BALANCE"]
        : def.table === "CAR_OUT"
          ? ["CAR_ENTRY"]
          : []),
    ];
    const auditBinds = Object.fromEntries(
      auditedTables.map((t, i) => ["n" + i, "APP_AUD_" + t])
    );
    const auditStatus = await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM USER_TRIGGERS t JOIN USER_OBJECTS o ON o.OBJECT_NAME=t.TRIGGER_NAME AND o.OBJECT_TYPE='TRIGGER' WHERE t.TRIGGER_NAME IN (" +
        auditedTables.map((_, i) => ":n" + i).join(",") +
        ") AND t.STATUS='ENABLED' AND o.STATUS='VALID'",
      auditBinds,
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );
    if (auditStatus.rows?.[0]?.N !== auditedTables.length)
      fail("سجل التدقيق غير جاهز؛ لا يمكن تنفيذ عملية غير مسجلة");
    await tagActor(c, actor);
    const previous =
      input.action === "insert" ? null : await loadRecord(c, def, input.id!);
    if (previous && previous.version !== input.version)
      fail(
        "تم تعديل السجل بواسطة مستخدم آخر؛ أغلق النموذج وأعد فتحه",
        "CONFLICT"
      );
    const isDelete = input.action === "delete";
    if (
      def.table === "MAIN_ACT" ||
      def.table === "BRANSH_ACT" ||
      def.table === "SON_ACT"
    ) {
      if (input.id) {
        const ledgerKey =
          def.table === "MAIN_ACT"
            ? "AL_MAIN_NUM"
            : def.table === "BRANSH_ACT"
              ? "AL_BAR_NUM"
              : "AL_ACC_NO";
        if (
          await count(
            c,
            "SELECT COUNT(*) N FROM ACCOUNT_LEDGER WHERE " + ledgerKey + "=:id",
            { id: input.id }
          )
        )
          fail("الحساب مرتبط بحركات محاسبية؛ لا يمكن تغييره أو حذفه");
        const child =
          def.table === "MAIN_ACT"
            ? ["BRANSH_ACT", "AC_NUM"]
            : def.table === "BRANSH_ACT"
              ? ["SON_ACT", "BAR_NUM"]
              : null;
        if (
          child &&
          input.action !== "insert" &&
          (await count(
            c,
            "SELECT COUNT(*) N FROM " +
              child[0] +
              " WHERE " +
              child[1] +
              "=:id",
            { id: input.id }
          ))
        )
          fail("الحساب يحتوي حسابات تابعة؛ عالج الارتباطات أولاً");
      }
      if (!isDelete && def.table === "BRANSH_ACT")
        await exists(c, "MAIN_ACT", "AC_NUM", values.AC_NUM);
      if (!isDelete && def.table === "SON_ACT")
        await exists(c, "BRANSH_ACT", "BAR_NUM", values.BAR_NUM);
    }
    if (
      def.table === "CAR_ENTRY" &&
      input.action !== "insert" &&
      (await count(c, "SELECT COUNT(*) N FROM CAR_OUT WHERE CO_REF=:id", {
        id: input.id,
      }))
    )
      fail("سجل الدخول مرتبط بسجل خروج؛ عالج الخروج أولاً");
    if (def.table === "CAR_OUT" && !isDelete) {
      await exists(c, "CAR_ENTRY", "CE_ID", values.CO_REF);
      if (
        await count(
          c,
          "SELECT COUNT(*) N FROM CAR_OUT WHERE CO_REF=:ref AND CO_ID<>:id",
          { ref: values.CO_REF, id: input.id ?? -1 }
        )
      )
        fail("السيارة لديها سجل خروج بالفعل");
    }
    if (def.table === "CAR_SALES" && !isDelete) {
      const total = Number(values.CS_TOTAL_MOUNT),
        paid = Number(values.CS_CASH_PAY);
      if (total < 0 || paid < 0 || paid > total)
        fail("مبلغ العقد والمدفوع غير صحيحين");
      values.CS_CASH_REMAIN = Math.round((total - paid) * 100) / 100;
      if (input.action === "insert")
        values.CS_ENTERED_BY = actor.USERNAME.slice(0, 50);
    }
    for (const key of ["CE_MOUNT", "CO_MOUNT", "CO_SAI"])
      if (values[key] != null && Number(values[key]) < 0)
        fail("القيمة لا يمكن أن تكون سالبة");
    if (def.table === "CAR_ENTRY" && input.action === "insert")
      values.CE_STATUS = 0;
    let id = input.id;
    if (input.action === "insert") {
      if (!def.manualId)
        id = (
          await c.execute<{ ID: number }>(
            "SELECT APP_RECORD_SEQ.NEXTVAL ID FROM DUAL",
            [],
            { outFormat: oracledb.OUT_FORMAT_OBJECT }
          )
        ).rows![0].ID;
      const keys = [def.pk, ...Object.keys(values)];
      const binds: Record<string, unknown> = {
        id,
        outId: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
      };
      const expr = keys.map((key, i) => {
        if (i === 0) return ":id";
        binds["v" + i] = values[key];
        return def.fields.find(f => f.key === key)?.type === "date"
          ? "TO_DATE(:v" + i + ",'YYYY-MM-DD')"
          : ":v" + i;
      });
      const result = await c.execute(
        "INSERT INTO " +
          def.table +
          "(" +
          keys.join(",") +
          ") VALUES(" +
          expr.join(",") +
          ") RETURNING " +
          def.pk +
          " INTO :outId",
        binds
      );
      id = Number((result.outBinds?.outId as number[])?.[0] ?? id);
    } else if (isDelete) {
      await c.execute(
        "DELETE FROM " + def.table + " WHERE " + def.pk + "=:id",
        { id }
      );
    } else {
      const binds: Record<string, unknown> = { id };
      const sets = Object.keys(values)
        .filter(
          key =>
            !(
              def.fields.find(f => f.key === key)?.type === "date" &&
              values[key] === previous?.record[key]
            )
        )
        .map((key, i) => {
          binds["v" + i] = values[key];
          return (
            key +
            "=" +
            (def.fields.find(f => f.key === key)?.type === "date"
              ? "TO_DATE(:v" + i + ",'YYYY-MM-DD')"
              : ":v" + i)
          );
        });
      await c.execute(
        "UPDATE " +
          def.table +
          " SET " +
          sets.join(",") +
          " WHERE " +
          def.pk +
          "=:id",
        binds
      );
    }
    if (def.table === "SON_ACT" && input.action !== "insert") {
      if (
        await count(
          c,
          "SELECT COUNT(*) N FROM TRAIL_BALANCE WHERE TB_SON_NUM=:id AND (NVL(TB_SUM_DEPIT,0)<>0 OR NVL(TB_SUM_CREDIT,0)<>0 OR NVL(TB_DEPIT_BAL,0)<>0 OR NVL(TB_CREDIT_BAL,0)<>0)",
          { id }
        )
      )
        fail("الحساب مرتبط بميزان ذي أرصدة");
      if (isDelete)
        await c.execute("DELETE FROM TRAIL_BALANCE WHERE TB_SON_NUM=:id", {
          id,
        });
      else
        await c.execute(
          "UPDATE TRAIL_BALANCE SET TB_SON_NAME=:name,TB_ACT_TYPE=:type,TB_BAR_NUM=:bar,TB_MAIN_NUM=(SELECT AC_NUM FROM BRANSH_ACT WHERE BAR_NUM=:bar),TB_BAR_NAME=(SELECT AC_NAM FROM BRANSH_ACT WHERE BAR_NUM=:bar),TB_MAIN_NAME=(SELECT m.AC_NAM FROM MAIN_ACT m JOIN BRANSH_ACT b ON b.AC_NUM=m.AC_NUM WHERE b.BAR_NUM=:bar) WHERE TB_SON_NUM=:id",
          {
            id,
            name: values.AC_NAM,
            type: values.SON_TYPE,
            bar: values.BAR_NUM,
          }
        );
    }
    if (def.table === "CAR_OUT") {
      for (const ref of Array.from(
        new Set([previous?.record.CO_REF, values.CO_REF].filter(x => x != null))
      ))
        await c.execute(
          "UPDATE CAR_ENTRY e SET CE_STATUS=CASE WHEN EXISTS(SELECT 1 FROM CAR_OUT o WHERE o.CO_REF=e.CE_ID) THEN 1 ELSE 0 END WHERE CE_ID=:ref",
          { ref }
        );
    }
    await c.commit();
    return { id, action: input.action };
  } catch (error) {
    await c.rollback();
    if (error instanceof TRPCError) throw error;
    const n = (error as { errorNum?: number }).errorNum;
    if (n === 1) fail("الرقم مستخدم بالفعل", "CONFLICT");
    if (n === 54 || n === 60)
      fail("توجد عملية أخرى قيد التنفيذ؛ أعد المحاولة", "CONFLICT");
    if (n === 1950)
      fail("لا توجد حصة تخزين للجدول؛ يلزم إصلاح موقعه أو حصته قبل الحفظ");
    if (n === 2292) fail("لا يمكن حذف السجل لوجود بيانات مرتبطة");
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message:
        "لم تُحفظ العملية. تراجعت جميع تغييراتها؛ راجع صلاحية المشغلات والحقول.",
      cause: error,
    });
  }
}
