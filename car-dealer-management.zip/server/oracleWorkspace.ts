import { oracleConnection, actorFor } from "./oracleSession";
import oracledb from "oracledb";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { getOracleConfig } from "./oracle";
import { discoverOracleSchema, verifyLegacyMapping } from "./oracleValidation";
import {
  datasetKeys,
  oracleDatasets,
  oracleTableScreens,
  type OracleDataset,
  type OracleRow,
} from "../shared/oracleWorkspace";

export const datasetSql: Record<OracleDataset, string> = {
  mainAccounts:
    "SELECT AC_NUM ID, AC_NAM NAME, DE_CR NATURE, NOTE NOTES FROM MAIN_ACT",
  branchAccounts:
    "SELECT b.BAR_NUM ID, b.AC_NAM NAME, b.AC_NUM PARENT_ID, m.AC_NAM PARENT_NAME, b.DE_CR NATURE, b.NOTE NOTES FROM BRANSH_ACT b LEFT JOIN MAIN_ACT m ON m.AC_NUM=b.AC_NUM",
  subAccounts:
    "SELECT s.SON_NUM ID, s.AC_NAM NAME, s.BAR_NUM PARENT_ID, b.AC_NAM PARENT_NAME, s.SON_PHONE PHONE, s.SON_IQAMA IDENTITY, s.SON_ACTIVATE ACTIVE, s.SON_TYPE TYPE, s.NOTE NOTES FROM SON_ACT s LEFT JOIN BRANSH_ACT b ON b.BAR_NUM=s.BAR_NUM",
  accountDirectory:
    "SELECT m.AC_NUM ID, m.AC_NAM MAIN_NAME, b.BAR_NUM BRANCH_ID, b.AC_NAM BRANCH_NAME, s.SON_NUM SUB_ID, s.AC_NAM SUB_NAME FROM MAIN_ACT m LEFT JOIN BRANSH_ACT b ON b.AC_NUM=m.AC_NUM LEFT JOIN SON_ACT s ON s.BAR_NUM=b.BAR_NUM",
  costCenters: "SELECT CC_ID ID, CC_NAME NAME FROM CENTER_COST",
  inventory:
    "SELECT cp.CP_ID ID, cp.CP_TYPE CAR, cp.CP_MODEL MODEL, cp.CP_PANEL PLATE, cp.CP_HIKL VIN, cp.CP_COLOR COLOR, cp.CP_PURCH_PRICE PURCHASE_COST, cp.CP_STATUS STATUS, cp.CP_PRICE_OUT SALE_PRICE, cp.CP_INV_REF PURCHASE_INVOICE_ID, TO_CHAR(cp.CP_DATE_IN,'YYYY-MM-DD') \"DATE\", cp.CP_CAR_NOTE NOTES, p.PUI_BRANSH BRANCH, p.PUI_SUPPLIER SUPPLIER, (SELECT COUNT(*) FROM CAR_SALES_INV s WHERE s.CSI_CP_ID=cp.CP_ID) SOLD_LINES FROM CAR_PURCHASE cp LEFT JOIN PURCHASE_INVOICE p ON p.PUI_ID=cp.CP_INV_REF",
  purchases:
    "SELECT PUI_ID ID, TO_CHAR(PUI_DATE,'YYYY-MM-DD') \"DATE\", PUI_SUPPLIER SUPPLIER, BC_STORE_NAME STOCK_NAME, PUI_OWNER_NAME OWNER_NAME, PUI_TOTAL TOTAL, PUI_BRANSH BRANCH, PUI_STATUS STATUS, PUI_NOTE NOTES FROM PURCHASE_INVOICE",
  purchaseLines:
    "SELECT CP_ID ID, CP_TYPE CAR, CP_MODEL MODEL, CP_PANEL PLATE, CP_HIKL VIN, CP_PURCH_PRICE PURCHASE_COST, CP_STATUS STATUS FROM CAR_PURCHASE WHERE CP_INV_REF=:documentId",
  sales:
    "SELECT SI_ID ID, TO_CHAR(SI_DATE,'YYYY-MM-DD') \"DATE\", SI_CUSTOMER CUSTOMER, SI_PHONE PHONE, SI_TOTAL TOTAL, SI_VAT VAT, SI_COST_TOTAL COST, SI_BRANSH BRANCH, SI_POST_STATUS STATUS FROM SALES_INVOICE",
  salesLines:
    "SELECT CSI_ID ID, CSI_CP_ID PURCHASE_ID, CSI_TYPE CAR, CSI_MODEL MODEL, CSI_PANEL PLATE, CSI_HIKL VIN, CSI_SALES_PRICE PRICE, CSI_PURCH_PRICE COST FROM CAR_SALES_INV WHERE CSI_INV_REF=:documentId",
  customers:
    "SELECT SI_CUSTOMER CUSTOMER, SI_PHONE PHONE, COUNT(*) INVOICE_COUNT, SUM(SI_TOTAL) TOTAL, TO_CHAR(MAX(SI_DATE),'YYYY-MM-DD') LAST_DATE FROM SALES_INVOICE WHERE SI_CUSTOMER IS NOT NULL GROUP BY SI_CUSTOMER,SI_PHONE",
  suppliers:
    "SELECT PUI_SUPPLIER SUPPLIER, COUNT(*) INVOICE_COUNT, SUM(PUI_TOTAL) TOTAL, TO_CHAR(MAX(PUI_DATE),'YYYY-MM-DD') LAST_DATE FROM PURCHASE_INVOICE WHERE PUI_SUPPLIER IS NOT NULL GROUP BY PUI_SUPPLIER",
  contracts:
    "SELECT CS_ID ID, TO_CHAR(CS_DATE,'YYYY-MM-DD') \"DATE\", CS_SAL_NAME SELLER, CS_PURCH_NAME CUSTOMER, CS_CAR_TYPE CAR, CS_MODEL MODEL, CS_PANEL PLATE, CS_TOTAL_MOUNT TOTAL, CS_CASH_PAY PAID, CS_CASH_REMAIN REMAINING FROM CAR_SALES",
  expenses:
    "SELECT C_ID ID, TO_CHAR(C_DATE,'YYYY-MM-DD') \"DATE\", DC_NAM DEBIT_ACCOUNT, DD_NAM CREDIT_ACCOUNT, C_VC DEBIT, C_VD CREDIT, C_EXP NOTES, STATUS FROM C_ENT",
  receipts:
    "SELECT B_ID ID, TO_CHAR(B_DATE,'YYYY-MM-DD') \"DATE\", BC_NAM DEBIT_ACCOUNT, BD_NAM CREDIT_ACCOUNT, B_VC DEBIT, B_VD CREDIT, B_EXP NOTES FROM BB_ENT",
  journal:
    "SELECT A_ID ID, TO_CHAR(A_DATE,'YYYY-MM-DD') \"DATE\", AC_NAM DEBIT_ACCOUNT, AD_NAM CREDIT_ACCOUNT, A_VC DEBIT, A_VD CREDIT, A_EXP NOTES FROM A_ENT",
  ledger:
    "SELECT AL_ID ID, TO_CHAR(AL_DATE,'YYYY-MM-DD') \"DATE\", AL_ACC_NAME ACCOUNT, AL_DEPIT_MOUNT DEBIT, AL_CREDIT_MOUNT CREDIT, AL_DOC_ID DOCUMENT, AL_DOC_TYPE DOCUMENT_TYPE, AL_EXP NOTES FROM ACCOUNT_LEDGER",
  stock:
    "SELECT ST_ID ID, TO_CHAR(ST_DATE,'YYYY-MM-DD') \"DATE\", ST_INV_REF DOCUMENT, ST_TYPE CAR, ST_MODEL MODEL, ST_PANEL PLATE, ST_PRICE_IN PRICE_IN, ST_PRICE_OUT PRICE_OUT, ST_STATUS STATUS FROM STOCK_LEDGER",
  entries:
    "SELECT CE_ID ID, TO_CHAR(CE_DATE,'YYYY-MM-DD') \"DATE\", CE_NAME CAR, CE_MODEL MODEL, CE_PANEL PLATE, CE_SUPLIER SUPPLIER, CE_MOUNT AMOUNT, CE_STATUS STATUS FROM CAR_ENTRY",
  deliveries:
    "SELECT CO_ID ID, TO_CHAR(CO_DATE,'YYYY-MM-DD') \"DATE\", CO_REF ENTRY_ID, CO_NAME CAR, CO_MODEL MODEL, CO_PANEL PLATE, CO_CUSTOMER CUSTOMER, CO_MOUNT AMOUNT FROM CAR_OUT",
};

// Local preview is read-only, explicitly enabled and limited to loopback requests.
export function allowsLocalOracleRead(
  req: {
    socket?: { remoteAddress?: string };
    headers: {
      origin?: string;
      host?: string;
      "sec-fetch-site"?: string | string[];
    };
  },
  env = process.env
) {
  if (env.NODE_ENV === "production" || env.LOCAL_ORACLE_READONLY_UI !== "true")
    return false;
  if (
    !["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(
      req.socket?.remoteAddress ?? ""
    )
  )
    return false;
  if (req.headers["sec-fetch-site"] === "cross-site") return false;
  try {
    const host = new URL("http://" + (req.headers.host ?? "")).hostname;
    if (!["localhost", "127.0.0.1", "[::1]"].includes(host)) return false;
    if (
      req.headers.origin &&
      new URL(req.headers.origin).host !== req.headers.host
    )
      return false;
  } catch {
    return false;
  }
  return true;
}
const readProcedure = publicProcedure.use(async ({ ctx, next }) => {
  if (
    !ctx.user &&
    !allowsLocalOracleRead(ctx.req) &&
    !(await oracleConnection(c => actorFor(ctx.req, c)))
  )
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "يلزم تسجيل الدخول أو فتح وضع القراءة المحلي على نفس الجهاز",
    });
  return next();
});

async function withConnection<T>(
  run: (
    connection: Awaited<ReturnType<typeof oracledb.getConnection>>
  ) => Promise<T>
) {
  let connection:
    | Awaited<ReturnType<typeof oracledb.getConnection>>
    | undefined;
  try {
    connection = await oracledb.getConnection(getOracleConfig());
    return await run(connection);
  } catch (error) {
    if (error instanceof TRPCError) throw error;
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "تعذر قراءة Oracle. تحقق من الاتصال وصلاحية الجداول.",
      cause: error,
    });
  } finally {
    if (connection) await connection.close();
  }
}
export const tableInput = z
  .object({
    dataset: z.enum(datasetKeys),
    search: z.string().trim().max(120).default(""),
    page: z.number().int().min(1).max(100000).default(1),
    pageSize: z.number().int().min(8).max(100).default(25),
    documentId: z.number().int().positive().optional(),
    vehicleType: z.string().trim().max(200).optional(),
    model: z.string().trim().max(50).optional(),
    posting: z.enum(["posted", "unposted"]).optional(),
    inventorySort: z.enum(["newest", "costAsc", "costDesc"]).optional(),
    recordId: z.number().int().positive().optional(),
  })
  .superRefine((input, ctx) => {
    if (
      input.dataset !== "inventory" &&
      [
        input.vehicleType,
        input.model,
        input.posting,
        input.inventorySort,
        input.recordId,
      ].some(v => v !== undefined)
    )
      ctx.addIssue({
        code: "custom",
        message: "مرشحات السيارات متاحة للمخزون فقط",
      });
    if (
      ["salesLines", "purchaseLines"].includes(input.dataset) &&
      !input.documentId
    )
      ctx.addIssue({
        code: "custom",
        path: ["documentId"],
        message: "مرجع الفاتورة مطلوب",
      });
  });
export function buildTableQuery(input: z.infer<typeof tableInput>) {
  const columns = Object.keys(oracleDatasets[input.dataset].columns);
  const binds: Record<string, unknown> = {};
  if (["salesLines", "purchaseLines"].includes(input.dataset))
    binds.documentId = input.documentId;
  let condition = input.search
    ? " WHERE (" +
      columns
        .map(
          key =>
            'INSTR(UPPER(NVL(TO_CHAR(t."' + key + "\"),'')),UPPER(:search))>0"
        )
        .join(" OR ") +
      ")"
    : "";
  if (input.search) binds.search = input.search;
  const filters: string[] = [];
  if (input.dataset === "inventory") {
    for (const [field, column] of [
      ["vehicleType", "CAR"],
      ["model", "MODEL"],
      ["recordId", "ID"],
    ] as const)
      if (input[field] !== undefined && input[field] !== "") {
        filters.push('t."' + column + '"=:' + field);
        binds[field] = input[field];
      }
    if (input.posting) {
      filters.push('LOWER(TRIM(t."STATUS"))=:posting');
      binds.posting = input.posting;
    }
  }
  if (filters.length)
    condition += (condition ? " AND " : " WHERE ") + filters.join(" AND ");
  const from = " FROM (" + datasetSql[input.dataset] + ") t" + condition;
  const order =
    input.dataset === "inventory" &&
    input.inventorySort &&
    input.inventorySort !== "newest"
      ? 't."PURCHASE_COST" ' +
        (input.inventorySort === "costAsc" ? "ASC" : "DESC") +
        ' NULLS LAST,t."ID" DESC'
      : input.dataset === "accountDirectory"
        ? 't."ID" ASC, t."BRANCH_ID" ASC NULLS LAST, t."SUB_ID" ASC NULLS LAST'
        : columns.includes("ID")
          ? 't."ID" DESC'
          : input.dataset === "customers"
            ? 't."CUSTOMER" ASC, t."PHONE" ASC NULLS LAST'
            : 't."SUPPLIER" ASC';
  return {
    count: "SELECT COUNT(*) TOTAL" + from,
    rows:
      "SELECT t.*" +
      from +
      " ORDER BY " +
      order +
      " OFFSET :skip ROWS FETCH NEXT :take ROWS ONLY",
    binds,
  };
}
export const oracleWorkspaceRouter = router({
  mode: publicProcedure.query(() => ({
    provider: process.env.DATABASE_PROVIDER === "oracle" ? "oracle" : "mysql",
    readOnly: false,
  })),
  table: readProcedure.input(tableInput).query(({ input }) =>
    withConnection(async connection => {
      const query = buildTableQuery(input);
      const count = await connection.execute<{ TOTAL: number }>(
        query.count,
        query.binds,
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      const rows = await connection.execute<OracleRow>(
        query.rows,
        {
          ...query.binds,
          skip: (input.page - 1) * input.pageSize,
          take: input.pageSize,
        },
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      return {
        rows: rows.rows ?? [],
        total: Number(count.rows?.[0]?.TOTAL ?? 0),
        page: input.page,
        pageSize: input.pageSize,
      };
    })
  ),
  inventoryOptions: readProcedure.query(() =>
    withConnection(async connection => {
      const types = await connection.execute<{ VALUE: string }>(
        "SELECT DISTINCT CP_TYPE VALUE FROM CAR_PURCHASE WHERE CP_TYPE IS NOT NULL ORDER BY VALUE",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      const models = await connection.execute<{ VALUE: string }>(
        "SELECT DISTINCT CP_MODEL VALUE FROM CAR_PURCHASE WHERE CP_MODEL IS NOT NULL ORDER BY VALUE DESC",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      return {
        types: types.rows?.map(r => r.VALUE) ?? [],
        models: models.rows?.map(r => r.VALUE) ?? [],
      };
    })
  ),
  summary: readProcedure.query(() =>
    withConnection(async connection => {
      const result = await connection.execute<OracleRow>(
        "SELECT (SELECT COUNT(*) FROM CAR_PURCHASE) VEHICLES, (SELECT NVL(SUM(CP_PURCH_PRICE),0) FROM CAR_PURCHASE) PURCHASE_VALUE, (SELECT COUNT(*) FROM BB_ENT) RECEIPTS, (SELECT COUNT(*) FROM C_ENT) PAYOUTS, (SELECT COUNT(*) FROM MAIN_ACT) MAIN_ACCOUNTS, (SELECT COUNT(*) FROM USER_TRIGGERS WHERE STATUS='DISABLED') DISABLED_TRIGGERS, (SELECT COUNT(*) FROM PURCHASE_INVOICE) PURCHASES, (SELECT COUNT(*) FROM SALES_INVOICE) SALES, (SELECT COUNT(*) FROM CAR_SALES) CONTRACTS, (SELECT NVL(SUM(PUI_TOTAL),0) FROM PURCHASE_INVOICE) PURCHASE_TOTAL, (SELECT NVL(SUM(SI_TOTAL),0) FROM SALES_INVOICE) SALES_TOTAL FROM DUAL",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      const monthly = await connection.execute<OracleRow>(
        "SELECT TO_CHAR(SI_DATE,'YYYY-MM') MONTH, COUNT(*) INVOICES, SUM(SI_TOTAL) TOTAL FROM SALES_INVOICE WHERE SI_DATE IS NOT NULL GROUP BY TO_CHAR(SI_DATE,'YYYY-MM') ORDER BY MONTH DESC FETCH FIRST 12 ROWS ONLY",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      const states = await connection.execute<OracleRow>(
        "SELECT NVL(LOWER(TRIM(CP_STATUS)),'unknown') STATUS,COUNT(*) TOTAL FROM CAR_PURCHASE GROUP BY NVL(LOWER(TRIM(CP_STATUS)),'unknown') ORDER BY TOTAL DESC",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      return {
        totals: result.rows?.[0] ?? {},
        monthly: monthly.rows ?? [],
        states: states.rows ?? [],
      };
    })
  ),
  audit: readProcedure.query(async () => {
    const snapshot = await discoverOracleSchema();
    const objects = await withConnection(
      async connection =>
        (
          await connection.execute<{
            OBJECT_NAME: string;
            OBJECT_TYPE: string;
          }>(
            "SELECT OBJECT_NAME,OBJECT_TYPE FROM USER_OBJECTS WHERE STATUS='INVALID' ORDER BY OBJECT_TYPE,OBJECT_NAME",
            [],
            { outFormat: oracledb.OUT_FORMAT_OBJECT }
          )
        ).rows ?? []
    );
    return {
      snapshot,
      mapping: verifyLegacyMapping(snapshot),
      invalidObjects: objects,
      tableCoverage: snapshot.tables.map(table => ({
        table,
        screen: oracleTableScreens[table] ?? null,
      })),
    };
  }),
});
