declare module "oracledb" {
  export const OUT_FORMAT_OBJECT: number;
  export const BIND_OUT: number;
  export const NUMBER: number;
  export const CLOB: number;
  export const STRING: number;
  export type Connection = {
    execute<T = unknown>(
      sql: string,
      binds?: unknown[] | Record<string, unknown>,
      options?: {
        outFormat?: number;
        autoCommit?: boolean;
        fetchInfo?: Record<string, { type: number }>;
      }
    ): Promise<{
      rows?: T[];
      rowsAffected?: number;
      outBinds?: Record<string, unknown>;
    }>;
    commit(): Promise<void>;
    rollback(): Promise<void>;
    close(): Promise<void>;
  };
  export function getConnection(config: {
    user: string;
    password: string;
    connectString: string;
  }): Promise<Connection>;
  const oracledb: {
    getConnection: typeof getConnection;
    OUT_FORMAT_OBJECT: number;
    BIND_OUT: number;
    NUMBER: number;
    CLOB: number;
    STRING: number;
  };
  export default oracledb;
}
