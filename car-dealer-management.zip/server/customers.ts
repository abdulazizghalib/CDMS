import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { requireDb } from "./db";
import { customers } from "../drizzle/schema";

export const customerInput = z.object({
  name: z.string().min(1),
  phone: z.string().min(1),
  email: z.string().email().optional().or(z.literal("")),
  idNumber: z.string().optional(),
  address: z.string().optional(),
  notes: z.string().optional(),
});

export const customersRouter = router({
  list: protectedProcedure
    .input(z.object({
      search: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      const db = await requireDb();
      if (!db) return [];
      // In a real app, we would add search filters
      const results = await db.select().from(customers);
      return results;
    }),

  create: protectedProcedure
    .input(customerInput)
    .mutation(async ({ input }) => {
      const db = await requireDb();
      if (!db) throw new Error("Database not available");
      
      const [newCustomer] = await db.insert(customers).values({
        ...input,
        email: input.email || null,
      });
      return newCustomer;
    }),
});
