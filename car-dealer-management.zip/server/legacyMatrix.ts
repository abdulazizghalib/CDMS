export const legacyMatrix = {
  objects: [
    "CAR_ENTRY", "CAR_ENTRY_VIEW", "CAR_PURCHASE", "CAR_PURCHASE_VIEW", "CAR_SALES", "CAR_SALES_VIEW",
    "CAR_SALES_INV", "SALES", "SALES_DETAIL", "SALES_INVOICE", "SALES_INVOICE_DETAIL", "SALES_TOTAL_VIEW",
    "PURCHASE_INVOICE", "PURCHASE_INVOICE_DETAIL", "PURCHASE_LEDGER_VIEW", "PURCHASE_TO_STOCK_LEDGER",
    "CAR_OUT", "CAR_OUT_VIEW", "STOCK_LEDGER", "CAR_LEDGER", "CAR_SALES_TO_STOCK_LEDGER",
    "CENTER_COST", "COSTMAX", "EXP", "EXPN", "ACCOUNT_LEDGER", "SALES_COST_VIEW",
    "CASH_ACT", "CASHMAX", "PAYMENT", "BANKMAX", "CARTVIEW", "BUYVIEW", "USER_BRANSH", "USERS", "USERTYPE",
  ],
  triggerPatterns: ["_TRIGGER", "_BEFORE", "_PK", "_FK", "_SEQ"],
  sequences: ["CAR_SEQ", "SALES_SEQ", "PURCHASE_SEQ", "INVOICE_SEQ"],
  rules: [
    "car-lifecycle-traceability",
    "branch-scoped-access",
    "sale-requires-available-car",
    "profit-includes-preparation-cost",
    "invoice-linked-collections",
    "delivery-requires-contract-clearance",
  ],
} as const;

export type LegacyMatrix = typeof legacyMatrix;
