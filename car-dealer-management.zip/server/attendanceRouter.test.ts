﻿import { describe, it, expect, vi, beforeEach } from "vitest";
import type { TrpcContext } from "./_core/context";
vi.mock("oracledb", () => ({
  default: { getConnection: vi.fn(), OUT_FORMAT_OBJECT: 4002 },
}));
vi.mock("./oracle", () => ({
  getOracleConfig: () => ({
    user: "test",
    password: "test",
    connectString: "test",
  }),
}));
vi.mock("./attendance", () => ({
  attendanceSettings: vi.fn().mockResolvedValue({ shifts: [], employees: [] }),
  saveShift: vi.fn().mockResolvedValue({ id: 1 }),
  assignShift: vi.fn().mockResolvedValue({ ok: true }),
  myAttendance: vi.fn().mockResolvedValue({ shift: null }),
  checkIn: vi.fn().mockResolvedValue({ id: 1 }),
  checkOut: vi.fn().mockResolvedValue({ id: 1 }),
  attendanceReport: vi.fn().mockResolvedValue([]),
}));
import oracledb from "oracledb";
import { attendanceRouter } from "./attendanceRouter";
import { checkIn, attendanceReport } from "./attendance";
const shift = {
  name: "Shift",
  branch: "Branch",
  latitude: 24,
  longitude: 46,
  radius: 100,
  startTime: "07:00",
  endTime: "17:00",
  active: true,
};
const point = {
  latitude: 24,
  longitude: 46,
  accuracy: 5,
  capturedAt: "2026-10-05T04:00:00.000Z",
};
function caller(
  role: string,
  authenticated = true,
  origin = "http://localhost:3000"
) {
  const actor = {
    ID: 7,
    USERNAME: "employee",
    DISPLAY_NAME: "Employee",
    ROLE: role,
  };
  const c = {
    execute: vi.fn().mockResolvedValue({ rows: [actor] }),
    close: vi.fn(),
    commit: vi.fn(),
    rollback: vi.fn(),
  };
  vi.mocked(oracledb.getConnection).mockResolvedValue(c);
  const req = {
    headers: {
      host: "localhost:3000",
      origin,
      cookie: authenticated ? "dealer_oracle_session=" + "a".repeat(64) : "",
    },
    socket: { remoteAddress: "127.0.0.1" },
  };
  return attendanceRouter.createCaller({
    req,
    res: {},
    user: null,
  } as unknown as TrpcContext);
}
beforeEach(() => vi.clearAllMocks());
describe("attendance permissions", () => {
  it("requires authentication for employee attendance", async () => {
    await expect(caller("viewer", false).mine()).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
  });
  it.each(["viewer", "editor"])(
    "limits shift settings and assignments to admins (%s)",
    async role => {
      await expect(caller(role).saveShift(shift)).rejects.toMatchObject({
        code: "FORBIDDEN",
      });
      await expect(
        caller(role).assignShift({ shiftId: 1, employeeIds: [7] })
      ).rejects.toMatchObject({ code: "FORBIDDEN" });
    }
  );
  it("protects attendance reports from viewer accounts", async () => {
    await expect(
      caller("viewer").report({ date1: "2026-10-05", date2: "2026-10-05" })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(attendanceReport).not.toHaveBeenCalled();
  });
  it("records only the authenticated employee even if a different id is submitted", async () => {
    await caller("viewer").checkIn({
      ...point,
      employeeId: 999,
    } as typeof point);
    expect(checkIn).toHaveBeenCalledWith(
      expect.anything(),
      expect.objectContaining({ ID: 7 }),
      point
    );
  });
  it("rejects attendance submissions from other origins", async () => {
    await expect(
      caller("viewer", true, "https://other.example").checkOut(point)
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
