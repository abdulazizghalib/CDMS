import { router, publicProcedure } from "./_core/trpc";
import {
  oracleConnection,
  requireActor,
  requireSameOrigin,
} from "./oracleSession";
import {
  shiftInput,
  assignmentInput,
  checkInInput,
  attendanceReportInput,
} from "../shared/attendance";
import {
  attendanceSettings,
  saveShift,
  assignShift,
  myAttendance,
  checkIn,
  checkOut,
  attendanceReport,
} from "./attendance";
export const attendanceRouter = router({
  checkOut: publicProcedure.input(checkInInput).mutation(({ ctx, input }) => {
    requireSameOrigin(ctx.req);
    return oracleConnection(async c =>
      checkOut(
        c,
        await requireActor(ctx.req, c, ["admin", "editor", "viewer"]),
        input
      )
    );
  }),
  settings: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c, ["admin"]);
      return attendanceSettings(c);
    })
  ),
  saveShift: publicProcedure.input(shiftInput).mutation(({ ctx, input }) => {
    requireSameOrigin(ctx.req);
    return oracleConnection(async c =>
      saveShift(c, await requireActor(ctx.req, c, ["admin"]), input)
    );
  }),
  assignShift: publicProcedure
    .input(assignmentInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        assignShift(c, await requireActor(ctx.req, c, ["admin"]), input)
      );
    }),
  mine: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c =>
      myAttendance(
        c,
        await requireActor(ctx.req, c, ["admin", "editor", "viewer"])
      )
    )
  ),
  checkIn: publicProcedure.input(checkInInput).mutation(({ ctx, input }) => {
    requireSameOrigin(ctx.req);
    return oracleConnection(async c =>
      checkIn(
        c,
        await requireActor(ctx.req, c, ["admin", "editor", "viewer"]),
        input
      )
    );
  }),
  report: publicProcedure.input(attendanceReportInput).query(({ ctx, input }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c, ["admin", "editor"]);
      return attendanceReport(c, input);
    })
  ),
});
