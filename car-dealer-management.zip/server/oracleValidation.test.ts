import { describe, expect, it } from "vitest";
import { legacyMatrix } from "./legacyMatrix";
import { oracleRuntimeStatus, verifyLegacyMapping } from "./oracleValidation";

describe("Oracle validation flow", () => {
  it("verifies the complete legacy matrix without writing to Oracle", () => {
    const result = verifyLegacyMapping({
      tables: [...legacyMatrix.objects],
      views: [],
      columns: [],
      triggers: legacyMatrix.triggerPatterns.map((pattern) => `CAR${pattern}`),
      sequences: [...legacyMatrix.sequences],
      constraints: ["CAR_PK", "CAR_FK"],
      rules: [...legacyMatrix.rules],
    });
    expect(result.objects).toHaveLength(legacyMatrix.objects.length);
    expect(result.objects.every((item) => item.found)).toBe(true);
    expect(result.triggers.every((item) => item.found)).toBe(true);
    expect(result.sequences.every((item) => item.found)).toBe(true);
    expect(result.constraints.every((item) => item.found)).toBe(true);
    expect(result.rules.every((item) => item.found)).toBe(true);
    expect(result.missingObjects).toEqual([]);
    expect(result.missingTriggers).toEqual([]);
    expect(result.missingSequences).toEqual([]);
    expect(result.missingRules).toEqual([]);
  });

  it("returns a graceful disabled status for incomplete or unsafe production configuration", () => {
    expect(oracleRuntimeStatus("production")).toMatchObject({ enabled: false });
  });
});
