import { z } from "zod";
import oracledb, { type Connection } from "oracledb";
import { TRPCError } from "@trpc/server";
import { sha256, tagActor, type Actor } from "./oracleSession";
export const brandingInput = z.object({
  name: z.string().trim().min(2).max(100),
  logo: z.string().max(710000).nullable(),
});
export function validateLogo(logo: string | null) {
  if (logo === null) return;
  const match = logo.match(
    /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/
  );
  if (!match)
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "الشعار يجب أن يكون صورة PNG أو JPEG أو WebP",
    });
  const b = Buffer.from(match[2], "base64");
  const valid =
    match[1] === "png"
      ? b.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))
      : match[1] === "jpeg"
        ? b[0] === 255 && b[1] === 216 && b[2] === 255
        : b.toString("ascii", 0, 4) === "RIFF" &&
          b.toString("ascii", 8, 12) === "WEBP";
  if (!valid || b.length > 512 * 1024 || b.toString("base64") !== match[2])
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "صورة غير صحيحة أو حجمها يتجاوز 512 كيلوبايت",
    });
}
export async function getBranding(c: Connection) {
  const row = (
    await c.execute<{ NAME: string; LOGO_DATA: string | null }>(
      "SELECT NAME,LOGO_DATA FROM APP_BRANDING WHERE ID=1",
      [],
      {
        outFormat: oracledb.OUT_FORMAT_OBJECT,
        fetchInfo: { LOGO_DATA: { type: oracledb.STRING } },
      }
    )
  ).rows?.[0];
  return {
    name: row?.NAME ?? "إدارة معرض السيارات",
    logo: row?.LOGO_DATA ?? null,
  };
}
export async function saveBranding(
  c: Connection,
  actor: Actor,
  input: z.infer<typeof brandingInput>
) {
  validateLogo(input.logo);
  try {
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    const before = await getBranding(c);
    await tagActor(c, actor);
    await c.execute(
      "UPDATE APP_BRANDING SET NAME=:name,LOGO_DATA=:logo WHERE ID=1",
      { name: input.name, logo: { val: input.logo, type: oracledb.CLOB } }
    );
    const snapshot = (v: typeof before) =>
      JSON.stringify({
        name: v.name,
        logoHash: v.logo ? sha256(v.logo) : null,
      });
    await c.execute(
      "INSERT INTO APP_AUDIT_LOG(ACTOR_ID,ACTOR_NAME,DB_USER,SOURCE,ACTION,TABLE_NAME,RECORD_ID,BEFORE_JSON,AFTER_JSON,TRANSACTION_ID) VALUES(:actor,:name,USER,'DEALER_WEB','UPDATE','APP_BRANDING','1',:before,:after,DBMS_TRANSACTION.LOCAL_TRANSACTION_ID)",
      {
        actor: String(actor.ID),
        name: actor.DISPLAY_NAME,
        before: snapshot(before),
        after: snapshot(input),
      }
    );
    await c.commit();
    return { ok: true };
  } catch (error) {
    await c.rollback();
    throw error;
  }
}
export async function getInvoiceForPrint(
  c: Connection,
  kind: "sales" | "purchases",
  id: number
) {
  const sales = kind === "sales";
  const sql = sales
    ? "SELECT SI_ID ID,TO_CHAR(SI_DATE,'YYYY-MM-DD') DOC_DATE,SI_CUSTOMER PARTY,SI_PHONE PHONE,SI_BRANSH BRANCH,SI_NOTE NOTES,SI_TOTAL TOTAL,SI_VAT VAT,SI_USER_ENTERED ENTERED_BY FROM SALES_INVOICE WHERE SI_ID=:id"
    : "SELECT PUI_ID ID,TO_CHAR(PUI_DATE,'YYYY-MM-DD') DOC_DATE,PUI_SUPPLIER PARTY,BC_STORE_NAME STOCK_NAME,PUI_OWNER_NAME OWNER_NAME,CAST(NULL AS VARCHAR2(100)) PHONE,PUI_BRANSH BRANCH,PUI_NOTE NOTES,PUI_TOTAL TOTAL,CAST(NULL AS NUMBER) VAT,PUI_ENTERED_BY ENTERED_BY FROM PURCHASE_INVOICE WHERE PUI_ID=:id";
  const invoice = (
    await c.execute<{
      ID: number;
      DOC_DATE: string | null;
      PARTY: string | null;
      STOCK_NAME?: string | null;
      OWNER_NAME?: string | null;
      PHONE: string | null;
      BRANCH: string | null;
      NOTES: string | null;
      TOTAL: number | null;
      VAT: number | null;
      ENTERED_BY: string | null;
    }>(sql, { id }, { outFormat: oracledb.OUT_FORMAT_OBJECT })
  ).rows?.[0];
  if (!invoice)
    throw new TRPCError({ code: "NOT_FOUND", message: "الفاتورة غير موجودة" });
  const query = sales
    ? "SELECT CSI_TYPE CAR,CSI_MODEL MODEL,CSI_COLOR COLOR,CSI_PANEL PLATE,CSI_HIKL VIN,CSI_SALES_PRICE PRICE,CSI_CAR_NOTE NOTES FROM CAR_SALES_INV WHERE CSI_INV_REF=:id ORDER BY CSI_ID"
    : "SELECT CP_TYPE CAR,CP_MODEL MODEL,CP_COLOR COLOR,CP_PANEL PLATE,CP_HIKL VIN,CP_PURCH_PRICE PRICE,CP_CAR_NOTE NOTES FROM CAR_PURCHASE WHERE CP_INV_REF=:id ORDER BY CP_ID";
  const lines =
    (
      await c.execute<{
        CAR: string | null;
        MODEL: string | null;
        COLOR: string | null;
        PLATE: string | null;
        VIN: string | null;
        PRICE: number | null;
        NOTES: string | null;
      }>(query, { id }, { outFormat: oracledb.OUT_FORMAT_OBJECT })
    ).rows ?? [];
  return { kind, invoice, lines, branding: await getBranding(c) };
}
