import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { requireDb } from "./db";
import { sales, vehicles } from "../drizzle/schema";
import { eq } from "drizzle-orm";

export const saleInput = z.object({
  invoiceNumber: z.string().min(1),
  vehicleId: z.number(),
  customerId: z.number(),
  saleDate: z.date().optional(),
  salePrice: z.number().min(0),
  discount: z.number().default(0),
  tax: z.number().default(0),
  paymentStatus: z.enum(["unpaid", "partial", "paid"]),
  paymentMethod: z.enum(["cash", "bank_transfer", "finance", "check"]),
  branch: z.string().default("الفرع الرئيسي"),
  notes: z.string().optional(),
});

export const salesRouter = router({
  list: protectedProcedure
    .input(z.object({
      branch: z.string().optional(),
      status: z.string().optional(),
    }).optional())
    .query(async () => {
      const db = await requireDb();
      if (!db) return [];
      const results = await db.select().from(sales);
      return results;
    }),

  create: protectedProcedure
    .input(saleInput)
    .mutation(async ({ input, ctx }) => {
      const db = await requireDb();
      if (!db) throw new Error("Database not available");
      
      const totalAmount = input.salePrice - input.discount + input.tax;
      
      return await db.transaction(async (tx) => {
        const [newSale] = await tx.insert(sales).values({
          ...input,
          totalAmount,
          createdBy: ctx.user.id,
          saleDate: input.saleDate ?? new Date(),
        });

        await tx.update(vehicles)
          .set({ status: "sold" })
          .where(eq(vehicles.id, input.vehicleId));

        return newSale;
      });
    }),
});
