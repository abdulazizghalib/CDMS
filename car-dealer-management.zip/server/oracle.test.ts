import { describe, expect, it } from "vitest";
import { checkOracleConnection, validateOracleTarget } from "./oracle";

describe("Oracle connectivity", () => {
  it.skipIf(process.env.RUN_ORACLE_CONNECTIVITY_TEST !== "true")("can run a lightweight DUAL query when Oracle credentials are configured", async () => {
    if (!process.env.ORACLE_HOST || !process.env.ORACLE_SERVICE_NAME || !process.env.ORACLE_USER || !process.env.ORACLE_PASSWORD) {
      throw new Error("Oracle secrets are required for this connectivity test");
    }
    const dbTime = await checkOracleConnection();
    expect(dbTime).toMatch(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/);
  }, 20_000);

  it("rejects localhost targets in production but allows local development", () => {
    expect(() => validateOracleTarget("127.0.0.1", "production")).toThrow(/not allowed/);
    expect(validateOracleTarget("127.0.0.1", "development")).toBe("127.0.0.1");
  });
});
