import oracledb from "oracledb";
import { getOracleConfig } from "./oracle";
import { legacyMatrix } from "./legacyMatrix";

export const legacyMappingTargets = legacyMatrix.objects;
export const legacyTriggerTargets = legacyMatrix.triggerPatterns;

export type OracleSchemaSnapshot = {
  tables: string[];
  views: string[];
  triggers: string[];
  sequences: string[];
  constraints: string[];
  columns: string[];
  rules?: string[];
  triggerDetails?: { TRIGGER_NAME: string; TABLE_NAME: string; STATUS: string; OBJECT_STATUS: string; TRIGGER_TYPE: string; TRIGGERING_EVENT: string }[];
  triggerErrors?: { NAME: string; LINE: number; POSITION: number; TEXT: string }[];
  constraintDetails?: { CONSTRAINT_NAME: string; TABLE_NAME: string; CONSTRAINT_TYPE: string; STATUS: string; R_CONSTRAINT_NAME: string | null }[];
};

export function oracleRuntimeStatus(runtime = process.env.NODE_ENV || "development") {
  try {
    getOracleConfig(runtime);
    return { enabled: true, reason: "إعدادات Oracle مكتملة؛ يلزم فحص الاتصال" } as const;
  } catch {
    return { enabled: false, reason: "إعدادات Oracle غير مكتملة أو وجهة الاتصال غير مسموحة" } as const;
  }
}

export function verifyLegacyMapping(snapshot: OracleSchemaSnapshot) {
  const objects = new Set([...snapshot.tables, ...snapshot.views].map((name) => name.toUpperCase()));
  const triggerNames = new Set(snapshot.triggers.map((name) => name.toUpperCase()));
  const sequenceNames = new Set(snapshot.sequences.map((name) => name.toUpperCase()));
  const constraints = new Set(snapshot.constraints.map((name) => name.toUpperCase()));
  const rules = new Set(snapshot.rules ?? []);
  const triggerCoverage = legacyMatrix.triggerPatterns.map((pattern) => ({
    target: pattern,
    found: Array.from(triggerNames).some((name) => name.endsWith(pattern)),
  }));
  const ruleCoverage = legacyMatrix.rules.map((rule) => ({ target: rule, found: rules.has(rule) }));
  const sequenceCoverage = legacyMatrix.sequences.map((sequence) => ({ target: sequence, found: sequenceNames.has(sequence) }));
  return {
    unhealthyTriggers: (snapshot.triggerDetails ?? []).filter(t => t.STATUS !== "ENABLED" || t.OBJECT_STATUS !== "VALID"),
    triggerErrors: snapshot.triggerErrors ?? [],
    triggerHealthVerified: snapshot.triggerDetails !== undefined && snapshot.triggerErrors !== undefined,
    objects: legacyMatrix.objects.map((target) => ({ target, found: objects.has(target) })),
    triggers: triggerCoverage,
    sequences: sequenceCoverage,
    constraints: [
      { target: "PRIMARY_KEYS", found: snapshot.constraintDetails ? snapshot.constraintDetails.some(c => c.CONSTRAINT_TYPE === "P" && c.STATUS === "ENABLED") : Array.from(constraints).some((name) => name.includes("PK")) },
      { target: "FOREIGN_KEYS", found: snapshot.constraintDetails ? snapshot.constraintDetails.some(c => c.CONSTRAINT_TYPE === "R" && c.STATUS === "ENABLED") : Array.from(constraints).some((name) => name.includes("FK")) },
    ],
    rules: ruleCoverage,
    missingObjects: legacyMatrix.objects.filter((target) => !objects.has(target)),
    missingTriggers: triggerCoverage.filter((item) => !item.found).map((item) => item.target),
    missingSequences: sequenceCoverage.filter((item) => !item.found).map((item) => item.target),
    missingRules: ruleCoverage.filter((item) => !item.found).map((item) => item.target),
  };
}

export async function discoverOracleSchema(): Promise<OracleSchemaSnapshot> {
  const connection = await oracledb.getConnection(getOracleConfig());
  try {
    const [tables, views, columns, triggers, sequences, constraints, triggerErrors] = await Promise.all([
      connection.execute<{ TABLE_NAME: string }>("SELECT TABLE_NAME FROM USER_TABLES ORDER BY TABLE_NAME", [], { outFormat: oracledb.OUT_FORMAT_OBJECT }),
      connection.execute<{ VIEW_NAME: string }>("SELECT VIEW_NAME FROM USER_VIEWS ORDER BY VIEW_NAME", [], { outFormat: oracledb.OUT_FORMAT_OBJECT }),
      connection.execute<{ TABLE_NAME: string; COLUMN_NAME: string }>("SELECT TABLE_NAME, COLUMN_NAME FROM USER_TAB_COLUMNS ORDER BY TABLE_NAME, COLUMN_ID", [], { outFormat: oracledb.OUT_FORMAT_OBJECT }),
      connection.execute<NonNullable<OracleSchemaSnapshot["triggerDetails"]>[number]>("SELECT t.TRIGGER_NAME, t.TABLE_NAME, t.STATUS, o.STATUS AS OBJECT_STATUS, t.TRIGGER_TYPE, t.TRIGGERING_EVENT FROM USER_TRIGGERS t LEFT JOIN USER_OBJECTS o ON o.OBJECT_NAME = t.TRIGGER_NAME AND o.OBJECT_TYPE = 'TRIGGER' ORDER BY t.TABLE_NAME, t.TRIGGER_NAME", [], { outFormat: oracledb.OUT_FORMAT_OBJECT }),
      connection.execute<{ SEQUENCE_NAME: string }>("SELECT SEQUENCE_NAME FROM USER_SEQUENCES ORDER BY SEQUENCE_NAME", [], { outFormat: oracledb.OUT_FORMAT_OBJECT }),
      connection.execute<NonNullable<OracleSchemaSnapshot["constraintDetails"]>[number]>("SELECT CONSTRAINT_NAME, TABLE_NAME, CONSTRAINT_TYPE, STATUS, R_CONSTRAINT_NAME FROM USER_CONSTRAINTS ORDER BY TABLE_NAME, CONSTRAINT_NAME", [], { outFormat: oracledb.OUT_FORMAT_OBJECT }),
      connection.execute<NonNullable<OracleSchemaSnapshot["triggerErrors"]>[number]>("SELECT NAME, LINE, POSITION, TEXT FROM USER_ERRORS WHERE TYPE = 'TRIGGER' AND ATTRIBUTE = 'ERROR' ORDER BY NAME, SEQUENCE", [], { outFormat: oracledb.OUT_FORMAT_OBJECT }),
    ]);
    return {
      triggerDetails: triggers.rows ?? [],
      triggerErrors: triggerErrors.rows ?? [],
      constraintDetails: constraints.rows ?? [],
      tables: (tables.rows ?? []).map((row) => row.TABLE_NAME),
      views: (views.rows ?? []).map((row) => row.VIEW_NAME),
      columns: (columns.rows ?? []).map((row) => `${row.TABLE_NAME}.${row.COLUMN_NAME}`),
      triggers: (triggers.rows ?? []).map((row) => row.TRIGGER_NAME),
      sequences: (sequences.rows ?? []).map((row) => row.SEQUENCE_NAME),
      constraints: (constraints.rows ?? []).map((row) => row.CONSTRAINT_NAME),
    };
  } finally {
    await connection.close();
  }
}
