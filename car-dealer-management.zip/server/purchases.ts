import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { requireDb } from "./db";
import { purchaseInvoices, carPurchases, vehicles, type InsertPurchaseInvoice, type InsertCarPurchase } from "../drizzle/schema";
import { protectedProcedure, router } from "./_core/trpc";

export const purchaseInput = z.object({
  invoiceNumber: z.string().min(1),
  supplierName: z.string().trim().min(2, "اسم المورد مطلوب").max(160),
  purchaseDate: z.coerce.date(),
  branchName: z.string().trim().min(2).max(120),
  paymentStatus: z.enum(["unpaid", "partial", "paid"]),
  notes: z.string().trim().max(1000).optional().or(z.literal("")),
  // Vehicle details (currently supporting one vehicle per invoice for simplicity in this step)
  vehicleName: z.string().trim().min(2, "اسم السيارة مطلوب").max(160),
  vin: z.string().trim().max(64).optional().or(z.literal("")),
  vehicleYear: z.coerce.number().int().min(1900).max(2100),
  purchaseCost: z.coerce.number().int().nonnegative(),
  preparationCost: z.coerce.number().int().nonnegative().default(0),
  transportCost: z.coerce.number().int().nonnegative().default(0),
  registrationCost: z.coerce.number().int().nonnegative().default(0),
  status: z.enum(["received", "preparing", "ready", "cancelled"]),
});

export type PurchaseInput = z.infer<typeof purchaseInput>;

export function calculatePurchaseTotal(input: Pick<PurchaseInput, "purchaseCost" | "preparationCost" | "transportCost" | "registrationCost">) {
  return input.purchaseCost + input.preparationCost + input.transportCost + input.registrationCost;
}

export const purchasesRouter = router({
  list: protectedProcedure.query(async () => {
    const db = await requireDb();
    if (!db) return [];
    // Join invoice with its car purchases
    const results = await db.select().from(purchaseInvoices).orderBy(desc(purchaseInvoices.createdAt));
    return results;
  }),

  create: protectedProcedure.input(purchaseInput).mutation(async ({ input, ctx }) => {
    const totalVehicleCost = calculatePurchaseTotal(input);
    const db = await requireDb();

    if (!db) throw new Error("Database not available");

    return await db.transaction(async (tx) => {
      // 1. Create Invoice (Master)
      const invoiceValues: InsertPurchaseInvoice = {
        createdBy: ctx.user.id,
        invoiceNumber: input.invoiceNumber,
        supplierName: input.supplierName,
        purchaseDate: input.purchaseDate,
        totalAmount: totalVehicleCost,
        paymentStatus: input.paymentStatus,
        branchName: input.branchName,
        notes: input.notes || null,
      };

      const [invoiceResult] = await tx.insert(purchaseInvoices).values(invoiceValues);
      const invoiceId = invoiceResult.insertId;

      // 2. Create Car Purchase (Detail - CP_INV_REF -> invoiceId)
      const carPurchaseValues: InsertCarPurchase = {
        invoiceId,
        vehicleName: input.vehicleName,
        vin: input.vin || null,
        vehicleYear: input.vehicleYear,
        purchaseCost: input.purchaseCost,
        preparationCost: input.preparationCost,
        transportCost: input.transportCost,
        registrationCost: input.registrationCost,
        totalVehicleCost,
        status: input.status,
      };

      await tx.insert(carPurchases).values(carPurchaseValues);
      
      // 3. Create Vehicle in inventory
      const nameParts = input.vehicleName.split(" ");
      const make = nameParts[0];
      const model = nameParts.slice(1).join(" ") || "طراز غير محدد";

      await tx.insert(vehicles).values({
        vin: input.vin || null,
        make,
        model,
        year: input.vehicleYear,
        status: input.status === "ready" ? "available" : "maintenance",
        branch: input.branchName,
        purchasePrice: input.purchaseCost,
        askingPrice: Math.round(totalVehicleCost * 1.15),
      });

      return { success: true, invoiceId };
    });
  }),
});
