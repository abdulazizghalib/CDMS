import { afterEach, describe, expect, it, vi } from "vitest";
import { oracleRuntimeStatus, verifyLegacyMapping } from "./oracleValidation";
afterEach(() => vi.unstubAllEnvs());
describe("Oracle audit accuracy",()=>{
 it("uses LOCAL_ORACLE configuration in development",()=>{
 for(const [key,value] of Object.entries({LOCAL_ORACLE_HOST:"127.0.0.1",LOCAL_ORACLE_SERVICE_NAME:"ORCL",LOCAL_ORACLE_USER:"test",LOCAL_ORACLE_PASSWORD:"test-only",ORACLE_HOST:""})) vi.stubEnv(key,value);
 expect(oracleRuntimeStatus("development").enabled).toBe(true);
 });
 it("flags disabled and invalid triggers and uses constraint types",()=>{
 const result=verifyLegacyMapping({tables:[],views:[],columns:[],triggers:["A","B","C"],sequences:[],constraints:["SYS_C1","SYS_C2"],constraintDetails:[{CONSTRAINT_NAME:"SYS_C1",TABLE_NAME:"CAR",CONSTRAINT_TYPE:"P",STATUS:"ENABLED",R_CONSTRAINT_NAME:null},{CONSTRAINT_NAME:"SYS_C2",TABLE_NAME:"CAR",CONSTRAINT_TYPE:"R",STATUS:"ENABLED",R_CONSTRAINT_NAME:"SYS_C1"}],triggerDetails:[{TRIGGER_NAME:"A",TABLE_NAME:"CAR",STATUS:"ENABLED",OBJECT_STATUS:"VALID",TRIGGER_TYPE:"BEFORE EACH ROW",TRIGGERING_EVENT:"INSERT"},{TRIGGER_NAME:"B",TABLE_NAME:"CAR",STATUS:"DISABLED",OBJECT_STATUS:"VALID",TRIGGER_TYPE:"BEFORE EACH ROW",TRIGGERING_EVENT:"INSERT"},{TRIGGER_NAME:"C",TABLE_NAME:"CAR",STATUS:"ENABLED",OBJECT_STATUS:"INVALID",TRIGGER_TYPE:"BEFORE EACH ROW",TRIGGERING_EVENT:"INSERT"}],triggerErrors:[{NAME:"C",LINE:3,POSITION:1,TEXT:"compile error"}]});
 expect(result.unhealthyTriggers.map(t=>t.TRIGGER_NAME)).toEqual(["B","C"]);
 expect(result.constraints.every(c=>c.found)).toBe(true);
 expect(result.triggerErrors).toHaveLength(1);
 expect(result.triggerHealthVerified).toBe(true);
 });
});
