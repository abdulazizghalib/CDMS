import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

const context = {
  user: undefined,
  req: {} as TrpcContext["req"],
  res: {} as TrpcContext["res"],
} as TrpcContext;

describe("oracle router", () => {
  it("returns a safe status response when Oracle is unavailable", async () => {
    const result = await appRouter.createCaller(context).oracle.status();
    expect(result).toHaveProperty("enabled");
    expect(result).toHaveProperty("reason");
  });
});
