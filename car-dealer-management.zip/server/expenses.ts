import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { requireDb } from "./db";
import { expenses } from "../drizzle/schema";

export const expenseInput = z.object({
  title: z.string().min(1),
  amount: z.number().min(0),
  category: z.enum(["rent", "utilities", "salaries", "marketing", "maintenance", "other"]),
  expenseDate: z.date().optional(),
  branch: z.string().default("الفرع الرئيسي"),
  notes: z.string().optional(),
});

export const expensesRouter = router({
  list: protectedProcedure
    .input(z.object({
      branch: z.string().optional(),
      category: z.string().optional(),
    }).optional())
    .query(async () => {
      const db = await requireDb();
      if (!db) return [];
      const results = await db.select().from(expenses);
      return results;
    }),

  create: protectedProcedure
    .input(expenseInput)
    .mutation(async ({ input }) => {
      const db = await requireDb();
      if (!db) throw new Error("Database not available");
      
      const [newExpense] = await db.insert(expenses).values({
        ...input,
        expenseDate: input.expenseDate ?? new Date(),
      });
      return newExpense;
    }),
});
