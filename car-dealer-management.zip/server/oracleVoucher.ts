﻿import oracledb, { type Connection } from "oracledb";
import { TRPCError } from "@trpc/server";
import type { z } from "zod";
import { voucherInput } from "../shared/oracleVoucher";
import { tagActor, type Actor } from "./oracleSession";
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
export const voucherDefinitions = {
  receipts: {
    table: "BB_ENT",
    prefix: "B",
    creditPrefix: "BD",
    debitPrefix: "BC",
    creditName: "BD_NAM",
    debitName: "BC_NAM",
    actor: "USER_ENTERED",
    source: "سند قبض",
    docType: 3,
    yomiaType: 1,
  },
  expenses: {
    table: "C_ENT",
    prefix: "C",
    creditPrefix: "CD",
    debitPrefix: "CC",
    creditName: "DD_NAM",
    debitName: "DC_NAM",
    actor: "USER_ENTERED",
    source: "سند صرف",
    docType: 4,
    yomiaType: 2,
  },
  journal: {
    table: "A_ENT",
    prefix: "A",
    creditPrefix: "AD",
    debitPrefix: "AC",
    creditName: "AD_NAM",
    debitName: "AC_NAM",
    actor: "A_USER_ENTERED",
    source: "سند قيد",
    docType: 6,
    yomiaType: 0,
  },
} as const;
export async function voucherAccounts(c: Connection) {
  return (
    (
      await c.execute<{
        ID: number;
        NAME: string;
        BAR_NUM: number;
        MAIN_NUM: number;
      }>(
        "SELECT s.SON_NUM ID,s.AC_NAM NAME,s.BAR_NUM,b.AC_NUM MAIN_NUM FROM SON_ACT s JOIN BRANSH_ACT b ON b.BAR_NUM=s.BAR_NUM JOIN MAIN_ACT m ON m.AC_NUM=b.AC_NUM ORDER BY s.SON_NUM",
        [],
        o
      )
    ).rows ?? []
  );
}
function reject(message: string): never {
  throw new TRPCError({ code: "BAD_REQUEST", message });
}
export async function createVoucher(
  c: Connection,
  actor: Actor,
  raw: z.infer<typeof voucherInput>
) {
  const input = voucherInput.parse(raw),
    d = voucherDefinitions[input.kind];
  if (Buffer.byteLength(input.notes, "utf8") > 400)
    reject("البيان أطول من سعة الحقل؛ اختصره");
  try {
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    await c.execute(
      `LOCK TABLE ${d.table},ACCOUNT_LEDGER,YOMIA_LEDGER,TRAIL_BALANCE,SON_ACT,BRANSH_ACT,MAIN_ACT IN EXCLUSIVE MODE NOWAIT`
    );
    const required = [
      "APP_AUD_" + d.table,
      "APP_AUD_ACCOUNT_LEDGER",
      "APP_AUD_TRAIL_BALANCE",
      d.table + "_TO_ACCOUNT_LEDGER",
      ...(d.yomiaType
        ? ["APP_AUD_YOMIA_LEDGER", d.table + "_TO_YOMIA_LEDGER"]
        : []),
    ];
    const binds = Object.fromEntries(required.map((v, i) => ["t" + i, v]));
    const ready = (
      await c.execute<{ N: number }>(
        `SELECT COUNT(*) N FROM USER_TRIGGERS t JOIN USER_OBJECTS o ON o.OBJECT_NAME=t.TRIGGER_NAME AND o.OBJECT_TYPE='TRIGGER' WHERE t.TRIGGER_NAME IN (${required.map((_, i) => ":t" + i).join(",")}) AND t.STATUS='ENABLED' AND o.STATUS='VALID'`,
        binds,
        o
      )
    ).rows?.[0]?.N;
    if (ready !== required.length)
      reject("مشغلات السند والترحيل وسجل التدقيق غير جاهزة");
    const accounts = await voucherAccounts(c),
      debit = accounts.find(a => a.ID === input.debitAccount),
      credit = accounts.find(a => a.ID === input.creditAccount);
    if (!debit || !credit)
      reject("اختر حسابين صحيحين من المستوى الثالث مرتبطين بدليل الحسابات");
    const limit = input.kind === "journal" ? 250 : 200;
    if (
      [debit.NAME, credit.NAME].some(
        n => !n || Buffer.byteLength(n, "utf8") > limit
      )
    )
      reject("اسم الحساب لا يناسب سعة السند");
    await tagActor(c, actor);
    const keys = [
      d.prefix + "_ID",
      d.prefix + "_DATE",
      d.prefix + "_VD",
      d.prefix + "_VC",
      d.creditPrefix + "_NUM",
      d.debitPrefix + "_NUM",
      d.creditName,
      d.debitName,
      d.creditPrefix + "_BAR_NUM",
      d.creditPrefix + "_MAIN_NUM",
      d.debitPrefix + "_BAR_NUM",
      d.debitPrefix + "_MAIN_NUM",
      d.prefix + "_EXP",
      "STATUS",
      d.actor,
    ];
    // Legacy *_D fields generate credits; *_C fields generate debits. Preserve that mapping.
    const result = await c.execute(
      `INSERT INTO ${d.table}(${keys.join(",")}) VALUES((SELECT NVL(MAX(${d.prefix}_ID),0)+1 FROM ${d.table}),TO_DATE(:dateValue,'YYYY-MM-DD'),:amount,:amount,:creditId,:debitId,:creditName,:debitName,:creditBar,:creditMain,:debitBar,:debitMain,:notes,:source,:actor) RETURNING ${d.prefix}_ID INTO :id`,
      {
        dateValue: input.date,
        amount: input.amount,
        creditId: credit.ID,
        debitId: debit.ID,
        creditName: credit.NAME,
        debitName: debit.NAME,
        creditBar: credit.BAR_NUM,
        creditMain: credit.MAIN_NUM,
        debitBar: debit.BAR_NUM,
        debitMain: debit.MAIN_NUM,
        notes: input.notes,
        source: d.source,
        actor: actor.USERNAME,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
      }
    );
    const id = Number((result.outBinds as { id: number[] }).id[0]);
    const rows =
      (
        await c.execute<{
          AL_ACC_NO: number;
          AL_DEPIT_MOUNT: number;
          AL_CREDIT_MOUNT: number;
          AL_BAR_NUM: number;
          AL_MAIN_NUM: number;
        }>(
          "SELECT AL_ACC_NO,AL_DEPIT_MOUNT,AL_CREDIT_MOUNT,AL_BAR_NUM,AL_MAIN_NUM FROM ACCOUNT_LEDGER WHERE AL_DOC_TYPE=:type AND AL_DOC_ID=:id",
          { type: d.docType, id },
          o
        )
      ).rows ?? [];
    const cents = (n: number) => Math.round(Number(n ?? 0) * 100),
      amount = cents(input.amount);
    if (
      rows.length !== 2 ||
      !rows.some(
        r =>
          r.AL_ACC_NO === debit.ID &&
          cents(r.AL_DEPIT_MOUNT) === amount &&
          cents(r.AL_CREDIT_MOUNT) === 0 &&
          r.AL_BAR_NUM === debit.BAR_NUM &&
          r.AL_MAIN_NUM === debit.MAIN_NUM
      ) ||
      !rows.some(
        r =>
          r.AL_ACC_NO === credit.ID &&
          cents(r.AL_CREDIT_MOUNT) === amount &&
          cents(r.AL_DEPIT_MOUNT) === 0 &&
          r.AL_BAR_NUM === credit.BAR_NUM &&
          r.AL_MAIN_NUM === credit.MAIN_NUM
      )
    )
      reject("تعذر التحقق من توازن وترحيل السند؛ لم تُحفظ العملية");
    if (d.yomiaType) {
      const n = (
        await c.execute<{ N: number }>(
          "SELECT COUNT(*) N FROM YOMIA_LEDGER WHERE YL_DOC_TYPE=:type AND YL_SID=:id",
          { type: d.yomiaType, id },
          o
        )
      ).rows?.[0]?.N;
      if (n !== 1) reject("لم يتم ترحيل السند إلى سجل اليومية");
    }
    await c.commit();
    return { id };
  } catch (e) {
    await c.rollback();
    throw e;
  }
}
