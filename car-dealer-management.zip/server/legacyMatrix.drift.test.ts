import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { legacyMatrix } from "./legacyMatrix";

const markdown = readFileSync(new URL("./legacyMatrix.md", import.meta.url), "utf8");

function readSection(title: string) {
  const match = markdown.match(new RegExp(`## ${title}\\n\\n([\\s\\S]*?)(?=\\n## |$)`));
  if (!match) throw new Error(`Missing matrix section: ${title}`);
  return match[1]
    .replace(/[.\s]+$/, "")
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean)
    .sort();
}

function normalized(values: readonly string[]) {
  return [...values].sort();
}

describe("legacy matrix documentation", () => {
  it("matches source and generated documentation bidirectionally", () => {
    expect(readSection("Objects")).toEqual(normalized(legacyMatrix.objects));
    expect(readSection("Trigger families")).toEqual(normalized(legacyMatrix.triggerPatterns));
    expect(readSection("Sequences")).toEqual(normalized(legacyMatrix.sequences));
    expect(readSection("Preserved business rules")).toEqual(normalized(legacyMatrix.rules));
  });
});
