import { describe, it, expect, vi } from "vitest";
import type { Connection } from "oracledb";
import { oraclePurchaseInput } from "../shared/oraclePurchaseInvoice";
import { createPurchaseInvoice } from "./oraclePurchaseInvoice";
vi.mock("./oracleSession", () => ({ tagActor: vi.fn() }));
const actor = {
  ID: 1,
  USERNAME: "tester",
  DISPLAY_NAME: "Tester",
  ROLE: "editor" as const,
};
const line = {
  car: "Car",
  model: "2026",
  color: "",
  plate: "ABC",
  vin: "VIN",
  price: 115.25,
  notes: "",
};
const input = {
  date: "2026-10-04",
  supplierId: 10,
  paymentId: 20,
  ownerId: 30,
  branch: "",
  notes: "",
  lines: [line],
};
function db(
  fail = false,
  duplicate = false,
  supplierParent = 2007,
  stockParent = 2003,
  ownerParent = 2006
) {
  const execute = vi.fn(async (sql: string) => {
    if (sql.includes("FROM APP_PURCHASE_SETTINGS"))
      return {
        rows: [
          {
            SUPPLIER_PARENT: supplierParent,
            STOCK_PARENT: stockParent,
            OWNER_PARENT: ownerParent,
          },
        ],
      };
    if (sql.includes("USER_OBJECTS")) return { rows: [{ N: 8 }] };
    if (sql.includes("FROM SON_ACT s"))
      return {
        rows: [
          { ID: 10, NAME: "Supplier", BAR_NUM: 2007, MAIN_NUM: 1002 },
          { ID: 20, NAME: "Stock", BAR_NUM: 2003, MAIN_NUM: 1000 },
          { ID: 30, NAME: "Owner", BAR_NUM: 2006, MAIN_NUM: 1000 },
        ],
      };
    if (sql.includes("COUNT(*) N FROM CAR_PURCHASE"))
      return { rows: [{ N: duplicate ? 1 : 0 }] };
    if (sql.startsWith("INSERT INTO PURCHASE_INVOICE"))
      return { outBinds: { id: [42] } };
    if (sql.startsWith("INSERT INTO CAR_PURCHASE") && fail)
      throw new Error("fail");
    if (sql.includes("PUI_TOTAL TOTAL")) return { rows: [{ TOTAL: 115.25 }] };
    return { rows: [] };
  });
  return {
    execute,
    commit: vi.fn(),
    rollback: vi.fn(),
  } as unknown as Connection;
}
describe("Oracle purchase invoices", () => {
  it("rejects accounts outside the configured supplier and counterpart parents", async () => {
    for (const c of [
      db(false, false, 2006),
      db(false, false, 2007, 2006),
      db(false, false, 2007, 2003, 2007),
    ]) {
      await expect(createPurchaseInvoice(c, actor, input)).rejects.toThrow(
        "إعدادات المشتريات"
      );
      expect(c.commit).not.toHaveBeenCalled();
      expect(
        vi
          .mocked(c.execute)
          .mock.calls.some(([q]) => String(q).startsWith("INSERT"))
      ).toBe(false);
    }
  });
  it("accepts accounts from the configured parents", async () => {
    const c = db(false, false, 2007, 2003);
    expect(await createPurchaseInvoice(c, actor, input)).toEqual({
      id: 42,
      total: 115.25,
    });
  });
  it("rejects using the same account on both sides", async () => {
    const c = db(false, false, 2007, 2007);
    await expect(
      createPurchaseInvoice(c, actor, { ...input, paymentId: 10 })
    ).rejects.toThrow("يختلف");
    expect(c.commit).not.toHaveBeenCalled();
  });
  it("validates duplicate plates and VINs, dates and amounts", () => {
    expect(
      oraclePurchaseInput.safeParse({ ...input, lines: [line, line] }).success
    ).toBe(false);
    expect(
      oraclePurchaseInput.safeParse({ ...input, date: "2026-02-30" }).success
    ).toBe(false);
    expect(
      oraclePurchaseInput.safeParse({
        ...input,
        lines: [{ ...line, price: -1 }],
      }).success
    ).toBe(false);
  });
  it("saves the master with zero total before the detail triggers calculate it", async () => {
    const c = db();
    expect(await createPurchaseInvoice(c, actor, input)).toEqual({
      id: 42,
      total: 115.25,
    });
    const insert = vi
      .mocked(c.execute)
      .mock.calls.find(([q]) =>
        String(q).startsWith("INSERT INTO CAR_PURCHASE")
      );
    expect(insert?.[1]).toMatchObject({ invoice: 42, price: 115.25 });
    const master = vi
      .mocked(c.execute)
      .mock.calls.find(([q]) =>
        String(q).startsWith("INSERT INTO PURCHASE_INVOICE")
      );
    expect(master?.[1]).toMatchObject({
      oid: 30,
      oname: "Owner",
      obar: 2006,
      omain: 1000,
      pid: 20,
      pbar: 2003,
      sbar: 2007,
    });
    expect(c.commit).toHaveBeenCalledOnce();
  });
  it("rolls back on detail failure", async () => {
    const c = db(true);
    await expect(createPurchaseInvoice(c, actor, input)).rejects.toThrow(
      "لم تُحفظ"
    );
    expect(c.commit).not.toHaveBeenCalled();
    expect(c.rollback).toHaveBeenCalledOnce();
  });
  it("rejects vehicles already in inventory before writing", async () => {
    const c = db(false, true);
    await expect(createPurchaseInvoice(c, actor, input)).rejects.toThrow(
      "مسجل مسبقاً"
    );
    expect(
      vi
        .mocked(c.execute)
        .mock.calls.some(([q]) => String(q).startsWith("INSERT"))
    ).toBe(false);
  });
});
