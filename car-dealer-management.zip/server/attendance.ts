import oracledb, { type Connection } from "oracledb";
import { TRPCError } from "@trpc/server";
import type { z } from "zod";
import {
  shiftInput,
  assignmentInput,
  checkInInput,
  attendanceReportInput,
  attendanceWindow,
  locationAllowed,
  expectedTimes,
  type AttendanceShift,
} from "../shared/attendance";
import { tagActor, type Actor } from "./oracleSession";
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
const shiftColumns =
  "ID,NAME,BRANCH,LATITUDE,LONGITUDE,RADIUS,START_TIME,END_TIME,WORK_START,WORK_END,LATE_GRACE,ACTIVE";
function reject(
  message: string,
  code: "BAD_REQUEST" | "CONFLICT" = "BAD_REQUEST"
): never {
  throw new TRPCError({ code, message });
}
async function lock(c: Connection, actor: Actor) {
  await c.execute("SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT");
  await tagActor(c, actor);
}
async function audit(
  c: Connection,
  actor: Actor,
  table: string,
  id: number,
  action: string,
  before: unknown,
  after: unknown
) {
  await c.execute(
    "INSERT INTO APP_AUDIT_LOG(ACTOR_ID,ACTOR_NAME,DB_USER,SOURCE,ACTION,TABLE_NAME,RECORD_ID,BEFORE_JSON,AFTER_JSON,TRANSACTION_ID) VALUES(:actor,:name,USER,'DEALER_WEB',:action,:tableName,:id,:before,:after,DBMS_TRANSACTION.LOCAL_TRANSACTION_ID)",
    {
      actor: String(actor.ID),
      name: actor.DISPLAY_NAME,
      action,
      tableName: table,
      id: String(id),
      before: before ? JSON.stringify(before) : null,
      after: after ? JSON.stringify(after) : null,
    }
  );
}
async function dbNow(c: Connection) {
  const value = (
    await c.execute<{ NOW_VALUE: string }>(
      `SELECT TO_CHAR(SYSTIMESTAMP AT TIME ZONE '+03:00','YYYY-MM-DD"T"HH24:MI:SS') NOW_VALUE FROM DUAL`,
      [],
      o
    )
  ).rows![0].NOW_VALUE;
  return { now: Date.parse(value + "+03:00"), serverTime: value + "+03:00" };
}
export async function attendanceSettings(c: Connection) {
  const shifts =
    (
      await c.execute<AttendanceShift>(
        `SELECT ${shiftColumns} FROM APP_ATTENDANCE_SHIFTS ORDER BY ID`,
        [],
        o
      )
    ).rows ?? [];
  const employees =
    (
      await c.execute<{
        ID: number;
        USERNAME: string;
        DISPLAY_NAME: string;
        ACTIVE: number;
        SHIFT_ID: number | null;
      }>(
        "SELECT u.ID,u.USERNAME,u.DISPLAY_NAME,u.ACTIVE,a.SHIFT_ID FROM APP_USERS u LEFT JOIN APP_SHIFT_ASSIGNMENTS a ON a.USER_ID=u.ID WHERE u.ACTIVE=1 AND (u.EXPIRES_AT IS NULL OR u.EXPIRES_AT>SYSTIMESTAMP) ORDER BY u.DISPLAY_NAME,u.ID",
        [],
        o
      )
    ).rows ?? [];
  return { shifts, employees };
}
async function history(c: Connection, userId: number, shiftId: number | null) {
  await c.execute(
    "UPDATE APP_SHIFT_ASSIGN_HISTORY SET VALID_TO=SYSTIMESTAMP WHERE USER_ID=:id AND VALID_TO IS NULL",
    { id: userId }
  );
  if (shiftId !== null)
    await c.execute(
      "INSERT INTO APP_SHIFT_ASSIGN_HISTORY(USER_ID,SHIFT_ID,EMPLOYEE_NAME,SHIFT_NAME,BRANCH,START_TIME,END_TIME,WORK_START,WORK_END,LATE_GRACE,ACTIVE) SELECT u.ID,s.ID,u.DISPLAY_NAME,s.NAME,s.BRANCH,s.START_TIME,s.END_TIME,s.WORK_START,s.WORK_END,s.LATE_GRACE,s.ACTIVE FROM APP_USERS u CROSS JOIN APP_ATTENDANCE_SHIFTS s WHERE u.ID=:userId AND s.ID=:shiftId",
      { userId, shiftId }
    );
}
export async function saveShift(
  c: Connection,
  actor: Actor,
  raw: z.infer<typeof shiftInput>
) {
  const input = shiftInput.parse(raw);
  try {
    await lock(c, actor);
    let before: AttendanceShift | undefined,
      id = input.id;
    if (id) {
      before = (
        await c.execute<AttendanceShift>(
          `SELECT ${shiftColumns} FROM APP_ATTENDANCE_SHIFTS WHERE ID=:id FOR UPDATE`,
          { id },
          o
        )
      ).rows?.[0];
      if (!before) reject("الوردية غير موجودة");
    }
    const binds = {
      name: input.name,
      branch: input.branch,
      lat: input.latitude,
      lon: input.longitude,
      radius: input.radius,
      startTime: input.startTime,
      endTime: input.endTime,
      workStart: input.workStart,
      workEnd: input.workEnd,
      grace: input.lateGrace,
      active: input.active ? 1 : 0,
    };
    if (id)
      await c.execute(
        "UPDATE APP_ATTENDANCE_SHIFTS SET NAME=:name,BRANCH=:branch,LATITUDE=:lat,LONGITUDE=:lon,RADIUS=:radius,START_TIME=:startTime,END_TIME=:endTime,WORK_START=:workStart,WORK_END=:workEnd,LATE_GRACE=:grace,ACTIVE=:active,UPDATED_AT=SYSTIMESTAMP WHERE ID=:id",
        { ...binds, id }
      );
    else {
      const result = await c.execute(
        "INSERT INTO APP_ATTENDANCE_SHIFTS(NAME,BRANCH,LATITUDE,LONGITUDE,RADIUS,START_TIME,END_TIME,WORK_START,WORK_END,LATE_GRACE,ACTIVE,CREATED_BY) VALUES(:name,:branch,:lat,:lon,:radius,:startTime,:endTime,:workStart,:workEnd,:grace,:active,:actor) RETURNING ID INTO :id",
        {
          ...binds,
          actor: actor.ID,
          id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
        }
      );
      id = Number((result.outBinds as { id: number[] }).id[0]);
    }
    if (input.id) {
      const assigned =
        (
          await c.execute<{ USER_ID: number }>(
            "SELECT USER_ID FROM APP_SHIFT_ASSIGNMENTS WHERE SHIFT_ID=:id",
            { id },
            o
          )
        ).rows ?? [];
      for (const e of assigned) await history(c, e.USER_ID, id);
    }
    await audit(
      c,
      actor,
      "APP_ATTENDANCE_SHIFTS",
      id,
      input.id ? "UPDATE" : "INSERT",
      before,
      input
    );
    await c.commit();
    return { id };
  } catch (e) {
    await c.rollback();
    throw e;
  }
}
export async function assignShift(
  c: Connection,
  actor: Actor,
  raw: z.infer<typeof assignmentInput>
) {
  const input = assignmentInput.parse(raw);
  try {
    await lock(c, actor);
    const state = await attendanceSettings(c);
    const shift = state.shifts.find(s => s.ID === input.shiftId);
    if (!shift || !shift.ACTIVE) reject("اختر وردية مفعلة");
    if (input.employeeIds.some(id => !state.employees.some(e => e.ID === id)))
      reject("أحد الموظفين غير موجود أو حسابه غير مفعل");
    const old =
      (
        await c.execute<{ USER_ID: number; SHIFT_ID: number }>(
          "SELECT USER_ID,SHIFT_ID FROM APP_SHIFT_ASSIGNMENTS",
          [],
          o
        )
      ).rows ?? [];
    for (const row of old.filter(
      r =>
        r.SHIFT_ID === input.shiftId && !input.employeeIds.includes(r.USER_ID)
    )) {
      await c.execute("DELETE FROM APP_SHIFT_ASSIGNMENTS WHERE USER_ID=:id", {
        id: row.USER_ID,
      });
      await history(c, row.USER_ID, null);
      await audit(
        c,
        actor,
        "APP_SHIFT_ASSIGNMENTS",
        row.USER_ID,
        "DELETE",
        row,
        null
      );
    }
    for (const id of input.employeeIds) {
      const before = old.find(r => r.USER_ID === id);
      if (before?.SHIFT_ID === input.shiftId) continue;
      await c.execute(
        "MERGE INTO APP_SHIFT_ASSIGNMENTS a USING (SELECT :employee USER_ID FROM DUAL) s ON (a.USER_ID=s.USER_ID) WHEN MATCHED THEN UPDATE SET SHIFT_ID=:shift,ASSIGNED_BY=:actor,ASSIGNED_AT=SYSTIMESTAMP WHEN NOT MATCHED THEN INSERT(USER_ID,SHIFT_ID,ASSIGNED_BY) VALUES(:employee,:shift,:actor)",
        { employee: id, shift: input.shiftId, actor: actor.ID }
      );
      await history(c, id, input.shiftId);
      await audit(
        c,
        actor,
        "APP_SHIFT_ASSIGNMENTS",
        id,
        before ? "UPDATE" : "INSERT",
        before,
        { USER_ID: id, SHIFT_ID: input.shiftId }
      );
    }
    await c.commit();
    return { ok: true };
  } catch (e) {
    await c.rollback();
    throw e;
  }
}
type CheckRecord = {
  ID: number;
  CHECKED_AT: string;
  CHECKED_OUT_AT: string | null;
  WORK_DATE: string;
  BRANCH: string;
  LATE_MINUTES: number;
  SHIFT_LATITUDE: number;
  SHIFT_LONGITUDE: number;
  SHIFT_RADIUS: number;
};
export async function myAttendance(c: Connection, actor: Actor) {
  const clock = await dbNow(c);
  const shift =
    (
      await c.execute<AttendanceShift>(
        `SELECT ${shiftColumns
          .split(",")
          .map(v => "s." + v)
          .join(
            ","
          )} FROM APP_SHIFT_ASSIGNMENTS a JOIN APP_ATTENDANCE_SHIFTS s ON s.ID=a.SHIFT_ID WHERE a.USER_ID=:id`,
        { id: actor.ID },
        o
      )
    ).rows?.[0] ?? null;
  const window = shift ? attendanceWindow(shift, clock.now) : null;
  const checked =
    (
      await c.execute<CheckRecord>(
        `SELECT * FROM (SELECT ID,TO_CHAR(CHECKED_AT AT TIME ZONE '+03:00','YYYY-MM-DD HH24:MI:SS') CHECKED_AT,TO_CHAR(CHECKED_OUT_AT AT TIME ZONE '+03:00','YYYY-MM-DD HH24:MI:SS') CHECKED_OUT_AT,TO_CHAR(WORK_DATE,'YYYY-MM-DD') WORK_DATE,BRANCH,LATE_MINUTES,SHIFT_LATITUDE,SHIFT_LONGITUDE,SHIFT_RADIUS FROM APP_EMPLOYEE_ATTENDANCE WHERE USER_ID=:id AND (WORK_DATE=TO_DATE(:day,'YYYY-MM-DD') OR WORK_DATE=TO_DATE(:today,'YYYY-MM-DD') OR CHECKED_OUT_AT IS NULL) ORDER BY ID DESC) WHERE ROWNUM=1`,
        {
          id: actor.ID,
          day: window?.workDate ?? clock.serverTime.slice(0, 10),
          today: clock.serverTime.slice(0, 10),
        },
        o
      )
    ).rows?.[0] ?? null;
  return { employeeName: actor.DISPLAY_NAME, shift, window, checked, ...clock };
}
function validateLocation(
  input: z.infer<typeof checkInInput>,
  now: number,
  shift: Pick<AttendanceShift, "LATITUDE" | "LONGITUDE" | "RADIUS">
) {
  const age = now - Date.parse(input.capturedAt);
  if (age > 60000 || age < -10000)
    reject("الموقع غير حديث؛ حدّث موقعك وحاول مجددًا");
  const location = locationAllowed(shift, input);
  if (!location.accurate)
    reject("دقة الموقع غير كافية؛ فعّل الموقع الدقيق وأعد المحاولة");
  if (!location.inside) reject("أنت خارج النطاق المسموح للوردية");
  return location;
}
function localStamp(ms: number) {
  return new Date(ms + 10800000).toISOString().slice(0, 19);
}
export async function checkIn(
  c: Connection,
  actor: Actor,
  raw: z.infer<typeof checkInInput>
) {
  const input = checkInInput.parse(raw);
  try {
    await lock(c, actor);
    const state = await myAttendance(c, actor);
    if (!state.shift || !state.shift.ACTIVE)
      reject("لا توجد وردية مفعلة مسندة إلى حسابك");
    if (!state.window?.allowed)
      reject("تسجيل الحضور غير متاح خارج وقت السماح للوردية");
    if (state.checked)
      reject(
        "تم تسجيل حضورك بالفعل؛ سجّل الانصراف إن كان الحضور السابق مفتوحًا",
        "CONFLICT"
      );
    const location = validateLocation(input, state.now, state.shift),
      expected = expectedTimes(state.shift, state.window.workDate),
      lateMinutes =
        state.now > expected.start + state.shift.LATE_GRACE * 60000
          ? Math.ceil((state.now - expected.start) / 60000)
          : 0;
    const result = await c.execute(
      `INSERT INTO APP_EMPLOYEE_ATTENDANCE(USER_ID,SHIFT_ID,WORK_DATE,EMPLOYEE_NAME,SHIFT_NAME,BRANCH,LATITUDE,LONGITUDE,ACCURACY,DISTANCE_METERS,EXPECTED_START,EXPECTED_END,LATE_MINUTES,SHIFT_LATITUDE,SHIFT_LONGITUDE,SHIFT_RADIUS) VALUES(:employee,:shift,TO_DATE(:day,'YYYY-MM-DD'),:name,:shiftName,:branch,:lat,:lon,:accuracy,:distance,TO_TIMESTAMP(:expectedStart,'YYYY-MM-DD"T"HH24:MI:SS'),TO_TIMESTAMP(:expectedEnd,'YYYY-MM-DD"T"HH24:MI:SS'),:late,:shiftLat,:shiftLon,:radius) RETURNING ID INTO :id`,
      {
        employee: actor.ID,
        shift: state.shift.ID,
        day: state.window.workDate,
        name: actor.DISPLAY_NAME,
        shiftName: state.shift.NAME,
        branch: state.shift.BRANCH,
        lat: input.latitude,
        lon: input.longitude,
        accuracy: input.accuracy,
        distance: Math.round(location.distance),
        expectedStart: localStamp(expected.start),
        expectedEnd: localStamp(expected.end),
        late: lateMinutes,
        shiftLat: state.shift.LATITUDE,
        shiftLon: state.shift.LONGITUDE,
        radius: state.shift.RADIUS,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
      }
    );
    const id = Number((result.outBinds as { id: number[] }).id[0]);
    await audit(c, actor, "APP_EMPLOYEE_ATTENDANCE", id, "INSERT", null, {
      employee: actor.ID,
      shift: state.shift.ID,
      branch: state.shift.BRANCH,
      workDate: state.window.workDate,
      lateMinutes,
    });
    await c.commit();
    return { id };
  } catch (e) {
    await c.rollback();
    throw e;
  }
}
export async function checkOut(
  c: Connection,
  actor: Actor,
  raw: z.infer<typeof checkInInput>
) {
  const input = checkInInput.parse(raw);
  try {
    await lock(c, actor);
    const state = await myAttendance(c, actor),
      record = state.checked;
    if (!record || record.CHECKED_OUT_AT)
      reject("لا يوجد حضور مفتوح لتسجيل الانصراف", "CONFLICT");
    const location = validateLocation(input, state.now, {
      LATITUDE: record.SHIFT_LATITUDE,
      LONGITUDE: record.SHIFT_LONGITUDE,
      RADIUS: record.SHIFT_RADIUS,
    });
    await c.execute(
      "UPDATE APP_EMPLOYEE_ATTENDANCE SET CHECKED_OUT_AT=SYSTIMESTAMP,OUT_LATITUDE=:lat,OUT_LONGITUDE=:lon,OUT_ACCURACY=:accuracy,OUT_DISTANCE=:distance WHERE ID=:id AND USER_ID=:employee AND CHECKED_OUT_AT IS NULL",
      {
        lat: input.latitude,
        lon: input.longitude,
        accuracy: input.accuracy,
        distance: Math.round(location.distance),
        id: record.ID,
        employee: actor.ID,
      }
    );
    await audit(
      c,
      actor,
      "APP_EMPLOYEE_ATTENDANCE",
      record.ID,
      "UPDATE",
      { checkedAt: record.CHECKED_AT },
      { checkedOutAt: state.serverTime }
    );
    await c.commit();
    return { id: record.ID };
  } catch (e) {
    await c.rollback();
    throw e;
  }
}
type ReportRow = {
  ID: number | null;
  USER_ID: number;
  EMPLOYEE_NAME: string;
  SHIFT_NAME: string;
  BRANCH: string;
  WORK_DATE: string;
  CHECKED_AT: string | null;
  CHECKED_OUT_AT: string | null;
  LATE_MINUTES: number;
  DISTANCE_METERS: number | null;
  EXPECTED_START: string | null;
  EXPECTED_END: string | null;
  STATUS: "present" | "late" | "absent" | "pending";
  DURATION_MINUTES: number | null;
};
export async function attendanceReport(
  c: Connection,
  raw: z.infer<typeof attendanceReportInput>
) {
  const input = attendanceReportInput.parse(raw),
    days = (Date.parse(input.date2) - Date.parse(input.date1)) / 86400000 + 1;
  if (days > 93) reject("اختر فترة لا تتجاوز 93 يومًا لتقرير الحضور");
  const clock = await dbNow(c);
  const expected =
    (
      await c.execute<{
        USER_ID: number;
        EMPLOYEE_NAME: string;
        SHIFT_NAME: string;
        BRANCH: string;
        WORK_DATE: string;
        START_TIME: string;
        END_TIME: string;
        WORK_START: string;
        WORK_END: string;
      }>(
        `SELECT USER_ID,EMPLOYEE_NAME,SHIFT_NAME,BRANCH,TO_CHAR(DAY_VALUE,'YYYY-MM-DD') WORK_DATE,START_TIME,END_TIME,WORK_START,WORK_END FROM (SELECT h.USER_ID,h.EMPLOYEE_NAME,h.SHIFT_NAME,h.BRANCH,d.DAY_VALUE,h.START_TIME,h.END_TIME,h.WORK_START,h.WORK_END,ROW_NUMBER() OVER(PARTITION BY h.USER_ID,d.DAY_VALUE ORDER BY h.VALID_FROM DESC,h.ID DESC) RN FROM (SELECT TO_DATE(:date1,'YYYY-MM-DD')+LEVEL-1 DAY_VALUE FROM DUAL CONNECT BY LEVEL<=TO_DATE(:date2,'YYYY-MM-DD')-TO_DATE(:date1,'YYYY-MM-DD')+1) d JOIN APP_SHIFT_ASSIGN_HISTORY h ON CAST(h.VALID_FROM AT TIME ZONE '+03:00' AS TIMESTAMP)<CAST(d.DAY_VALUE+1 AS TIMESTAMP) AND (h.VALID_TO IS NULL OR CAST(h.VALID_TO AT TIME ZONE '+03:00' AS TIMESTAMP)>CAST(d.DAY_VALUE AS TIMESTAMP)) WHERE h.ACTIVE=1) WHERE RN=1`,
        input,
        o
      )
    ).rows ?? [];
  const actual =
    (
      await c.execute<ReportRow>(
        `SELECT ID,USER_ID,EMPLOYEE_NAME,SHIFT_NAME,BRANCH,TO_CHAR(WORK_DATE,'YYYY-MM-DD') WORK_DATE,TO_CHAR(CHECKED_AT AT TIME ZONE '+03:00','YYYY-MM-DD HH24:MI:SS') CHECKED_AT,TO_CHAR(CHECKED_OUT_AT AT TIME ZONE '+03:00','YYYY-MM-DD HH24:MI:SS') CHECKED_OUT_AT,LATE_MINUTES,DISTANCE_METERS,TO_CHAR(EXPECTED_START,'YYYY-MM-DD HH24:MI:SS') EXPECTED_START,TO_CHAR(EXPECTED_END,'YYYY-MM-DD HH24:MI:SS') EXPECTED_END FROM APP_EMPLOYEE_ATTENDANCE WHERE WORK_DATE>=TO_DATE(:date1,'YYYY-MM-DD') AND WORK_DATE<TO_DATE(:date2,'YYYY-MM-DD')+1`,
        input,
        o
      )
    ).rows ?? [];
  const records = new Map<string, ReportRow>();
  for (const e of expected) {
    let deadline = Date.parse(e.WORK_DATE + "T" + e.END_TIME + ":00+03:00");
    if (e.END_TIME < e.START_TIME) deadline += 86400000;
    const { start, end } = expectedTimes(e, e.WORK_DATE);
    records.set(e.USER_ID + ":" + e.WORK_DATE, {
      ID: null,
      USER_ID: e.USER_ID,
      EMPLOYEE_NAME: e.EMPLOYEE_NAME,
      SHIFT_NAME: e.SHIFT_NAME,
      BRANCH: e.BRANCH,
      WORK_DATE: e.WORK_DATE,
      CHECKED_AT: null,
      CHECKED_OUT_AT: null,
      LATE_MINUTES: 0,
      DISTANCE_METERS: null,
      EXPECTED_START: localStamp(start).replace("T", " "),
      EXPECTED_END: localStamp(end).replace("T", " "),
      STATUS: clock.now > deadline ? "absent" : "pending",
      DURATION_MINUTES: null,
    });
  }
  for (const r of actual) {
    records.set(r.USER_ID + ":" + r.WORK_DATE, {
      ...r,
      STATUS: r.LATE_MINUTES > 0 ? "late" : "present",
      DURATION_MINUTES:
        r.CHECKED_OUT_AT && r.CHECKED_AT
          ? Math.max(
              0,
              Math.floor(
                (Date.parse(r.CHECKED_OUT_AT.replace(" ", "T") + "+03:00") -
                  Date.parse(r.CHECKED_AT.replace(" ", "T") + "+03:00")) /
                  60000
              )
            )
          : null,
    });
  }
  return Array.from(records.values()).sort(
    (a, b) =>
      b.WORK_DATE.localeCompare(a.WORK_DATE) ||
      a.EMPLOYEE_NAME.localeCompare(b.EMPLOYEE_NAME)
  );
}
