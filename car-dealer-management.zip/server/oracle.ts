import oracledb from "oracledb";

export function validateOracleTarget(host: string, runtime = process.env.NODE_ENV || "development") {
  const isLocalhost = host === "127.0.0.1" || host === "localhost" || host === "::1";
  if (runtime === "production" && isLocalhost) {
    throw new Error("Localhost Oracle targets are not allowed in production");
  }
  return host;
}

export function getOracleConfigFromEnv(env: NodeJS.ProcessEnv, runtime = env.NODE_ENV || "development") {
  const prefix = runtime === "production" ? "ORACLE_" : "LOCAL_ORACLE_";
  const host = env[`${prefix}HOST`];
  const port = env[`${prefix}PORT`] || "1521";
  const service = env[`${prefix}SERVICE_NAME`];
  const user = env[`${prefix}USER`];
  const password = env[`${prefix}PASSWORD`];
  if (!host || !service || !user || !password) {
    throw new Error(`Oracle ${runtime} configuration is incomplete`);
  }
  validateOracleTarget(host, runtime);
  return { user, password, connectString: `${host}:${port}/${service}` };
}

export function getOracleConfig(runtime = process.env.NODE_ENV || "development") {
  return getOracleConfigFromEnv(process.env, runtime);
}

export async function checkOracleConnection() {
  const connection = await oracledb.getConnection(getOracleConfig());
  try {
    const result = await connection.execute<{ DB_TIME: string }>("SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS DB_TIME FROM DUAL", [], { outFormat: oracledb.OUT_FORMAT_OBJECT });
    return result.rows?.[0]?.DB_TIME ?? null;
  } finally {
    await connection.close();
  }
}
