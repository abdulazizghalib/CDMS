﻿import { describe, it, expect, vi } from "vitest";
import type { Connection } from "oracledb";
import { activityInput } from "../shared/dealerActivities";
import { createActivity, finishActivity } from "./dealerActivities";
vi.mock("./oracleSession", () => ({ tagActor: vi.fn() }));
const actor = {
  ID: 1,
  USERNAME: "test",
  DISPLAY_NAME: "Tester",
  ROLE: "editor" as const,
};
const input = {
  kind: "reservation" as const,
  customer: "Customer",
  phone: "0500000000",
  vehicleId: 7,
  scheduledAt: "2099-01-01T12:00",
  notes: "",
};
function connection(available = true, status = "active", expired = 0) {
  return {
    execute: vi.fn(async (sql: string) => {
      if (sql.includes("FROM CAR_PURCHASE p"))
        return {
          rows: available
            ? [{ ID: 7, CAR: "Car", MODEL: "2026", PLATE: "123" }]
            : [],
        };
      if (sql.startsWith("INSERT INTO APP_DEALER_ACTIVITIES"))
        return { outBinds: { id: [42] } };
      if (sql.startsWith("SELECT STATUS"))
        return { rows: [{ STATUS: status, EXPIRED: expired }] };
      return { rows: [] };
    }),
    commit: vi.fn(),
    rollback: vi.fn(),
  } as unknown as Connection;
}
describe("dealer reservations and followups", () => {
  it("requires a vehicle for reservations and accepts optional follow-up vehicle", () => {
    expect(activityInput.safeParse({ ...input, vehicleId: null }).success).toBe(
      false
    );
    expect(
      activityInput.safeParse({ ...input, kind: "followup", vehicleId: null })
        .success
    ).toBe(true);
  });
  it.each(["2099-02-30T10:00", "2099-01-01T25:00", "bad"])(
    "rejects invalid timestamp %s",
    scheduledAt =>
      expect(activityInput.safeParse({ ...input, scheduledAt }).success).toBe(
        false
      )
  );
  it("rejects past time before writes", async () => {
    const c = connection();
    await expect(
      createActivity(c, actor, { ...input, scheduledAt: "2000-01-01T12:00" })
    ).rejects.toThrow("المستقبل");
    expect(c.execute).not.toHaveBeenCalled();
  });
  it("rejects unavailable or already reserved cars and rolls back", async () => {
    const c = connection(false);
    await expect(createActivity(c, actor, input)).rejects.toThrow("غير متاحة");
    expect(c.commit).not.toHaveBeenCalled();
    expect(c.rollback).toHaveBeenCalledOnce();
  });
  it("audits and commits the reservation", async () => {
    const c = connection();
    expect(await createActivity(c, actor, input)).toEqual({ id: 42 });
    expect(
      vi
        .mocked(c.execute)
        .mock.calls.some(([sql]) =>
          String(sql).startsWith("INSERT INTO APP_AUDIT_LOG")
        )
    ).toBe(true);
    expect(c.commit).toHaveBeenCalledOnce();
  });
  it.each([
    ["cancelled", 0],
    ["completed", 0],
    ["active", 1],
  ])("rejects closed or expired reservation %s", async (status, expired) => {
    const c = connection(true, String(status), Number(expired));
    await expect(
      finishActivity(c, actor, { id: 42, status: "completed" })
    ).rejects.toThrow("مغلق");
    expect(c.commit).not.toHaveBeenCalled();
  });
});
