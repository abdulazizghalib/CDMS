﻿import { describe, it, expect, vi } from "vitest";
import type { Connection } from "oracledb";
import { validateLogo, getInvoiceForPrint } from "./dealerBranding";
describe("dealer logo and invoice print data", () => {
  it("accepts raster signatures and rejects active content, mismatched types and oversized images", () => {
    const png =
      "data:image/png;base64," +
      Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]).toString("base64");
    expect(() => validateLogo(png)).not.toThrow();
    expect(() => validateLogo(null)).not.toThrow();
    expect(() =>
      validateLogo(
        "data:image/svg+xml;base64," + Buffer.from("<svg/>").toString("base64")
      )
    ).toThrow();
    expect(() =>
      validateLogo(
        "data:image/png;base64," + Buffer.from("<script>").toString("base64")
      )
    ).toThrow();
    expect(() =>
      validateLogo(png + Buffer.alloc(600000).toString("base64"))
    ).toThrow();
  });
  it("loads all saved invoice lines with branding and binds the invoice ID", async () => {
    const lines = Array.from({ length: 30 }, (_, i) => ({ CAR: "Car " + i }));
    const execute = vi
      .fn()
      .mockResolvedValueOnce({ rows: [{ ID: 7, TOTAL: 30 }] })
      .mockResolvedValueOnce({ rows: lines })
      .mockResolvedValueOnce({ rows: [{ NAME: "Dealer", LOGO_DATA: null }] });
    const c = { execute } as unknown as Connection;
    const result = await getInvoiceForPrint(c, "purchases", 7);
    expect(result.lines).toHaveLength(30);
    expect(result.branding.name).toBe("Dealer");
    expect(execute.mock.calls[1][0]).toContain("CP_INV_REF=:id");
    expect(execute.mock.calls[1][1]).toEqual({ id: 7 });
  });
  it("reports a missing invoice", async () => {
    const c = {
      execute: vi.fn().mockResolvedValue({ rows: [] }),
    } as unknown as Connection;
    await expect(getInvoiceForPrint(c, "sales", 7)).rejects.toThrow(
      "غير موجودة"
    );
  });
});
