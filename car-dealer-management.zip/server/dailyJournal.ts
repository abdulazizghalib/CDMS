﻿import oracledb, { type Connection } from "oracledb";
import { journalReportInput } from "../shared/accountStatement";
import type { z } from "zod";
export async function getDailyJournal(
  c: Connection,
  raw: z.infer<typeof journalReportInput>
) {
  const input = journalReportInput.parse(raw);
  const lines =
    (
      await c.execute<{
        AL_ID: number;
        AL_DATE: string;
        AL_ACC_NO: number | null;
        AL_ACC_NAME: string | null;
        AL_EXP: string | null;
        AL_SOURCE: string | null;
        AL_DEPIT_MOUNT: number;
        AL_CREDIT_MOUNT: number;
        AL_DOC_TYPE: string | null;
        AL_DOC_ID: number | null;
      }>(
        `SELECT AL_ID,TO_CHAR(AL_DATE,'YYYY-MM-DD HH24:MI:SS') AL_DATE,AL_ACC_NO,AL_ACC_NAME,AL_EXP,AL_SOURCE,NVL(AL_DEPIT_MOUNT,0) AL_DEPIT_MOUNT,NVL(AL_CREDIT_MOUNT,0) AL_CREDIT_MOUNT,AL_DOC_TYPE,AL_DOC_ID FROM ACCOUNT_LEDGER WHERE AL_DATE>=TO_DATE(:date1,'YYYY-MM-DD') AND AL_DATE<TO_DATE(:date2,'YYYY-MM-DD')+1 ORDER BY AL_DATE,AL_ID`,
        input,
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows ?? [];
  const debit =
    lines.reduce((n, r) => n + Math.round(Number(r.AL_DEPIT_MOUNT) * 100), 0) /
    100;
  const credit =
    lines.reduce((n, r) => n + Math.round(Number(r.AL_CREDIT_MOUNT) * 100), 0) /
    100;
  return {
    ...input,
    lines,
    debit,
    credit,
    difference: Math.round((debit - credit) * 100) / 100,
  };
}
