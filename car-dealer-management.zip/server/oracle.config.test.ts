import { describe, expect, it } from "vitest";
import { getOracleConfigFromEnv } from "./oracle";

const base = {
  LOCAL_ORACLE_HOST: "127.0.0.1",
  LOCAL_ORACLE_PORT: "1521",
  LOCAL_ORACLE_SERVICE_NAME: "ORCL",
  LOCAL_ORACLE_USER: "OPAL",
  LOCAL_ORACLE_PASSWORD: "local-secret",
  ORACLE_HOST: "db.example.internal",
  ORACLE_PORT: "1521",
  ORACLE_SERVICE_NAME: "PROD",
  ORACLE_USER: "APP_READ",
  ORACLE_PASSWORD: "prod-secret",
};

describe("Oracle runtime configuration", () => {
  it("uses only local variables in development", () => {
    expect(getOracleConfigFromEnv(base, "development")).toEqual({ user: "OPAL", password: "local-secret", connectString: "127.0.0.1:1521/ORCL" });
  });

  it("uses only hosted variables in production", () => {
    expect(getOracleConfigFromEnv(base, "production")).toEqual({ user: "APP_READ", password: "prod-secret", connectString: "db.example.internal:1521/PROD" });
  });
});
