import { describe, it, expect, vi, beforeEach } from "vitest";
import type { Connection } from "oracledb";
import type { TrpcContext } from "./_core/context";
import {
  definition,
  normalizeValues,
  mutationInput,
  writeRecord,
} from "./oracleWrite";
import {
  passwordHash,
  passwordMatches,
  requireSameOrigin,
  actorFor,
  requireActor,
  sha256,
} from "./oracleSession";
import { oracleOperationsRouter } from "./oracleOperations";
vi.mock("oracledb", () => ({
  default: {
    getConnection: vi.fn(),
    OUT_FORMAT_OBJECT: 4002,
    BIND_OUT: 3003,
    NUMBER: 2010,
  },
}));
import oracledb from "oracledb";
vi.mock("./oracle", () => ({
  getOracleConfig: () => ({
    user: "test",
    password: "test",
    connectString: "test",
  }),
}));
const req = (cookie = "") =>
  ({
    headers: {
      host: "localhost:3100",
      origin: "http://localhost:3100",
      cookie,
    },
    socket: { remoteAddress: "127.0.0.1" },
    secure: false,
  }) as TrpcContext["req"];
const actor = {
  ID: 7,
  USERNAME: "tester",
  DISPLAY_NAME: "Tester",
  ROLE: "editor" as const,
};
const makeConnection = (rows: unknown[] = []) =>
  ({
    execute: vi.fn().mockResolvedValue({ rows }),
    commit: vi.fn(),
    rollback: vi.fn(),
    close: vi.fn(),
  }) as unknown as Connection;
describe("Oracle mutation validation", () => {
  it("rejects unlisted datasets and columns", () => {
    expect(() => definition("sales")).toThrow();
    expect(() => definition("__proto__")).toThrow();
    expect(() =>
      normalizeValues(definition("costCenters"), {
        CC_NAME: "name",
        TABLE_NAME: "users",
      })
    ).toThrow();
  });
  it("validates required fields and Oracle byte lengths", () => {
    expect(() =>
      normalizeValues(definition("costCenters"), { CC_NAME: " " })
    ).toThrow();
    expect(() =>
      normalizeValues(definition("mainAccounts"), { AC_NAM: "س".repeat(51) })
    ).toThrow();
  });
  it("rejects impossible dates and nonfinite numbers", () => {
    expect(() =>
      normalizeValues(definition("entries"), {
        CE_NAME: "car",
        CE_DATE: "2026-02-30",
      })
    ).toThrow();
    expect(() =>
      normalizeValues(definition("entries"), {
        CE_NAME: "car",
        CE_DATE: "2026-02-28",
        CE_MOUNT: "Infinity",
      })
    ).toThrow();
  });
  it("requires a version for updates and checks audit readiness before DML", async () => {
    const c = makeConnection([{ N: 0 }]);
    await expect(
      writeRecord(
        c,
        actor,
        mutationInput.parse({
          dataset: "costCenters",
          action: "update",
          id: 1,
          values: { CC_NAME: "x" },
        })
      )
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
    await expect(
      writeRecord(
        c,
        actor,
        mutationInput.parse({
          dataset: "costCenters",
          action: "insert",
          values: { CC_NAME: "x" },
        })
      )
    ).rejects.toThrow("التدقيق");
    expect(c.rollback).toHaveBeenCalled();
    expect(
      vi.mocked(c.execute).mock.calls.some(([sql]) => sql.startsWith("INSERT"))
    ).toBe(false);
  });
});
describe("Oracle identity and permissions", () => {
  beforeEach(() => vi.clearAllMocks());
  it("hashes passwords with independent salts and verifies them", async () => {
    const first = await passwordHash("long-password-for-test"),
      second = await passwordHash("long-password-for-test");
    expect(first).not.toBe(second);
    expect(await passwordMatches("long-password-for-test", first)).toBe(true);
    expect(await passwordMatches("wrong-password", first)).toBe(false);
  });
  it("does not accept absent or cross-origin mutation origins", () => {
    expect(() =>
      requireSameOrigin({
        ...req(),
        headers: { host: "localhost:3100" },
      } as TrpcContext["req"])
    ).toThrow();
    expect(() =>
      requireSameOrigin({
        ...req(),
        headers: { host: "localhost:3100", origin: "https://other.test" },
      } as TrpcContext["req"])
    ).toThrow();
    expect(() => requireSameOrigin(req())).not.toThrow();
  });
  it("never treats local read access or client-provided actor as authentication", async () => {
    const c = makeConnection();
    expect(await actorFor(req(), c)).toBeNull();
    await expect(requireActor(req(), c)).rejects.toMatchObject({
      code: "UNAUTHORIZED",
    });
    expect(c.execute).not.toHaveBeenCalled();
  });
  it("hashes session tokens and checks expiry and active status in Oracle", async () => {
    const c = makeConnection([actor]),
      token = "a".repeat(64);
    expect(await actorFor(req("dealer_oracle_session=" + token), c)).toEqual(
      actor
    );
    expect(c.execute).toHaveBeenCalledWith(
      expect.stringContaining("s.EXPIRES_AT>SYSTIMESTAMP AND u.ACTIVE=1"),
      { token: sha256(token) },
      expect.anything()
    );
  });
  it("forbids editor deletion and audit reporting at the server", async () => {
    const c = makeConnection([actor]);
    vi.mocked(oracledb.getConnection).mockResolvedValue(c);
    const caller = oracleOperationsRouter.createCaller({
      req: req("dealer_oracle_session=" + "a".repeat(64)),
      res: {},
      user: null,
    } as TrpcContext);
    await expect(
      caller.write({
        dataset: "costCenters",
        action: "delete",
        id: 1,
        version: "x",
      })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.history({})).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
    expect(c.commit).not.toHaveBeenCalled();
  });
});
describe("Admin-issued trial accounts", () => {
  beforeEach(() => vi.clearAllMocks());
  const sessionReq = () => req("dealer_oracle_session=" + "a".repeat(64));
  const callerFor = (c: Connection) => {
    vi.mocked(oracledb.getConnection).mockResolvedValue(c);
    return oracleOperationsRouter.createCaller({
      req: sessionReq(),
      res: { cookie: vi.fn(), clearCookie: vi.fn() },
      user: null,
    } as unknown as TrpcContext);
  };
  const admin = { ...actor, ROLE: "admin" as const };
  const credentials = "long-password-for-test";

  it("refuses an expired trial at login and never opens a session", async () => {
    const expired = makeConnection([
      {
        ID: 9,
        USERNAME: "trial",
        DISPLAY_NAME: "Trial",
        ROLE: "editor",
        PASSWORD_HASH: await passwordHash(credentials),
        EXPIRES_AT: "2026-01-01",
        EXPIRED: 1,
      },
    ]);
    await expect(
      callerFor(expired).login({ username: "trial", password: credentials })
    ).rejects.toMatchObject({
      code: "UNAUTHORIZED",
      message: expect.stringContaining("تجريبي"),
    });
    expect(expired.commit).not.toHaveBeenCalled();
    expect(
      vi
        .mocked(expired.execute)
        .mock.calls.some(([sql]) =>
          String(sql).startsWith("INSERT INTO APP_SESSIONS")
        )
    ).toBe(false);
  });

  it("issues a session and reports the expiry for a live trial", async () => {
    const live = makeConnection([
      {
        ID: 10,
        USERNAME: "trial",
        DISPLAY_NAME: "Trial",
        ROLE: "editor",
        PASSWORD_HASH: await passwordHash(credentials),
        EXPIRES_AT: "2099-01-01",
        EXPIRED: 0,
      },
    ]);
    const cookie = vi.fn();
    vi.mocked(oracledb.getConnection).mockResolvedValue(live);
    const caller = oracleOperationsRouter.createCaller({
      req: sessionReq(),
      res: { cookie, clearCookie: vi.fn() },
      user: null,
    } as unknown as TrpcContext);
    await expect(
      caller.login({ username: "trial", password: credentials })
    ).resolves.toEqual({ ok: true });
    expect(cookie).toHaveBeenCalledWith(
      "dealer_oracle_session",
      expect.any(String),
      expect.objectContaining({ httpOnly: true, sameSite: "strict" })
    );
    expect(live.commit).toHaveBeenCalled();
  });

  it("stamps an expiry for trials and none for permanent accounts", async () => {
    const c = makeConnection();
    const execute = vi
      .mocked(c.execute)
      .mockResolvedValueOnce({ rows: [admin] } as never)
      .mockResolvedValueOnce({ outBinds: { id: [42] }, rowsAffected: 1 } as never)
      .mockResolvedValueOnce({
        rows: [{ ...admin, ID: 42, EXPIRES_AT: "2099-01-01" }],
      } as never)
      .mockResolvedValueOnce({ rows: [] } as never);
    await expect(
      callerFor(c).addUser({
        username: "prospect",
        displayName: "Prospect",
        password: credentials,
        role: "editor",
        accountType: "trial",
        trialDays: 30,
      })
    ).resolves.toEqual({ ok: true });
    expect(execute).toHaveBeenCalledWith(
      expect.stringContaining("NUMTODSINTERVAL"),
      expect.objectContaining({ trial: 1, days: 30 })
    );
    expect(c.commit).toHaveBeenCalled();
  });

  it("creates permanent accounts when no trial is requested", async () => {
    const c = makeConnection();
    const execute = vi
      .mocked(c.execute)
      .mockResolvedValueOnce({ rows: [admin] } as never)
      .mockResolvedValueOnce({ outBinds: { id: [43] }, rowsAffected: 1 } as never)
      .mockResolvedValueOnce({
        rows: [{ ...admin, ID: 43, EXPIRES_AT: null }],
      } as never)
      .mockResolvedValueOnce({ rows: [] } as never);
    await expect(
      callerFor(c).addUser({
        username: "staff",
        displayName: "Staff",
        password: credentials,
        role: "viewer",
        accountType: "standard",
        trialDays: 30,
      })
    ).resolves.toEqual({ ok: true });
    expect(execute).toHaveBeenCalledWith(
      expect.stringContaining("CASE WHEN :trial=1"),
      expect.objectContaining({ trial: 0 })
    );
  });

  it("renews, clears and audits expiry through setUserTrial", async () => {
    const c = makeConnection();
    const execute = vi
      .mocked(c.execute)
      .mockResolvedValueOnce({ rows: [admin] } as never)
      .mockResolvedValueOnce({
        rows: [{ ID: 5, USERNAME: "trial", EXPIRES_AT: "2026-01-01" }],
      } as never)
      .mockResolvedValueOnce({ rowsAffected: 1 } as never)
      .mockResolvedValueOnce({ rowsAffected: 1 } as never)
      .mockResolvedValueOnce({ rows: [{ ID: 5, EXPIRES_AT: null }] } as never)
      .mockResolvedValueOnce({ rows: [] } as never);
    await expect(
      callerFor(c).setUserTrial({ id: 5, days: 0 })
    ).resolves.toEqual({ ok: true });
    expect(execute).toHaveBeenCalledWith(
      expect.stringContaining("SET EXPIRES_AT=CASE WHEN :days=0 THEN NULL"),
      { id: 5, days: 0 }
    );
    expect(execute).toHaveBeenCalledWith(
      "DELETE FROM APP_SESSIONS WHERE USER_ID=:id",
      { id: 5 }
    );
    expect(c.commit).toHaveBeenCalled();
  });

  it("keeps trial creation and expiry admin-only and bounds the length", async () => {
    const caller = callerFor(makeConnection([actor]));
    await expect(caller.users(undefined)).rejects.toMatchObject({
      code: "FORBIDDEN",
    });
    await expect(
      caller.addUser({
        username: "prospect",
        displayName: "Prospect",
        password: credentials,
        role: "editor",
        accountType: "trial",
        trialDays: 30,
      })
    ).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.setUserTrial({ id: 3, days: 30 })).rejects.toMatchObject(
      { code: "FORBIDDEN" }
    );

    const adminCaller = callerFor(makeConnection([admin]));
    await expect(
      adminCaller.addUser({
        username: "prospect",
        displayName: "Prospect",
        password: credentials,
        role: "editor",
        accountType: "trial",
        trialDays: 400,
      })
    ).rejects.toThrow();
    await expect(
      adminCaller.addUser({
        username: "prospect",
        displayName: "Prospect",
        password: credentials,
        role: "editor",
        accountType: "forever",
      } as never)
    ).rejects.toThrow();
  });
});
