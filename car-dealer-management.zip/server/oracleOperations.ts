import {
  collectionAccountInput,
  createCollectionAccount,
  createOwnerAccount,
} from "./collectionAccount";
import {
  getPurchaseAccountSettings,
  savePurchaseAccountSettings,
  purchaseAccountSettingsInput,
} from "./purchaseAccountSettings";
import { voucherInput } from "../shared/oracleVoucher";
import { voucherAccounts, createVoucher } from "./oracleVoucher";
import {
  getTrialBalance,
  getIncomeStatement,
  getBalanceSheet,
} from "./trialBalance";
import { getDailyJournal } from "./dailyJournal";
import {
  accountStatementInput,
  journalReportInput,
} from "../shared/accountStatement";
import { statementAccounts, getAccountStatement } from "./accountStatement";
import { getAccountTree } from "./accountTree";
import {
  activityKind,
  activityInput,
  activityStatusInput,
} from "../shared/dealerActivities";
import {
  listActivities,
  activityVehicles,
  createActivity,
  finishActivity,
} from "./dealerActivities";
import {
  brandingInput,
  getBranding,
  saveBranding,
  getInvoiceForPrint,
} from "./dealerBranding";
import { oraclePurchaseInput } from "../shared/oraclePurchaseInvoice";
import {
  createPurchaseInvoice,
  purchaseInvoiceOptions,
} from "./oraclePurchaseInvoice";
import {
  getSalesAccountSettings,
  saveSalesAccountSettings,
  salesAccountSettingsInput,
} from "./salesAccountSettings";
import { salesInvoiceInput } from "../shared/salesInvoice";
import { createSalesInvoice, salesInvoiceOptions } from "./salesInvoice";
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import oracledb from "oracledb";
import { parse } from "cookie";
import { router, publicProcedure } from "./_core/trpc";
import {
  oracleConnection,
  actorFor,
  requireActor,
  requireSameOrigin,
  passwordHash,
  passwordMatches,
  startSession,
  sessionCookie,
  sha256,
  tagActor,
  type Actor,
} from "./oracleSession";
import {
  definition,
  loadRecord,
  mutationInput,
  writeRecord,
} from "./oracleWrite";
const username = z
  .string()
  .trim()
  .min(3)
  .max(50)
  .regex(/^[a-zA-Z0-9_.-]+$/);
const password = z.string().min(12).max(128);
/** Length of the standard trial the admin hands out, in days. */
const TRIAL_DAYS = 30;
const userInput = z.object({
  username,
  displayName: z.string().trim().min(2).max(100),
  password,
  role: z.enum(["admin", "editor", "viewer"]),
  accountType: z.enum(["standard", "trial"]).default("standard"),
  trialDays: z.number().int().min(1).max(365).default(TRIAL_DAYS),
});
const attempts = new Map<string, { count: number; until: number }>();
function rateLimit(key: string) {
  const now = Date.now();
  for (const [k, v] of Array.from(attempts))
    if (v.until < now) attempts.delete(k);
  const item = attempts.get(key) ?? { count: 0, until: now + 15 * 60 * 1000 };
  if (item.count >= 8)
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "محاولات كثيرة؛ حاول بعد 15 دقيقة",
    });
  item.count++;
  attempts.set(key, item);
}
function localBootstrap(req: {
  socket: { remoteAddress?: string };
  headers: { host?: string };
}) {
  return (
    process.env.NODE_ENV !== "production" &&
    ["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(
      req.socket.remoteAddress ?? ""
    ) &&
    ["localhost", "127.0.0.1", "[::1]"].includes(
      new URL("http://" + req.headers.host).hostname
    )
  );
}
async function auditUser(
  c: Parameters<typeof tagActor>[0],
  actor: Actor,
  action: string,
  id: number,
  _name: string,
  before: Record<string, unknown> | null = null
) {
  const after =
    (
      await c.execute<Record<string, unknown>>(
        "SELECT ID,USERNAME,DISPLAY_NAME,ROLE,ACTIVE,TO_CHAR(EXPIRES_AT AT TIME ZONE '+03:00','YYYY-MM-DD') EXPIRES_AT FROM APP_USERS WHERE ID=:id",
        { id },
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows?.[0] ?? null;
  await c.execute(
    "INSERT INTO APP_AUDIT_LOG(ACTOR_ID,ACTOR_NAME,DB_USER,SOURCE,ACTION,TABLE_NAME,RECORD_ID,BEFORE_JSON,AFTER_JSON,TRANSACTION_ID) VALUES(:actor,:name,USER,'DEALER_WEB',:action,'APP_USERS',:id,:before,:after,DBMS_TRANSACTION.LOCAL_TRANSACTION_ID)",
    {
      actor: String(actor.ID),
      name: actor.DISPLAY_NAME,
      action,
      id: String(id),
      before: before ? JSON.stringify(before) : null,
      after: after ? JSON.stringify(after) : null,
    }
  );
}
export const oracleOperationsRouter = router({
  voucherAccounts: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c);
      return voucherAccounts(c);
    })
  ),
  createVoucher: publicProcedure
    .input(voucherInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        createVoucher(c, await requireActor(ctx.req, c), input)
      );
    }),
  balanceSheet: publicProcedure
    .input(journalReportInput)
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c, ["admin", "editor", "viewer"]);
        return getBalanceSheet(c, input);
      })
    ),
  incomeStatement: publicProcedure
    .input(journalReportInput)
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c, ["admin", "editor", "viewer"]);
        return getIncomeStatement(c, input);
      })
    ),
  trialBalance: publicProcedure
    .input(journalReportInput)
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c, ["admin", "editor", "viewer"]);
        return getTrialBalance(c, input);
      })
    ),
  dailyJournal: publicProcedure
    .input(journalReportInput)
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c, ["admin", "editor", "viewer"]);
        return getDailyJournal(c, input);
      })
    ),
  statementAccounts: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c, ["admin", "editor", "viewer"]);
      return statementAccounts(c);
    })
  ),
  accountStatement: publicProcedure
    .input(accountStatementInput)
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c, ["admin", "editor", "viewer"]);
        return getAccountStatement(c, input);
      })
    ),
  accountTree: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c, ["admin", "editor", "viewer"]);
      return getAccountTree(c);
    })
  ),
  activities: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c, ["admin", "editor", "viewer"]);
      return listActivities(c);
    })
  ),
  activityVehicles: publicProcedure
    .input(activityKind)
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c);
        return activityVehicles(c, input === "followup");
      })
    ),
  createActivity: publicProcedure
    .input(activityInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        createActivity(c, await requireActor(ctx.req, c), input)
      );
    }),
  finishActivity: publicProcedure
    .input(activityStatusInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        finishActivity(c, await requireActor(ctx.req, c), input)
      );
    }),
  session: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      const actor = await actorFor(ctx.req, c);
      const result = await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM APP_USERS",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      return {
        actor,
        canBootstrap: localBootstrap(ctx.req) && result.rows?.[0]?.N === 0,
      };
    })
  ),
  bootstrap: publicProcedure
    .input(userInput.omit({ role: true }))
    .mutation(async ({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      if (!localBootstrap(ctx.req))
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "إنشاء أول مدير متاح محليًا فقط",
        });
      return oracleConnection(async c => {
        try {
          await c.execute("LOCK TABLE APP_USERS IN EXCLUSIVE MODE NOWAIT");
          const n = await c.execute<{ N: number }>(
            "SELECT COUNT(*) N FROM APP_USERS",
            [],
            { outFormat: oracledb.OUT_FORMAT_OBJECT }
          );
          if (n.rows?.[0]?.N)
            throw new TRPCError({
              code: "CONFLICT",
              message: "تم إعداد المدير بالفعل",
            });
          const hash = await passwordHash(input.password);
          const created = await c.execute(
            "INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE) VALUES(:username,:name,:hash,'admin') RETURNING ID INTO :id",
            {
              username: input.username.toLowerCase(),
              name: input.displayName,
              hash,
              id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
            }
          );
          const actor: Actor = {
            ID: Number((created.outBinds!.id as number[])[0]),
            USERNAME: input.username.toLowerCase(),
            DISPLAY_NAME: input.displayName,
            ROLE: "admin",
          };
          await auditUser(c, actor, "INSERT", actor.ID, actor.USERNAME);
          await startSession(c, ctx, actor);
          await c.commit();
          return { ok: true };
        } catch (e) {
          await c.rollback();
          throw e;
        }
      });
    }),
  login: publicProcedure
    .input(z.object({ username, password: z.string().min(1).max(128) }))
    .mutation(async ({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      rateLimit(ctx.req.socket.remoteAddress ?? "unknown");
      return oracleConnection(async c => {
        const result = await c.execute<
          Actor & { PASSWORD_HASH: string; EXPIRED: number }
        >(
          "SELECT ID,USERNAME,DISPLAY_NAME,ROLE,PASSWORD_HASH,TO_CHAR(EXPIRES_AT AT TIME ZONE '+03:00','YYYY-MM-DD') EXPIRES_AT,CASE WHEN EXPIRES_AT IS NOT NULL AND EXPIRES_AT<=SYSTIMESTAMP THEN 1 ELSE 0 END EXPIRED FROM APP_USERS WHERE USERNAME=:username AND ACTIVE=1",
          { username: input.username.toLowerCase() },
          { outFormat: oracledb.OUT_FORMAT_OBJECT }
        );
        const actor = result.rows?.[0];
        const valid = await passwordMatches(
          input.password,
          actor?.PASSWORD_HASH ?? "0".repeat(32) + ":" + "0".repeat(128)
        );
        if (!actor || !valid)
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "اسم المستخدم أو كلمة المرور غير صحيحة",
          });
        if (actor.EXPIRED)
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message:
              "انتهت صلاحية الحساب التجريبي. تواصل مع مدير النظام لتجديد المدة.",
          });
        await startSession(c, ctx, actor);
        await c.commit();
        return { ok: true };
      });
    }),
  logout: publicProcedure.mutation(({ ctx }) => {
    requireSameOrigin(ctx.req);
    return oracleConnection(async c => {
      const token = parse(ctx.req.headers.cookie ?? "")[sessionCookie];
      if (token)
        await c.execute("DELETE FROM APP_SESSIONS WHERE TOKEN_HASH=:token", {
          token: sha256(token),
        });
      await c.commit();
      ctx.res.clearCookie(sessionCookie, {
        path: "/",
        httpOnly: true,
        sameSite: "strict",
        secure: ctx.req.secure,
      });
      return { ok: true };
    });
  }),
  users: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c, ["admin"]);
      return (
        (
          await c.execute<
            Actor & {
              ACTIVE: number;
              EXPIRES_AT: string | null;
              EXPIRED: number;
            }
          >(
            "SELECT ID,USERNAME,DISPLAY_NAME,ROLE,ACTIVE,TO_CHAR(EXPIRES_AT AT TIME ZONE '+03:00','YYYY-MM-DD') EXPIRES_AT,CASE WHEN EXPIRES_AT IS NOT NULL AND EXPIRES_AT<=SYSTIMESTAMP THEN 1 ELSE 0 END EXPIRED FROM APP_USERS ORDER BY ID",
            [],
            { outFormat: oracledb.OUT_FORMAT_OBJECT }
          )
        ).rows ?? []
      );
    })
  ),
  addUser: publicProcedure.input(userInput).mutation(({ ctx, input }) => {
    requireSameOrigin(ctx.req);
    return oracleConnection(async c => {
      const actor = await requireActor(ctx.req, c, ["admin"]);
      try {
        const r = await c.execute(
          "INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE,EXPIRES_AT) VALUES(:username,:name,:hash,:role,CASE WHEN :trial=1 THEN SYSTIMESTAMP+NUMTODSINTERVAL(:days,'DAY') ELSE NULL END) RETURNING ID INTO :id",
          {
            username: input.username.toLowerCase(),
            name: input.displayName,
            hash: await passwordHash(input.password),
            role: input.role,
            trial: input.accountType === "trial" ? 1 : 0,
            days: input.trialDays,
            id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
          }
        );
        await auditUser(
          c,
          actor,
          "INSERT",
          Number((r.outBinds!.id as number[])[0]),
          input.username
        );
        await c.commit();
        return { ok: true };
      } catch (e) {
        await c.rollback();
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "تعذر إنشاء المستخدم؛ تحقق من عدم تكرار الاسم",
          cause: e,
        });
      }
    });
  }),
  setUserActive: publicProcedure
    .input(z.object({ id: z.number().int().positive(), active: z.boolean() }))
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c => {
        const actor = await requireActor(ctx.req, c, ["admin"]);
        if (actor.ID === input.id)
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "لا يمكنك تعطيل حسابك",
          });
        try {
          const previous =
            (
              await c.execute<Record<string, unknown>>(
                "SELECT ID,USERNAME,DISPLAY_NAME,ROLE,ACTIVE,TO_CHAR(EXPIRES_AT AT TIME ZONE '+03:00','YYYY-MM-DD') EXPIRES_AT FROM APP_USERS WHERE ID=:id FOR UPDATE",
                { id: input.id },
                { outFormat: oracledb.OUT_FORMAT_OBJECT }
              )
            ).rows?.[0] ?? null;
          const r = await c.execute(
            "UPDATE APP_USERS SET ACTIVE=:active WHERE ID=:id",
            { id: input.id, active: input.active ? 1 : 0 }
          );
          if (r.rowsAffected !== 1)
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "المستخدم غير موجود",
            });
          await c.execute("DELETE FROM APP_SESSIONS WHERE USER_ID=:id", {
            id: input.id,
          });
          await auditUser(
            c,
            actor,
            "UPDATE",
            input.id,
            input.active ? "ACTIVATED" : "DISABLED",
            previous
          );
          await c.commit();
          return { ok: true };
        } catch (e) {
          await c.rollback();
          throw e;
        }
      });
    }),
  setUserTrial: publicProcedure
    .input(
      z.object({
        id: z.number().int().positive(),
        /** 0 clears the expiry (permanent account); 1..365 renews the trial. */
        days: z.number().int().min(0).max(365),
      })
    )
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c => {
        const actor = await requireActor(ctx.req, c, ["admin"]);
        try {
          const previous =
            (
              await c.execute<Record<string, unknown>>(
                "SELECT ID,USERNAME,DISPLAY_NAME,ROLE,ACTIVE,TO_CHAR(EXPIRES_AT AT TIME ZONE '+03:00','YYYY-MM-DD') EXPIRES_AT FROM APP_USERS WHERE ID=:id FOR UPDATE",
                { id: input.id },
                { outFormat: oracledb.OUT_FORMAT_OBJECT }
              )
            ).rows?.[0] ?? null;
          if (!previous)
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "المستخدم غير موجود",
            });
          const r = await c.execute(
            "UPDATE APP_USERS SET EXPIRES_AT=CASE WHEN :days=0 THEN NULL ELSE SYSTIMESTAMP+NUMTODSINTERVAL(:days,'DAY') END WHERE ID=:id",
            { id: input.id, days: input.days }
          );
          if (r.rowsAffected !== 1)
            throw new TRPCError({
              code: "NOT_FOUND",
              message: "المستخدم غير موجود",
            });
          // Expiry is part of the session check, so drop live sessions to
          // force a fresh decision on the next request.
          await c.execute("DELETE FROM APP_SESSIONS WHERE USER_ID=:id", {
            id: input.id,
          });
          await auditUser(
            c,
            actor,
            "UPDATE",
            input.id,
            input.days === 0 ? "TRIAL_CLEARED" : "TRIAL_" + input.days + "D",
            previous
          );
          await c.commit();
          return { ok: true };
        } catch (e) {
          await c.rollback();
          throw e;
        }
      });
    }),
  branding: publicProcedure.query(() => oracleConnection(getBranding)),
  saveBranding: publicProcedure
    .input(brandingInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        saveBranding(c, await requireActor(ctx.req, c, ["admin"]), input)
      );
    }),
  invoiceForPrint: publicProcedure
    .input(
      z.object({
        kind: z.enum(["sales", "purchases"]),
        id: z.number().int().positive(),
      })
    )
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c, ["admin", "editor", "viewer"]);
        return getInvoiceForPrint(c, input.kind, input.id);
      })
    ),
  purchaseInvoiceOptions: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c);
      return purchaseInvoiceOptions(c);
    })
  ),
  createPurchaseInvoice: publicProcedure
    .input(oraclePurchaseInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        createPurchaseInvoice(c, await requireActor(ctx.req, c), input)
      );
    }),
  purchaseAccountSettings: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c);
      const settings = await getPurchaseAccountSettings(c);
      const parents = await c.execute<{
        ID: number;
        NAME: string;
        MAIN_NUM: number;
        MAIN_NAME: string;
      }>(
        "SELECT b.BAR_NUM ID,b.AC_NAM NAME,b.AC_NUM MAIN_NUM,m.AC_NAM MAIN_NAME FROM BRANSH_ACT b JOIN MAIN_ACT m ON m.AC_NUM=b.AC_NUM ORDER BY b.AC_NUM,b.BAR_NUM",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      return { ...settings, parents: parents.rows ?? [] };
    })
  ),
  savePurchaseAccountSettings: publicProcedure
    .input(purchaseAccountSettingsInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        savePurchaseAccountSettings(
          c,
          await requireActor(ctx.req, c, ["admin"]),
          input
        )
      );
    }),
  salesAccountSettings: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c);
      const settings = await getSalesAccountSettings(c);
      const parents = await c.execute<{ ID: number; NAME: string }>(
        "SELECT BAR_NUM ID,AC_NAM NAME FROM BRANSH_ACT ORDER BY BAR_NUM",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      );
      return { ...settings, parents: parents.rows ?? [] };
    })
  ),
  saveSalesAccountSettings: publicProcedure
    .input(salesAccountSettingsInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        saveSalesAccountSettings(
          c,
          await requireActor(ctx.req, c, ["admin"]),
          input
        )
      );
    }),
  createOwnerAccount: publicProcedure
    .input(collectionAccountInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        createOwnerAccount(c, await requireActor(ctx.req, c), input)
      );
    }),
  createCollectionAccount: publicProcedure
    .input(collectionAccountInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        createCollectionAccount(c, await requireActor(ctx.req, c), input)
      );
    }),
  salesInvoiceOptions: publicProcedure.query(({ ctx }) =>
    oracleConnection(async c => {
      await requireActor(ctx.req, c);
      return salesInvoiceOptions(c);
    })
  ),
  createSalesInvoice: publicProcedure
    .input(salesInvoiceInput)
    .mutation(({ ctx, input }) => {
      requireSameOrigin(ctx.req);
      return oracleConnection(async c =>
        createSalesInvoice(c, await requireActor(ctx.req, c), input)
      );
    }),
  record: publicProcedure
    .input(z.object({ dataset: z.string(), id: z.number().int().positive() }))
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c);
        return loadRecord(c, definition(input.dataset), input.id);
      })
    ),
  write: publicProcedure.input(mutationInput).mutation(({ ctx, input }) => {
    requireSameOrigin(ctx.req);
    return oracleConnection(async c => {
      const actor = await requireActor(
        ctx.req,
        c,
        input.action === "delete" ? ["admin"] : ["admin", "editor"]
      );
      return writeRecord(c, actor, input);
    });
  }),
  history: publicProcedure
    .input(
      z.object({
        page: z.number().int().min(1).default(1),
        action: z.enum(["", "INSERT", "UPDATE", "DELETE"]).default(""),
        actor: z.string().trim().max(100).default(""),
        table: z.string().trim().max(128).default(""),
        recordId: z.string().trim().max(100).default(""),
        from: z.iso.date().optional(),
        to: z.iso.date().optional(),
      })
    )
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c, ["admin"]);
        if (input.from && input.to && input.from > input.to)
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "الفترة غير صحيحة",
          });
        const conditions: string[] = [];
        const binds: Record<string, unknown> = {};
        for (const [field, column] of [
          ["action", "ACTION"],
          ["table", "TABLE_NAME"],
          ["recordId", "RECORD_ID"],
        ] as const)
          if (input[field]) {
            conditions.push(column + "=:" + field);
            binds[field] = input[field];
          }
        if (input.actor) {
          conditions.push(
            "(INSTR(LOWER(ACTOR_NAME),LOWER(:actor))>0 OR ACTOR_ID=:actor)"
          );
          binds.actor = input.actor;
        }
        if (input.from) {
          conditions.push(
            "EVENT_AT>=TO_TIMESTAMP_TZ(:from||' 00:00:00 +03:00','YYYY-MM-DD HH24:MI:SS TZH:TZM')"
          );
          binds.from = input.from;
        }
        if (input.to) {
          conditions.push(
            "EVENT_AT<TO_TIMESTAMP_TZ(:to||' 00:00:00 +03:00','YYYY-MM-DD HH24:MI:SS TZH:TZM')+INTERVAL '1' DAY"
          );
          binds.to = input.to;
        }
        const where = conditions.length
          ? " WHERE " + conditions.join(" AND ")
          : "";
        const total = (
          await c.execute<{ N: number }>(
            "SELECT COUNT(*) N FROM APP_AUDIT_LOG" + where,
            binds,
            { outFormat: oracledb.OUT_FORMAT_OBJECT }
          )
        ).rows![0].N;
        const rows =
          (
            await c.execute<Record<string, string | number | null>>(
              "SELECT ID,TO_CHAR(EVENT_AT AT TIME ZONE '+03:00','YYYY-MM-DD HH24:MI:SS') EVENT_AT,ACTOR_ID,ACTOR_NAME,DB_USER,SOURCE,ACTION,TABLE_NAME,RECORD_ID,TRANSACTION_ID FROM APP_AUDIT_LOG" +
                where +
                " ORDER BY ID DESC OFFSET :skip ROWS FETCH NEXT 25 ROWS ONLY",
              { ...binds, skip: (input.page - 1) * 25 },
              { outFormat: oracledb.OUT_FORMAT_OBJECT }
            )
          ).rows ?? [];
        return { rows, total };
      })
    ),
  historyDetail: publicProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(({ ctx, input }) =>
      oracleConnection(async c => {
        await requireActor(ctx.req, c, ["admin"]);
        const r = await c.execute<{
          BEFORE_JSON: unknown;
          AFTER_JSON: unknown;
        }>(
          "SELECT BEFORE_JSON,AFTER_JSON FROM APP_AUDIT_LOG WHERE ID=:id",
          { id: input.id },
          { outFormat: oracledb.OUT_FORMAT_OBJECT }
        );
        const row = r.rows?.[0];
        if (!row) throw new TRPCError({ code: "NOT_FOUND" });
        const read = async (v: unknown) =>
          v === null
            ? null
            : JSON.parse(
                typeof v === "string"
                  ? v
                  : await (v as { getData: () => Promise<string> }).getData()
              );
        return {
          before: (await read(row.BEFORE_JSON)) as Record<
            string,
            unknown
          > | null,
          after: (await read(row.AFTER_JSON)) as Record<string, unknown> | null,
        };
      })
    ),
});
