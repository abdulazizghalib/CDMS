import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { requireDb } from "./db";
import { vehicles } from "../drizzle/schema";
import { eq } from "drizzle-orm";

export const vehicleInput = z.object({
  vin: z.string().optional(),
  make: z.string().min(1),
  model: z.string().min(1),
  year: z.number(),
  color: z.string().optional(),
  mileage: z.number().default(0),
  status: z.enum(["available", "reserved", "sold", "maintenance"]).default("available"),
  branch: z.string().default("الفرع الرئيسي"),
  purchasePrice: z.number().default(0),
  askingPrice: z.number().default(0),
  description: z.string().optional(),
});

export const vehiclesRouter = router({
  list: protectedProcedure
    .input(z.object({
      status: z.string().optional(),
      branch: z.string().optional(),
    }).optional())
    .query(async ({ input }) => {
      const db = await requireDb();
      if (!db) return [];
      
      let query = db.select().from(vehicles);
      
      // In a real app, we would add filters based on input
      const results = await query;
      return results;
    }),

  getById: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      const db = await requireDb();
      if (!db) return null;
      const result = await db.select().from(vehicles).where(eq(vehicles.id, input)).limit(1);
      return result[0] || null;
    }),

  updateStatus: protectedProcedure
    .input(z.object({
      id: z.number(),
      status: z.enum(["available", "reserved", "sold", "maintenance"]),
    }))
    .mutation(async ({ input }) => {
      const db = await requireDb();
      if (!db) throw new Error("Database not available");
      
      await db.update(vehicles)
        .set({ status: input.status })
        .where(eq(vehicles.id, input.id));
      return { success: true };
    }),
});
