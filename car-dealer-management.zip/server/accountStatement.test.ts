﻿import { describe, it, expect, vi } from "vitest";
import type { Connection } from "oracledb";
import { accountStatementInput } from "../shared/accountStatement";
import { getAccountStatement } from "./accountStatement";
describe("account statement", () => {
  it("rejects reversed periods and invalid dates", () => {
    expect(
      accountStatementInput.safeParse({
        accountNo: 1,
        date1: "2026-10-05",
        date2: "2026-10-01",
      }).success
    ).toBe(false);
    expect(
      accountStatementInput.safeParse({
        accountNo: 1,
        date1: "2026-02-30",
        date2: "2026-10-05",
      }).success
    ).toBe(false);
  });
  it("includes opening balance and calculates running balances in cents", async () => {
    const execute = vi.fn().mockResolvedValue({
      rows: [
        { IS_OPENING: 1, OPENING: 10.1 },
        { ID: 1, IS_OPENING: 0, DEBIT: 0.2, CREDIT: 0 },
        { ID: 2, IS_OPENING: 0, DEBIT: 0, CREDIT: 5.3 },
      ],
    });
    const r = await getAccountStatement({ execute } as unknown as Connection, {
      accountNo: 7,
      date1: "2026-10-01",
      date2: "2026-10-05",
    });
    expect(r.lines.map(l => l.BALANCE)).toEqual([10.3, 5]);
    expect(r.closing).toBe(5);
    expect(r.debit).toBe(0.2);
    expect(r.credit).toBe(5.3);
    expect(execute.mock.calls[0][0]).toContain(
      "AL_DATE<TO_DATE(:date2,'YYYY-MM-DD')+1"
    );
    expect(execute.mock.calls[0][1]).toEqual({
      accountNo: 7,
      date1: "2026-10-01",
      date2: "2026-10-05",
    });
  });
});
