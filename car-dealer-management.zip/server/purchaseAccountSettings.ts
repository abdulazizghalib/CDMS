﻿import { z } from "zod";
import oracledb, { type Connection } from "oracledb";
import { TRPCError } from "@trpc/server";
import { tagActor, type Actor } from "./oracleSession";
export const purchaseAccountSettingsInput = z.object({
  supplierParent: z.number().int().positive(),
  stockParent: z.number().int().positive(),
  ownerParent: z.number().int().positive(),
});
export async function getPurchaseAccountSettings(c: Connection) {
  const row = (
    await c.execute<{
      SUPPLIER_PARENT: number;
      STOCK_PARENT: number;
      OWNER_PARENT: number;
    }>(
      "SELECT SUPPLIER_PARENT,STOCK_PARENT,OWNER_PARENT FROM APP_PURCHASE_SETTINGS WHERE ID=1",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0];
  if (!row)
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "إعدادات حسابات المشتريات غير مهيأة",
    });
  return {
    supplierParent: row.SUPPLIER_PARENT,
    stockParent: row.STOCK_PARENT,
    ownerParent: row.OWNER_PARENT,
  };
}
export async function savePurchaseAccountSettings(
  c: Connection,
  actor: Actor,
  input: z.infer<typeof purchaseAccountSettingsInput>
) {
  input = purchaseAccountSettingsInput.parse(input);
  try {
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    const before = await getPurchaseAccountSettings(c);
    const parents =
      (
        await c.execute<{ BAR_NUM: number }>(
          "SELECT b.BAR_NUM FROM BRANSH_ACT b JOIN MAIN_ACT m ON m.AC_NUM=b.AC_NUM WHERE b.BAR_NUM IN (:s,:p,:owner)",
          {
            s: input.supplierParent,
            p: input.stockParent,
            owner: input.ownerParent,
          },
          { outFormat: oracledb.OUT_FORMAT_OBJECT }
        )
      ).rows ?? [];
    if (
      ![input.supplierParent, input.stockParent, input.ownerParent].every(id =>
        parents.some(a => a.BAR_NUM === id)
      )
    )
      throw new TRPCError({
        code: "BAD_REQUEST",
        message: "اختر حسابًا أبًا من المستوى الثاني مرتبطًا بحساب رئيسي موجود",
      });
    await tagActor(c, actor);
    await c.execute(
      "UPDATE APP_PURCHASE_SETTINGS SET SUPPLIER_PARENT=:s,STOCK_PARENT=:p,OWNER_PARENT=:owner WHERE ID=1",
      {
        s: input.supplierParent,
        p: input.stockParent,
        owner: input.ownerParent,
      }
    );
    await c.execute(
      "INSERT INTO APP_AUDIT_LOG(ACTOR_ID,ACTOR_NAME,DB_USER,SOURCE,ACTION,TABLE_NAME,RECORD_ID,BEFORE_JSON,AFTER_JSON,TRANSACTION_ID) VALUES(:actor,:name,USER,'DEALER_WEB','UPDATE','APP_PURCHASE_SETTINGS','1',:before,:after,DBMS_TRANSACTION.LOCAL_TRANSACTION_ID)",
      {
        actor: String(actor.ID),
        name: actor.DISPLAY_NAME,
        before: JSON.stringify(before),
        after: JSON.stringify(input),
      }
    );
    await c.commit();
    return input;
  } catch (error) {
    await c.rollback();
    throw error;
  }
}
