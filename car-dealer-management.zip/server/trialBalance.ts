import oracledb, { type Connection } from "oracledb";
import { journalReportInput } from "../shared/accountStatement";
import type { z } from "zod";
export async function getTrialBalance(
  c: Connection,
  raw: z.infer<typeof journalReportInput>,
  incomeOnly = false,
  balanceSheetOnly = false
) {
  const input = journalReportInput.parse(raw);
  const lines =
    (
      await c.execute<{
        AL_MAIN_NUM: number | null;
        AC_NAM: string | null;
        AL_BAR_NUM: number | null;
        BRANSHACNAM: string | null;
        AL_ACC_NO: number | null;
        AL_ACC_NAME: string | null;
        CREDIT: number;
        DEPIT: number;
        BALANCE: number;
      }>(
        `SELECT AL_MAIN_NUM,AC_NAM,AL_BAR_NUM,BRANSHACNAM,AL_ACC_NO,AL_ACC_NAME,NVL(SUM(AL_CREDIT_MOUNT),0) CREDIT,NVL(SUM(AL_DEPIT_MOUNT),0) DEPIT,NVL(SUM(AL_CREDIT_MOUNT),0)-NVL(SUM(AL_DEPIT_MOUNT),0) BALANCE FROM TRIAL_BALANCE_VIEW3 WHERE ${balanceSheetOnly ? "AL_MAIN_NUM IN (1000,1001,1002,1003,1004) AND " : incomeOnly ? "AL_MAIN_NUM IN (1005,1006) AND " : ""}AL_DATE>=TO_DATE(:date1,'YYYY-MM-DD') AND AL_DATE<TO_DATE(:date2,'YYYY-MM-DD')+1 GROUP BY AL_MAIN_NUM,AC_NAM,AL_BAR_NUM,BRANSHACNAM,AL_ACC_NO,AL_ACC_NAME ORDER BY AL_MAIN_NUM,AL_BAR_NUM,AL_ACC_NO,AC_NAM,BRANSHACNAM,AL_ACC_NAME`,
        input,
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows ?? [];
  const debit =
    lines.reduce((n, r) => n + Math.round(Number(r.DEPIT) * 100), 0) / 100;
  const credit =
    lines.reduce((n, r) => n + Math.round(Number(r.CREDIT) * 100), 0) / 100;
  return {
    ...input,
    lines,
    debit,
    credit,
    balance: Math.round((credit - debit) * 100) / 100,
  };
}
export async function getIncomeStatement(
  c: Connection,
  input: z.infer<typeof journalReportInput>
) {
  return getTrialBalance(c, input, true);
}
export async function getBalanceSheet(
  c: Connection,
  input: z.infer<typeof journalReportInput>
) {
  return getTrialBalance(c, input, false, true);
}
