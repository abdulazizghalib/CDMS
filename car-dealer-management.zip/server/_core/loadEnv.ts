import { config } from "dotenv";
// Shell variables take precedence; local secrets are never read in production.
if (process.env.NODE_ENV !== "production") config({ path: ".env.local", quiet: true });
config({ quiet: true });
