import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { requireDb } from "./db";
import { sales, purchaseInvoices, carPurchases, expenses, vehicles } from "../drizzle/schema";
import { sql } from "drizzle-orm";

export const reportsRouter = router({
  getSummary: protectedProcedure.query(async () => {
    const db = await requireDb();
    if (!db) return { totalSales: 0, totalPurchases: 0, totalExpenses: 0, inventoryValue: 0 };

    const [salesRes] = await db.select({ val: sql<number>`sum(${sales.totalAmount})` }).from(sales);
    const [purchasesRes] = await db.select({ val: sql<number>`sum(${purchaseInvoices.totalAmount})` }).from(purchaseInvoices);
    const [expensesRes] = await db.select({ val: sql<number>`sum(${expenses.amount})` }).from(expenses);
    const [inventoryRes] = await db.select({ val: sql<number>`sum(${vehicles.purchasePrice})` }).from(vehicles);

    return {
      totalSales: Number(salesRes?.val || 0),
      totalPurchases: Number(purchasesRes?.val || 0),
      totalExpenses: Number(expensesRes?.val || 0),
      inventoryValue: Number(inventoryRes?.val || 0),
    };
  }),

  getProfitability: protectedProcedure.query(async () => {
    const db = await requireDb();
    if (!db) return [];
    
    // In a real app, we would join sales and purchases by vehicleId
    const results = await db.select().from(sales).limit(10);
    return results;
  }),
});
