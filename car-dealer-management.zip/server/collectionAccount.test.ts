import { getPurchaseAccountSettings } from "./purchaseAccountSettings";
import { describe, it, expect, vi, beforeEach } from "vitest";
import type { Connection } from "oracledb";
import {
  createCollectionAccount,
  createOwnerAccount,
  collectionAccountInput,
} from "./collectionAccount";
import { writeRecord } from "./oracleWrite";
import { getSalesAccountSettings } from "./salesAccountSettings";
vi.mock("./oracleWrite", () => ({ writeRecord: vi.fn() }));
vi.mock("./salesAccountSettings", () => ({ getSalesAccountSettings: vi.fn() }));
vi.mock("./purchaseAccountSettings", () => ({
  getPurchaseAccountSettings: vi.fn(),
}));
const actor = {
  ID: 7,
  USERNAME: "tester",
  DISPLAY_NAME: "Tester",
  ROLE: "editor" as const,
};
function db(duplicate = false) {
  return {
    execute: vi.fn(async (sql: string) =>
      sql.includes("JOIN MAIN_ACT")
        ? { rows: [{ BAR_NUM: 2006 }] }
        : sql.includes("COUNT(*)")
          ? { rows: [{ N: duplicate ? 1 : 0 }] }
          : sql.includes("MAX(SON_NUM)")
            ? { rows: [{ ID: 4500 }] }
            : { rows: [] }
    ),
    rollback: vi.fn(),
    commit: vi.fn(),
  } as unknown as Connection;
}
beforeEach(() => {
  vi.resetAllMocks();
  vi.mocked(getPurchaseAccountSettings).mockResolvedValue({
    ownerParent: 2006,
    stockParent: 2003,
    supplierParent: 2007,
  });
  vi.mocked(getSalesAccountSettings).mockResolvedValue({
    paymentParent: 2006,
    salesParent: 2001,
  });
  vi.mocked(writeRecord).mockResolvedValue({ id: 4500, action: "insert" });
});
describe("Create collection account from sales invoice", () => {
  it("creates owners under the configured owner parent independently from collection settings", async () => {
    vi.mocked(getPurchaseAccountSettings).mockResolvedValue({
      ownerParent: 2008,
      stockParent: 2003,
      supplierParent: 2007,
    });
    const c = db();
    const account = await createOwnerAccount(c, actor, {
      name: "Owner",
      phone: "055",
      notes: "",
    });
    expect(account.BAR_NUM).toBe(2008);
    expect(writeRecord).toHaveBeenCalledWith(
      c,
      actor,
      expect.objectContaining({
        values: expect.objectContaining({ BAR_NUM: 2008, AC_NAM: "Owner" }),
      })
    );
    expect(getSalesAccountSettings).not.toHaveBeenCalled();
  });
  it("uses the configured parent and generated number rather than caller supplied values", async () => {
    const c = db();
    const parsed = collectionAccountInput.parse({
      name: " New customer ",
      phone: "055",
      parent: 2007,
      id: 1,
    });
    const result = await createCollectionAccount(c, actor, parsed);
    expect(result).toMatchObject({
      ID: 4500,
      NAME: "New customer",
      BAR_NUM: 2006,
    });
    expect(writeRecord).toHaveBeenCalledWith(
      c,
      actor,
      expect.objectContaining({
        id: 4500,
        values: expect.objectContaining({
          BAR_NUM: 2006,
          AC_NAM: "New customer",
          SON_PHONE: "055",
        }),
      })
    );
  });
  it("refuses duplicate names in the collection branch without writing", async () => {
    const c = db(true);
    await expect(
      createCollectionAccount(c, actor, {
        name: "Customer",
        phone: "",
        notes: "",
      })
    ).rejects.toThrow("يوجد حساب");
    expect(writeRecord).not.toHaveBeenCalled();
    expect(c.rollback).toHaveBeenCalled();
  });
  it("uses updated settings for account creation", async () => {
    vi.mocked(getSalesAccountSettings).mockResolvedValue({
      paymentParent: 2008,
      salesParent: 2001,
    });
    const c = db();
    await createCollectionAccount(c, actor, {
      name: "Customer",
      phone: "",
      notes: "",
    });
    expect(writeRecord).toHaveBeenCalledWith(
      c,
      actor,
      expect.objectContaining({
        values: expect.objectContaining({ BAR_NUM: 2008 }),
      })
    );
  });
  it("rolls back if audited account insertion fails", async () => {
    vi.mocked(writeRecord).mockRejectedValue(new Error("failure"));
    const c = db();
    await expect(
      createCollectionAccount(c, actor, {
        name: "Customer",
        phone: "",
        notes: "",
      })
    ).rejects.toThrow("تعذر");
    expect(c.rollback).toHaveBeenCalled();
  });
  it("rejects blank names and Arabic text exceeding Oracle byte capacity", () => {
    expect(collectionAccountInput.safeParse({ name: " " }).success).toBe(false);
    expect(
      collectionAccountInput.safeParse({ name: "س".repeat(51) }).success
    ).toBe(false);
  });
});
