import { attendanceRouter } from "./attendanceRouter";
import {oracleOperationsRouter} from "./oracleOperations";
import { oracleWorkspaceRouter } from "./oracleWorkspace";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { discoverOracleSchema, oracleRuntimeStatus, verifyLegacyMapping } from "./oracleValidation";
import { purchasesRouter } from "./purchases";
import { salesRouter } from "./sales";
import { customersRouter } from "./customers";
import { expensesRouter } from "./expenses";
import { vehiclesRouter } from "./vehicles";
import { reportsRouter } from "./reports";

export const appRouter = router({
  attendance: attendanceRouter,
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  oracleWorkspace: oracleWorkspaceRouter,
 oracleOperations:oracleOperationsRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  purchases: purchasesRouter,
  sales: salesRouter,
  customers: customersRouter,
  expenses: expensesRouter,
  vehicles: vehiclesRouter,
  reports: reportsRouter,
  oracle: router({
    status: publicProcedure.query(() => oracleRuntimeStatus()),
    discover: protectedProcedure.query(async () => {
      const status = oracleRuntimeStatus();
      if (!status.enabled) {
        return { status, snapshot: null, mapping: null } as const;
      }
      try {
        const snapshot = await discoverOracleSchema();
        return { status, snapshot, mapping: verifyLegacyMapping(snapshot) } as const;
      } catch {
        return { status: { enabled: false, reason: "تعذر الوصول إلى Oracle من بيئة التشغيل" }, snapshot: null, mapping: null } as const;
      }
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
