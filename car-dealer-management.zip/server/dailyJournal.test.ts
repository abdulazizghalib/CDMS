﻿import { describe, it, expect, vi } from "vitest";
import type { Connection } from "oracledb";
import { getDailyJournal } from "./dailyJournal";
import { journalReportInput } from "../shared/accountStatement";
describe("daily journal", () => {
  it("rejects invalid dates and reversed periods", () => {
    expect(
      journalReportInput.safeParse({ date1: "2026-02-30", date2: "2026-10-05" })
        .success
    ).toBe(false);
    expect(
      journalReportInput.safeParse({ date1: "2026-10-05", date2: "2026-10-01" })
        .success
    ).toBe(false);
  });
  it("returns all fields and sums both sides without rounding drift", async () => {
    const rows = [
      { AL_ID: 1, AL_SOURCE: "Sales", AL_DEPIT_MOUNT: 0.1, AL_CREDIT_MOUNT: 0 },
      {
        AL_ID: 2,
        AL_SOURCE: "Sales",
        AL_DEPIT_MOUNT: 0.2,
        AL_CREDIT_MOUNT: 0.3,
      },
    ];
    const execute = vi.fn().mockResolvedValue({ rows });
    const r = await getDailyJournal({ execute } as unknown as Connection, {
      date1: "2026-10-01",
      date2: "2026-10-05",
    });
    expect(r.lines).toEqual(rows);
    expect(r.debit).toBe(0.3);
    expect(r.credit).toBe(0.3);
    expect(r.difference).toBe(0);
    expect(execute.mock.calls[0][0]).toContain(
      "AL_DATE<TO_DATE(:date2,'YYYY-MM-DD')+1"
    );
  });
});
