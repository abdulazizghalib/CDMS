import oracledb, { type Connection } from "oracledb";
import type { AccountEntry } from "../shared/accountTree";
export async function getAccountTree(c: Connection): Promise<AccountEntry[]> {
  return (
    (
      await c.execute<AccountEntry>(
        `SELECT AC_NUM ID,AC_NAM NAME,CAST(NULL AS NUMBER) PARENT_ID,1 "LEVEL",DE_CR NATURE,NOTE NOTES,CAST(NULL AS VARCHAR2(100)) PHONE,CAST(NULL AS VARCHAR2(100)) ACTIVE FROM MAIN_ACT
    UNION ALL SELECT BAR_NUM,AC_NAM,AC_NUM,2,DE_CR,NOTE,NULL,NULL FROM BRANSH_ACT
    UNION ALL SELECT SON_NUM,AC_NAM,BAR_NUM,3,NULL,NOTE,CAST(SON_PHONE AS VARCHAR2(100)),CAST(SON_ACTIVATE AS VARCHAR2(100)) FROM SON_ACT
    ORDER BY 4,1`,
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows ?? []
  );
}
