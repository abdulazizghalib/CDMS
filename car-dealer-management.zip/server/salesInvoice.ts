import { getSalesAccountSettings } from "./salesAccountSettings";
import oracledb, { type Connection } from "oracledb";
import { TRPCError } from "@trpc/server";
import type { z } from "zod";
import { salesInvoiceInput } from "../shared/salesInvoice";
import { tagActor, type Actor } from "./oracleSession";
const options = { outFormat: oracledb.OUT_FORMAT_OBJECT };
function reject(message: string): never {
  throw new TRPCError({ code: "BAD_REQUEST", message });
}
type Car = {
  CP_ID: number;
  CP_TYPE: string;
  CP_PANEL: string;
  CP_MODEL: string | null;
  CP_COLOR: string | null;
  CP_HIKL: string | null;
  CP_CAR_LIST: string | null;
  CP_PURCH_PRICE: number;
  CP_STATUS: string | null;
};
export async function salesInvoiceOptions(c: Connection) {
  const accounts = await c.execute<{
    ID: number;
    NAME: string;
    BAR_NUM: number;
  }>(
    "SELECT SON_NUM ID,AC_NAM NAME,BAR_NUM FROM SON_ACT ORDER BY SON_NUM",
    [],
    options
  );
  const vehicles = await c.execute<{
    ID: number;
    CAR: string;
    PLATE: string;
    MODEL: string;
    COST: number;
  }>(
    "SELECT CP_ID ID,CP_TYPE CAR,CP_PANEL PLATE,CP_MODEL MODEL,CP_PURCH_PRICE COST FROM CAR_PURCHASE p WHERE NOT EXISTS (SELECT 1 FROM CAR_SALES_INV s WHERE s.CSI_CP_ID=p.CP_ID OR s.CSI_PANEL=p.CP_PANEL) AND CP_STATUS='unposted' AND NOT EXISTS (SELECT 1 FROM APP_DEALER_ACTIVITIES a WHERE a.VEHICLE_ID=p.CP_ID AND a.KIND='reservation' AND a.STATUS='active' AND a.SCHEDULED_AT>CAST(SYSTIMESTAMP AT TIME ZONE '+03:00' AS TIMESTAMP)) ORDER BY CP_ID ASC",
    [],
    options
  );
  return {
    accounts: accounts.rows ?? [],
    vehicles: vehicles.rows ?? [],
    settings: await getSalesAccountSettings(c),
  };
}
export async function createSalesInvoice(
  c: Connection,
  actor: Actor,
  input: z.infer<typeof salesInvoiceInput>
) {
  input = salesInvoiceInput.parse(input);
  try {
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    await c.execute(
      "LOCK TABLE SALES_INVOICE, CAR_SALES_INV, CAR_PURCHASE, STOCK_LEDGER, ACCOUNT_LEDGER, MAIN_ACT, BRANSH_ACT, SON_ACT IN EXCLUSIVE MODE NOWAIT"
    );
    const ready = await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM USER_TRIGGERS t JOIN USER_OBJECTS o ON o.OBJECT_NAME=t.TRIGGER_NAME AND o.OBJECT_TYPE='TRIGGER' WHERE t.TRIGGER_NAME IN ('APP_AUD_SALES_INVOICE','APP_AUD_CAR_SALES_INV','APP_AUD_CAR_PURCHASE','APP_AUD_STOCK_LEDGER','APP_AUD_ACCOUNT_LEDGER','SAL_INV_ACC_TRIGGER','CAR_SALES_INV_BEFORE','CAR_SALES_INV_TRIGGER') AND t.STATUS='ENABLED' AND o.STATUS='VALID'",
      [],
      options
    );
    if (ready.rows?.[0]?.N !== 8)
      reject("مشغلات فاتورة المبيعات وسجل التدقيق غير جاهزة");
    type Account = {
      SON_NUM: number;
      SONNAM: string;
      BAR_NUM: number;
      AC_NUM: number;
    };
    const accounts = await c.execute<Account>(
      "SELECT SON_NUM,SONNAM,BAR_NUM,AC_NUM FROM CLASSACT WHERE SON_NUM IN (:account,:payment,3005,3006) AND EXISTS (SELECT 1 FROM SON_ACT a WHERE a.SON_NUM=CLASSACT.SON_NUM)",
      { account: input.accountId, payment: input.paymentAccountId },
      options
    );
    const find = (id: number) => accounts.rows?.find(a => a.SON_NUM === id);
    if (!find(3005) || !find(3006))
      reject(
        "يلزم إعداد حسابي تكلفة المبيعات والمخزون 3005 و3006 في دليل الحسابات قبل الحفظ"
      );
    const account = find(input.accountId),
      payment = find(input.paymentAccountId);
    if (!account || !payment)
      reject("الحساب المحدد غير موجود في دليل الحسابات");
    const settings = await getSalesAccountSettings(c);
    if (
      account.BAR_NUM !== settings.salesParent ||
      payment.BAR_NUM !== settings.paymentParent
    )
      reject(
        "الحساب المختار لا يتبع إعدادات حسابات المبيعات الحالية؛ أعد فتح الفاتورة"
      );
    await tagActor(c, actor);
    const cars: Car[] = [];
    for (const line of input.lines) {
      const car = (
        await c.execute<Car>(
          "SELECT CP_ID,CP_TYPE,CP_PANEL,CP_MODEL,CP_COLOR,CP_HIKL,CP_CAR_LIST,CP_PURCH_PRICE,CP_STATUS FROM CAR_PURCHASE WHERE CP_ID=:id",
          { id: line.purchaseId },
          options
        )
      ).rows?.[0];
      if (!car) reject("السيارة المحددة غير موجودة");
      const sold = await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM CAR_SALES_INV WHERE CSI_CP_ID=:id OR CSI_PANEL=:plate",
        { id: line.purchaseId, plate: car.CP_PANEL },
        options
      );
      if (
        sold.rows?.[0]?.N ||
        car.CP_STATUS !== "unposted" ||
        cars.some(c => c.CP_PANEL === car.CP_PANEL)
      )
        reject(
          "السيارة غير متاحة للبيع؛ يجب أن تكون حالتها unposted وألا تكون مباعة أو مكررة في الفاتورة"
        );
      const reserved = await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM APP_DEALER_ACTIVITIES WHERE VEHICLE_ID=:id AND KIND='reservation' AND STATUS='active' AND SCHEDULED_AT>CAST(SYSTIMESTAMP AT TIME ZONE '+03:00' AS TIMESTAMP)",
        { id: car.CP_ID },
        options
      );
      if (reserved.rows?.[0]?.N)
        reject("السيارة محجوزة؛ أكمل الحجز أو ألغِه قبل إصدار فاتورة المبيعات");
      cars.push(car);
    }
    const money = (v: number) => Math.round(v * 100) / 100;
    const total = money(input.lines.reduce((n, l) => n + money(l.price), 0)),
      cost = money(cars.reduce((n, c) => n + Number(c.CP_PURCH_PRICE), 0));
    if (input.vat > total)
      reject("مبلغ الضريبة لا يمكن أن يتجاوز إجمالي الفاتورة");
    const saved = await c.execute(
      "INSERT INTO SALES_INVOICE(SI_ID,SI_DATE,SI_CUSTOMER,SI_PHONE,SI_BRANSH,SI_NOTE,SI_TOTAL,SI_VAT,SI_COST_TOTAL,SI_NUM,SI_BAR_NUM,SI_MAIN_NUM,SI_BC_NUM,SI_BC_BAR_NUM,SI_BC_MAIN_NUM,SI_ACT_NAME,SI_USER_ENTERED,SI_STATUS,SI_POST_STATUS) VALUES(APP_RECORD_SEQ.NEXTVAL,TO_DATE(:d,'YYYY-MM-DD'),:customer,:phone,:branch,:notes,:total,:vat,:cost,:account,:bar,:main,:payment,:pbar,:pmain,:pname,:actor,'المبيعات','UN POST') RETURNING SI_ID INTO :id",
      {
        d: input.date,
        customer: payment.SONNAM,
        phone: input.phone,
        branch: input.branch,
        notes: input.notes,
        total,
        vat: money(input.vat),
        cost,
        account: account.SON_NUM,
        bar: account.BAR_NUM,
        main: account.AC_NUM,
        payment: payment.SON_NUM,
        pbar: payment.BAR_NUM,
        pmain: payment.AC_NUM,
        pname: payment.SONNAM,
        actor: actor.USERNAME,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
      }
    );
    const id = Number((saved.outBinds as { id: number[] }).id[0]);
    const stockTrigger = await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM USER_TRIGGERS WHERE TRIGGER_NAME='CAR_SALES_TO_STOCK_LEDGER' AND STATUS='ENABLED'",
      [],
      options
    );
    for (let i = 0; i < input.lines.length; i++) {
      const line = input.lines[i];
      const car = cars[i];
      const savedLine = await c.execute(
        "INSERT INTO CAR_SALES_INV(CSI_INV_REF,CSI_CP_ID,CSI_TYPE,CSI_MODEL,CSI_COLOR,CSI_PANEL,CSI_DATE_IN,CSI_PURCH_PRICE,CSI_HIKL,CSI_SALES_PRICE,CSI_CAR_LIST) VALUES(:invoice,:car,:name,:model,:color,:plate,TO_DATE(:d,'YYYY-MM-DD'),:cost,:vin,:price,:list) RETURNING CSI_ID INTO :id",
        {
          invoice: id,
          car: car.CP_ID,
          name: car.CP_TYPE,
          model: car.CP_MODEL,
          color: car.CP_COLOR,
          plate: car.CP_PANEL,
          d: input.date,
          cost: car.CP_PURCH_PRICE,
          vin: car.CP_HIKL,
          price: money(line.price),
          list: car.CP_CAR_LIST,
          id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
        }
      );
      const lineId = Number((savedLine.outBinds as { id: number[] }).id[0]);
      if (!stockTrigger.rows?.[0]?.N) {
        await c.execute(
          "INSERT INTO STOCK_LEDGER(ST_ID,ST_DATE,ST_SNO,ST_INV_REF,ST_TYPE,ST_COLOR,ST_MODEL,ST_PANEL,ST_HIKL,ST_PRICE_OUT,ST_STATUS,ST_TAKE_STATUS,ST_CAR_LIST) SELECT (SELECT NVL(MAX(ST_ID),0)+1 FROM STOCK_LEDGER),CSI_DATE_IN,CSI_ID,CSI_INV_REF,CSI_TYPE,CSI_COLOR,CSI_MODEL,CSI_PANEL,CSI_HIKL,CSI_SALES_PRICE,'sales','taken',CSI_CAR_LIST FROM CAR_SALES_INV WHERE CSI_ID=:id",
          { id: lineId }
        );
        await c.execute(
          "UPDATE CAR_PURCHASE SET CP_PRICE_OUT=:price WHERE CP_ID=:id",
          { price: money(line.price), id: line.purchaseId }
        );
      }
    }
    await c.commit();
    return { id };
  } catch (error) {
    await c.rollback();
    if (error instanceof TRPCError) throw error;
    const n = (error as { errorNum?: number }).errorNum;
    throw new TRPCError({
      code: n === 54 || n === 60 ? "CONFLICT" : "INTERNAL_SERVER_ERROR",
      message:
        n === 54 || n === 60
          ? "توجد عملية أخرى قيد التنفيذ؛ أعد المحاولة"
          : "لم تُحفظ الفاتورة؛ تراجعت جميع التغييرات. راجع إعدادات الحسابات والمشغلات.",
      cause: error,
    });
  }
}
