import { describe, expect, it } from "vitest";
import { calculatePurchaseTotal, purchaseInput } from "./purchases";

const validPurchase = {
  invoiceNumber: "PUR-00001",
  vehicleName: "لكزس GX 550",
  vin: "JTJAAAA1234567890",
  vehicleYear: 2024,
  supplierName: "شركة المتحدة للسيارات",
  sourceType: "supplier" as const,
  purchaseDate: new Date("2026-08-26"),
  purchaseCost: 425000,
  preparationCost: 4500,
  transportCost: 1800,
  registrationCost: 1200,
  paymentStatus: "partial" as const,
  status: "preparing" as const,
  branchName: "الفرع الرئيسي",
  notes: "فحص شامل قبل العرض",
};

describe("purchases", () => {
  it("calculates the complete landed cost", () => {
    expect(calculatePurchaseTotal(validPurchase)).toBe(432500);
  });

  it("accepts a complete purchase record", () => {
    const result = purchaseInput.safeParse(validPurchase);
    expect(result.success).toBe(true);
  });

  it("rejects negative costs and missing vehicle name", () => {
    const result = purchaseInput.safeParse({ ...validPurchase, vehicleName: "", purchaseCost: -1 });
    expect(result.success).toBe(false);
  });
});
