import oracledb, { type Connection } from "oracledb";
import { TRPCError } from "@trpc/server";
import {
  activityInput,
  activityStatusInput,
  type DealerActivity,
} from "../shared/dealerActivities";
import { tagActor, type Actor } from "./oracleSession";
import type { z } from "zod";
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
export async function listActivities(c: Connection) {
  const rows = await c.execute<DealerActivity>(
    `SELECT a.ID,a.KIND,a.CUSTOMER,a.PHONE,a.VEHICLE_ID,p.CP_TYPE CAR,p.CP_MODEL MODEL,p.CP_PANEL PLATE,
    TO_CHAR(a.SCHEDULED_AT,'YYYY-MM-DD"T"HH24:MI') SCHEDULED_AT,a.NOTES,
    CASE WHEN a.KIND='reservation' AND a.STATUS='active' AND a.SCHEDULED_AT<=CAST(SYSTIMESTAMP AT TIME ZONE '+03:00' AS TIMESTAMP) THEN 'expired' ELSE a.STATUS END STATUS,
    u.DISPLAY_NAME CREATED_BY FROM APP_DEALER_ACTIVITIES a LEFT JOIN CAR_PURCHASE p ON p.CP_ID=a.VEHICLE_ID LEFT JOIN APP_USERS u ON u.ID=a.CREATED_BY ORDER BY a.SCHEDULED_AT DESC,a.ID DESC`,
    [],
    o
  );
  return rows.rows ?? [];
}
export async function activityVehicles(c: Connection, includeReserved = false) {
  return (
    (
      await c.execute<{
        ID: number;
        CAR: string;
        MODEL: string;
        PLATE: string;
      }>(
        `SELECT CP_ID ID,CP_TYPE CAR,CP_MODEL MODEL,CP_PANEL PLATE FROM CAR_PURCHASE p WHERE CP_STATUS='unposted'
    AND NOT EXISTS (SELECT 1 FROM CAR_SALES_INV s WHERE s.CSI_CP_ID=p.CP_ID OR s.CSI_PANEL=p.CP_PANEL)
    AND (:includeReserved=1 OR NOT EXISTS (SELECT 1 FROM APP_DEALER_ACTIVITIES a WHERE a.VEHICLE_ID=p.CP_ID AND a.KIND='reservation' AND a.STATUS='active' AND a.SCHEDULED_AT>CAST(SYSTIMESTAMP AT TIME ZONE '+03:00' AS TIMESTAMP))) ORDER BY CP_ID`,
        { includeReserved: includeReserved ? 1 : 0 },
        o
      )
    ).rows ?? []
  );
}
async function audit(
  c: Connection,
  actor: Actor,
  id: number,
  action: string,
  before: unknown,
  after: unknown
) {
  await c.execute(
    "INSERT INTO APP_AUDIT_LOG(ACTOR_ID,ACTOR_NAME,DB_USER,SOURCE,ACTION,TABLE_NAME,RECORD_ID,BEFORE_JSON,AFTER_JSON,TRANSACTION_ID) VALUES(:actor,:name,USER,'DEALER_WEB',:action,'APP_DEALER_ACTIVITIES',:id,:before,:after,DBMS_TRANSACTION.LOCAL_TRANSACTION_ID)",
    {
      actor: String(actor.ID),
      name: actor.DISPLAY_NAME,
      action,
      id: String(id),
      before: before ? JSON.stringify(before) : null,
      after: JSON.stringify(after),
    }
  );
}
export async function createActivity(
  c: Connection,
  actor: Actor,
  raw: z.infer<typeof activityInput>
) {
  const input = activityInput.parse(raw);
  if (new Date(input.scheduledAt + ":00+03:00").getTime() <= Date.now())
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "اختر موعدًا في المستقبل بتوقيت الرياض",
    });
  try {
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    await tagActor(c, actor);
    if (
      input.vehicleId !== null &&
      !(await activityVehicles(c, input.kind === "followup")).some(
        v => v.ID === input.vehicleId
      )
    )
      throw new TRPCError({
        code: "CONFLICT",
        message: "السيارة غير متاحة أو محجوزة؛ حدّث القائمة",
      });
    const result = await c.execute(
      "INSERT INTO APP_DEALER_ACTIVITIES(KIND,CUSTOMER,PHONE,VEHICLE_ID,SCHEDULED_AT,NOTES,CREATED_BY) VALUES(:kind,:customer,:phone,:vehicle,TO_TIMESTAMP(:scheduled,'YYYY-MM-DD\"T\"HH24:MI'),:notes,:actor) RETURNING ID INTO :id",
      {
        kind: input.kind,
        customer: input.customer,
        phone: input.phone,
        vehicle: input.vehicleId,
        scheduled: input.scheduledAt,
        notes: input.notes || null,
        actor: actor.ID,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
      }
    );
    const id = Number((result.outBinds as { id: number[] }).id[0]);
    await audit(c, actor, id, "INSERT", null, { ...input, status: "active" });
    await c.commit();
    return { id };
  } catch (e) {
    await c.rollback();
    throw e;
  }
}
export async function finishActivity(
  c: Connection,
  actor: Actor,
  input: z.infer<typeof activityStatusInput>
) {
  try {
    await c.execute(
      "SELECT ID FROM APP_WRITE_LOCK WHERE ID=1 FOR UPDATE NOWAIT"
    );
    const before = (
      await c.execute<{ STATUS: string; EXPIRED: number }>(
        "SELECT STATUS,CASE WHEN KIND='reservation' AND SCHEDULED_AT<=CAST(SYSTIMESTAMP AT TIME ZONE '+03:00' AS TIMESTAMP) THEN 1 ELSE 0 END EXPIRED FROM APP_DEALER_ACTIVITIES WHERE ID=:id FOR UPDATE",
        { id: input.id },
        o
      )
    ).rows?.[0];
    if (!before)
      throw new TRPCError({ code: "NOT_FOUND", message: "السجل غير موجود" });
    if (before.STATUS !== "active" || before.EXPIRED)
      throw new TRPCError({
        code: "CONFLICT",
        message: "السجل مغلق أو انتهت مدة الحجز",
      });
    await tagActor(c, actor);
    await c.execute(
      "UPDATE APP_DEALER_ACTIVITIES SET STATUS=:status,UPDATED_AT=SYSTIMESTAMP WHERE ID=:id",
      input
    );
    await audit(c, actor, input.id, "UPDATE", before, { status: input.status });
    await c.commit();
    return { ok: true };
  } catch (e) {
    await c.rollback();
    throw e;
  }
}
