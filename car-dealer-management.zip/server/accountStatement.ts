import oracledb, { type Connection } from "oracledb";
import { accountStatementInput } from "../shared/accountStatement";
import type { z } from "zod";
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
export async function statementAccounts(c: Connection) {
  return (
    (
      await c.execute<{ ID: number; NAME: string }>(
        "SELECT SON_NUM ID,AC_NAM NAME FROM SON_ACT UNION ALL SELECT AL_ACC_NO,MAX(AL_ACC_NAME) FROM ACCOUNT_LEDGER l WHERE AL_ACC_NO IS NOT NULL AND NOT EXISTS (SELECT 1 FROM SON_ACT s WHERE s.SON_NUM=l.AL_ACC_NO) GROUP BY AL_ACC_NO ORDER BY 1",
        [],
        o
      )
    ).rows ?? []
  );
}
export async function getAccountStatement(
  c: Connection,
  raw: z.infer<typeof accountStatementInput>
) {
  const input = accountStatementInput.parse(raw);
  // A single read-consistent query includes the opening balance and every movement in the period.
  const result = await c.execute<{
    ID: number;
    DATE: string;
    ACCOUNT: string | null;
    DEBIT: number;
    CREDIT: number;
    DOCUMENT: string | null;
    DOCUMENT_TYPE: string | null;
    NOTES: string | null;
    OPENING: number;
    IS_OPENING: number;
  }>(
    `SELECT AL_ID ID,TO_CHAR(AL_DATE,'YYYY-MM-DD HH24:MI:SS') "DATE",AL_ACC_NAME ACCOUNT,NVL(AL_DEPIT_MOUNT,0) DEBIT,NVL(AL_CREDIT_MOUNT,0) CREDIT,AL_DOC_ID DOCUMENT,AL_DOC_TYPE DOCUMENT_TYPE,AL_EXP NOTES,0 OPENING,0 IS_OPENING FROM ACCOUNT_LEDGER WHERE AL_ACC_NO=:accountNo AND AL_DATE>=TO_DATE(:date1,'YYYY-MM-DD') AND AL_DATE<TO_DATE(:date2,'YYYY-MM-DD')+1
 UNION ALL SELECT NULL,NULL,NULL,0,0,NULL,NULL,NULL,NVL(SUM(NVL(AL_DEPIT_MOUNT,0)-NVL(AL_CREDIT_MOUNT,0)),0),1 FROM ACCOUNT_LEDGER WHERE AL_ACC_NO=:accountNo AND AL_DATE<TO_DATE(:date1,'YYYY-MM-DD') ORDER BY 10 DESC,2,1`,
    input,
    o
  );
  const cents = (n: number) => Math.round(Number(n) * 100);
  const rows = result.rows ?? [],
    opening = cents(rows.find(r => r.IS_OPENING === 1)?.OPENING ?? 0);
  let balance = opening,
    debit = 0,
    credit = 0;
  const lines = rows
    .filter(r => r.IS_OPENING === 0)
    .map(({ OPENING, IS_OPENING, ...r }) => {
      debit += cents(r.DEBIT);
      credit += cents(r.CREDIT);
      balance += cents(r.DEBIT) - cents(r.CREDIT);
      return { ...r, BALANCE: balance / 100 };
    });
  return {
    ...input,
    opening: opening / 100,
    debit: debit / 100,
    credit: credit / 100,
    closing: balance / 100,
    lines,
  };
}
