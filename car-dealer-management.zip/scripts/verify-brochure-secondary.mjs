
import fs from "node:fs/promises";
const base = process.env.ORACLE_PREVIEW_URL || "http://127.0.0.1:3100";
const target = await (await fetch("http://127.0.0.1:9225/json/new?"+encodeURIComponent("about:blank"), {method:"PUT"})).json();
const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve,reject)=>{socket.addEventListener("open",resolve,{once:true});socket.addEventListener("error",reject,{once:true});});
let sequence=0; const requests=new Map(); const exceptions=[];
socket.addEventListener("message",event=>{const message=JSON.parse(event.data);if(message.id){const pending=requests.get(message.id);if(pending){requests.delete(message.id);clearTimeout(pending.timer);message.error?pending.reject(new Error(message.error.message)):pending.resolve(message.result);}}else if(message.method==="Runtime.exceptionThrown")exceptions.push(message.params.exceptionDetails.text);});
function send(method,params={}){return new Promise((resolve,reject)=>{const id=++sequence;const timer=setTimeout(()=>{requests.delete(id);reject(new Error("CDP timeout: "+method));},25000);requests.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});}
async function evaluate(expression){const result=await send("Runtime.evaluate",{expression,returnByValue:true,awaitPromise:true});if(result.exceptionDetails)throw new Error("Browser evaluation failed");return result.result?.value;}
async function waitFor(expression,label){const deadline=Date.now()+45000;while(Date.now()<deadline){if(await evaluate(expression))return;await new Promise(resolve=>setTimeout(resolve,400));}throw new Error("Timed out: "+label);}
async function capture(path){const shot=await send("Page.captureScreenshot",{format:"png",captureBeyondViewport:false});await fs.writeFile(path,Buffer.from(shot.data,"base64"));}

import "./../server/_core/loadEnv.ts";
import oracledb from "oracledb";
import {getOracleConfig} from "../server/oracle.ts";
import {passwordHash,tagActor} from "../server/oracleSession.ts";
import {randomBytes} from "node:crypto";
const c=await oracledb.getConnection(getOracleConfig());
const suffix=Date.now().toString();
const username="browser_verify_"+suffix;
const password=randomBytes(24).toString("base64url");
const name="اختبار آلي "+suffix;

let userId;
const results=[];
async function fill(selector,value){await evaluate("(()=>{const input=document.querySelector("+JSON.stringify(selector)+");Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,"+JSON.stringify(value)+");input.dispatchEvent(new Event('input',{bubbles:true}));})()");}

try {
 const created=await c.execute("INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE) VALUES(:username,:name,:hash,'admin') RETURNING ID INTO :id",{username,name,hash:await passwordHash(password),id:{dir:oracledb.BIND_OUT,type:oracledb.NUMBER}});
 userId=Number(created.outBinds.id[0]);await c.commit();
 await send("Page.enable");await send("Runtime.enable");
 await send("Emulation.setDeviceMetricsOverride",{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
 await send("Page.navigate",{url:base+"/?view=costCenters"});
 await waitFor("document.querySelector('input[autocomplete=username]')!==null","login form");
 if(await evaluate("Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='إضافة سجل')"))throw new Error("Anonymous visitor sees write controls");
 await fill("input[autocomplete=username]",username);
 await fill("input[autocomplete='current-password']",password);
 await evaluate("document.querySelector('input[autocomplete=username]').form.requestSubmit()");
 await waitFor("document.body.textContent.includes("+JSON.stringify(name)+")","authenticated identity");

 for(const width of [1440,390]) {
 await send('Emulation.setDeviceMetricsOverride',{width,height:1000,deviceScaleFactor:1,mobile:width===390});
 for(const view of ['customers','users','history','contracts']) {
 await send('Page.navigate',{url:base+'/?view='+view});
 await waitFor("document.querySelector('.oracle-content') && document.querySelectorAll('.dealer-car-card, .dealer-stat, .oracle-table-scroll tbody tr, .dealer-hub-card, .dealer-history, .dealer-users, .oracle-empty').length > 0",view);
 await new Promise(r=>setTimeout(r,1800));
 const state=await evaluate("({overflow:document.documentElement.scrollWidth>innerWidth,images:[...document.querySelectorAll('.dealer-car-image img')].every(i=>i.complete&&i.naturalWidth>0),cards:document.querySelectorAll('.dealer-car-card').length})");
 if(state.overflow)throw Error('Overflow '+view+' '+width);
 if(!state.images)throw Error('Images missing');
 await capture('brochure-'+view+'-'+width+'.png');results.push({view,width,...state});console.log('PASS '+view+' '+width);
 if(view==='customers') {
 await evaluate("document.querySelectorAll('.oracle-row-action')[1].click()");
 const selected=await evaluate("document.querySelector('.dealer-selected-row')?.textContent.includes(document.querySelector('.dealer-profile-heading h2').textContent)");
 if(!selected)throw Error('Customer profile does not follow selected row');
 await capture('brochure-customer-profile-'+width+'.png');
 }
 if(view==='contracts') {
 await evaluate("document.querySelector('.oracle-row-action').click()");
 await waitFor("Boolean(document.querySelector('.dealer-record-dialog'))",'record dialog');
 await capture('brochure-contract-dialog-'+width+'.png');
 }
 if(view==='inventory') {
 await evaluate("document.querySelector('.dealer-car-card').click()");
 await waitFor("Boolean(document.querySelector('.dealer-vehicle-detail'))",'vehicle detail');
 await capture('brochure-detail-'+width+'.png');
 }
 }
 }
 if(exceptions.length)throw Error(JSON.stringify(exceptions));
 await fs.writeFile('brochure-secondary-verification.json',JSON.stringify({results,exceptions},null,2));
} finally {if(userId){await c.execute('DELETE FROM APP_SESSIONS WHERE USER_ID=:id',{id:userId});await c.execute('DELETE FROM APP_USERS WHERE ID=:id AND USERNAME=:username',{id:userId,username});await c.commit();}await c.close();socket.close();await fetch('http://127.0.0.1:9225/json/close/'+target.id).catch(()=>{});}
