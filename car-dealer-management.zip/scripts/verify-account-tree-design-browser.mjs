import "../server/_core/loadEnv";
import fs from "node:fs/promises";
import { randomBytes, createHash } from "node:crypto";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
async function connect(url) {
  const socket = new WebSocket(url);
  await new Promise((r, j) => {
    socket.addEventListener("open", r, { once: true });
    socket.addEventListener("error", j, { once: true });
  });
  let seq = 0;
  const requests = new Map();
  socket.addEventListener("message", e => {
    const m = JSON.parse(e.data);
    if (m.id) {
      const p = requests.get(m.id);
      if (p) {
        requests.delete(m.id);
        clearTimeout(p.timer);
        m.error ? p.j(new Error(m.error.message)) : p.r(m.result);
      }
    }
  });
  return {
    socket,
    send: (method, params = {}) =>
      new Promise((r, j) => {
        const id = ++seq;
        const timer = setTimeout(
          () => j(new Error("CDP timeout " + method)),
          20000
        );
        requests.set(id, { r, j, timer });
        socket.send(JSON.stringify({ id, method, params }));
      }),
  };
}
const c = await oracledb.getConnection(getOracleConfig());
const token = randomBytes(32).toString("hex"),
  hash = createHash("sha256").update(token).digest("hex");
let browser, context, page;
try {
  const actor = (
    await c.execute(
      "SELECT ID FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND (EXPIRES_AT IS NULL OR EXPIRES_AT>SYSTIMESTAMP) AND ROWNUM=1",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0];
  if (!actor) throw new Error("No active admin for browser verification");
  await c.execute(
    "INSERT INTO APP_SESSIONS(TOKEN_HASH,USER_ID,EXPIRES_AT) VALUES(:token,:actor,SYSTIMESTAMP+NUMTODSINTERVAL(5,'MINUTE'))",
    { token: hash, actor: actor.ID }
  );
  await c.commit();
  const version = await (
    await fetch("http://127.0.0.1:9225/json/version")
  ).json();
  browser = await connect(version.webSocketDebuggerUrl);
  context = (await browser.send("Target.createBrowserContext"))
    .browserContextId;
  const target = (
    await browser.send("Target.createTarget", {
      url: "about:blank",
      browserContextId: context,
    })
  ).targetId;
  const list = await (await fetch("http://127.0.0.1:9225/json/list")).json();
  page = await connect(list.find(t => t.id === target).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Runtime.enable");
  await page.send("Emulation.setDeviceMetricsOverride", {
    width: 1440,
    height: 1100,
    deviceScaleFactor: 1,
    mobile: false,
  });
  await page.send("Network.setCookie", {
    name: "dealer_oracle_session",
    value: token,
    url: "http://localhost:3000",
    httpOnly: true,
    sameSite: "Lax",
  });
  const evaluate = async expression => {
    const r = await page.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text);
    return r.result.value;
  };
  async function wait(expr, label) {
    const until = Date.now() + 30000;
    while (Date.now() < until) {
      if (await evaluate(expr)) return;
      await new Promise(r => setTimeout(r, 300));
    }
    throw new Error(
      "Timed out: " +
        label +
        " - " +
        (await evaluate("document.body.innerText.slice(0,6000)"))
    );
  }
  await page.send("Page.navigate", {
    url: "http://localhost:3000/?view=accountDirectory",
  });
  await wait(
    "document.querySelector('[aria-label=\"شجرة دليل الحسابات\"] button') !== null",
    "account tree loaded"
  );
  await evaluate(
    "Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='توسيع الكل').click()"
  );
  await wait(
    "document.querySelector('[aria-label=\"شجرة دليل الحسابات\"] ul ul ul') !== null",
    "all three account levels"
  );
  const rows = await evaluate(
    "document.querySelectorAll('[aria-label=\"شجرة دليل الحسابات\"] li').length"
  );
  if (rows < 25)
    throw new Error("Accounts must not be limited to a table page");
  await evaluate("document.querySelector('[aria-label=\"شجرة دليل الحسابات\"] button[aria-pressed]').click()");
  await wait("document.querySelector('.account-details-identity') !== null", "details panel");
  const desktop = await page.send('Page.captureScreenshot',{format:'png'});await fs.writeFile('_account-tree-professional.png',Buffer.from(desktop.data,'base64'));
  await page.send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
  await evaluate("document.querySelector('button[aria-label=\"تحديث دليل الحسابات\"]').scrollIntoView({block:'start'})");
  await new Promise(r=>setTimeout(r,600));
  const overflow=await evaluate("document.documentElement.scrollWidth > window.innerWidth + 2");if(overflow)throw new Error('Mobile horizontal overflow');
  const mobile = await page.send('Page.captureScreenshot',{format:'png'});await fs.writeFile('_account-tree-mobile.png',Buffer.from(mobile.data,'base64'));
  await page.send('Emulation.setDeviceMetricsOverride',{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
  await evaluate("window.scrollTo(0,0)");
  await evaluate(
    "Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='إعدادات دليل الحسابات').click()"
  );
  await wait(
    "document.body.textContent.includes('إعدادات حسابات فواتير المبيعات')",
    "account settings"
  );
  await evaluate(
    "document.querySelector('[aria-label=\"شجرة دليل الحسابات\"] button[aria-pressed]').click()"
  );
  await wait(
    "Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='تعديل')",
    "selected account edit"
  );
  let shot = await page.send("Page.captureScreenshot", { format: "png" });
  await fs.writeFile(
    "_account-tree-preview.png",
    Buffer.from(shot.data, "base64")
  );
  console.log(
    "PASS Full three-level tree, selected account details and settings: " +
      rows +
      " accounts"
  );
  await evaluate(
    "Array.from(document.querySelectorAll('button')).filter(b=>b.textContent.trim()==='إضافة سجل')[1].click()"
  );
  await wait(
    "document.querySelector('[role=dialog] select')?.options.length>1",
    "parent account dropdown"
  );
  console.log("PASS Add level-two account with parent selector");
} finally {
  if (page) page.socket.close();
  if (browser && context) {
    await browser.send("Target.disposeBrowserContext", {
      browserContextId: context,
    });
    browser.socket.close();
  }
  await c.execute("DELETE FROM APP_SESSIONS WHERE TOKEN_HASH=:token", {
    token: hash,
  });
  await c.commit();
  await c.close();
}
