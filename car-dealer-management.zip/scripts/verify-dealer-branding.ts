﻿import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "../server/oracle";
import { passwordHash, type Actor } from "../server/oracleSession";
import {
  getBranding,
  saveBranding,
  getInvoiceForPrint,
} from "../server/dealerBranding";
const c = await oracledb.getConnection(getOracleConfig());
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
try {
  const before = await getBranding(c);
  const user = await c.execute(
    "INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE) VALUES(:u,'Branding verification',:h,'admin') RETURNING ID INTO :id",
    {
      u: "branding_verify_" + Date.now(),
      h: await passwordHash("branding-verification-password"),
      id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
    }
  );
  const actor: Actor = {
    ID: Number((user.outBinds as { id: number[] }).id[0]),
    USERNAME: "branding_verifier",
    DISPLAY_NAME: "Branding verification",
    ROLE: "admin",
  };
  const scoped = {
    execute: c.execute.bind(c),
    commit: async () => {},
    rollback: c.rollback.bind(c),
    close: async () => {},
  } as Connection;
  const logo =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aD1sAAAAASUVORK5CYII=";
  await saveBranding(scoped, actor, { name: "Verification Dealer", logo });
  assert.deepEqual(await getBranding(c), { name: "Verification Dealer", logo });
  for (const kind of ["sales", "purchases"] as const) {
    const table = kind === "sales" ? "SALES_INVOICE" : "PURCHASE_INVOICE",
      pk = kind === "sales" ? "SI_ID" : "PUI_ID";
    const id = (
      await c.execute<{ ID: number }>(
        "SELECT " + pk + " ID FROM " + table + " WHERE ROWNUM=1",
        [],
        o
      )
    ).rows![0].ID;
    const document = await getInvoiceForPrint(c, kind, id);
    assert.equal(document.branding.logo, logo);
    assert.equal(document.invoice.ID, id);
    assert.ok(document.lines.length > 0);
  }
  const logs = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM APP_AUDIT_LOG WHERE TABLE_NAME='APP_BRANDING' AND ACTOR_ID=:id",
      { id: String(actor.ID) },
      o
    )
  ).rows![0].N;
  assert.equal(logs, 1);
  await c.rollback();
  assert.deepEqual(await getBranding(c), before);
  console.log(
    "PASS Logo storage, invoice branding, audit and complete rollback"
  );
} finally {
  await c.rollback();
  await c.close();
}
