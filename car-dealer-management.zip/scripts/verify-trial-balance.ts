﻿import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
import { getTrialBalance } from "../server/trialBalance";
const c = await oracledb.getConnection(getOracleConfig());
try {
  const input = { date1: "2025-12-09", date2: "2025-12-09" };
  const data = await getTrialBalance(c, input);
  const totals = (
    await c.execute<{ D: number; C: number }>(
      "SELECT NVL(SUM(AL_DEPIT_MOUNT),0) D,NVL(SUM(AL_CREDIT_MOUNT),0) C FROM TRIAL_BALANCE_VIEW3 WHERE AL_DATE>=TO_DATE(:date1,'YYYY-MM-DD') AND AL_DATE<TO_DATE(:date2,'YYYY-MM-DD')+1",
      input,
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows![0];
  assert.equal(data.debit, Math.round(totals.D * 100) / 100);
  assert.equal(data.credit, Math.round(totals.C * 100) / 100);
  for (const row of data.lines)
    assert.equal(
      Math.round(row.BALANCE * 100),
      Math.round((row.CREDIT - row.DEPIT) * 100)
    );
  console.log(
    "PASS Oracle trial balance " +
      data.lines.length +
      " grouped rows, matching debit/credit totals and credit-minus-debit balances"
  );
} finally {
  await c.close();
}
