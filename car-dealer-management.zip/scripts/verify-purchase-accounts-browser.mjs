import "../server/_core/loadEnv";
import fs from "node:fs/promises";
import { randomBytes, createHash } from "node:crypto";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
async function connect(url) {
  const socket = new WebSocket(url);
  await new Promise((r, j) => {
    socket.addEventListener("open", r, { once: true });
    socket.addEventListener("error", j, { once: true });
  });
  let seq = 0;
  const requests = new Map();
  socket.addEventListener("message", e => {
    const m = JSON.parse(e.data);
    if (m.id) {
      const p = requests.get(m.id);
      if (p) {
        requests.delete(m.id);
        clearTimeout(p.timer);
        m.error ? p.j(new Error(m.error.message)) : p.r(m.result);
      }
    }
  });
  return {
    socket,
    send: (method, params = {}) =>
      new Promise((r, j) => {
        const id = ++seq;
        const timer = setTimeout(
          () => j(new Error("CDP timeout " + method)),
          20000
        );
        requests.set(id, { r, j, timer });
        socket.send(JSON.stringify({ id, method, params }));
      }),
  };
}
const c = await oracledb.getConnection(getOracleConfig());
const token = randomBytes(32).toString("hex"),
  hash = createHash("sha256").update(token).digest("hex");
let browser, context, page;
try {
  const actor = (
    await c.execute(
      "SELECT ID FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND (EXPIRES_AT IS NULL OR EXPIRES_AT>SYSTIMESTAMP) AND ROWNUM=1",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0];
  if (!actor) throw new Error("No active admin for browser verification");
  await c.execute(
    "INSERT INTO APP_SESSIONS(TOKEN_HASH,USER_ID,EXPIRES_AT) VALUES(:token,:actor,SYSTIMESTAMP+NUMTODSINTERVAL(5,'MINUTE'))",
    { token: hash, actor: actor.ID }
  );
  await c.commit();
  const version = await (
    await fetch("http://127.0.0.1:9225/json/version")
  ).json();
  browser = await connect(version.webSocketDebuggerUrl);
  context = (await browser.send("Target.createBrowserContext"))
    .browserContextId;
  const target = (
    await browser.send("Target.createTarget", {
      url: "about:blank",
      browserContextId: context,
    })
  ).targetId;
  const list = await (await fetch("http://127.0.0.1:9225/json/list")).json();
  page = await connect(list.find(t => t.id === target).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Runtime.enable");
  await page.send("Emulation.setDeviceMetricsOverride", {
    width: 1440,
    height: 1100,
    deviceScaleFactor: 1,
    mobile: false,
  });
  await page.send("Network.setCookie", {
    name: "dealer_oracle_session",
    value: token,
    url: "http://localhost:3000",
    httpOnly: true,
    sameSite: "Lax",
  });
  const evaluate = async expression => {
    const r = await page.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text);
    return r.result.value;
  };
  async function wait(expr, label) {
    const until = Date.now() + 30000;
    while (Date.now() < until) {
      if (await evaluate(expr)) return;
      await new Promise(r => setTimeout(r, 300));
    }
    throw new Error(
      "Timed out: " +
        label +
        " - " +
        (await evaluate("document.body.innerText.slice(0,6000)"))
    );
  }
  await page.send("Page.navigate", {
    url: "http://localhost:3000/?view=settings",
  });
  await wait(
    "Array.from(document.querySelectorAll('section')).some(s=>s.querySelector('h2')?.textContent==='إعدادات حسابات فواتير المشتريات' && s.querySelectorAll('select').length===3)",
    "purchase settings"
  );
  const settings = await evaluate(
    "Array.from(document.querySelectorAll('section')).find(s=>s.querySelector('h2')?.textContent==='إعدادات حسابات فواتير المشتريات').innerText"
  );
  for (const label of ["مخزون المعرض", "المالك", "الموردين"])
    if (!settings.includes(label)) throw new Error("Missing settings " + label);
  await wait(
    "Array.from(document.querySelectorAll('section')).find(s=>s.querySelector('h2')?.textContent==='إعدادات حسابات فواتير المشتريات').querySelectorAll('select')[0].value==='2003'",
    "settings defaults"
  );
  const values = await evaluate(
    "Array.from(Array.from(document.querySelectorAll('section')).find(s=>s.querySelector('h2')?.textContent==='إعدادات حسابات فواتير المشتريات').querySelectorAll('select')).map(s=>s.value)"
  );
  if (JSON.stringify(values) !== JSON.stringify(["2003", "2006", "2007"]))
    throw new Error("Wrong default parents " + values);
  console.log("PASS Three purchase account settings and defaults");
  await page.send("Page.navigate", {
    url: "http://localhost:3000/?view=purchases",
  });
  await wait(
    "Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='إضافة فاتورة مشتريات')",
    "purchase page"
  );
  await evaluate(
    "Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='إضافة فاتورة مشتريات').click()"
  );
  await wait(
    "document.querySelectorAll('[role=dialog] select').length===3 && Array.from(document.querySelectorAll('[role=dialog] select')).every(s=>s.options.length>1)",
    "three invoice lists"
  );
  const fields = await evaluate(
    "Array.from(document.querySelectorAll('[role=dialog] select')).map(s=>({label:s.closest('label').querySelector('span').textContent,count:s.options.length}))"
  );
  if (fields.map(f => f.label).join(",") !== "مخزون المعرض *,المورد *,المالك *")
    throw new Error("Wrong fields " + JSON.stringify(fields));
  console.log("PASS Stock, supplier and owner lists populated");
  const shot = await page.send("Page.captureScreenshot", { format: "png" });
  await fs.writeFile(
    "_purchase-three-accounts-preview.png",
    Buffer.from(shot.data, "base64")
  );
} finally {
  if (page) page.socket.close();
  if (browser && context) {
    await browser.send("Target.disposeBrowserContext", {
      browserContextId: context,
    });
    browser.socket.close();
  }
  await c.execute("DELETE FROM APP_SESSIONS WHERE TOKEN_HASH=:token", {
    token: hash,
  });
  await c.commit();
  await c.close();
}
