
import fs from "node:fs/promises";
const base = process.env.ORACLE_PREVIEW_URL || "http://127.0.0.1:3100";
const target = await (await fetch("http://127.0.0.1:9225/json/new?"+encodeURIComponent("about:blank"), {method:"PUT"})).json();
const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve,reject)=>{socket.addEventListener("open",resolve,{once:true});socket.addEventListener("error",reject,{once:true});});
let sequence=0; const requests=new Map(); const exceptions=[];
socket.addEventListener("message",event=>{const message=JSON.parse(event.data);if(message.id){const pending=requests.get(message.id);if(pending){requests.delete(message.id);clearTimeout(pending.timer);message.error?pending.reject(new Error(message.error.message)):pending.resolve(message.result);}}else if(message.method==="Runtime.exceptionThrown")exceptions.push(message.params.exceptionDetails.text);});
function send(method,params={}){return new Promise((resolve,reject)=>{const id=++sequence;const timer=setTimeout(()=>{requests.delete(id);reject(new Error("CDP timeout: "+method));},25000);requests.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});}
async function evaluate(expression){const result=await send("Runtime.evaluate",{expression,returnByValue:true,awaitPromise:true});if(result.exceptionDetails)throw new Error("Browser evaluation failed");return result.result?.value;}
async function waitFor(expression,label){const deadline=Date.now()+45000;while(Date.now()<deadline){if(await evaluate(expression))return;await new Promise(resolve=>setTimeout(resolve,400));}throw new Error("Timed out: "+label);}
async function capture(path){const shot=await send("Page.captureScreenshot",{format:"png",captureBeyondViewport:false});await fs.writeFile(path,Buffer.from(shot.data,"base64"));}
const results=[];
function pass(name){results.push({name,passed:true});console.log("PASS "+name);}
try {
 await send("Page.enable");await send("Runtime.enable");
 await send("Emulation.setDeviceMetricsOverride",{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
 await send("Page.navigate",{url:base+"/?view=dashboard"});
 await waitFor("document.querySelectorAll('.oracle-stat-grid .oracle-stat strong').length === 4","dashboard data");
 pass("Desktop dashboard loads Oracle totals");await capture("oracle-dashboard-desktop.png");
 await evaluate("Array.from(document.querySelectorAll('.oracle-sidebar nav button')).find(b=>b.textContent.includes('مخزون السيارات')).click()");
 await waitFor("document.querySelectorAll('.oracle-data-panel > .oracle-table-scroll tbody tr').length === 25","inventory first page");
 pass("Inventory shows 25 live rows");
 await evaluate("document.querySelector('button[aria-label=\"الصفحة التالية\"]').click()");
 await waitFor("document.querySelector('.oracle-pagination > div > span')?.textContent.startsWith('2 /')","pagination");
 pass("Inventory pagination");
 await evaluate("(()=>{const input=document.querySelector('.oracle-search input');Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,'zz-no-match-review-987654321');input.dispatchEvent(new Event('input',{bubbles:true}));})()");
 await evaluate("document.querySelector('.oracle-table-toolbar form').requestSubmit()");
 await waitFor("document.querySelector('.oracle-empty h3')?.textContent.includes('لا توجد نتائج')","empty search");
 pass("Search filters through server and renders empty result");
 await evaluate("Array.from(document.querySelectorAll('.oracle-sidebar nav button')).find(b=>b.textContent.trim()==='المبيعات').click()");
 await waitFor("document.querySelector('.oracle-row-action') !== null","sales list");
 await evaluate("document.querySelector('.oracle-row-action').click()");
 await waitFor("document.querySelector('[role=dialog] .oracle-data-panel .oracle-table-scroll tbody tr') !== null","sales invoice details");
 pass("Sales invoice opens linked vehicle details");
 await send("Page.navigate",{url:base+"/?view=purchases"});
 await waitFor("document.querySelector('.oracle-row-action') !== null","purchases list");
 await evaluate("document.querySelector('.oracle-row-action').click()");
 await waitFor("document.querySelector('[role=dialog] .oracle-data-panel .oracle-table-scroll tbody tr') !== null","purchase invoice details");
 pass("Purchase invoice opens linked vehicle details");
 await send("Page.navigate",{url:base+"/?view=audit"});
 await waitFor("document.querySelector('.oracle-audit') !== null","database audit");
 const auditCounts=await evaluate("Array.from(document.querySelectorAll('.oracle-audit > section table tbody')).map(t=>t.rows.length)");
 if(!auditCounts.includes(56)||!auditCounts.includes(35))throw new Error("Incomplete trigger/table coverage");
 pass("Audit displays all 56 triggers and 35 tables");
 await send("Emulation.setDeviceMetricsOverride",{width:390,height:844,deviceScaleFactor:1,mobile:true});
 await send("Page.navigate",{url:base+"/?view=dashboard"});
 await waitFor("document.querySelectorAll('.oracle-stat-grid .oracle-stat strong').length===4","mobile dashboard");
 if(!await evaluate("document.documentElement.scrollWidth <= window.innerWidth"))throw new Error("Mobile page overflows horizontally");
 await capture("oracle-dashboard-mobile.png");pass("Mobile dashboard has no horizontal overflow");
 await evaluate("document.querySelector('.oracle-menu').click()");
 await waitFor("document.querySelector('.oracle-sidebar.is-open') !== null","mobile menu");
 await evaluate("Array.from(document.querySelectorAll('.oracle-sidebar nav button')).find(b=>b.textContent.includes('مخزون السيارات')).click()");
 await waitFor("document.querySelectorAll('.oracle-table-scroll tbody tr').length===25 && !document.querySelector('.oracle-sidebar.is-open')","mobile navigation");
 if(!await evaluate("document.documentElement.scrollWidth <= window.innerWidth"))throw new Error("Mobile inventory overflows");
 await capture("oracle-inventory-mobile.png");pass("Mobile navigation closes drawer and confines table scrolling");
 if(exceptions.length)throw new Error("Browser runtime exceptions: "+exceptions.length);
 pass("No browser runtime exceptions");
 await fs.writeFile("oracle-browser-verification.json",JSON.stringify({checkedAt:new Date().toISOString(),results},null,2));
} finally {socket.close();await fetch("http://127.0.0.1:9225/json/close/"+target.id).catch(()=>{});}
