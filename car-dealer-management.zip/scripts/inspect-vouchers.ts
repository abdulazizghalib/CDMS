﻿import "../server/_core/loadEnv";
import oracledb from "oracledb";
import {getOracleConfig} from "../server/oracle";
const c=await oracledb.getConnection(getOracleConfig());try {const o={outFormat:oracledb.OUT_FORMAT_OBJECT};for(const t of ['BB_ENT','C_ENT','A_ENT']){console.log(t);console.log((await c.execute("SELECT COLUMN_NAME,DATA_TYPE,DATA_LENGTH,NULLABLE,DATA_DEFAULT FROM USER_TAB_COLUMNS WHERE TABLE_NAME=:t ORDER BY COLUMN_ID",{t},o)).rows);console.log((await c.execute("SELECT TRIGGER_NAME,STATUS,TRIGGER_BODY FROM USER_TRIGGERS WHERE TABLE_NAME=:t AND TRIGGER_NAME NOT LIKE 'APP_AUD%'",{t},o)).rows);}}finally{await c.close();}
