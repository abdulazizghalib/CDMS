import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "../server/oracle";
import { createOwnerAccount } from "../server/collectionAccount";
import { getPurchaseAccountSettings } from "../server/purchaseAccountSettings";
import { purchaseInvoiceOptions } from "../server/oraclePurchaseInvoice";
import type { Actor } from "../server/oracleSession";
const c = await oracledb.getConnection(getOracleConfig());
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
try {
  const before = (
    await c.execute<{ N: number }>("SELECT COUNT(*) N FROM SON_ACT", [], o)
  ).rows![0].N;
  const actor = (
    await c.execute<Actor>(
      "SELECT ID,USERNAME,DISPLAY_NAME,ROLE FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND ROWNUM=1",
      [],
      o
    )
  ).rows![0];
  const scoped = {
    execute: c.execute.bind(c),
    commit: async () => {},
    rollback: async () => {},
  } as Connection;
  const name = "Inline owner verification " + Date.now();
  const settings = await getPurchaseAccountSettings(c);
  const account = await createOwnerAccount(scoped, actor, {
    name,
    phone: "0550000000",
    notes: "Rollback verification",
  });
  assert.equal(account.BAR_NUM, settings.ownerParent);
  assert(
    (await purchaseInvoiceOptions(c)).owners.some(
      a => a.ID === account.ID && a.BAR_NUM === settings.ownerParent
    )
  );
  const audit = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM APP_AUDIT_LOG WHERE TABLE_NAME='SON_ACT' AND RECORD_ID=:id AND ACTION='INSERT' AND ACTOR_ID=:actor",
      { id: String(account.ID), actor: String(actor.ID) },
      o
    )
  ).rows![0].N;
  assert.equal(audit, 1);
  await assert.rejects(() =>
    createOwnerAccount(scoped, actor, { name, phone: "", notes: "" })
  );
  await c.rollback();
  assert.equal(
    (await c.execute<{ N: number }>("SELECT COUNT(*) N FROM SON_ACT", [], o))
      .rows![0].N,
    before
  );
  console.log(
    "PASS Inline owner creation, configured parent, invoice options, audit, duplicate prevention and complete rollback"
  );
} finally {
  await c.rollback();
  await c.close();
}
