﻿import '../server/_core/loadEnv';
import assert from 'node:assert/strict';
import oracledb,{type Connection} from 'oracledb';
import {getOracleConfig} from '../server/oracle';
import {getSalesAccountSettings,saveSalesAccountSettings} from '../server/salesAccountSettings';
import {passwordHash,type Actor} from '../server/oracleSession';
const c=await oracledb.getConnection(getOracleConfig());const o={outFormat:oracledb.OUT_FORMAT_OBJECT};
const before=await getSalesAccountSettings(c);
try{
 const saved=await c.execute("INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE) VALUES(:u,'Settings verification',:hash,'admin') RETURNING ID INTO :id",{u:'settings_verify_'+Date.now(),hash:await passwordHash('settings-verification-password'),id:{dir:oracledb.BIND_OUT,type:oracledb.NUMBER}});
 const actor:Actor={ID:Number((saved.outBinds as {id:number[]}).id[0]),USERNAME:'settings_verifier',DISPLAY_NAME:'Settings verification',ROLE:'admin'};
 const scoped={execute:c.execute.bind(c),commit:async()=>{},rollback:c.rollback.bind(c),close:async()=>{}} as Connection;
 const changed={salesParent:before.paymentParent,paymentParent:before.salesParent};
 await saveSalesAccountSettings(scoped,actor,changed);
 assert.deepEqual(await getSalesAccountSettings(c),changed);
 const audit=(await c.execute<{N:number}>("SELECT COUNT(*) N FROM APP_AUDIT_LOG WHERE TABLE_NAME='APP_SALES_SETTINGS' AND ACTOR_ID=:id",{id:String(actor.ID)},o)).rows![0].N;
 assert.equal(audit,1);
 await c.rollback();assert.deepEqual(await getSalesAccountSettings(c),before);
 console.log('PASS Settings persistence, actor audit and rollback; defaults unchanged');
}finally{await c.rollback();await c.close();}
