import "../server/_core/loadEnv";
import fs from "node:fs/promises";
import { randomBytes, createHash } from "node:crypto";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
async function connect(url) {
  const socket = new WebSocket(url);
  await new Promise((r, j) => {
    socket.addEventListener("open", r, { once: true });
    socket.addEventListener("error", j, { once: true });
  });
  let seq = 0;
  const requests = new Map();
  socket.addEventListener("message", e => {
    const m = JSON.parse(e.data);
    if (m.id) {
      const p = requests.get(m.id);
      if (p) {
        requests.delete(m.id);
        clearTimeout(p.timer);
        m.error ? p.j(new Error(m.error.message)) : p.r(m.result);
      }
    }
  });
  return {
    socket,
    send: (method, params = {}) =>
      new Promise((r, j) => {
        const id = ++seq;
        const timer = setTimeout(
          () => j(new Error("CDP timeout " + method)),
          20000
        );
        requests.set(id, { r, j, timer });
        socket.send(JSON.stringify({ id, method, params }));
      }),
  };
}
const c = await oracledb.getConnection(getOracleConfig());
const token = randomBytes(32).toString("hex"),
  hash = createHash("sha256").update(token).digest("hex");
let browser, context, page;
try {
  const actor = (
    await c.execute(
      "SELECT ID FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND (EXPIRES_AT IS NULL OR EXPIRES_AT>SYSTIMESTAMP) AND ROWNUM=1",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0];
  if (!actor) throw new Error("No active admin for browser verification");
  await c.execute(
    "INSERT INTO APP_SESSIONS(TOKEN_HASH,USER_ID,EXPIRES_AT) VALUES(:token,:actor,SYSTIMESTAMP+NUMTODSINTERVAL(5,'MINUTE'))",
    { token: hash, actor: actor.ID }
  );
  await c.commit();
  const version = await (
    await fetch("http://127.0.0.1:9225/json/version")
  ).json();
  browser = await connect(version.webSocketDebuggerUrl);
  context = (await browser.send("Target.createBrowserContext"))
    .browserContextId;
  const target = (
    await browser.send("Target.createTarget", {
      url: "about:blank",
      browserContextId: context,
    })
  ).targetId;
  const list = await (await fetch("http://127.0.0.1:9225/json/list")).json();
  page = await connect(list.find(t => t.id === target).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Runtime.enable");
  await page.send("Emulation.setDeviceMetricsOverride", {
    width: 1440,
    height: 1100,
    deviceScaleFactor: 1,
    mobile: false,
  });
  await page.send("Network.setCookie", {
    name: "dealer_oracle_session",
    value: token,
    url: "http://localhost:3000",
    httpOnly: true,
    sameSite: "Lax",
  });
  const evaluate = async expression => {
    const r = await page.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text);
    return r.result.value;
  };
  async function wait(expr, label) {
    const until = Date.now() + 30000;
    while (Date.now() < until) {
      if (await evaluate(expr)) return;
      await new Promise(r => setTimeout(r, 300));
    }
    throw new Error(
      "Timed out: " +
        label +
        " - " +
        (await evaluate("document.body.innerText.slice(0,6000)"))
    );
  }
  await page.send('Page.navigate',{url:'http://localhost:3000/?view=vouchers'});
  await wait("document.querySelectorAll('.dealer-hub-card').length===3",'vouchers hub');
  console.log('PASS Vouchers parent menu with three document types');
  for(const [kind,title] of [['receipts','سند قبض'],['expenses','سند صرف'],['journal','سند قيد']]){
   await page.send('Page.navigate',{url:'http://localhost:3000/?view='+kind});
   await wait(`Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='إضافة ${title}')`,'voucher button '+kind);
   await evaluate(`Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='إضافة ${title}').click()`);
   await wait("document.querySelector('[role=dialog] select')?.options.length>2",'accounts '+kind);
   const fields=await evaluate("({selects:document.querySelectorAll('[role=dialog] select').length,amount:!!document.querySelector('[role=dialog] input[type=number]'),date:!!document.querySelector('[role=dialog] input[type=date]'),note:!!document.querySelector('[role=dialog] textarea')})");
   if(fields.selects!==2 || !fields.amount || !fields.date || !fields.note)throw new Error('Missing voucher fields');
   if(kind==='receipts'){const shot=await page.send('Page.captureScreenshot',{format:'png'});await fs.writeFile('_voucher-form-preview.png',Buffer.from(shot.data,'base64'));}
   console.log('PASS '+kind+' add form, searchable account selectors, amount/date/description');
  }
} finally {
  if (page) page.socket.close();
  if (browser && context) {
    await browser.send("Target.disposeBrowserContext", {
      browserContextId: context,
    });
    browser.socket.close();
  }
  await c.execute("DELETE FROM APP_SESSIONS WHERE TOKEN_HASH=:token", {
    token: hash,
  });
  await c.commit();
  await c.close();
}
