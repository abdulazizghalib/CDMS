import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "../server/oracle";
import {
  saveShift,
  assignShift,
  myAttendance,
  checkIn,
  checkOut,
  attendanceReport,
  attendanceSettings,
} from "../server/attendance";
import type { Actor } from "../server/oracleSession";
const c = await oracledb.getConnection(getOracleConfig()),
  o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
const scoped = {
  execute: c.execute.bind(c),
  commit: async () => {},
  rollback: async () => {},
  close: async () => {},
} as Connection;
try {
  const admin = (
    await c.execute<Actor>(
      "SELECT ID,USERNAME,DISPLAY_NAME,ROLE FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND ROWNUM=1",
      [],
      o
    )
  ).rows![0];
  const before = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM APP_EMPLOYEE_ATTENDANCE",
      [],
      o
    )
  ).rows![0].N;
  const people: Actor[] = [];
  for (const suffix of ["present", "late", "absent", "pending", "unassigned"]) {
    const username = "att_verify_" + Date.now() + "_" + suffix;
    const result = await c.execute(
      "INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE) VALUES(:u,:n,'verification-only-not-a-password','viewer') RETURNING ID INTO :id",
      {
        u: username,
        n: "Verification " + suffix,
        id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
      }
    );
    people.push({
      ID: Number((result.outBinds as { id: number[] }).id[0]),
      USERNAME: username,
      DISPLAY_NAME: "Verification " + suffix,
      ROLE: "viewer",
    });
  }
  const state = await myAttendance(c, people[0]),
    now = state.now,
    clock = (ms: number) => new Date(ms + 10800000).toISOString().slice(11, 16);
  const base = {
    name: "Verification shift",
    branch: "Verification branch",
    latitude: 24.7136,
    longitude: 46.6753,
    radius: 100,
    startTime: clock(now - 600000),
    endTime: clock(now + 600000),
    workStart: clock(now),
    workEnd: clock(now + 3600000),
    lateGrace: 1,
    active: true,
  };
  const normal = await saveShift(scoped, admin, base);
  await assignShift(scoped, admin, {
    shiftId: normal.id,
    employeeIds: [people[0].ID, people[3].ID],
  });
  const late = await saveShift(scoped, admin, {
    ...base,
    name: "Late verification",
    workStart: clock(now - 300000),
    lateGrace: 0,
  });
  await assignShift(scoped, admin, {
    shiftId: late.id,
    employeeIds: [people[1].ID],
  });
  const absent = await saveShift(scoped, admin, {
    ...base,
    name: "Absent verification",
  });
  await assignShift(scoped, admin, {
    shiftId: absent.id,
    employeeIds: [people[2].ID],
  });
  // The report only marks absence after the allowed entry deadline; move this temporary history to yesterday.
  await c.execute(
    "UPDATE APP_SHIFT_ASSIGN_HISTORY SET VALID_FROM=SYSTIMESTAMP-INTERVAL '2' DAY,END_TIME='00:01',START_TIME='00:00' WHERE USER_ID=:id",
    { id: people[2].ID }
  );
  const point = {
    latitude: base.latitude,
    longitude: base.longitude,
    accuracy: 5,
    capturedAt: new Date().toISOString(),
  };
  await assert.rejects(checkIn(scoped, people[4], point), /لا توجد وردية/);
  await assert.rejects(
    checkIn(scoped, people[0], { ...point, latitude: 25 }),
    /خارج النطاق/
  );
  await assert.rejects(
    checkIn(scoped, people[0], { ...point, accuracy: 150 }),
    /دقة الموقع/
  );
  await assert.rejects(
    checkIn(scoped, people[0], {
      ...point,
      capturedAt: new Date(now - 120000).toISOString(),
    }),
    /غير حديث/
  );
  await checkIn(scoped, people[0], {
    ...point,
    capturedAt: new Date().toISOString(),
  });
  await assert.rejects(
    checkIn(scoped, people[0], {
      ...point,
      capturedAt: new Date().toISOString(),
    }),
    /بالفعل/
  );
  await checkIn(scoped, people[1], {
    ...point,
    capturedAt: new Date().toISOString(),
  });
  await assert.rejects(
    checkOut(scoped, people[0], {
      ...point,
      latitude: 25,
      capturedAt: new Date().toISOString(),
    }),
    /خارج النطاق/
  );
  await saveShift(scoped, admin, {
    ...base,
    id: normal.id,
    startTime: clock(now + 3600000),
    endTime: clock(now + 7200000),
    latitude: 0,
    longitude: 0,
  });
  // Departure uses the original attendance location and is allowed after the entry window closes.
  await checkOut(scoped, people[0], {
    ...point,
    capturedAt: new Date().toISOString(),
  });
  await assert.rejects(
    checkOut(scoped, people[0], {
      ...point,
      capturedAt: new Date().toISOString(),
    }),
    /لا يوجد حضور مفتوح/
  );
  const mine = await myAttendance(c, people[0]);
  assert.ok(mine.checked?.CHECKED_OUT_AT);
  const day = state.serverTime.slice(0, 10),
    yesterday = new Date(now + 10800000 - 86400000).toISOString().slice(0, 10),
    rows = await attendanceReport(c, { date1: yesterday, date2: day });
  const own = rows.filter(r => people.some(p => p.ID === r.USER_ID));
  assert.ok(
    own.some(
      r =>
        r.USER_ID === people[0].ID && r.STATUS === "present" && r.CHECKED_OUT_AT
    )
  );
  assert.ok(
    own.some(
      r =>
        r.USER_ID === people[1].ID && r.STATUS === "late" && r.LATE_MINUTES > 0
    )
  );
  assert.ok(own.some(r => r.USER_ID === people[2].ID && r.STATUS === "absent"));
  assert.ok(
    own.some(r => r.USER_ID === people[3].ID && r.STATUS === "pending")
  );
  assert.ok(!own.some(r => r.USER_ID === people[4].ID));
  await saveShift(scoped, admin, {
    ...base,
    id: normal.id,
    branch: "Updated verification branch",
    latitude: 0,
    longitude: 0,
  });
  assert.equal((await myAttendance(c, people[0])).checked?.BRANCH, base.branch);
  await assignShift(scoped, admin, { shiftId: normal.id, employeeIds: [] });
  assert.ok(
    (await attendanceReport(c, { date1: yesterday, date2: day })).some(
      r => r.USER_ID === people[0].ID && r.CHECKED_OUT_AT
    )
  );
  const blocked = await saveShift(scoped, admin, {
    ...base,
    name: "Outside time verification",
    startTime: clock(now + 3600000),
    endTime: clock(now + 7200000),
  });
  await assignShift(scoped, admin, {
    shiftId: blocked.id,
    employeeIds: [people[3].ID],
  });
  await assert.rejects(
    checkIn(scoped, people[3], {
      ...point,
      capturedAt: new Date().toISOString(),
    }),
    /خارج وقت السماح/
  );
  await saveShift(scoped, admin, { ...base, id: blocked.id, active: false });
  await assert.rejects(
    checkIn(scoped, people[3], {
      ...point,
      capturedAt: new Date().toISOString(),
    }),
    /وردية مفعلة/
  );
  await c.rollback();
  assert.equal(
    (
      await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM APP_EMPLOYEE_ATTENDANCE",
        [],
        o
      )
    ).rows![0].N,
    before
  );
  console.log(
    "PASS Oracle shifts, assignments, location/time validation, duplicate prevention, check-out, present/late/absent/pending reports and history. All test data rolled back."
  );
} finally {
  await c.rollback();
  await c.close();
}
