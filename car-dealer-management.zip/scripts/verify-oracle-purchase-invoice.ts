import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "../server/oracle";
import { passwordHash, type Actor } from "../server/oracleSession";
import {
  createPurchaseInvoice,
  purchaseInvoiceOptions,
} from "../server/oraclePurchaseInvoice";
const c = await oracledb.getConnection(getOracleConfig());
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
const tables = [
  "PURCHASE_INVOICE",
  "CAR_PURCHASE",
  "STOCK_LEDGER",
  "ACCOUNT_LEDGER",
  "APP_USERS",
  "APP_AUDIT_LOG",
];
async function counts() {
  const r: Record<string, number> = {};
  for (const t of tables)
    r[t] = (
      await c.execute<{ N: number }>("SELECT COUNT(*) N FROM " + t, [], o)
    ).rows![0].N;
  return r;
}
const before = await counts();
try {
  const user = await c.execute(
    "INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE) VALUES(:u,'Purchase verification',:h,'admin') RETURNING ID INTO :id",
    {
      u: "purchase_verify_" + Date.now(),
      h: await passwordHash("purchase-verification-password"),
      id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
    }
  );
  const actor: Actor = {
    ID: Number((user.outBinds as { id: number[] }).id[0]),
    USERNAME: "purchase_verifier",
    DISPLAY_NAME: "Purchase verification",
    ROLE: "admin",
  };
  const choices = await purchaseInvoiceOptions(c);
  const supplier = choices.suppliers[0];
  const payment = choices.accounts[0];
  const suffix = String(Date.now());
  const scoped = {
    execute: c.execute.bind(c),
    commit: async () => {},
    rollback: c.rollback.bind(c),
    close: async () => {},
  } as Connection;
  const input = {
    date: "2026-10-04",
    supplierId: supplier.ID,
    paymentId: payment.ID,
    ownerId: choices.owners[0].ID,
    branch: "",
    notes: "Rollback verification",
    lines: [
      {
        car: "Test car",
        model: "2026",
        color: "",
        plate: "PV" + suffix,
        vin: "VIN" + suffix,
        price: 12000.5,
        notes: "",
      },
      {
        car: "Test car 2",
        model: "2025",
        color: "",
        plate: "PV2" + suffix,
        vin: "VIN2" + suffix,
        price: 8000.25,
        notes: "",
      },
    ],
  };
  const result = await createPurchaseInvoice(scoped, actor, input);
  assert.equal(result.total, 20000.75);
  const ownerRow = (
    await c.execute<{
      PUI_OWNER_NUM: number;
      PUI_OWNER_NAME: string;
      BC_NUM: number;
      PUI_NUM: number;
    }>(
      "SELECT PUI_OWNER_NUM,PUI_OWNER_NAME,BC_NUM,PUI_NUM FROM PURCHASE_INVOICE WHERE PUI_ID=:id",
      { id: result.id },
      o
    )
  ).rows![0];
  assert.equal(ownerRow.PUI_OWNER_NUM, input.ownerId);
  assert.equal(ownerRow.PUI_OWNER_NAME, choices.owners[0].NAME);
  assert.equal(ownerRow.BC_NUM, input.paymentId);
  assert.equal(ownerRow.PUI_NUM, input.supplierId);
  const ownerAudit = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM APP_AUDIT_LOG WHERE TABLE_NAME='PURCHASE_INVOICE' AND RECORD_ID=:id AND ACTION='INSERT' AND JSON_VALUE(AFTER_JSON,'$.PUI_OWNER_NUM' RETURNING NUMBER)=:owner",
      { id: String(result.id), owner: input.ownerId },
      o
    )
  ).rows![0];
  assert.equal(ownerAudit.N, 1);
  const detail = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM CAR_PURCHASE WHERE CP_INV_REF=:id",
      { id: result.id },
      o
    )
  ).rows![0].N;
  assert.equal(detail, 2);
  const stock = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM STOCK_LEDGER WHERE ST_INV_REF=:id AND ST_STATUS='purchase'",
      { id: result.id },
      o
    )
  ).rows![0].N;
  assert.equal(stock, 2);
  const ledger = (
    await c.execute<{ AL_CREDIT_MOUNT: number; AL_DEPIT_MOUNT: number }>(
      "SELECT AL_CREDIT_MOUNT,AL_DEPIT_MOUNT FROM ACCOUNT_LEDGER WHERE AL_DOC_ID=:id AND AL_DOC_TYPE=9",
      { id: result.id },
      o
    )
  ).rows!;
  assert.equal(ledger.length, 2);
  assert.equal(
    ledger.reduce((n, l) => n + Number(l.AL_CREDIT_MOUNT), 0),
    20000.75
  );
  assert.equal(
    ledger.reduce((n, l) => n + Number(l.AL_DEPIT_MOUNT), 0),
    20000.75
  );
  console.log(
    "PASS Purchase master, 2 cars, 2 stock entries, balanced accounting and exact total"
  );
  await c.rollback();
  assert.deepEqual(await counts(), before);
  console.log("PASS Complete rollback; no test business data retained");
} finally {
  await c.rollback();
  await c.close();
}
