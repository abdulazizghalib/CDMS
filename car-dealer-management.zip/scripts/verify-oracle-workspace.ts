import "../server/_core/loadEnv";
import { oracleWorkspaceRouter } from "../server/oracleWorkspace";
import { datasetKeys, oracleDatasets } from "../shared/oracleWorkspace";
import type { TrpcContext } from "../server/_core/context";
const context = {
  user: null,
  req: {
    socket: { remoteAddress: "127.0.0.1" },
    headers: { host: "localhost:3000" },
  },
  res: {},
} as unknown as TrpcContext;
const caller = oracleWorkspaceRouter.createCaller(context);
let checks = 0;
for (const dataset of datasetKeys) {
  if (dataset === "salesLines" || dataset === "purchaseLines") continue;
  const result = await caller.table({ dataset, pageSize: 10 });
  for (const row of result.rows)
    for (const column of Object.keys(oracleDatasets[dataset].columns))
      if (!(column in row))
        throw new Error("Missing " + dataset + "." + column);
  console.log(dataset + ": " + result.total + " records; projection OK");
  checks++;
  if ((dataset === "sales" || dataset === "purchases") && result.rows[0]) {
    const detail = await caller.table({
      dataset: dataset === "sales" ? "salesLines" : "purchaseLines",
      documentId: Number(result.rows[0].ID),
      pageSize: 10,
    });
    console.log(dataset + " detail relationship: " + detail.total + " records");
    checks++;
  }
}
const summary = await caller.summary();
if (!summary.totals.VEHICLES) throw new Error("No inventory summary");
const audit = await caller.audit();
console.log(
  JSON.stringify({
    checks,
    triggerCount: audit.snapshot.triggers.length,
    disabledOrInvalid: audit.mapping.unhealthyTriggers.length,
    invalidObjects: audit.invalidObjects.length,
  })
);
