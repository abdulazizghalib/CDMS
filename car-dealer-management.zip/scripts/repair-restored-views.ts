﻿import "../server/_core/loadEnv";
import fs from "node:fs";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
const definitions: Record<string, string> = {
  MAINACTMAX: "SELECT NVL(MAX(AC_NUM)+1,1) MAINMAX FROM MAIN_ACT",
  BRANSHMAX: "SELECT NVL(MAX(BAR_NUM)+1,1) MAINMAX FROM BRANSH_ACT",
  SALES_INVOICE_VIEW:
    "SELECT m.SI_ID,m.SI_DATE,m.SI_TIME,m.SI_SHIFT,m.SI_POST_STATUS,m.SI_USER_ENTERED,m.SI_BRANSH,d.CSI_INV_REF SID_INV_REF,m.SI_TOTAL FROM SALES_INVOICE m JOIN CAR_SALES_INV d ON d.CSI_INV_REF=m.SI_ID",
  INV_SALES_DET_VIEW:
    "SELECT m.SI_ID,m.SI_TOTAL,m.SI_USER_ENTERED,d.CSI_TYPE PROD_NAM,1 SID_QUANTITY,d.CSI_SALES_PRICE SID_PRICE,m.CLOSE_REF,m.SI_DATE,m.SI_TIME FROM SALES_INVOICE m JOIN CAR_SALES_INV d ON d.CSI_INV_REF=m.SI_ID",
  INVOICE_DATAIL2_VIEW:
    "SELECT SI_ID,SI_TOTAL,SI_USER_ENTERED,PROD_NAM,CLOSE_REF,SI_DATE,SI_TIME,SID_QUANTITY,SID_QUANTITY*SID_PRICE NET_TOTAL FROM INV_SALES_DET_VIEW",
  INVOICE_PRINT_VIEW:
    "SELECT SI_ID,SI_TOTAL,SI_USER_ENTERED,PROD_NAM,SUM(SID_QUANTITY) QTY,SUM(NET_TOTAL) TOTAL FROM INVOICE_DATAIL2_VIEW GROUP BY SI_ID,SI_TOTAL,SI_USER_ENTERED,PROD_NAM",
  INVOICE_CLOSE_DETAIL:
    "SELECT SI_ID,SI_TOTAL,SI_USER_ENTERED,PROD_NAM,CLOSE_REF,SI_DATE,SI_TIME,SID_QUANTITY,SID_PRICE NET_TOTAL,SID_PRICE FROM INV_SALES_DET_VIEW",
  INVOICE_CLOSE_DETAIL_VIEW:
    "SELECT SUM(SID_QUANTITY*SID_PRICE) SUM_TOTAL,SI_USER_ENTERED,PROD_NAM,CLOSE_REF,SUM(SID_QUANTITY) SUM_QTY,SID_PRICE FROM INVOICE_CLOSE_DETAIL GROUP BY SI_USER_ENTERED,PROD_NAM,CLOSE_REF,SID_PRICE",
  SALES_COST_VIEW:
    "SELECT s.ST_PRICE_OUT TOTAL,m.SI_USER_ENTERED SL_ENTERED_BY FROM STOCK_LEDGER s JOIN SALES_INVOICE m ON m.SI_ID=s.ST_INV_REF WHERE m.SI_POST_STATUS='UN POST' AND s.ST_STATUS='sales'",
  SALES_CLOSE_COST_VIEW:
    "SELECT SUM(TOTAL) SL_TOTAL,SL_ENTERED_BY FROM SALES_COST_VIEW GROUP BY SL_ENTERED_BY",
};
const c = await oracledb.getConnection(getOracleConfig());
const apply = process.argv.includes("--apply");
try {
  const backup: Record<string, string> = {};
  for (const name of Object.keys(definitions)) {
    const row = (
      await c.execute<{ TEXT: string }>(
        "SELECT TEXT FROM USER_VIEWS WHERE VIEW_NAME=:name",
        { name },
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows?.[0];
    if (!row) throw new Error("Expected restored view missing: " + name);
    backup[name] = "CREATE OR REPLACE VIEW " + name + " AS " + row.TEXT;
  }
  const backupPath = "database/restored-view-backup.json";
  if (apply && !fs.existsSync(backupPath))
    fs.writeFileSync(backupPath, JSON.stringify(backup, null, 2));
  for (const [name, query] of Object.entries(definitions)) {
    const sql = "CREATE OR REPLACE VIEW " + name + " AS " + query;
    if (!apply) {
      console.log(sql + ";");
      continue;
    }
    await c.execute(sql);
    await c.execute("SELECT * FROM " + name + " WHERE ROWNUM <= 1");
    console.log("REPAIRED " + name);
  }
  if (apply) {
    // Recompile dependents without enabling disabled business triggers.
    const invalid =
      (
        await c.execute<{ OBJECT_NAME: string; OBJECT_TYPE: string }>(
          "SELECT OBJECT_NAME,OBJECT_TYPE FROM USER_OBJECTS WHERE STATUS='INVALID' AND OBJECT_TYPE IN ('VIEW','FUNCTION','TRIGGER')",
          [],
          { outFormat: oracledb.OUT_FORMAT_OBJECT }
        )
      ).rows ?? [];
    for (const item of invalid) {
      if (!/^[A-Z0-9_]+$/.test(item.OBJECT_NAME)) continue;
      try {
        await c.execute(
          "ALTER " + item.OBJECT_TYPE + " " + item.OBJECT_NAME + " COMPILE"
        );
      } catch {}
    }
    const remaining =
      (
        await c.execute<{ OBJECT_NAME: string; OBJECT_TYPE: string }>(
          "SELECT OBJECT_NAME,OBJECT_TYPE FROM USER_OBJECTS WHERE STATUS='INVALID' ORDER BY OBJECT_TYPE,OBJECT_NAME",
          [],
          { outFormat: oracledb.OUT_FORMAT_OBJECT }
        )
      ).rows ?? [];
    const errors = (
      await c.execute(
        "SELECT NAME,TYPE,LINE,TEXT FROM USER_ERRORS ORDER BY NAME,SEQUENCE",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows;
    fs.writeFileSync(
      "_database-repair-result.json",
      JSON.stringify(
        { repaired: Object.keys(definitions), remaining, errors },
        null,
        2
      )
    );
    console.log("Remaining invalid objects: " + remaining.length);
  }
} finally {
  await c.close();
}
