import "../server/_core/loadEnv";
import fs from "node:fs/promises";
import { randomBytes, createHash } from "node:crypto";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
async function connect(url) {
  const socket = new WebSocket(url);
  await new Promise((r, j) => {
    socket.addEventListener("open", r, { once: true });
    socket.addEventListener("error", j, { once: true });
  });
  let seq = 0;
  const requests = new Map();
  socket.addEventListener("message", e => {
    const m = JSON.parse(e.data);
    if (m.id) {
      const p = requests.get(m.id);
      if (p) {
        requests.delete(m.id);
        clearTimeout(p.timer);
        m.error ? p.j(new Error(m.error.message)) : p.r(m.result);
      }
    }
  });
  return {
    socket,
    send: (method, params = {}) =>
      new Promise((r, j) => {
        const id = ++seq;
        const timer = setTimeout(
          () => j(new Error("CDP timeout " + method)),
          20000
        );
        requests.set(id, { r, j, timer });
        socket.send(JSON.stringify({ id, method, params }));
      }),
  };
}
const c = await oracledb.getConnection(getOracleConfig());
const token = randomBytes(32).toString("hex"),
  hash = createHash("sha256").update(token).digest("hex");
let browser, context, page;
try {
  const actor = (
    await c.execute(
      "SELECT ID FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND (EXPIRES_AT IS NULL OR EXPIRES_AT>SYSTIMESTAMP) AND ROWNUM=1",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0];
  if (!actor) throw new Error("No active admin for browser verification");
  await c.execute(
    "INSERT INTO APP_SESSIONS(TOKEN_HASH,USER_ID,EXPIRES_AT) VALUES(:token,:actor,SYSTIMESTAMP+NUMTODSINTERVAL(5,'MINUTE'))",
    { token: hash, actor: actor.ID }
  );
  await c.commit();
  const version = await (
    await fetch("http://127.0.0.1:9225/json/version")
  ).json();
  browser = await connect(version.webSocketDebuggerUrl);
  context = (await browser.send("Target.createBrowserContext"))
    .browserContextId;
  const target = (
    await browser.send("Target.createTarget", {
      url: "about:blank",
      browserContextId: context,
    })
  ).targetId;
  const list = await (await fetch("http://127.0.0.1:9225/json/list")).json();
  page = await connect(list.find(t => t.id === target).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Runtime.enable");
  await page.send("Emulation.setDeviceMetricsOverride", {
    width: 1440,
    height: 1100,
    deviceScaleFactor: 1,
    mobile: false,
  });
  await page.send("Network.setCookie", {
    name: "dealer_oracle_session",
    value: token,
    url: "http://localhost:3000",
    httpOnly: true,
    sameSite: "Lax",
  });
  const evaluate = async expression => {
    const r = await page.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text);
    return r.result.value;
  };
  async function wait(expr, label) {
    const until = Date.now() + 30000;
    while (Date.now() < until) {
      if (await evaluate(expr)) return;
      await new Promise(r => setTimeout(r, 300));
    }
    throw new Error(
      "Timed out: " +
        label +
        " - " +
        (await evaluate("document.body.innerText.slice(0,6000)"))
    );
  }
  await page.send("Page.addScriptToEvaluateOnNewDocument", {
    source: `const originalFetch=window.fetch.bind(window);window.fetch=async(...args)=>{const url=String(args[0] instanceof Request?args[0].url:args[0]);if(url.includes('oracleOperations.createOwnerAccount'))return new Response(JSON.stringify([{result:{data:{json:{ID:999999,NAME:'مالك اختبار الواجهة',BAR_NUM:2006,phone:'0551234567'}}}}]),{status:200,headers:{'content-type':'application/json'}});return originalFetch(...args);};`,
  });
  await page.send("Page.navigate", {
    url: "http://localhost:3000/?view=purchases",
  });
  await wait(
    "Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='إضافة فاتورة مشتريات')",
    "sales page"
  );
  await evaluate(
    "Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='إضافة فاتورة مشتريات').click()"
  );
  await wait(
    "!!document.querySelector('#purchase-account-المالك') && document.querySelector('#purchase-account-المالك').options.length>1",
    "sales account list"
  );
  await evaluate(
    "Array.from(document.querySelectorAll('[role=dialog] button')).find(b=>b.textContent.trim()==='إضافة مالك').click()"
  );
  await wait(
    "!!document.querySelector('[aria-label=\"إضافة مالك\"]')",
    "inline account form"
  );
  await evaluate(
    "(()=>{const box=document.querySelector('[aria-label=\"إضافة مالك\"]');const input=box.querySelector('input');Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,'مالك اختبار الواجهة');input.dispatchEvent(new Event('input',{bubbles:true}));})()"
  );
  await wait(
    "Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='حفظ المالك واختياره'&&!b.disabled)",
    "account name input"
  );
  await evaluate(
    "Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='حفظ المالك واختياره').click()"
  );
  await wait(
    "document.querySelector('#purchase-account-المالك').value==='999999'",
    "new account selected"
  );
  const label = await evaluate(
    "document.querySelector('#purchase-account-المالك').selectedOptions[0].textContent"
  );
  if (!label.includes("مالك اختبار الواجهة"))
    throw new Error("Created account name missing");
  if (await evaluate("!!document.querySelector('[aria-label=\"إضافة مالك\"]')"))
    throw new Error("Inline account form did not close");
  const shot = await page.send("Page.captureScreenshot", { format: "png" });
  await fs.writeFile(
    "_purchase-inline-owner-preview.png",
    Buffer.from(shot.data, "base64")
  );
  console.log(
    "PASS Inline owner form, automatic selection and purchase invoice stays open; owner creation simulated without business writes"
  );
} finally {
  if (page) page.socket.close();
  if (browser && context) {
    await browser.send("Target.disposeBrowserContext", {
      browserContextId: context,
    });
    browser.socket.close();
  }
  await c.execute("DELETE FROM APP_SESSIONS WHERE TOKEN_HASH=:token", {
    token: hash,
  });
  await c.commit();
  await c.close();
}
