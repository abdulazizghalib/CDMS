import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "../server/oracle";
import { definition, loadRecord, writeRecord } from "../server/oracleWrite";
import { passwordHash, type Actor } from "../server/oracleSession";
const c = await oracledb.getConnection(getOracleConfig());
let checks = 0;
const pass = (name: string) => {
  checks++;
  console.log("PASS " + name);
};
const request = async (
  dataset: string,
  action: "insert" | "update" | "delete",
  values: Record<string, string | number | null>,
  id?: number,
  version?: string
) => {
  await c.execute("SAVEPOINT verify_operation");
  const scoped: Connection = {
    execute: c.execute.bind(c),
    close: async () => {},
    commit: async () => {},
    rollback: async () => {
      await c.execute("ROLLBACK TO verify_operation");
    },
  };
  return writeRecord(scoped, actor, { dataset, action, values, id, version });
};
let actor: Actor;
const username = "verify_" + Date.now();
try {
  const user = await c.execute(
    "INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE) VALUES(:name,'Transaction verification',:hash,'admin') RETURNING ID INTO :id",
    {
      name: username,
      hash: await passwordHash("temporary-verification-password"),
      id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
    }
  );
  actor = {
    ID: Number((user.outBinds!.id as number[])[0]),
    USERNAME: username,
    DISPLAY_NAME: "Transaction verification",
    ROLE: "admin",
  };
  const startAudit = Number(
    (
      await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM APP_AUDIT_LOG",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows![0].N
  );
  const center = await request("costCenters", "insert", {
    CC_NAME: "اختبار دون تثبيت",
  });
  let record = await loadRecord(c, definition("costCenters"), center.id!);
  const oldVersion = record.version;
  await request(
    "costCenters",
    "update",
    { CC_NAME: "اختبار تعديل دون تثبيت" },
    center.id,
    record.version
  );
  await assert.rejects(
    () =>
      request(
        "costCenters",
        "update",
        { CC_NAME: "stale" },
        center.id,
        oldVersion
      ),
    /مستخدم آخر/
  );
  pass("Stale updates rejected");
  record = await loadRecord(c, definition("costCenters"), center.id!);
  await request("costCenters", "delete", {}, center.id, record.version);
  const events = await c.execute<{
    ACTION: string;
    ACTOR_ID: string;
    BEFORE_JSON: { getData(): Promise<string> } | null;
    AFTER_JSON: { getData(): Promise<string> } | null;
  }>(
    "SELECT ACTION,ACTOR_ID,BEFORE_JSON,AFTER_JSON FROM APP_AUDIT_LOG WHERE TABLE_NAME='CENTER_COST' AND RECORD_ID=:id AND ACTOR_ID=:actor ORDER BY ID",
    { id: String(center.id), actor: String(actor.ID) },
    { outFormat: oracledb.OUT_FORMAT_OBJECT }
  );
  assert.deepEqual(
    events.rows?.map(x => x.ACTION),
    ["INSERT", "UPDATE", "DELETE"]
  );
  assert.equal(
    JSON.parse(await events.rows![1].BEFORE_JSON!.getData()).CC_NAME,
    "اختبار دون تثبيت"
  );
  assert.equal(
    JSON.parse(await events.rows![1].AFTER_JSON!.getData()).CC_NAME,
    "اختبار تعديل دون تثبيت"
  );
  pass("Create/update/delete audit includes actor and before/after values");
  await assert.rejects(
    () =>
      c.execute("DELETE FROM APP_AUDIT_LOG WHERE ACTOR_ID=:id", {
        id: String(actor.ID),
      }),
    /ORA-20071/
  );
  pass("Audit log rejects deletion");
  const a = 9000000001,
    b = 9000000002,
    s = 9000000003;
  await request("mainAccounts", "insert", { AC_NAM: "تحقق رئيسي" }, a);
  await request(
    "branchAccounts",
    "insert",
    { AC_NAM: "تحقق فرعي", AC_NUM: a },
    b
  );
  await request(
    "subAccounts",
    "insert",
    { AC_NAM: "تحقق تفصيلي", BAR_NUM: b },
    s
  );
  let main = await loadRecord(c, definition("mainAccounts"), a);
  await assert.rejects(
    () => request("mainAccounts", "delete", {}, a, main.version),
    /تابعة/
  );
  pass("Parent deletion protected");
  let sub = await loadRecord(c, definition("subAccounts"), s);
  await request(
    "subAccounts",
    "update",
    { AC_NAM: "تفصيلي محدث", BAR_NUM: b },
    s,
    sub.version
  );
  const trail = (
    await c.execute<{ NAME: string }>(
      "SELECT TB_SON_NAME NAME FROM TRAIL_BALANCE WHERE TB_SON_NUM=:id",
      { id: s },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows!;
  assert.equal(trail[0].NAME, "تفصيلي محدث");
  pass("Account edits synchronize zero-balance trial definitions");
  sub = await loadRecord(c, definition("subAccounts"), s);
  await request("subAccounts", "delete", {}, s, sub.version);
  let branch = await loadRecord(c, definition("branchAccounts"), b);
  await request("branchAccounts", "delete", {}, b, branch.version);
  main = await loadRecord(c, definition("mainAccounts"), a);
  await request("mainAccounts", "delete", {}, a, main.version);
  pass("Three account levels create/edit/delete");
  const e1 = await request("entries", "insert", {
    CE_NAME: "Test entry 1",
    CE_DATE: "2026-10-03",
  });
  const e2 = await request("entries", "insert", {
    CE_NAME: "Test entry 2",
    CE_DATE: "2026-10-03",
  });
  const delivery = await request("deliveries", "insert", {
    CO_REF: e1.id!,
    CO_DATE: "2026-10-03",
  });
  const entry = await loadRecord(c, definition("entries"), e1.id!);
  await assert.rejects(
    () => request("entries", "delete", {}, e1.id, entry.version),
    /خروج/
  );
  await assert.rejects(
    () =>
      request("deliveries", "insert", {
        CO_REF: e1.id!,
        CO_DATE: "2026-10-03",
      }),
    /بالفعل/
  );
  pass("Delivered entry cannot be deleted or delivered twice");
  let out = await loadRecord(c, definition("deliveries"), delivery.id!);
  await request(
    "deliveries",
    "update",
    { CO_REF: e2.id!, CO_DATE: "2026-10-03" },
    delivery.id,
    out.version
  );
  assert.equal(
    (await loadRecord(c, definition("entries"), e1.id!)).record.CE_STATUS,
    0
  );
  assert.equal(
    (await loadRecord(c, definition("entries"), e2.id!)).record.CE_STATUS,
    1
  );
  out = await loadRecord(c, definition("deliveries"), delivery.id!);
  await request("deliveries", "delete", {}, delivery.id, out.version);
  assert.equal(
    (await loadRecord(c, definition("entries"), e2.id!)).record.CE_STATUS,
    0
  );
  pass("Changing/deleting delivery reconciles both entry states");
  for (const id of [e1.id!, e2.id!]) {
    const r = await loadRecord(c, definition("entries"), id);
    await request("entries", "delete", {}, id, r.version);
  }
  const contract: Record<string, string | number | null> = {};
  for (const field of definition("contracts").fields)
    contract[field.key] =
      field.type === "date"
        ? "2026-10-03"
        : field.type === "number"
          ? 1
          : "اختبار";
  contract.CS_TOTAL_MOUNT = 100;
  contract.CS_CASH_PAY = 40;
  const cr = await request("contracts", "insert", contract);
  let crRecord = await loadRecord(c, definition("contracts"), cr.id!);
  assert.equal(crRecord.record.CS_CASH_REMAIN, 60);
  await request(
    "contracts",
    "update",
    { ...contract, CS_CASH_PAY: 75 },
    cr.id,
    crRecord.version
  );
  crRecord = await loadRecord(c, definition("contracts"), cr.id!);
  assert.equal(crRecord.record.CS_CASH_REMAIN, 25);
  await request("contracts", "delete", {}, cr.id, crRecord.version);
  pass("Contract CRUD calculates remaining amount");
  const afterAudit = Number(
    (
      await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM APP_AUDIT_LOG",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows![0].N
  );
  assert.ok(afterAudit > startAudit);
  await c.rollback();
  const persisted = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM APP_AUDIT_LOG WHERE ACTOR_ID=:id",
      { id: String(actor.ID) },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows![0].N;
  assert.equal(persisted, 0);
  assert.equal(
    (
      await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM APP_USERS WHERE USERNAME=:name",
        { name: username },
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows![0].N,
    0
  );
  pass("Rollback removes business records, test user and audit together");
  console.log(JSON.stringify({ checks, committedBusinessChanges: 0 }));
} finally {
  await c.rollback();
  await c.close();
}
