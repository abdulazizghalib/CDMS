import "../server/_core/loadEnv";
import fs from "node:fs";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
const c = await oracledb.getConnection(getOracleConfig());
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
const apply = process.argv.includes("--apply");
const keyword = new Set(
  "SELECT FROM WHERE GROUP BY ORDER HAVING INTO AS DISTINCT NVL MAX MIN SUM COUNT TO_DATE TO_CHAR CASE WHEN THEN ELSE END NULL NOT AND OR IN IS ON JOIN LEFT RIGHT INNER OUTER DATE NUMBER VARCHAR2 RETURN BEGIN LOOP FOR INSERT UPDATE DELETE SET VALUES IF OLD NEW DUAL".split(
    " "
  )
);
function identifiers(expr: string) {
  return [...expr.replace(/'[^']*'/g, "").matchAll(/\b[A-Z][A-Z0-9_]*\b/g)]
    .filter(
      m =>
        !keyword.has(m[0]) && !/^\s*\(/.test(expr.slice(m.index! + m[0].length))
    )
    .map(m => m[0]);
}
function splitExpressions(expr: string) {
  let depth = 0,
    start = 0;
  const parts: string[] = [];
  for (let i = 0; i < expr.length; i++) {
    if (expr[i] === "(") depth++;
    if (expr[i] === ")") depth--;
    if (expr[i] === "," && depth === 0) {
      parts.push(expr.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(expr.slice(start));
  return parts;
}
try {
  const objects = new Set(
    (
      await c.execute<{ OBJECT_NAME: string }>(
        "SELECT OBJECT_NAME FROM USER_OBJECTS WHERE OBJECT_TYPE IN ('TABLE','VIEW','SYNONYM')",
        [],
        o
      )
    ).rows!.map(r => r.OBJECT_NAME)
  );
  const cols = (
    await c.execute<{
      TABLE_NAME: string;
      COLUMN_NAME: string;
      DATA_TYPE: string;
      CHAR_LENGTH: number;
      DATA_PRECISION: number | null;
      DATA_SCALE: number | null;
    }>(
      "SELECT TABLE_NAME,COLUMN_NAME,DATA_TYPE,CHAR_LENGTH,DATA_PRECISION,DATA_SCALE FROM USER_TAB_COLUMNS",
      [],
      o
    )
  ).rows!;
  const views = (
    await c.execute<{ VIEW_NAME: string; TEXT: string }>(
      "SELECT VIEW_NAME,TEXT FROM USER_VIEWS WHERE VIEW_NAME IN (SELECT OBJECT_NAME FROM USER_OBJECTS WHERE STATUS='INVALID')",
      [],
      o
    )
  ).rows!;
  const source = (
    await c.execute<{ NAME: string; TEXT: string }>(
      "SELECT NAME,TEXT FROM USER_SOURCE WHERE NAME IN (SELECT OBJECT_NAME FROM USER_OBJECTS WHERE STATUS='INVALID') ORDER BY NAME,LINE",
      [],
      o
    )
  ).rows!;
  const grouped = new Map<string, string>();
  for (const s of source)
    grouped.set(s.NAME, (grouped.get(s.NAME) ?? "") + s.TEXT);
  const documents = [
    ...views.map(v => ({ name: v.VIEW_NAME, text: v.TEXT.toUpperCase() })),
    ...[...grouped].map(([name, text]) => ({ name, text: text.toUpperCase() })),
  ];
  const inferred = new Map<string, Set<string>>();
  const users = new Map<string, Set<string>>();
  function add(table: string, col: string, source: string) {
    if (
      objects.has(table) ||
      table === "DUAL" ||
      keyword.has(col) ||
      !/^[A-Z][A-Z0-9_]*$/.test(col)
    )
      return;
    if (!inferred.has(table)) inferred.set(table, new Set());
    inferred.get(table)!.add(col);
    if (!users.has(table)) users.set(table, new Set());
    users.get(table)!.add(source);
  }
  for (const doc of documents) {
    const aliases = new Map<string, string>();
    const tables = new Set<string>();
    const fromRx =
      /\bFROM\s+([A-Z][A-Z0-9_]*(?:\s+(?!WHERE\b|GROUP\b|ORDER\b|HAVING\b|LOOP\b|SET\b)[A-Z][A-Z0-9_]*)?(?:\s*,\s*[A-Z][A-Z0-9_]*(?:\s+(?!WHERE\b|GROUP\b|ORDER\b|HAVING\b)[A-Z][A-Z0-9_]*)?)*)/g;
    for (const m of doc.text.matchAll(fromRx)) {
      for (const entry of m[1].split(",")) {
        const [table, alias] = entry.trim().split(/\s+/);
        if (table === "DUAL") continue;
        tables.add(table);
        aliases.set(table, table);
        if (alias) aliases.set(alias, table);
      }
    }
    for (const m of doc.text.matchAll(
      /\b(?:UPDATE|INSERT\s+INTO)\s+([A-Z][A-Z0-9_]*)/g
    )) {
      tables.add(m[1]);
      aliases.set(m[1], m[1]);
    }
    for (const m of doc.text.matchAll(
      /\b([A-Z][A-Z0-9_]*)\.([A-Z][A-Z0-9_]*)\b/g
    )) {
      const table = aliases.get(m[1]);
      if (table) add(table, m[2], doc.name);
    }
    for (const m of doc.text.matchAll(
      /INSERT\s+INTO\s+([A-Z][A-Z0-9_]*)\s*\(([^)]+)\)/g
    ))
      for (const col of m[2].split(",")) add(m[1], col.trim(), doc.name);
    // Unqualified expressions are attributable only when a query has one source table.
    for (const m of doc.text.matchAll(
      /\bSELECT\s+([\s\S]*?)\bFROM\s+([A-Z][A-Z0-9_]*)/g
    )) {
      const table = m[2];
      if (objects.has(table) || table === "DUAL") continue;
      const after = doc.text.slice(m.index! + m[0].length);
      if (/^\s*,/.test(after)) continue;
      for (let expr of splitExpressions(m[1].split(/\bINTO\b/)[0])) {
        expr = expr
          .trim()
          .replace(/\s+AS\s+[A-Z][A-Z0-9_]*$/, "")
          .replace(/(?<=[)\d])\s+[A-Z][A-Z0-9_]*$/, "");
        if (expr.includes(".")) continue;
        for (const col of identifiers(expr)) add(table, col, doc.name);
      }
      const where = after.match(
        /^\s+WHERE\s+([^;\n]*?)(?:\bLOOP\b|\bGROUP\b|\bORDER\b|$)/
      )?.[1];
      if (where)
        for (const x of where.matchAll(
          /\b([A-Z][A-Z0-9_]*)\s*(?:=|<>|<=|>=|<|>|\bIS\b)/g
        ))
          add(table, x[1], doc.name);
    }
    if (tables.size === 1) {
      const table = [...tables][0];
      for (const m of doc.text.matchAll(
        /\b(?:WHERE|SET)\s+([A-Z][A-Z0-9_]*)\s*=/g
      ))
        add(table, m[1], doc.name);
    }
  }
  const supplemental: Record<string, string[]> = {
    ENTDETAIL: ["ID_NO", "ST"],
    PRODUCT_COLLECT: [
      "PC_ID",
      "PC_PROD_ID",
      "PC_UNIT",
      "PC_QUANTITY",
      "PC_PRICE",
      "PC_PROD_GROUP",
    ],
  };
  for (const [table, columns] of Object.entries(supplemental))
    for (const col of columns)
      add(table, col, "surviving trigger/view column references");
  function type(col: string) {
    if (col === "CL_DATE_IN") return "DATE";
    if (
      ["AID", "BID", "CID", "DID", "EID", "FID", "GID", "QTY_CHANGE"].includes(
        col
      )
    )
      return "NUMBER";
    const matches = cols.filter(
      c => c.COLUMN_NAME === col && objects.has(c.TABLE_NAME)
    );
    const types = [...new Set(matches.map(c => c.DATA_TYPE))];
    if (types.length === 1) {
      if (types[0] === "NUMBER") return "NUMBER";
      if (types[0] === "DATE") return "DATE";
      if (types[0] === "VARCHAR2" || types[0] === "CHAR")
        return (
          "VARCHAR2(" +
          Math.max(200, ...matches.map(c => c.CHAR_LENGTH)) +
          " CHAR)"
        );
    }
    if (/(?:^|_)(?:DATE|DAT|TIME_DATE)$/.test(col) || col === "CH_DAT")
      return "DATE";
    if (
      /(?:^|_)(?:ID|NO|NUM|REF|QTY|QUANTITY|PRICE|TOTAL|MOUNT|AMOUNT|COST|BALANCE|VD|VC|SNO|SEQ|ENO|TYPNO|PCENT|DEPOSIT|REMAIN)$/.test(
        col
      ) ||
      /^(?:QTY\d*|IN_QTY|I_QUAN|I_UN_PRI|I_PU_PR)$/.test(col)
    )
      return "NUMBER";
    return "VARCHAR2(4000 CHAR)";
  }
  const plan = [...inferred]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([table, columns]) => ({
      table,
      columns: [...columns].sort().map(name => ({ name, type: type(name) })),
      referencedBy: [...users.get(table)!].sort(),
      provenance:
        "Inferred from surviving SQL; original definitions and historical rows are unavailable",
    }));
  fs.writeFileSync(
    "database/missing-table-plan.json",
    JSON.stringify(plan, null, 2)
  );
  fs.writeFileSync(
    "database/create-missing-tables.sql",
    plan
      .map(
        p =>
          "CREATE TABLE " +
          p.table +
          " (\n" +
          p.columns.map(c => "  " + c.name + " " + c.type).join(",\n") +
          "\n);"
      )
      .join("\n\n")
  );
  console.log("Inferred missing tables: " + plan.length);
  if (apply) {
    for (const p of plan) {
      await c.execute(
        "CREATE TABLE " +
          p.table +
          " (" +
          p.columns.map(c => c.name + " " + c.type).join(",") +
          ")"
      );
      console.log("CREATED " + p.table + " (" + p.columns.length + " columns)");
    }
  }
} finally {
  await c.close();
}
