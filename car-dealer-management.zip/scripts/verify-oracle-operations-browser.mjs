
import fs from "node:fs/promises";
const base = process.env.ORACLE_PREVIEW_URL || "http://127.0.0.1:3100";
const target = await (await fetch("http://127.0.0.1:9225/json/new?"+encodeURIComponent("about:blank"), {method:"PUT"})).json();
const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve,reject)=>{socket.addEventListener("open",resolve,{once:true});socket.addEventListener("error",reject,{once:true});});
let sequence=0; const requests=new Map(); const exceptions=[];
socket.addEventListener("message",event=>{const message=JSON.parse(event.data);if(message.id){const pending=requests.get(message.id);if(pending){requests.delete(message.id);clearTimeout(pending.timer);message.error?pending.reject(new Error(message.error.message)):pending.resolve(message.result);}}else if(message.method==="Runtime.exceptionThrown")exceptions.push(message.params.exceptionDetails.text);});
function send(method,params={}){return new Promise((resolve,reject)=>{const id=++sequence;const timer=setTimeout(()=>{requests.delete(id);reject(new Error("CDP timeout: "+method));},25000);requests.set(id,{resolve,reject,timer});socket.send(JSON.stringify({id,method,params}));});}
async function evaluate(expression){const result=await send("Runtime.evaluate",{expression,returnByValue:true,awaitPromise:true});if(result.exceptionDetails)throw new Error("Browser evaluation failed");return result.result?.value;}
async function waitFor(expression,label){const deadline=Date.now()+45000;while(Date.now()<deadline){if(await evaluate(expression))return;await new Promise(resolve=>setTimeout(resolve,400));}throw new Error("Timed out: "+label);}
async function capture(path){const shot=await send("Page.captureScreenshot",{format:"png",captureBeyondViewport:false});await fs.writeFile(path,Buffer.from(shot.data,"base64"));}

import "./../server/_core/loadEnv.ts";
import oracledb from "oracledb";
import {getOracleConfig} from "../server/oracle.ts";
import {passwordHash,tagActor} from "../server/oracleSession.ts";
import {randomBytes} from "node:crypto";
const c=await oracledb.getConnection(getOracleConfig());
const suffix=Date.now().toString();
const username="browser_verify_"+suffix;
const password=randomBytes(24).toString("base64url");
const name="اختبار آلي "+suffix;
const beforeName="اختبار واجهة "+suffix;
const afterName="اختبار معدل "+suffix;
let userId; const results=[];
const pass=name=>{results.push({name,passed:true});console.log("PASS "+name);};
async function fill(selector,value){await evaluate("(()=>{const input=document.querySelector("+JSON.stringify(selector)+");Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(input,"+JSON.stringify(value)+");input.dispatchEvent(new Event('input',{bubbles:true}));})()");}
async function clickText(text,root="document"){await evaluate("Array.from("+root+".querySelectorAll('button')).find(b=>b.textContent.trim()==="+JSON.stringify(text)+").click()");}
async function openRow(text){await evaluate("Array.from(document.querySelectorAll('.oracle-data-panel > .oracle-table-scroll tbody tr')).find(r=>r.textContent.includes("+JSON.stringify(text)+")).querySelector('.oracle-row-action').click()");}
const lastDialog="Array.from(document.querySelectorAll('[role=dialog]')).at(-1)";
try{
 const created=await c.execute("INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE) VALUES(:username,:name,:hash,'admin') RETURNING ID INTO :id",{username,name,hash:await passwordHash(password),id:{dir:oracledb.BIND_OUT,type:oracledb.NUMBER}});
 userId=Number(created.outBinds.id[0]);await c.commit();
 await send("Page.enable");await send("Runtime.enable");
 await send("Emulation.setDeviceMetricsOverride",{width:1440,height:1100,deviceScaleFactor:1,mobile:false});
 await send("Page.navigate",{url:base+"/?view=costCenters"});
 await waitFor("document.querySelector('input[autocomplete=username]')!==null","login form");
 if(await evaluate("Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='إضافة سجل')"))throw new Error("Anonymous visitor sees write controls");
 await fill("input[autocomplete=username]",username);
 await fill("input[autocomplete='current-password']",password);
 await evaluate("document.querySelector('input[autocomplete=username]').form.requestSubmit()");
 await waitFor("document.body.textContent.includes("+JSON.stringify(name)+")","authenticated identity");
 pass("Personal login and server-issued session");
 await clickText("إضافة سجل");
 await waitFor("document.querySelector('[role=dialog] input')!==null","create form");
 await fill("[role=dialog] input",beforeName);
 await evaluate("document.querySelector('[role=dialog] form').requestSubmit()");
 await waitFor("!document.querySelector('[role=dialog]') && document.querySelector('.oracle-data-panel')?.textContent.includes("+JSON.stringify(beforeName)+")","saved center");
 pass("Create cost center through browser");
 await openRow(beforeName);await clickText("تعديل",lastDialog);
 await waitFor("document.querySelector('[role=dialog] form input:not(:disabled)')!==null","edit form");
 await fill("[role=dialog] form input",afterName);
 await evaluate(lastDialog+".querySelector('form').requestSubmit()");
 await waitFor("!document.querySelector('[role=dialog]') && document.querySelector('.oracle-data-panel')?.textContent.includes("+JSON.stringify(afterName)+")","updated center");
 pass("Edit loads full record and saves latest version");
 await openRow(afterName);await clickText("حذف",lastDialog);
 await waitFor("document.querySelector('[role=dialog] form button[type=submit]:not(:disabled)')!==null","delete confirmation");
 await evaluate(lastDialog+".querySelector('form').requestSubmit()");
 await waitFor("!document.querySelector('[role=dialog]') && !document.querySelector('.oracle-data-panel')?.textContent.includes("+JSON.stringify(afterName)+")","deleted center");
 pass("Delete requires confirmation and removes record");
 await send("Page.navigate",{url:base+"/?view=history"});
 await waitFor("document.querySelector('form input')!==null && document.body.textContent.includes('عرض التقرير')","audit report");
 await fill("form input",name);
 await evaluate("document.querySelector('form').requestSubmit()");
 await waitFor("document.querySelectorAll('.oracle-content > section table tbody tr').length===3","three audit events");
 const text=await evaluate("document.querySelector('.oracle-content > section').textContent");
 for(const action of ["إضافة","تعديل","حذف"])if(!text.includes(action))throw new Error("Missing audit action "+action);
 pass("Report filters three committed operations by authenticated actor");
 await clickText("قبل / بعد");
 await waitFor("document.querySelector('[role=dialog] table tbody tr')!==null","audit before after");
 if(!await evaluate("document.querySelector('[role=dialog]').textContent.includes("+JSON.stringify(afterName)+")"))throw new Error("Deleted record snapshot missing");
 pass("Deleted data remains available in audit detail");
 await capture("oracle-operations-audit.png");
 await send("Emulation.setDeviceMetricsOverride",{width:390,height:844,deviceScaleFactor:1,mobile:true});
 await send("Page.navigate",{url:base+"/?view=history"});
 await waitFor("document.body.textContent.includes('عرض التقرير')","mobile report");
 if(!await evaluate("document.documentElement.scrollWidth<=window.innerWidth"))throw new Error("Mobile report overflow");
 pass("Mobile report layout");
 await clickText("تسجيل الخروج");
 await waitFor("document.body.textContent.includes('سجل الدخول بحساب مدير')","logout permissions");
 pass("Logout revokes access to audit report");
 if(exceptions.length)throw new Error("Browser exceptions: "+exceptions.join(","));
 await fs.writeFile("oracle-operations-browser-verification.json",JSON.stringify({checkedAt:new Date().toISOString(),results},null,2));
}catch(error){await capture("oracle-operations-failure.png").catch(()=>{});throw error;}finally{
 try{
  if(userId){
   await tagActor(c,{ID:userId,USERNAME:username,DISPLAY_NAME:name,ROLE:"admin"});
   // Only remove this run's exact fixture names if a browser assertion failed before deletion.
   await c.execute("DELETE FROM CENTER_COST WHERE CC_NAME IN (:beforeName,:afterName)",{beforeName,afterName});
   await c.execute("DELETE FROM APP_SESSIONS WHERE USER_ID=:id",{id:userId});
   await c.execute("DELETE FROM APP_USERS WHERE ID=:id AND USERNAME=:username",{id:userId,username});
   await c.commit();
  }
 }finally{await c.close();socket.close();await fetch("http://127.0.0.1:9225/json/close/"+target.id).catch(()=>{});}
}
