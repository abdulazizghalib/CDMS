import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "../server/oracle";
import {
  getPurchaseAccountSettings,
  savePurchaseAccountSettings,
} from "../server/purchaseAccountSettings";
import { purchaseInvoiceOptions } from "../server/oraclePurchaseInvoice";
import type { Actor } from "../server/oracleSession";
const c = await oracledb.getConnection(getOracleConfig());
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
try {
  const before = await getPurchaseAccountSettings(c);
  const actor = (
    await c.execute<Actor>(
      "SELECT ID,USERNAME,DISPLAY_NAME,ROLE FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 ORDER BY ID",
      [],
      o
    )
  ).rows![0];
  const parent = (
    await c.execute<{ BAR_NUM: number }>(
      "SELECT DISTINCT BAR_NUM FROM SON_ACT ORDER BY BAR_NUM",
      [],
      o
    )
  ).rows![0].BAR_NUM;
  const scoped = {
    execute: c.execute.bind(c),
    commit: async () => {},
    rollback: async () => {},
  } as Connection;
  await savePurchaseAccountSettings(scoped, actor, {
    supplierParent: parent,
    stockParent: parent,
    ownerParent: parent,
  });
  const options = await purchaseInvoiceOptions(c);
  assert(options.suppliers.length > 0 && options.accounts.length > 0);
  assert(
    options.suppliers.every(a => a.BAR_NUM === parent) &&
      options.accounts.every(a => a.BAR_NUM === parent) &&
      options.owners.every(a => a.BAR_NUM === parent)
  );
  await assert.rejects(() =>
    savePurchaseAccountSettings(scoped, actor, {
      supplierParent: 99999999,
      stockParent: parent,
      ownerParent: parent,
    })
  );
  const row = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM APP_AUDIT_LOG WHERE TABLE_NAME='APP_PURCHASE_SETTINGS' AND TRANSACTION_ID=DBMS_TRANSACTION.LOCAL_TRANSACTION_ID",
      [],
      o
    )
  ).rows![0];
  assert(row.N >= 1);
  await c.rollback();
  assert.deepEqual(await getPurchaseAccountSettings(c), before);
  console.log(
    "PASS Configured account filtering, parent validation, audit and complete rollback"
  );
} finally {
  await c.rollback();
  await c.close();
}
