﻿import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
const c = await oracledb.getConnection(getOracleConfig());
try {
  const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
  async function value(sql: string) {
    return Number((await c.execute<{ N: number }>(sql, [], o)).rows![0].N);
  }
  const lines = await value(
    "SELECT COUNT(*) N FROM CAR_SALES_INV d JOIN SALES_INVOICE m ON m.SI_ID=d.CSI_INV_REF"
  );
  assert.equal(await value("SELECT COUNT(*) N FROM SALES_INVOICE_VIEW"), lines);
  assert.equal(await value("SELECT COUNT(*) N FROM INV_SALES_DET_VIEW"), lines);
  const total = await value(
    "SELECT NVL(SUM(CSI_SALES_PRICE),0) N FROM CAR_SALES_INV d JOIN SALES_INVOICE m ON m.SI_ID=d.CSI_INV_REF"
  );
  for (const sql of [
    "SELECT NVL(SUM(NET_TOTAL),0) N FROM INVOICE_DATAIL2_VIEW",
    "SELECT NVL(SUM(TOTAL),0) N FROM INVOICE_PRINT_VIEW",
    "SELECT NVL(SUM(SUM_TOTAL),0) N FROM INVOICE_CLOSE_DETAIL_VIEW",
  ])
    assert.equal(await value(sql), total);
  assert.equal(
    await value("SELECT MAINMAX N FROM MAINACTMAX"),
    await value("SELECT NVL(MAX(AC_NUM)+1,1) N FROM MAIN_ACT")
  );
  assert.equal(
    await value("SELECT MAINMAX N FROM BRANSHMAX"),
    await value("SELECT NVL(MAX(BAR_NUM)+1,1) N FROM BRANSH_ACT")
  );
  assert.equal(
    await value("SELECT NVL(SUM(SL_TOTAL),0) N FROM SALES_CLOSE_COST_VIEW"),
    await value(
      "SELECT NVL(SUM(ST_PRICE_OUT),0) N FROM STOCK_LEDGER s JOIN SALES_INVOICE m ON m.SI_ID=s.ST_INV_REF WHERE m.SI_POST_STATUS='UN POST' AND s.ST_STATUS='sales'"
    )
  );
  console.log(
    JSON.stringify({
      checks: 8,
      linkedSalesLines: lines,
      salesLineTotal: total,
      committedBusinessChanges: 0,
    })
  );
} finally {
  await c.close();
}
