﻿import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
import { getDailyJournal } from "../server/dailyJournal";
const c = await oracledb.getConnection(getOracleConfig());
try {
  const input = { date1: "2025-12-09", date2: "2025-12-09" };
  const data = await getDailyJournal(c, input);
  const totals = (
    await c.execute<{ N: number; D: number; C: number }>(
      "SELECT COUNT(*) N,NVL(SUM(AL_DEPIT_MOUNT),0) D,NVL(SUM(AL_CREDIT_MOUNT),0) C FROM ACCOUNT_LEDGER WHERE AL_DATE>=TO_DATE(:date1,'YYYY-MM-DD') AND AL_DATE<TO_DATE(:date2,'YYYY-MM-DD')+1",
      input,
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows![0];
  assert.equal(data.lines.length, totals.N);
  assert.equal(data.debit, Math.round(totals.D * 100) / 100);
  assert.equal(data.credit, Math.round(totals.C * 100) / 100);
  assert.ok(data.lines.every(r => r.AL_DATE.startsWith(input.date1)));
  console.log(
    "PASS Oracle journal " +
      data.lines.length +
      " movements, all fields and matching totals"
  );
} finally {
  await c.close();
}
