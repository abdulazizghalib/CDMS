﻿import "../server/_core/loadEnv";
import fs from "node:fs";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
const c = await oracledb.getConnection(getOracleConfig());
try {
  const exists = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM USER_TABLES WHERE TABLE_NAME='APP_DEALER_ACTIVITIES'",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0]?.N;
  if (!exists)
    for (const sql of fs
      .readFileSync("database/oracle-dealer-activities.sql", "utf8")
      .replace(/^\uFEFF/, "")
      .split(";")
      .map(s => s.trim())
      .filter(Boolean))
      await c.execute(sql);
  console.log(
    exists
      ? "Activities table already installed"
      : "Installed activities table and index"
  );
} finally {
  await c.close();
}
