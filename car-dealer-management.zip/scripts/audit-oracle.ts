import "../server/_core/loadEnv";
import { discoverOracleSchema, oracleRuntimeStatus, verifyLegacyMapping } from "../server/oracleValidation";
const status = oracleRuntimeStatus();
if (!status.enabled) { console.error(status.reason); process.exitCode = 1; } else { try { const snapshot = await discoverOracleSchema(); console.log(JSON.stringify({ checkedAt: new Date().toISOString(), scope: "Connected user schema; metadata only, not business trigger execution", snapshot, mapping: verifyLegacyMapping(snapshot) }, null, 2)); } catch(error) { console.error("Oracle audit failed:", (error as { code?: string }).code ?? "CONNECTION_OR_QUERY_FAILED"); process.exitCode = 1; } }
