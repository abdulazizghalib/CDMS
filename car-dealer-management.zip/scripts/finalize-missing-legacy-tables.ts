﻿import "../server/_core/loadEnv";
import fs from "node:fs";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
const c = await oracledb.getConnection(getOracleConfig());
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
try {
  const old = (
    await c.execute<{ TEXT: string }>(
      "SELECT TEXT FROM USER_VIEWS WHERE VIEW_NAME='STOCK_LEDGER_DETAIL'",
      [],
      o
    )
  ).rows![0].TEXT;
  const path = "database/stock-detail-view-backup.sql";
  if (!fs.existsSync(path))
    fs.writeFileSync(
      path,
      "CREATE OR REPLACE VIEW STOCK_LEDGER_DETAIL AS " + old + ";\n"
    );
  const sql = `CREATE OR REPLACE VIEW STOCK_LEDGER_DETAIL AS
 SELECT s.ST_ID SL_ID,s.ST_DATE SL_DATE,
 CASE WHEN s.ST_STATUS='sales' THEN m.SI_TIME ELSE TO_CHAR(p.PUI_TIME,'HH24:MI:SS') END SL_TIME,
 CASE WHEN s.ST_STATUS='sales' THEN m.SI_SHIFT ELSE p.PUI_SHIFT END SL_SHIFT,
 CASE WHEN s.ST_STATUS='sales' THEN m.SI_BRANSH ELSE p.PUI_BRANSH END SL_BRANSH,
 CASE WHEN s.ST_STATUS='sales' THEN m.SI_USER_ENTERED ELSE p.PUI_ENTERED_BY END SL_ENTERED_BY,
 UPPER(s.ST_STATUS) SL_TRANSACTION_TYPE,s.ST_TYPE PROD_NAM,
 CAST(NULL AS VARCHAR2(50)) SL_QTY_IN_UNIT,
 CASE WHEN s.ST_STATUS='purchase' THEN 1 ELSE 0 END SL_QTY_IN,s.ST_PRICE_IN SL_QTY_IN_PRICE,
 CAST(NULL AS VARCHAR2(50)) SL_QTY_OUT_UNIT,
 CASE WHEN s.ST_STATUS='sales' THEN 1 ELSE 0 END SL_QTY_OUT,s.ST_PRICE_OUT SL_QTY_OUT_PRICE,
 s.ST_INV_REF SL_INV_NO,CAST(NULL AS VARCHAR2(100)) SL_PROD_GROUP,s.ST_HIKL SL_SERIAL_NO
 FROM STOCK_LEDGER s
 LEFT JOIN SALES_INVOICE m ON s.ST_STATUS='sales' AND m.SI_ID=s.ST_INV_REF
 LEFT JOIN PURCHASE_INVOICE p ON s.ST_STATUS='purchase' AND p.PUI_ID=s.ST_INV_REF`;
  await c.execute(sql);
  fs.writeFileSync("database/stock-detail-view-repair.sql", sql + ";\n");
  // PRODUCTCART.DAT is a formatted date string: CARTV explicitly converts it with TO_DATE.
  await c.execute("ALTER TABLE PRODUCTCART MODIFY DAT VARCHAR2(10 CHAR)");
  const invalid = (
    await c.execute(
      "SELECT OBJECT_NAME,OBJECT_TYPE FROM USER_OBJECTS WHERE STATUS='INVALID'",
      [],
      o
    )
  ).rows;
  const errors = (
    await c.execute(
      "SELECT NAME,TYPE,LINE,TEXT FROM USER_ERRORS WHERE ATTRIBUTE='ERROR'",
      [],
      o
    )
  ).rows;
  const sourceCount = (
    await c.execute<{ N: number }>("SELECT COUNT(*) N FROM STOCK_LEDGER", [], o)
  ).rows![0].N;
  const viewCount = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM STOCK_LEDGER_DETAIL",
      [],
      o
    )
  ).rows![0].N;
  if (sourceCount !== viewCount) throw new Error("Stock detail count mismatch");
  const plan = JSON.parse(
    fs.readFileSync("database/missing-table-plan.json", "utf8")
  );
  const tableChecks = [];
  for (const t of plan) {
    const n = (
      await c.execute<{ N: number }>("SELECT COUNT(*) N FROM " + t.table, [], o)
    ).rows![0].N;
    tableChecks.push({ table: t.table, rows: n });
    if (n !== 0) throw new Error("Unexpected rows in newly created table");
  }
  fs.writeFileSync(
    "_database-final-verification.json",
    JSON.stringify(
      {
        createdTables: tableChecks,
        invalidObjects: invalid,
        errors,
        stockRows: sourceCount,
        stockDetailRows: viewCount,
      },
      null,
      2
    )
  );
  console.log(
    JSON.stringify({
      createdTables: tableChecks.length,
      invalidObjects: invalid.length,
      errors: errors.length,
      stockRows: sourceCount,
      stockDetailRows: viewCount,
    })
  );
  if (invalid.length || errors.length) process.exitCode = 1;
} finally {
  await c.close();
}
