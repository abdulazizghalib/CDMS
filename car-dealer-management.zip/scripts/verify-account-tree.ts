﻿import "../server/_core/loadEnv";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
import { getAccountTree } from "../server/accountTree";
const c = await oracledb.getConnection(getOracleConfig());
try {
  console.log((await getAccountTree(c)).length);
} finally {
  await c.close();
}
