import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "../server/oracle";
import { type Actor } from "../server/oracleSession";
import {
  createActivity,
  finishActivity,
  listActivities,
  activityVehicles,
} from "../server/dealerActivities";
import { salesInvoiceOptions } from "../server/salesInvoice";
const c = await oracledb.getConnection(getOracleConfig());
const scope = {
  execute: c.execute.bind(c),
  commit: async () => {},
  rollback: async () => {},
  close: async () => {},
} as Connection;
try {
  const actor = (
    await c.execute<Actor>(
      "SELECT ID,USERNAME,DISPLAY_NAME,ROLE FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND ROWNUM=1",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows![0];
  const before = (await listActivities(c)).length;
  const car = (await activityVehicles(c))[0];
  assert.ok(car, "Available car required");
  const future = new Date(Date.now() + 86400000 + 10800000)
    .toISOString()
    .slice(0, 16);
  const input = {
    kind: "reservation" as const,
    customer: "اختبار حجز مؤقت",
    phone: "0500000000",
    vehicleId: car.ID,
    scheduledAt: future,
    notes: "ROLLBACK verification",
  };
  const { id } = await createActivity(scope, actor, input);
  assert.ok(
    (await listActivities(c)).some(r => r.ID === id && r.STATUS === "active")
  );
  assert.ok(!(await activityVehicles(c)).some(r => r.ID === car.ID));
  assert.ok(
    !(await salesInvoiceOptions(c)).vehicles.some(r => r.ID === car.ID)
  );
  await assert.rejects(
    createActivity(scope, actor, input),
    /السيارة غير متاحة/
  );
  const linkedFollow = await createActivity(scope, actor, {
    ...input,
    kind: "followup",
  });
  await finishActivity(scope, actor, {
    id: linkedFollow.id,
    status: "completed",
  });
  await finishActivity(scope, actor, { id, status: "cancelled" });
  assert.ok((await activityVehicles(c)).some(r => r.ID === car.ID));
  await assert.rejects(
    finishActivity(scope, actor, { id, status: "completed" }),
    /السجل مغلق/
  );
  const follow = await createActivity(scope, actor, {
    ...input,
    kind: "followup",
    vehicleId: null,
  });
  await finishActivity(scope, actor, { id: follow.id, status: "completed" });
  assert.ok(
    (await listActivities(c)).some(
      r => r.ID === follow.id && r.STATUS === "completed"
    )
  );
  const expiring = await createActivity(scope, actor, input);
  await c.execute(
    "UPDATE APP_DEALER_ACTIVITIES SET SCHEDULED_AT=CAST(SYSTIMESTAMP AT TIME ZONE '+03:00' AS TIMESTAMP)-INTERVAL '1' MINUTE WHERE ID=:id",
    { id: expiring.id }
  );
  assert.ok(
    (await listActivities(c)).some(
      r => r.ID === expiring.id && r.STATUS === "expired"
    )
  );
  assert.ok((await activityVehicles(c)).some(r => r.ID === car.ID));
  assert.ok((await salesInvoiceOptions(c)).vehicles.some(r => r.ID === car.ID));
  const auditCount = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM APP_AUDIT_LOG WHERE TABLE_NAME='APP_DEALER_ACTIVITIES' AND RECORD_ID=:id",
      { id: String(id) },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0]?.N;
  assert.equal(auditCount, 2);
  await c.rollback();
  assert.equal((await listActivities(c)).length, before);
  console.log(
    "PASS Oracle reservation, duplicate prevention, sales exclusion, cancellation, follow-up completion, audit and rollback"
  );
} finally {
  await c.rollback();
  await c.close();
}
