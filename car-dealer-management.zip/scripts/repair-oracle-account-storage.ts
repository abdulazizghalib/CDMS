import "../server/_core/loadEnv";
import fs from "node:fs";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
const c = await oracledb.getConnection(getOracleConfig());
try {
  const quota = (
    await c.execute<{ MAX_BYTES: number }>(
      "SELECT MAX_BYTES FROM USER_TS_QUOTAS WHERE TABLESPACE_NAME='USERS'",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0];
  if (!quota || quota.MAX_BYTES !== -1)
    throw new Error("Verify target USERS quota before moving storage");
  const plan: string[] = [];
  for (const table of ["MAIN_ACT", "BRANSH_ACT", "SON_ACT"]) {
    const n = (
      await c.execute<{ N: number }>("SELECT COUNT(*) N FROM " + table, [], {
        outFormat: oracledb.OUT_FORMAT_OBJECT,
      })
    ).rows![0].N;
    const storage = (
      await c.execute<{ TABLESPACE_NAME: string }>(
        "SELECT TABLESPACE_NAME FROM USER_TABLES WHERE TABLE_NAME=:tableName",
        { tableName: table },
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows![0];
    if (storage.TABLESPACE_NAME === "SYSTEM") {
      if (n !== 0) throw new Error("Refusing to move nonempty table " + table);
      plan.push("ALTER TABLE " + table + " MOVE TABLESPACE USERS");
    }
    const indexes = (
      await c.execute<{
        INDEX_NAME: string;
        TABLESPACE_NAME: string;
        STATUS: string;
      }>(
        "SELECT INDEX_NAME,TABLESPACE_NAME,STATUS FROM USER_INDEXES WHERE TABLE_NAME=:tableName",
        { tableName: table },
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows!;
    for (const index of indexes) {
      if (!/^[A-Z0-9_]+$/.test(index.INDEX_NAME))
        throw new Error("Unexpected index name");
      if (index.TABLESPACE_NAME === "SYSTEM" || index.STATUS !== "VALID")
        plan.push(
          "ALTER INDEX " + index.INDEX_NAME + " REBUILD TABLESPACE USERS"
        );
    }
  }
  if (plan.length)
    fs.writeFileSync(
      "database/oracle-account-storage.sql",
      "-- Verified empty account definitions; move storage only. No row changes.\n" +
        plan.join(";\n") +
        ";\n"
    );
  if (process.argv.includes("--apply"))
    for (const sql of plan) {
      await c.execute(sql);
      console.log(sql);
    }
  else console.log(plan.join("\n"));
  console.log("Account storage checks complete");
} finally {
  await c.close();
}
