import "../server/_core/loadEnv";
import fs from "node:fs/promises";
import { randomBytes, createHash } from "node:crypto";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
async function connect(url) {
  const socket = new WebSocket(url);
  await new Promise((r, j) => {
    socket.addEventListener("open", r, { once: true });
    socket.addEventListener("error", j, { once: true });
  });
  let seq = 0;
  const requests = new Map();
  socket.addEventListener("message", e => {
    const m = JSON.parse(e.data);
    if (m.id) {
      const p = requests.get(m.id);
      if (p) {
        requests.delete(m.id);
        clearTimeout(p.timer);
        m.error ? p.j(new Error(m.error.message)) : p.r(m.result);
      }
    }
  });
  return {
    socket,
    send: (method, params = {}) =>
      new Promise((r, j) => {
        const id = ++seq;
        const timer = setTimeout(
          () => j(new Error("CDP timeout " + method)),
          20000
        );
        requests.set(id, { r, j, timer });
        socket.send(JSON.stringify({ id, method, params }));
      }),
  };
}
const c = await oracledb.getConnection(getOracleConfig());
const token = randomBytes(32).toString("hex"),
  hash = createHash("sha256").update(token).digest("hex");
let browser, context, page;
try {
  const actor = (
    await c.execute(
      "SELECT ID FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND (EXPIRES_AT IS NULL OR EXPIRES_AT>SYSTIMESTAMP) AND ROWNUM=1",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0];
  if (!actor) throw new Error("No active admin for browser verification");
  await c.execute(
    "INSERT INTO APP_SESSIONS(TOKEN_HASH,USER_ID,EXPIRES_AT) VALUES(:token,:actor,SYSTIMESTAMP+NUMTODSINTERVAL(5,'MINUTE'))",
    { token: hash, actor: actor.ID }
  );
  await c.commit();
  const version = await (
    await fetch("http://127.0.0.1:9225/json/version")
  ).json();
  browser = await connect(version.webSocketDebuggerUrl);
  context = (await browser.send("Target.createBrowserContext"))
    .browserContextId;
  const target = (
    await browser.send("Target.createTarget", {
      url: "about:blank",
      browserContextId: context,
    })
  ).targetId;
  const list = await (await fetch("http://127.0.0.1:9225/json/list")).json();
  page = await connect(list.find(t => t.id === target).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Runtime.enable");
  await page.send("Emulation.setDeviceMetricsOverride", {
    width: 1440,
    height: 1100,
    deviceScaleFactor: 1,
    mobile: false,
  });
  await page.send("Network.setCookie", {
    name: "dealer_oracle_session",
    value: token,
    url: "http://localhost:3000",
    httpOnly: true,
    sameSite: "Lax",
  });
  const evaluate = async expression => {
    const r = await page.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text);
    return r.result.value;
  };
  async function wait(expr, label) {
    const until = Date.now() + 30000;
    while (Date.now() < until) {
      if (await evaluate(expr)) return;
      await new Promise(r => setTimeout(r, 300));
    }
    throw new Error(
      "Timed out: " +
        label +
        " - " +
        (await evaluate("document.body.innerText.slice(0,6000)"))
    );
  }
  await page.send("Page.navigate", {
    url: "http://localhost:3000/?view=balanceSheet",
  });
  await wait(
    "document.querySelectorAll('.balance-side').length===2",
    "balance sheet sides"
  );
  const placement = await evaluate(
    "({assets:document.querySelector('[data-balance-side=assets]').getBoundingClientRect().x,liabilities:document.querySelector('[data-balance-side=liabilities]').getBoundingClientRect().x})"
  );
  if (placement.assets <= placement.liabilities)
    throw new Error("Assets must appear on right");
  console.log(
    "PASS Actual report displays assets on right and liabilities/equity on left"
  );
  await page.send("Page.addScriptToEvaluateOnNewDocument", {
    source: `const originalFetch=window.fetch.bind(window);window.fetch=async(...args)=>{const response=await originalFetch(...args);const url=String(args[0] instanceof Request?args[0].url:args[0]);if(!url.includes('oracleOperations.balanceSheet'))return response;const body=await response.json();const list=Array.isArray(body)?body:[body];const names=new URL(url,location.href).pathname.split('/').pop().split(',');const index=names.indexOf('oracleOperations.balanceSheet');if(index>=0&&list[index]?.result)list[index].result.data={json:{date1:'2026-10-01',date2:'2026-10-06',debit:130000,credit:130000,balance:0,lines:[{AL_MAIN_NUM:1000,AC_NAM:'الأصول المتداولة',AL_BAR_NUM:2003,BRANSHACNAM:'مخزون المعرض',AL_ACC_NO:3001,AL_ACC_NAME:'مخزون',DEPIT:100000,CREDIT:30000,BALANCE:-70000},{AL_MAIN_NUM:1002,AC_NAM:'الخصوم المتداولة',AL_BAR_NUM:2007,BRANSHACNAM:'مورد عام',AL_ACC_NO:3002,AL_ACC_NAME:'المورد',DEPIT:30000,CREDIT:0,BALANCE:-30000},{AL_MAIN_NUM:1004,AC_NAM:'حقوق الملكية',AL_BAR_NUM:2010,BRANSHACNAM:'رأس المال',AL_ACC_NO:3003,AL_ACC_NAME:'المالك',DEPIT:0,CREDIT:100000,BALANCE:100000}]}};return new Response(JSON.stringify(Array.isArray(body)?list:list[0]),{status:200,headers:{'content-type':'application/json'}});};`,
  });
  await page.send("Page.navigate", {
    url: "http://localhost:3000/?view=balanceSheet",
  });
  await wait(
    "document.querySelectorAll('.balance-side tbody tr').length===3",
    "example figures"
  );
  const totals = await evaluate(
    "Array.from(document.querySelectorAll('.balance-side tfoot tr')).map(r=>r.innerText)"
  );
  if (totals.length !== 2) throw new Error("Missing totals");
  const screenshot = await page.send("Page.captureScreenshot", {
    format: "png",
  });
  await fs.writeFile(
    "_balance-sheet-preview.png",
    Buffer.from(screenshot.data, "base64")
  );
  await evaluate(
    "window.__prints=[];new MutationObserver(records=>{for(const r of records)for(const n of r.addedNodes)if(n.tagName==='IFRAME')n.contentWindow.print=()=>window.__prints.push(n.contentDocument.body.innerText)}).observe(document.body,{childList:true})"
  );
  await evaluate(
    "Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='طباعة الأصول').click()"
  );
  await wait("window.__prints.length===1", "asset print");
  const first = await evaluate("window.__prints[0]");
  if (!first.includes("مخزون المعرض") || first.includes("مورد عام"))
    throw new Error("Side print contains wrong accounts");
  await evaluate(
    "Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='طباعة الميزانية').click()"
  );
  await wait("window.__prints.length===2", "full print");
  const all = await evaluate("window.__prints[1]");
  if (
    !all.includes("مخزون المعرض") ||
    !all.includes("مورد عام") ||
    !all.includes("رأس المال")
  )
    throw new Error("Full print missing accounts");
  console.log(
    "PASS Grouped examples, side totals and isolated side/full print documents"
  );
  await page.send("Emulation.setDeviceMetricsOverride", {
    width: 390,
    height: 844,
    deviceScaleFactor: 1,
    mobile: true,
  });
  await new Promise(r => setTimeout(r, 500));
  const overflow = await evaluate(
    "document.documentElement.scrollWidth>window.innerWidth+2"
  );
  if (overflow) throw new Error("Mobile horizontal page overflow");
  console.log("PASS Mobile layout");
} finally {
  if (page) page.socket.close();
  if (browser && context) {
    await browser.send("Target.disposeBrowserContext", {
      browserContextId: context,
    });
    browser.socket.close();
  }
  await c.execute("DELETE FROM APP_SESSIONS WHERE TOKEN_HASH=:token", {
    token: hash,
  });
  await c.commit();
  await c.close();
}
