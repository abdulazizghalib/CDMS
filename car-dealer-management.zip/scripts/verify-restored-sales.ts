import "../server/_core/loadEnv";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "../server/oracle";
import { passwordHash, type Actor } from "../server/oracleSession";
import {
  salesInvoiceOptions,
  createSalesInvoice,
} from "../server/salesInvoice";
const c = await oracledb.getConnection(getOracleConfig());
const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
const tables = [
  "SALES_INVOICE",
  "CAR_SALES_INV",
  "ACCOUNT_LEDGER",
  "STOCK_LEDGER",
  "APP_USERS",
  "APP_AUDIT_LOG",
];
async function counts() {
  const out: Record<string, number> = {};
  for (const table of tables)
    out[table] = (
      await c.execute<{ N: number }>("SELECT COUNT(*) N FROM " + table, [], o)
    ).rows![0].N;
  return out;
}
const before = await counts();
try {
  const saved = await c.execute(
    "INSERT INTO APP_USERS(USERNAME,DISPLAY_NAME,PASSWORD_HASH,ROLE) VALUES(:name,'Rollback verification',:hash,'admin') RETURNING ID INTO :id",
    {
      name: "restore_verify_" + Date.now(),
      hash: await passwordHash("rollback-verification-password"),
      id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER },
    }
  );
  const actor: Actor = {
    ID: Number((saved.outBinds as { id: number[] }).id[0]),
    USERNAME: "restore_verifier",
    DISPLAY_NAME: "Rollback verification",
    ROLE: "admin",
  };
  const choices = await salesInvoiceOptions(c);
  if (!choices.vehicles.length)
    throw new Error("No available vehicles to verify");
  const v = choices.vehicles[0];
  const account = choices.accounts.find(
    a => a.BAR_NUM === choices.settings.salesParent
  )!;
  const payment = choices.accounts.find(
    a => a.BAR_NUM === choices.settings.paymentParent
  )!;
  const scoped = {
    execute: c.execute.bind(c),
    commit: async () => {},
    rollback: c.rollback.bind(c),
    close: async () => {},
  } as Connection;
  const result = await createSalesInvoice(scoped, actor, {
    date: "2026-10-04",
    phone: "",
    branch: "",
    notes: "Rollback test",
    accountId: account.ID,
    paymentAccountId: payment.ID,
    vat: 0,
    lines: [{ purchaseId: v.ID, price: Math.max(1, v.COST) }],
  });
  const detail = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM CAR_SALES_INV WHERE CSI_INV_REF=:id",
      { id: result.id },
      o
    )
  ).rows![0].N;
  const ledger = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM ACCOUNT_LEDGER WHERE AL_DOC_ID=:id AND AL_DOC_TYPE IN (10,11)",
      { id: result.id },
      o
    )
  ).rows![0].N;
  const stock = (
    await c.execute<{ N: number }>(
      "SELECT COUNT(*) N FROM STOCK_LEDGER WHERE ST_INV_REF=:id AND ST_STATUS='sales'",
      { id: result.id },
      o
    )
  ).rows![0].N;
  if (detail !== 1 || ledger !== 4 || stock !== 1)
    throw new Error(JSON.stringify({ detail, ledger, stock }));
  console.log(
    "PASS Sales invoice master/detail, 4 accounting entries, 1 stock entry"
  );
  await c.rollback();
  const after = await counts();
  if (JSON.stringify(before) !== JSON.stringify(after))
    throw new Error("Rollback count mismatch");
  console.log("PASS Rollback restored all business and application row counts");
} finally {
  await c.rollback();
  await c.close();
}
