﻿import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
const excelRequire = createRequire(
  createRequire(import.meta.url).resolve("exceljs")
);
const archiver = excelRequire("archiver");
const root = process.cwd();
const directories = [
  "client",
  "server",
  "shared",
  "scripts",
  "patches",
  "drizzle",
  ".github",
  ".devcontainer",
  "docs",
];
const rootFiles = [
  "package.json",
  "pnpm-lock.yaml",
  "tsconfig.json",
  "vite.config.ts",
  "vitest.config.ts",
  "drizzle.config.ts",
  "components.json",
  ".prettierrc",
  ".prettierignore",
  ".gitignore",
  ".env.local.example",
  ".env.production.example",
  "README.md",
];
const databaseFiles = [
  "oracle-audit-install.sql",
  "oracle-attendance.sql",
  "oracle-branding.sql",
  "oracle-dealer-activities.sql",
  "oracle-purchase-settings.sql",
  "oracle-sales-account-settings.sql",
  "oracle-trial-accounts.sql",
  "create-missing-tables.sql",
];
const files = [];
function walk(relative) {
  for (const e of fs.readdirSync(path.join(root, relative), {
    withFileTypes: true,
  })) {
    const item = path.posix.join(relative, e.name);
    if (e.isSymbolicLink()) throw new Error("Symlink excluded: " + item);
    if (
      e.name === "node_modules" ||
      e.name === "__manus__" ||
      e.name === "dist" ||
      /\.(log|dmp|pem|key|bak)$/i.test(e.name)
    )
      continue;
    if (e.isDirectory()) walk(item);
    else if (e.isFile()) files.push(item);
  }
}
for (const d of directories) if (fs.existsSync(path.join(root, d))) walk(d);
for (const f of rootFiles) if (fs.existsSync(path.join(root, f))) files.push(f);
for (const f of databaseFiles)
  if (fs.existsSync(path.join(root, "database", f)))
    files.push("database/" + f);
files.sort();
for (const file of files) {
  if (!/\.(png|jpe?g|webp|woff2?|ico|pdf)$/i.test(file)) {
    const source = fs.readFileSync(path.join(root, file), "utf8");
    if (
      /(?:ghp_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{50,}|-----BEGIN (?:RSA |OPENSSH )?PRIVATE KEY-----)/.test(
        source
      )
    )
      throw new Error("Potential credential found in " + file);
    if (/(?:LOCAL_)?ORACLE_PASSWORD\s*[=:]\s*["']OPAL["']/i.test(source))
      throw new Error("Hardcoded Oracle credential found in " + file);
  }
}
const output = fs.createWriteStream(path.join(root, "CDMS-github-source.zip"));
const archive = archiver("zip", { zlib: { level: 9 } });
const complete = new Promise((resolve, reject) => {
  output.on("close", resolve);
  output.on("error", reject);
  archive.on("error", reject);
});
archive.pipe(output);
for (const file of files) archive.file(path.join(root, file), { name: file });
await archive.finalize();
await complete;
fs.writeFileSync(
  "_github-upload-manifest.json",
  JSON.stringify(
    {
      repository: "https://github.com/abdulazizghalib/CDMS",
      files,
      count: files.length,
      bytes: archive.pointer(),
      excluded: [
        "local secrets",
        "Oracle dumps",
        "local business reports",
        "screenshots",
        "node_modules",
        "dist",
        "debug outputs",
      ],
    },
    null,
    2
  )
);
console.log(
  `Prepared source archive: ${files.length} files, ${archive.pointer()} bytes. No local environment files or Oracle backups included.`
);
