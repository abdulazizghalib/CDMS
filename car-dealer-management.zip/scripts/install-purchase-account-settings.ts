import "../server/_core/loadEnv";
import fs from "node:fs";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
const c = await oracledb.getConnection(getOracleConfig());
try {
  for (const sql of fs
    .readFileSync("database/oracle-purchase-settings.sql", "utf8")
    .replace(/^\uFEFF/, "")
    .split(";")
    .map(s => s.trim())
    .filter(Boolean)) {
    try {
      await c.execute(sql);
    } catch (e) {
      if (![955, 1430].includes((e as { errorNum: number }).errorNum)) throw e;
    }
  }
  const sources =
    (
      await c.execute<{ TEXT: string }>(
        "SELECT TEXT FROM USER_SOURCE WHERE NAME='APP_AUD_PURCHASE_INVOICE' AND TYPE='TRIGGER' ORDER BY LINE",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows ?? [];
  let source = sources.map(r => r.TEXT).join("");
  if (!source) throw new Error("Purchase invoice audit trigger missing");
  if (!source.includes("PUI_OWNER_NUM")) {
    for (const version of ["NEW", "OLD"])
      source = source.replaceAll(
        `'PUI_ID' VALUE :${version}.PUI_ID`,
        `'PUI_ID' VALUE :${version}.PUI_ID,'PUI_OWNER_NUM' VALUE :${version}.PUI_OWNER_NUM,'PUI_OWNER_NAME' VALUE :${version}.PUI_OWNER_NAME,'PUI_OWNER_BAR_NUM' VALUE :${version}.PUI_OWNER_BAR_NUM,'PUI_OWNER_MAIN_NUM' VALUE :${version}.PUI_OWNER_MAIN_NUM`
      );
    await c.execute("CREATE OR REPLACE " + source);
    const errors = (
      await c.execute(
        "SELECT TEXT FROM USER_ERRORS WHERE NAME='APP_AUD_PURCHASE_INVOICE'",
        [],
        { outFormat: oracledb.OUT_FORMAT_OBJECT }
      )
    ).rows;
    if (errors?.length) throw new Error(JSON.stringify(errors));
  }
  for (let pass = 0; pass < 2; pass++) {
    const invalid =
      (
        await c.execute<{ OBJECT_NAME: string; OBJECT_TYPE: string }>(
          "SELECT OBJECT_NAME,OBJECT_TYPE FROM USER_OBJECTS WHERE STATUS='INVALID' AND OBJECT_NAME IN ('FUN_SUPPLIER_NAME','CAR_PURCHASE_ACTION_TRIGGER','CAR_PURCHASE_TOTAL_TRIGGER','PURCHASE_LEDGER_VIEW','STOCK_LEDGER_DETAIL') ORDER BY OBJECT_TYPE,OBJECT_NAME",
          [],
          { outFormat: oracledb.OUT_FORMAT_OBJECT }
        )
      ).rows ?? [];
    for (const object of invalid)
      await c.execute(
        `ALTER ${object.OBJECT_TYPE} ${object.OBJECT_NAME} COMPILE`
      );
  }
  await c.commit();
  console.log("Installed purchase account settings");
} finally {
  await c.close();
}
