import "../server/_core/loadEnv";
import fs from "node:fs";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
const c = await oracledb.getConnection(getOracleConfig());
try {
  for (const sql of fs
    .readFileSync("database/oracle-attendance.sql", "utf8")
    .replace(/^\uFEFF/, "")
    .split(";")
    .map(s => s.trim())
    .filter(Boolean)) {
    try {
      await c.execute(sql);
    } catch (e) {
      if (![955,1430].includes((e as {errorNum:number}).errorNum)) throw e;
    }
  }
  console.log("Installed attendance shifts, assignments and attendance tables");
} finally {
  await c.close();
}
