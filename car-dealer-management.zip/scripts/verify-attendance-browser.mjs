import "../server/_core/loadEnv";
import fs from "node:fs/promises";
import { randomBytes, createHash } from "node:crypto";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
async function connect(url) {
  const socket = new WebSocket(url);
  await new Promise((r, j) => {
    socket.addEventListener("open", r, { once: true });
    socket.addEventListener("error", j, { once: true });
  });
  let seq = 0;
  const requests = new Map();
  socket.addEventListener("message", e => {
    const m = JSON.parse(e.data);
    if (m.id) {
      const p = requests.get(m.id);
      if (p) {
        requests.delete(m.id);
        clearTimeout(p.timer);
        m.error ? p.j(new Error(m.error.message)) : p.r(m.result);
      }
    }
  });
  return {
    socket,
    send: (method, params = {}) =>
      new Promise((r, j) => {
        const id = ++seq;
        const timer = setTimeout(
          () => j(new Error("CDP timeout " + method)),
          20000
        );
        requests.set(id, { r, j, timer });
        socket.send(JSON.stringify({ id, method, params }));
      }),
  };
}
const c = await oracledb.getConnection(getOracleConfig());
const token = randomBytes(32).toString("hex"),
  hash = createHash("sha256").update(token).digest("hex");
let browser, context, page;
try {
  const actor = (
    await c.execute(
      "SELECT ID FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND (EXPIRES_AT IS NULL OR EXPIRES_AT>SYSTIMESTAMP) AND ROWNUM=1",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    )
  ).rows?.[0];
  if (!actor) throw new Error("No active admin for browser verification");
  await c.execute(
    "INSERT INTO APP_SESSIONS(TOKEN_HASH,USER_ID,EXPIRES_AT) VALUES(:token,:actor,SYSTIMESTAMP+NUMTODSINTERVAL(5,'MINUTE'))",
    { token: hash, actor: actor.ID }
  );
  await c.commit();
  const version = await (
    await fetch("http://127.0.0.1:9225/json/version")
  ).json();
  browser = await connect(version.webSocketDebuggerUrl);
  context = (await browser.send("Target.createBrowserContext"))
    .browserContextId;
  const target = (
    await browser.send("Target.createTarget", {
      url: "about:blank",
      browserContextId: context,
    })
  ).targetId;
  const list = await (await fetch("http://127.0.0.1:9225/json/list")).json();
  page = await connect(list.find(t => t.id === target).webSocketDebuggerUrl);
  await page.send("Page.enable");
  await page.send("Runtime.enable");
  await page.send("Emulation.setDeviceMetricsOverride", {
    width: 1440,
    height: 1100,
    deviceScaleFactor: 1,
    mobile: false,
  });
  await page.send("Network.setCookie", {
    name: "dealer_oracle_session",
    value: token,
    url: "http://localhost:3000",
    httpOnly: true,
    sameSite: "Lax",
  });
  const evaluate = async expression => {
    const r = await page.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text);
    return r.result.value;
  };
  async function wait(expr, label) {
    const until = Date.now() + 30000;
    while (Date.now() < until) {
      if (await evaluate(expr)) return;
      await new Promise(r => setTimeout(r, 300));
    }
    throw new Error(
      "Timed out: " +
        label +
        " - " +
        (await evaluate("document.body.innerText.slice(0,6000)"))
    );
  }
  await page.send('Page.navigate',{url:'http://localhost:3000/?view=attendanceSettings'});
  await wait("Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='إضافة وردية')",'shift settings');
  await evaluate("Array.from(document.querySelectorAll('button')).find(b=>b.textContent.trim()==='إضافة وردية').click()");
  await wait("document.querySelector('[role=dialog] input[type=time]')!==null",'shift form');
  const fields=await evaluate("({times:document.querySelectorAll('[role=dialog] input[type=time]').length,coords:document.querySelectorAll('[role=dialog] input[type=number]').length})");if(fields.times!==4 || fields.coords!==4)throw new Error('Missing shift time/location/grace inputs');console.log('PASS Shift settings with location, radius, allowed window, work times and late grace');
  await page.send('Page.navigate',{url:'http://localhost:3000/?view=attendanceReport'});
  await wait("document.body.textContent.includes('تقرير الحضور والغياب والتأخير') && !!document.querySelector('table')",'attendance report');
  const headers=await evaluate("document.querySelector('thead').innerText");if(!headers.includes('الانصراف') || !headers.includes('الحالة') || !headers.includes('التأخير'))throw new Error('Missing attendance report fields');console.log('PASS Attendance report statuses, arrival/departure and lateness columns');
  // Read-only UI fixture; GPS gating is exercised without creating any attendance records.
  await page.send('Page.addScriptToEvaluateOnNewDocument',{source:`const originalFetch=window.fetch.bind(window);window.fetch=async(...args)=>{const response=await originalFetch(...args);const url=String(args[0] instanceof Request ? args[0].url : args[0]);if(!url.includes('attendance.mine'))return response;const body=await response.json();const names=new URL(url,location.href).pathname.split('/').pop().split(',');const list=Array.isArray(body)?body:[body];const index=names.indexOf('attendance.mine');const now=Date.now();if(index>=0 && list[index]?.result){list[index].result.data={json:{employeeName:'موظف اختبار الواجهة',now,serverTime:new Date(now).toISOString(),shift:{ID:999,NAME:'وردية اختبار',BRANCH:'فرع اختبار الواجهة',LATITUDE:24.7,LONGITUDE:46.7,RADIUS:100,START_TIME:'00:00',END_TIME:'23:59',WORK_START:'07:00',WORK_END:'17:00',LATE_GRACE:0,ACTIVE:1},window:{allowed:true,workDate:'2026-10-05'},checked:null}};}return new Response(JSON.stringify(Array.isArray(body)?list:list[0]),{status:200,headers:{'content-type':'application/json'}});};`});
  await page.send('Page.navigate',{url:'http://localhost:3000/?view=attendance'});
  await wait("document.body.textContent.includes('فرع اختبار الواجهة')",'employee attendance fixture');
  await evaluate("navigator.geolocation.getCurrentPosition=(resolve)=>resolve({coords:{latitude:24.7,longitude:46.7,accuracy:5},timestamp:Date.now()})");
  await evaluate("Array.from(document.querySelectorAll('button')).find(b=>b.textContent.includes('تحديد / تحديث موقعي')).click()");
  await wait("Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='تسجيل حضوري' && !b.disabled)",'inside GPS enabled');
  await page.send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});await new Promise(r=>setTimeout(r,600));
  const overflow=await evaluate("document.documentElement.scrollWidth>window.innerWidth+2");if(overflow)throw new Error('Attendance mobile overflow');
  const shot=await page.send('Page.captureScreenshot',{format:'png'});await fs.writeFile('_attendance-mobile-preview.png',Buffer.from(shot.data,'base64'));
  await evaluate("navigator.geolocation.getCurrentPosition=(resolve)=>resolve({coords:{latitude:25,longitude:46.7,accuracy:5},timestamp:Date.now()})");
  await evaluate("Array.from(document.querySelectorAll('button')).find(b=>b.textContent.includes('تحديد / تحديث موقعي')).click()");
  await wait("Array.from(document.querySelectorAll('button')).some(b=>b.textContent.trim()==='تسجيل حضوري' && b.disabled)",'outside GPS disabled');
  console.log('PASS Mobile attendance layout and simulated GPS gating; no attendance writes');
} finally {
  if (page) page.socket.close();
  if (browser && context) {
    await browser.send("Target.disposeBrowserContext", {
      browserContextId: context,
    });
    browser.socket.close();
  }
  await c.execute("DELETE FROM APP_SESSIONS WHERE TOKEN_HASH=:token", {
    token: hash,
  });
  await c.commit();
  await c.close();
}
