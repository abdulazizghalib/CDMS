﻿import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb, { type Connection } from "oracledb";
import { getOracleConfig } from "../server/oracle";
import {
  voucherAccounts,
  createVoucher,
  voucherDefinitions,
} from "../server/oracleVoucher";
import type { Actor } from "../server/oracleSession";
const c = await oracledb.getConnection(getOracleConfig()),
  o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
const scoped = {
  execute: c.execute.bind(c),
  commit: async () => {},
  rollback: c.rollback.bind(c),
  close: async () => {},
} as Connection;
try {
  const actor = (
    await c.execute<Actor>(
      "SELECT ID,USERNAME,DISPLAY_NAME,ROLE FROM APP_USERS WHERE ROLE='admin' AND ACTIVE=1 AND ROWNUM=1",
      [],
      o
    )
  ).rows![0];
  const accounts = await voucherAccounts(c);
  assert.ok(accounts.length >= 2);
  const before = (
    await c.execute<{ N: number }>(
      "SELECT (SELECT COUNT(*) FROM BB_ENT)+(SELECT COUNT(*) FROM C_ENT)+(SELECT COUNT(*) FROM A_ENT)+(SELECT COUNT(*) FROM ACCOUNT_LEDGER) N FROM DUAL",
      [],
      o
    )
  ).rows![0].N;
  for (const kind of ["receipts", "expenses", "journal"] as const) {
    const d = voucherDefinitions[kind],
      input = {
        kind,
        date: "2026-10-05",
        amount: 123.45,
        debitAccount: accounts[0].ID,
        creditAccount: accounts[1].ID,
        notes: "اختبار سند مؤقت مع التراجع",
      };
    const { id } = await createVoucher(scoped, actor, input);
    const master = (
      await c.execute<Record<string, unknown>>(
        `SELECT * FROM ${d.table} WHERE ${d.prefix}_ID=:id`,
        { id },
        o
      )
    ).rows![0];
    assert.equal(master[d.actor], actor.USERNAME);
    assert.equal(master[d.prefix + "_VD"], 123.45);
    const rows = (
      await c.execute<{
        AL_ACC_NO: number;
        AL_DEPIT_MOUNT: number;
        AL_CREDIT_MOUNT: number;
      }>(
        "SELECT AL_ACC_NO,AL_DEPIT_MOUNT,AL_CREDIT_MOUNT FROM ACCOUNT_LEDGER WHERE AL_DOC_TYPE=:type AND AL_DOC_ID=:id",
        { type: d.docType, id },
        o
      )
    ).rows!;
    assert.equal(rows.length, 2);
    assert.ok(
      rows.some(
        r => r.AL_ACC_NO === input.debitAccount && r.AL_DEPIT_MOUNT === 123.45
      )
    );
    assert.ok(
      rows.some(
        r => r.AL_ACC_NO === input.creditAccount && r.AL_CREDIT_MOUNT === 123.45
      )
    );
    const audit = (
      await c.execute<{ N: number }>(
        "SELECT COUNT(*) N FROM APP_AUDIT_LOG WHERE TABLE_NAME=:tableName AND RECORD_ID=:id AND ACTION='INSERT' AND ACTOR_ID=:actor",
        { tableName: d.table, id: String(id), actor: String(actor.ID) },
        o
      )
    ).rows![0].N;
    assert.equal(audit, 1);
    console.log(
      "PASS " +
        kind +
        " " +
        d.table +
        ": master, two balanced ledger entries, correct accounts, actor and audit"
    );
  }
  await c.rollback();
  const after = (
    await c.execute<{ N: number }>(
      "SELECT (SELECT COUNT(*) FROM BB_ENT)+(SELECT COUNT(*) FROM C_ENT)+(SELECT COUNT(*) FROM A_ENT)+(SELECT COUNT(*) FROM ACCOUNT_LEDGER) N FROM DUAL",
      [],
      o
    )
  ).rows![0].N;
  assert.equal(after, before);
  console.log("PASS All verification vouchers rolled back");
} finally {
  await c.rollback();
  await c.close();
}
