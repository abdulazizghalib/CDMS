﻿import "../server/_core/loadEnv";
import assert from "node:assert/strict";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
import {
  getAccountStatement,
  statementAccounts,
} from "../server/accountStatement";
const c = await oracledb.getConnection(getOracleConfig());
try {
  const o = { outFormat: oracledb.OUT_FORMAT_OBJECT };
  const id = (
    await c.execute<{ ID: number }>(
      "SELECT AL_ACC_NO ID FROM ACCOUNT_LEDGER WHERE AL_ACC_NO>0 AND ROWNUM=1",
      [],
      o
    )
  ).rows![0].ID;
  const input = { accountNo: id, date1: "2000-01-01", date2: "2099-12-31" };
  const result = await getAccountStatement(c, input);
  const total = (
    await c.execute<{ N: number; D: number; C: number }>(
      "SELECT COUNT(*) N,NVL(SUM(AL_DEPIT_MOUNT),0) D,NVL(SUM(AL_CREDIT_MOUNT),0) C FROM ACCOUNT_LEDGER WHERE AL_ACC_NO=:id AND AL_DATE>=DATE '2000-01-01' AND AL_DATE<DATE '2100-01-01'",
      { id },
      o
    )
  ).rows![0];
  assert.equal(result.lines.length, total.N);
  assert.equal(result.debit, Math.round(total.D * 100) / 100);
  assert.equal(result.credit, Math.round(total.C * 100) / 100);
  assert.equal(
    result.closing,
    Math.round((result.opening + result.debit - result.credit) * 100) / 100
  );
  assert.ok((await statementAccounts(c)).some(a => a.ID === id));
  const sameDay = result.lines[0]?.DATE.slice(0, 10);
  if (sameDay) {
    const day = await getAccountStatement(c, {
      accountNo: id,
      date1: sameDay,
      date2: sameDay,
    });
    assert.ok(day.lines.length > 0);
    assert.ok(day.lines.every(r => r.DATE.startsWith(sameDay)));
  }
  console.log(
    "PASS Oracle statement account " +
      id +
      ", " +
      total.N +
      " movements, totals and inclusive end date"
  );
} finally {
  await c.close();
}
