import "../server/_core/loadEnv";
import fs from "node:fs";
import oracledb from "oracledb";
import { getOracleConfig } from "../server/oracle";
const c = await oracledb.getConnection(getOracleConfig());
const apply = process.argv.includes("--apply");
const tables = [
  "MAIN_ACT",
  "BRANSH_ACT",
  "SON_ACT",
  "CENTER_COST",
  "CAR_ENTRY",
  "CAR_OUT",
  "CAR_SALES",
  "PURCHASE_INVOICE",
  "CAR_PURCHASE",
  "SALES_INVOICE",
  "CAR_SALES_INV",
  "BB_ENT",
  "C_ENT",
  "A_ENT",
  "ACCOUNT_LEDGER",
  "STOCK_LEDGER",
  "TRAIL_BALANCE",
  "YOMIA_LEDGER",
];
const primary: Record<string, string> = {
  MAIN_ACT: "AC_NUM",
  BRANSH_ACT: "BAR_NUM",
  SON_ACT: "SON_NUM",
  CENTER_COST: "CC_ID",
  CAR_ENTRY: "CE_ID",
  CAR_OUT: "CO_ID",
  CAR_SALES: "CS_ID",
  PURCHASE_INVOICE: "PUI_ID",
  CAR_PURCHASE: "CP_ID",
  SALES_INVOICE: "SI_ID",
  CAR_SALES_INV: "CSI_ID",
  BB_ENT: "B_ID",
  C_ENT: "C_ID",
  A_ENT: "A_ID",
  ACCOUNT_LEDGER: "AL_ID",
  STOCK_LEDGER: "ST_ID",
  TRAIL_BALANCE: "TB_ID",
  YOMIA_LEDGER: "YL_ID",
};
try {
  const statements: string[] = [
    "CREATE TABLE APP_USERS (ID NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, USERNAME VARCHAR2(80 CHAR) NOT NULL UNIQUE, DISPLAY_NAME VARCHAR2(120 CHAR) NOT NULL, PASSWORD_HASH VARCHAR2(200) NOT NULL, ROLE VARCHAR2(10) NOT NULL CHECK (ROLE IN ('admin','editor','viewer')), ACTIVE NUMBER(1) DEFAULT 1 NOT NULL CHECK(ACTIVE IN(0,1)), EXPIRES_AT TIMESTAMP WITH TIME ZONE, CREATED_AT TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL)",
    "CREATE TABLE APP_SESSIONS (TOKEN_HASH VARCHAR2(64) PRIMARY KEY, USER_ID NUMBER NOT NULL REFERENCES APP_USERS(ID), EXPIRES_AT TIMESTAMP WITH TIME ZONE NOT NULL)",
    "CREATE TABLE APP_AUDIT_LOG (ID NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, EVENT_AT TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL, ACTOR_ID VARCHAR2(64), ACTOR_NAME VARCHAR2(120 CHAR), DB_USER VARCHAR2(128) NOT NULL, SOURCE VARCHAR2(50), ACTION VARCHAR2(10) NOT NULL, TABLE_NAME VARCHAR2(128) NOT NULL, RECORD_ID VARCHAR2(100), BEFORE_JSON CLOB, AFTER_JSON CLOB, TRANSACTION_ID VARCHAR2(100))",
    "CREATE INDEX APP_AUDIT_TIME_IDX ON APP_AUDIT_LOG(EVENT_AT,ID)",
    "CREATE INDEX APP_AUDIT_ENTITY_IDX ON APP_AUDIT_LOG(TABLE_NAME,RECORD_ID)",
    "CREATE TABLE APP_WRITE_LOCK (ID NUMBER PRIMARY KEY)",
    "INSERT INTO APP_WRITE_LOCK(ID) VALUES(1)",
    "CREATE TABLE APP_BRANDING(ID NUMBER PRIMARY KEY CHECK(ID=1),NAME VARCHAR2(100 CHAR) NOT NULL,LOGO_DATA CLOB)",
    "MERGE INTO APP_BRANDING s USING(SELECT 1 ID FROM DUAL) d ON(s.ID=d.ID) WHEN NOT MATCHED THEN INSERT(ID,NAME) VALUES(1,'إدارة معرض السيارات')",
    "CREATE TABLE APP_SALES_SETTINGS (ID NUMBER PRIMARY KEY CHECK(ID=1), SALES_PARENT NUMBER NOT NULL REFERENCES BRANSH_ACT(BAR_NUM), PAYMENT_PARENT NUMBER NOT NULL REFERENCES BRANSH_ACT(BAR_NUM))",
    "MERGE INTO APP_SALES_SETTINGS s USING (SELECT 1 ID FROM DUAL) d ON(s.ID=d.ID) WHEN NOT MATCHED THEN INSERT(ID,SALES_PARENT,PAYMENT_PARENT) VALUES(1,2001,2006)",
    // Trial accounts: existing installs predate EXPIRES_AT, so add it in a way
    // that is safe to re-run (the apply loop ignores ORA-01430).
    "ALTER TABLE APP_USERS ADD (EXPIRES_AT TIMESTAMP WITH TIME ZONE)",
  ];
  const max = await c.execute<{ N: number }>(
    "SELECT GREATEST(NVL((SELECT MAX(CS_ID) FROM CAR_SALES),0),NVL((SELECT MAX(CE_ID) FROM CAR_ENTRY),0),NVL((SELECT MAX(CO_ID) FROM CAR_OUT),0),NVL((SELECT MAX(SI_ID) FROM SALES_INVOICE),0))+1000 N FROM DUAL",
    [],
    { outFormat: oracledb.OUT_FORMAT_OBJECT }
  );
  statements.push(
    "CREATE SEQUENCE APP_RECORD_SEQ START WITH " +
      Math.ceil(max.rows![0].N) +
      " NOCACHE"
  );
  statements.push(
    "CREATE OR REPLACE TRIGGER APP_AUDIT_IMMUTABLE BEFORE UPDATE OR DELETE ON APP_AUDIT_LOG BEGIN RAISE_APPLICATION_ERROR(-20071,'Audit log cannot be changed'); END;"
  );
  for (const table of tables) {
    const columns = await c.execute<{ COLUMN_NAME: string; DATA_TYPE: string }>(
      "SELECT COLUMN_NAME,DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME=:tableName ORDER BY COLUMN_ID",
      { tableName: table },
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );
    const json = (side: string) =>
      "JSON_OBJECT(" +
      columns
        .rows!.filter(
          x => !["BLOB", "CLOB", "LONG", "RAW"].includes(x.DATA_TYPE)
        )
        .map(
          x =>
            "'" +
            x.COLUMN_NAME +
            "' VALUE " +
            (x.DATA_TYPE === "DATE"
              ? "TO_CHAR(:" +
                side +
                "." +
                x.COLUMN_NAME +
                ",'YYYY-MM-DD\"T\"HH24:MI:SS')"
              : ":" + side + "." + x.COLUMN_NAME)
        )
        .join(",") +
      " NULL ON NULL RETURNING CLOB)";
    statements.push(`CREATE OR REPLACE TRIGGER APP_AUD_${table}
AFTER INSERT OR UPDATE OR DELETE ON ${table} FOR EACH ROW
DECLARE v_action VARCHAR2(10); v_before CLOB; v_after CLOB; v_id VARCHAR2(100); v_actor VARCHAR2(64); v_name VARCHAR2(120 CHAR); v_source VARCHAR2(50);
BEGIN
 v_actor:=SYS_CONTEXT('USERENV','CLIENT_IDENTIFIER');
 v_source:=NVL(SYS_CONTEXT('USERENV','MODULE'),'DATABASE');
 IF v_source='DEALER_WEB' THEN
  BEGIN SELECT DISPLAY_NAME INTO v_name FROM APP_USERS WHERE TO_CHAR(ID)=v_actor AND ACTIVE=1;
  EXCEPTION WHEN NO_DATA_FOUND THEN RAISE_APPLICATION_ERROR(-20072,'Authenticated actor required'); END;
 ELSE v_name:=SYS_CONTEXT('USERENV','SESSION_USER'); v_actor:=NULL; END IF;
 IF INSERTING THEN v_action:='INSERT'; SELECT ${json("NEW")} INTO v_after FROM DUAL;v_id:=TO_CHAR(:NEW.${primary[table]});
 ELSIF UPDATING THEN v_action:='UPDATE'; SELECT ${json("OLD")} INTO v_before FROM DUAL;SELECT ${json("NEW")} INTO v_after FROM DUAL;v_id:=TO_CHAR(:NEW.${primary[table]});
 ELSE v_action:='DELETE';SELECT ${json("OLD")} INTO v_before FROM DUAL;v_id:=TO_CHAR(:OLD.${primary[table]}); END IF;
 INSERT INTO APP_AUDIT_LOG(ACTOR_ID,ACTOR_NAME,DB_USER,SOURCE,ACTION,TABLE_NAME,RECORD_ID,BEFORE_JSON,AFTER_JSON,TRANSACTION_ID)
 VALUES(v_actor,v_name,SYS_CONTEXT('USERENV','SESSION_USER'),v_source,v_action,'${table}',v_id,v_before,v_after,DBMS_TRANSACTION.LOCAL_TRANSACTION_ID);
END;`);
  }
  statements.push(
    ...fs
      .readFileSync("database/oracle-dealer-activities.sql", "utf8")
      .replace(/^\uFEFF/, "")
      .split(";")
      .map(s => s.trim())
      .filter(Boolean)
  );
  statements.push(
    ...fs
      .readFileSync("database/oracle-attendance.sql", "utf8")
      .replace(/^\uFEFF/, "")
      .split(";")
      .map(s => s.trim())
      .filter(Boolean)
  );
  statements.push(
    ...fs
      .readFileSync("database/oracle-purchase-settings.sql", "utf8")
      .replace(/^\uFEFF/, "")
      .split(";")
      .map(s => s.trim())
      .filter(Boolean)
  );
  fs.mkdirSync("database", { recursive: true });
  fs.writeFileSync(
    "database/oracle-audit-install.sql",
    statements.map(s => s + "\n/").join("\n\n")
  );
  if (!apply) {
    console.log(
      "Prepared database/oracle-audit-install.sql; use --apply to install."
    );
  } else {
    for (const sql of statements) {
      try {
        await c.execute(sql);
      } catch (e) {
        const n = (e as { errorNum?: number }).errorNum;
        if (
          n !== 955 &&
          n !== 1430 &&
          !(n === 1 && sql.startsWith("INSERT INTO APP_WRITE_LOCK"))
        )
          throw e;
      }
    }
    await c.commit();
    const errors = await c.execute(
      "SELECT NAME,LINE,TEXT FROM USER_ERRORS WHERE NAME LIKE 'APP_AUD%' ORDER BY NAME,SEQUENCE",
      [],
      { outFormat: oracledb.OUT_FORMAT_OBJECT }
    );
    if (errors.rows?.length) throw new Error(JSON.stringify(errors.rows));
    console.log(
      "Installed audit on " +
        tables.length +
        " tables; no legacy trigger changed."
    );
  }
} finally {
  await c.close();
}
