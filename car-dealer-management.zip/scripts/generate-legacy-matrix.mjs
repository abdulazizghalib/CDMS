import { readFileSync, writeFileSync } from "node:fs";

const source = readFileSync(new URL("../server/legacyMatrix.ts", import.meta.url), "utf8");
const extract = (name) => {
  const match = source.match(new RegExp(`${name}: \\[(.*?)\\]`, "s"));
  if (!match) throw new Error(`Missing matrix section: ${name}`);
  return [...match[1].matchAll(/"([^"]+)"/g)].map((item) => item[1]);
};
const objects = extract("objects");
const triggerPatterns = extract("triggerPatterns");
const sequences = extract("sequences");
const rules = extract("rules");
const markdown = `# Legacy Oracle Matrix\n\n## Objects\n\n${objects.join(", ")}.\n\n## Trigger families\n\n${triggerPatterns.join(", ")}.\n\n## Sequences\n\n${sequences.join(", ")}.\n\n## Preserved business rules\n\n${rules.join(", ")}.\n`;
writeFileSync(new URL("../server/legacyMatrix.md", import.meta.url), markdown);
