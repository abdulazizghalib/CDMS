import { readFileSync } from "node:fs";

const path = process.argv[2] || process.env.TNS_ADMIN && `${process.env.TNS_ADMIN}/tnsnames.ora`;
if (!path) {
  console.error("Usage: node scripts/inspect-tns-orcl.mjs /path/to/tnsnames.ora");
  process.exit(1);
}
const text = readFileSync(path, "utf8");
const start = text.search(/(^|\n)\s*ORCL\s*=\s*/i);
if (start < 0) {
  console.error("TNS alias ORCL was not found.");
  process.exit(1);
}
const block = text.slice(start, text.indexOf("\n\n", start) > 0 ? text.indexOf("\n\n", start) : undefined);
const host = block.match(/HOST\s*=\s*([^\)\s]+)/i)?.[1] ?? null;
const port = block.match(/PORT\s*=\s*(\d+)/i)?.[1] ?? "1521";
const service = block.match(/SERVICE_NAME\s*=\s*([^\)\s]+)/i)?.[1] ?? null;
const sid = block.match(/SID\s*=\s*([^\)\s]+)/i)?.[1] ?? null;
console.log(JSON.stringify({ alias: "ORCL", host, port, serviceName: service, sid }, null, 2));
