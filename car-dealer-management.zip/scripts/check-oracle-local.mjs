import { config } from "dotenv";
config({ path: ".env.local", quiet: true });
import oracledb from "oracledb";

const host = process.env.LOCAL_ORACLE_HOST || "127.0.0.1";
const port = process.env.LOCAL_ORACLE_PORT || "1521";
const service = process.env.LOCAL_ORACLE_SERVICE_NAME || "ORCL";
const user = process.env.LOCAL_ORACLE_USER;
const password = process.env.LOCAL_ORACLE_PASSWORD;

if (!user || !password) {
  console.error("Set LOCAL_ORACLE_USER and LOCAL_ORACLE_PASSWORD in the local shell before running this check.");
  process.exit(1);
}

const connectString = `${host}:${port}/${service}`;
let connection;

try {
  connection = await oracledb.getConnection({ user, password, connectString });
  const result = await connection.execute("SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') AS DB_TIME FROM DUAL", [], { outFormat: oracledb.OUT_FORMAT_OBJECT });
  console.log(`Oracle local connection OK: ${result.rows?.[0]?.DB_TIME ?? "no result"}`);
} catch (error) {
  const code = error?.code ?? "UNKNOWN";
  if (code === "ORA-01017") {
    console.error("Oracle rejected the username or password. Use the same credentials that succeed in TOAD for the ORCL service.");
  } else if (code === "ECONNREFUSED") {
    console.error(`Oracle Listener is not reachable at ${host}:${port}. Start the Listener and verify the local port.`);
  } else if (code === "ORA-12514" || code === "ORA-12505") {
    console.error(`Oracle service ${service} was not found. Verify SERVICE_NAME/SID and the ORCL entry in tnsnames.ora.`);
  } else {
    console.error(`Oracle local connectivity check failed (${code}). Verify the ORCL TNS settings and local Listener.`);
  }
  process.exit(1);
} finally {
  if (connection) await connection.close();
}
