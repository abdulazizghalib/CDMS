CREATE TABLE `purchase_invoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceNumber` varchar(32) NOT NULL,
	`supplierName` varchar(160) NOT NULL,
	`purchaseDate` timestamp NOT NULL,
	`totalAmount` int NOT NULL,
	`paymentStatus` enum('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
	`branchName` varchar(120) NOT NULL DEFAULT 'الفرع الرئيسي',
	`notes` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `purchase_invoices_id` PRIMARY KEY(`id`),
	CONSTRAINT `purchase_invoices_invoiceNumber_unique` UNIQUE(`invoiceNumber`)
);
--> statement-breakpoint
RENAME TABLE `purchases` TO `car_purchases`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP INDEX `purchases_purchaseNumber_unique`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP PRIMARY KEY;--> statement-breakpoint
ALTER TABLE `car_purchases` MODIFY COLUMN `status` enum('received','preparing','ready','cancelled') NOT NULL DEFAULT 'received';--> statement-breakpoint
ALTER TABLE `car_purchases` ADD PRIMARY KEY(`id`);--> statement-breakpoint
ALTER TABLE `car_purchases` ADD `invoiceId` int NOT NULL;--> statement-breakpoint
ALTER TABLE `car_purchases` ADD `totalVehicleCost` int NOT NULL;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP COLUMN `purchaseNumber`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP COLUMN `supplierName`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP COLUMN `sourceType`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP COLUMN `purchaseDate`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP COLUMN `totalCost`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP COLUMN `paymentStatus`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP COLUMN `branchName`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP COLUMN `notes`;--> statement-breakpoint
ALTER TABLE `car_purchases` DROP COLUMN `createdBy`;