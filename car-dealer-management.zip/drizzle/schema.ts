import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// TODO: Add your tables here


export const purchaseInvoices = mysqlTable("purchase_invoices", {
  id: int("id").autoincrement().primaryKey(),
  invoiceNumber: varchar("invoiceNumber", { length: 32 }).notNull().unique(),
  supplierName: varchar("supplierName", { length: 160 }).notNull(),
  purchaseDate: timestamp("purchaseDate").notNull(),
  totalAmount: int("totalAmount").notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["unpaid", "partial", "paid"]).default("unpaid").notNull(),
  branchName: varchar("branchName", { length: 120 }).default("الفرع الرئيسي").notNull(),
  notes: text("notes"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const carPurchases = mysqlTable("car_purchases", {
  id: int("id").autoincrement().primaryKey(),
  invoiceId: int("invoiceId").notNull(), // Links to purchaseInvoices.id (equivalent to CP_INV_REF -> PUI_ID)
  vehicleName: varchar("vehicleName", { length: 160 }).notNull(),
  vin: varchar("vin", { length: 64 }),
  vehicleYear: int("vehicleYear"),
  purchaseCost: int("purchaseCost").notNull(),
  preparationCost: int("preparationCost").default(0).notNull(),
  transportCost: int("transportCost").default(0).notNull(),
  registrationCost: int("registrationCost").default(0).notNull(),
  totalVehicleCost: int("totalVehicleCost").notNull(),
  status: mysqlEnum("status", ["received", "preparing", "ready", "cancelled"]).default("received").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const purchaseItems = mysqlTable("purchase_items", {
  id: int("id").autoincrement().primaryKey(),
  purchaseId: int("purchaseId").notNull(),
  expenseType: mysqlEnum("expenseType", ["purchase", "transport", "maintenance", "detailing", "inspection", "registration", "other"]).notNull(),
  description: varchar("description", { length: 220 }).notNull(),
  amount: int("amount").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type PurchaseInvoice = typeof purchaseInvoices.$inferSelect;
export type InsertPurchaseInvoice = typeof purchaseInvoices.$inferInsert;
export type CarPurchase = typeof carPurchases.$inferSelect;
export type InsertCarPurchase = typeof carPurchases.$inferInsert;
export type PurchaseItem = typeof purchaseItems.$inferSelect;
export type InsertPurchaseItem = typeof purchaseItems.$inferInsert;

export const vehicles = mysqlTable("vehicles", {
  id: int("id").autoincrement().primaryKey(),
  vin: varchar("vin", { length: 64 }).unique(),
  make: varchar("make", { length: 80 }).notNull(),
  model: varchar("model", { length: 80 }).notNull(),
  year: int("year").notNull(),
  color: varchar("color", { length: 40 }),
  mileage: int("mileage").default(0),
  status: mysqlEnum("status", ["available", "reserved", "sold", "maintenance"]).default("available").notNull(),
  branch: varchar("branch", { length: 120 }).default("الفرع الرئيسي").notNull(),
  purchasePrice: int("purchasePrice").default(0),
  askingPrice: int("askingPrice").default(0),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  phone: varchar("phone", { length: 32 }).notNull(),
  email: varchar("email", { length: 320 }),
  idNumber: varchar("idNumber", { length: 64 }),
  address: text("address"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const sales = mysqlTable("sales", {
  id: int("id").autoincrement().primaryKey(),
  invoiceNumber: varchar("invoiceNumber", { length: 32 }).notNull().unique(),
  vehicleId: int("vehicleId").notNull(),
  customerId: int("customerId").notNull(),
  saleDate: timestamp("saleDate").defaultNow().notNull(),
  salePrice: int("salePrice").notNull(),
  discount: int("discount").default(0),
  tax: int("tax").default(0),
  totalAmount: int("totalAmount").notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["unpaid", "partial", "paid"]).default("unpaid").notNull(),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "bank_transfer", "finance", "check"]).default("cash").notNull(),
  branch: varchar("branch", { length: 120 }).default("الفرع الرئيسي").notNull(),
  notes: text("notes"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const expenses = mysqlTable("expenses", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  amount: int("amount").notNull(),
  category: mysqlEnum("category", ["rent", "utilities", "salaries", "marketing", "maintenance", "other"]).default("other").notNull(),
  expenseDate: timestamp("expenseDate").defaultNow().notNull(),
  branch: varchar("branch", { length: 120 }).default("الفرع الرئيسي").notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = typeof vehicles.$inferInsert;
export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = typeof customers.$inferInsert;
export type Sale = typeof sales.$inferSelect;
export type InsertSale = typeof sales.$inferInsert;
export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = typeof expenses.$inferInsert;
