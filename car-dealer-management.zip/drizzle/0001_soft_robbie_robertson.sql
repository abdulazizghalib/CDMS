CREATE TABLE `purchase_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`purchaseId` int NOT NULL,
	`expenseType` enum('purchase','transport','maintenance','detailing','inspection','registration','other') NOT NULL,
	`description` varchar(220) NOT NULL,
	`amount` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `purchase_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `purchases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`purchaseNumber` varchar(32) NOT NULL,
	`vehicleName` varchar(160) NOT NULL,
	`vin` varchar(64),
	`vehicleYear` int,
	`supplierName` varchar(160) NOT NULL,
	`sourceType` enum('supplier','auction','trade_in','other') NOT NULL DEFAULT 'supplier',
	`purchaseDate` timestamp NOT NULL,
	`purchaseCost` int NOT NULL,
	`preparationCost` int NOT NULL DEFAULT 0,
	`transportCost` int NOT NULL DEFAULT 0,
	`registrationCost` int NOT NULL DEFAULT 0,
	`totalCost` int NOT NULL,
	`paymentStatus` enum('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
	`status` enum('draft','received','preparing','ready','cancelled') NOT NULL DEFAULT 'received',
	`branchName` varchar(120) NOT NULL DEFAULT 'الفرع الرئيسي',
	`notes` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `purchases_id` PRIMARY KEY(`id`),
	CONSTRAINT `purchases_purchaseNumber_unique` UNIQUE(`purchaseNumber`)
);
