CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`phone` varchar(32) NOT NULL,
	`email` varchar(320),
	`idNumber` varchar(64),
	`address` text,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `expenses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(200) NOT NULL,
	`amount` int NOT NULL,
	`category` enum('rent','utilities','salaries','marketing','maintenance','other') NOT NULL DEFAULT 'other',
	`expenseDate` timestamp NOT NULL DEFAULT (now()),
	`branch` varchar(120) NOT NULL DEFAULT 'الفرع الرئيسي',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `expenses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sales` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceNumber` varchar(32) NOT NULL,
	`vehicleId` int NOT NULL,
	`customerId` int NOT NULL,
	`saleDate` timestamp NOT NULL DEFAULT (now()),
	`salePrice` int NOT NULL,
	`discount` int DEFAULT 0,
	`tax` int DEFAULT 0,
	`totalAmount` int NOT NULL,
	`paymentStatus` enum('unpaid','partial','paid') NOT NULL DEFAULT 'unpaid',
	`paymentMethod` enum('cash','bank_transfer','finance','check') NOT NULL DEFAULT 'cash',
	`branch` varchar(120) NOT NULL DEFAULT 'الفرع الرئيسي',
	`notes` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sales_id` PRIMARY KEY(`id`),
	CONSTRAINT `sales_invoiceNumber_unique` UNIQUE(`invoiceNumber`)
);
--> statement-breakpoint
CREATE TABLE `vehicles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`vin` varchar(64),
	`make` varchar(80) NOT NULL,
	`model` varchar(80) NOT NULL,
	`year` int NOT NULL,
	`color` varchar(40),
	`mileage` int DEFAULT 0,
	`status` enum('available','reserved','sold','maintenance') NOT NULL DEFAULT 'available',
	`branch` varchar(120) NOT NULL DEFAULT 'الفرع الرئيسي',
	`purchasePrice` int DEFAULT 0,
	`askingPrice` int DEFAULT 0,
	`description` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `vehicles_id` PRIMARY KEY(`id`),
	CONSTRAINT `vehicles_vin_unique` UNIQUE(`vin`)
);
