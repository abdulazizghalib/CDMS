﻿# تجهيز مستودع CDMS

المستودع: https://github.com/abdulazizghalib/CDMS

## رفع المصدر

عند توفر Git وتسجيل الدخول لحساب يملك صلاحية الكتابة، افحص المستودع البعيد أولًا. إذا كان فارغًا، من مجلد المشروع:

```powershell
git init -b main
git remote add origin https://github.com/abdulazizghalib/CDMS.git
git add .
git diff --cached --stat
git commit -m "Add CDMS application and GitHub CI"
git push -u origin main
```

إذا كان المستودع يحتوي ملفات، استنسخه في مجلد مستقل وانقل إليه المصدر ثم ارفع التغييرات دون force push. لا تحذف تاريخ المستودع الموجود.

استبعد ملفات البيئة وكلمات المرور ونسخ Oracle ونتائج الفحص التي تحتوي بيانات المعرض. إعداد .gitignore يغطي الملفات المحلية المعروفة، والأرشيف CDMS-github-source.zip يتضمن المصدر الذي اختاره scripts/package-github-source.mjs فقط.

## تشغيل النظام

GitHub يحتفظ بالمصدر وينفذ الفحوصات. تشغيل النظام يحتاج خادم Node.js يصل إلى Oracle، أو Codespaces للمعاينة مع اتصال Oracle صالح. إعداد Codespaces مُرفق في .devcontainer/، وخطوات التشغيل في README.md.

لا يوجد نشر تلقائي لخادم دائم في إعداد Actions الحالي. بعد تحديد جهاز التشغيل أو الاستضافة، يمكن إعداد التحديث والنشر المناسبين لها. لا تُحفظ بيانات Oracle الفعلية في workflow أو ملفات المصدر.

المراجع:

- https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages
- https://docs.github.com/en/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace
