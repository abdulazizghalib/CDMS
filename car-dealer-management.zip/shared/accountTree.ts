export type AccountLevel = 1 | 2 | 3;
export type AccountEntry = {
  ID: number;
  NAME: string | null;
  PARENT_ID: number | null;
  LEVEL: AccountLevel;
  NATURE: number | null;
  NOTES: string | null;
  PHONE?: string | null;
  ACTIVE?: number | string | null;
};
export type AccountNode = AccountEntry & {
  key: string;
  children: AccountNode[];
};
export function buildAccountTree(entries: AccountEntry[]) {
  const nodes = entries.map(e => ({
    ...e,
    key: `${e.LEVEL}:${e.ID}`,
    children: [] as AccountNode[],
  }));
  const byKey = new Map(nodes.map(n => [n.key, n]));
  const roots: AccountNode[] = [],
    orphans: AccountNode[] = [];
  for (const n of nodes) {
    if (n.LEVEL === 1) roots.push(n);
    else {
      const parent = byKey.get(`${n.LEVEL - 1}:${n.PARENT_ID}`);
      if (parent) parent.children.push(n);
      else orphans.push(n);
    }
  }
  const sort = (list: AccountNode[]) => {
    list.sort((a, b) => a.ID - b.ID);
    list.forEach(n => sort(n.children));
  };
  sort(roots);
  sort(orphans);
  return { roots, orphans };
}
export function filterAccountTree(
  nodes: AccountNode[],
  text: string
): AccountNode[] {
  const term = text
    .trim()
    .toLowerCase()
    .replace(/[٠-٩۰-۹]/g, c =>
      String(c.charCodeAt(0) - (c <= "٩" ? 1632 : 1776))
    );
  if (!term) return nodes;
  return nodes.flatMap(n => {
    if (`${n.ID} ${n.NAME ?? ""}`.toLowerCase().includes(term)) return [n];
    const children = filterAccountTree(n.children, term);
    return children.length ? [{ ...n, children }] : [];
  });
}
