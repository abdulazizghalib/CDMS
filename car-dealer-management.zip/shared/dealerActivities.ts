﻿import { z } from "zod";
export const activityKind = z.enum(["reservation", "followup"]);
export const activityInput = z
  .object({
    kind: activityKind,
    customer: z.string().trim().min(2).max(100),
    phone: z
      .string()
      .trim()
      .min(5)
      .max(30)
      .regex(/^[+\d\s()-]+$/, "رقم الهاتف غير صحيح"),
    vehicleId: z.number().int().positive().nullable(),
    scheduledAt: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/)
      .refine(v => {
        const d = new Date(v + ":00+03:00");
        return (
          Number.isFinite(d.getTime()) &&
          new Date(d.getTime() + 10800000).toISOString().slice(0, 16) === v
        );
      }, "التاريخ غير صحيح"),
    notes: z.string().trim().max(500).default(""),
  })
  .refine(
    v => v.kind !== "reservation" || v.vehicleId !== null,
    "اختر سيارة للحجز"
  );
export const activityStatusInput = z.object({
  id: z.number().int().positive(),
  status: z.enum(["completed", "cancelled"]),
});
export type DealerActivity = {
  ID: number;
  KIND: "reservation" | "followup";
  CUSTOMER: string;
  PHONE: string;
  VEHICLE_ID: number | null;
  CAR: string | null;
  MODEL: string | null;
  PLATE: string | null;
  SCHEDULED_AT: string;
  NOTES: string | null;
  STATUS: "active" | "completed" | "cancelled" | "expired";
  CREATED_BY: string;
};
