import { z } from "zod";
const text = (max: number) =>
  z
    .string()
    .trim()
    .refine(
      v => new TextEncoder().encode(v).length <= max,
      "النص أطول من سعة الحقل"
    );
export const purchaseCarInput = z.object({
  car: text(150).refine(v => !!v, "نوع السيارة مطلوب"),
  model: text(50),
  color: text(40),
  plate: text(40).refine(v => !!v, "رقم اللوحة مطلوب"),
  vin: text(100),
  price: z.number().finite().min(0).max(1e12),
  notes: text(200),
});
export const oraclePurchaseInput = z
  .object({
    date: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/)
      .refine(
        v =>
          !Number.isNaN(Date.parse(v)) &&
          new Date(v).toISOString().slice(0, 10) === v,
        "تاريخ غير صحيح"
      ),
    supplierId: z.number().int().positive(),
    paymentId: z.number().int().positive(),
    ownerId: z.number().int().positive(),
    branch: text(100),
    notes: text(200),
    lines: z.array(purchaseCarInput).min(1).max(500),
  })
  .superRefine((v, ctx) => {
    for (const key of ["plate", "vin"] as const) {
      const seen = new Set<string>();
      v.lines.forEach((l, i) => {
        const value = l[key].toUpperCase();
        if (value && seen.has(value))
          ctx.addIssue({
            code: "custom",
            path: ["lines", i, key],
            message: "قيمة مكررة داخل الفاتورة",
          });
        if (value) seen.add(value);
      });
    }
  });
export type PurchaseCarInput = z.infer<typeof purchaseCarInput>;
