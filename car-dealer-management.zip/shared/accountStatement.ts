import { z } from "zod";
export const reportDate = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .refine(
    v =>
      Number.isFinite(Date.parse(v)) &&
      new Date(v).toISOString().slice(0, 10) === v,
    "تاريخ غير صحيح"
  );
export const accountStatementInput = z
  .object({
    accountNo: z.number().int().positive().max(Number.MAX_SAFE_INTEGER),
    date1: reportDate,
    date2: reportDate,
  })
  .refine(v => v.date1 <= v.date2, "تاريخ البداية يجب أن يسبق تاريخ النهاية");
export const journalReportInput = z
  .object({ date1: reportDate, date2: reportDate })
  .refine(v => v.date1 <= v.date2, "تاريخ البداية يجب أن يسبق تاريخ النهاية");
