import { z } from "zod";
import { journalReportInput } from "./accountStatement";
const time = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "الوقت غير صحيح");
export const shiftInput = z
  .object({
    id: z.number().int().positive().optional(),
    name: z.string().trim().min(2).max(100),
    branch: z.string().trim().min(2).max(100),
    latitude: z.number().finite().min(-90).max(90),
    longitude: z.number().finite().min(-180).max(180),
    radius: z.number().int().min(20).max(5000).default(100),
    workStart: time.default("07:00"),
    workEnd: time.default("17:00"),
    lateGrace: z.number().int().min(0).max(120).default(0),
    startTime: time,
    endTime: time,
    active: z.boolean().default(true),
  })
  .refine(v => v.startTime !== v.endTime, "بداية السماح ونهايته يجب أن تختلفا")
  .refine(v => v.workStart !== v.workEnd, "بداية الدوام ونهايته يجب أن تختلفا");
export const assignmentInput = z
  .object({
    shiftId: z.number().int().positive(),
    employeeIds: z.array(z.number().int().positive()).max(500),
  })
  .refine(
    v => new Set(v.employeeIds).size === v.employeeIds.length,
    "الموظف مكرر"
  );
export const checkInInput = z.object({
  latitude: z.number().finite().min(-90).max(90),
  longitude: z.number().finite().min(-180).max(180),
  accuracy: z.number().finite().min(0).max(10000),
  capturedAt: z.string().datetime(),
});
export const attendanceReportInput = journalReportInput;
export type AttendanceShift = {
  ID: number;
  NAME: string;
  BRANCH: string;
  LATITUDE: number;
  LONGITUDE: number;
  RADIUS: number;
  WORK_START: string;
  WORK_END: string;
  LATE_GRACE: number;
  START_TIME: string;
  END_TIME: string;
  ACTIVE: number;
};
export function distanceMeters(a: number, b: number, c: number, d: number) {
  const rad = (v: number) => (v * Math.PI) / 180;
  const h =
    Math.sin(rad(c - a) / 2) ** 2 +
    Math.cos(rad(a)) * Math.cos(rad(c)) * Math.sin(rad(d - b) / 2) ** 2;
  return (
    6371000 *
    2 *
    Math.atan2(Math.sqrt(Math.min(1, h)), Math.sqrt(Math.max(0, 1 - h)))
  );
}
export function attendanceWindow(
  shift: Pick<AttendanceShift, "START_TIME" | "END_TIME">,
  now: number
) {
  const local = new Date(now + 10800000).toISOString(),
    seconds =
      Number(local.slice(11, 13)) * 3600 +
      Number(local.slice(14, 16)) * 60 +
      Number(local.slice(17, 19));
  const sec = (v: string) =>
      Number(v.slice(0, 2)) * 3600 + Number(v.slice(3, 5)) * 60,
    start = sec(shift.START_TIME),
    end = sec(shift.END_TIME),
    overnight = end < start;
  const workDate = new Date(
    now + 10800000 - (overnight && seconds < start ? 86400000 : 0)
  )
    .toISOString()
    .slice(0, 10);
  return {
    workDate,
    allowed: overnight
      ? seconds >= start || seconds <= end
      : seconds >= start && seconds <= end,
  };
}
export function locationAllowed(
  shift: Pick<AttendanceShift, "LATITUDE" | "LONGITUDE" | "RADIUS">,
  position: { latitude: number; longitude: number; accuracy: number }
) {
  const distance = distanceMeters(
    shift.LATITUDE,
    shift.LONGITUDE,
    position.latitude,
    position.longitude
  );
  return {
    distance,
    accurate: position.accuracy <= Math.min(100, shift.RADIUS),
    inside: distance + position.accuracy <= shift.RADIUS,
  };
}
export function expectedTimes(
  shift: Pick<
    AttendanceShift,
    "WORK_START" | "WORK_END" | "START_TIME" | "END_TIME"
  >,
  workDate: string
) {
  let start = Date.parse(workDate + "T" + shift.WORK_START + ":00+03:00");
  if (shift.END_TIME < shift.START_TIME && shift.WORK_START < shift.START_TIME)
    start += 86400000;
  let end = Date.parse(workDate + "T" + shift.WORK_END + ":00+03:00");
  while (end <= start) end += 86400000;
  return { start, end };
}
