﻿import { z } from "zod";
import { reportDate } from "./accountStatement";
export const voucherKind = z.enum(["receipts", "expenses", "journal"]);
export const voucherInput = z
  .object({
    kind: voucherKind,
    date: reportDate,
    amount: z
      .number()
      .finite()
      .positive()
      .max(999999999.99)
      .refine(
        v => Math.abs(v * 100 - Math.round(v * 100)) < 0.0001,
        "المبلغ يقبل منزلتين عشريتين فقط"
      ),
    debitAccount: z.number().int().positive(),
    creditAccount: z.number().int().positive(),
    notes: z.string().trim().min(2).max(400),
  })
  .refine(
    v => v.debitAccount !== v.creditAccount,
    "اختر حسابين مختلفين لطرفي السند"
  );
