import { z } from "zod";
const text = (bytes: number) =>
  z
    .string()
    .trim()
    .refine(
      v => new TextEncoder().encode(v).length <= bytes,
      "النص أطول من سعة الحقل"
    );
export const salesInvoiceInput = z
  .object({
    date: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/)
      .refine(
        v =>
          !Number.isNaN(Date.parse(v)) &&
          new Date(v).toISOString().slice(0, 10) === v,
        "تاريخ غير صحيح"
      ),
    phone: text(100),
    branch: text(100),
    notes: text(300),
    accountId: z.number().int().positive(),
    paymentAccountId: z.number().int().positive(),
    vat: z.number().finite().min(0).max(1e12),
    lines: z
      .array(
        z.object({
          purchaseId: z.number().int().positive(),
          price: z.number().finite().min(0).max(1e12),
        })
      )
      .min(1)
      .max(100),
  })
  .refine(
    v => new Set(v.lines.map(l => l.purchaseId)).size === v.lines.length,
    "لا يمكن تكرار السيارة في الفاتورة"
  );
