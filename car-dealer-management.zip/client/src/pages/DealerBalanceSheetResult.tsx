﻿import { useRef, useState } from "react";
import { Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { money } from "@/lib/dealerPresentation";
import { trpc } from "@/lib/trpc";
import { balanceSheetSides, type BalanceLine } from "@/lib/balanceSheet";
import "./dealer-balance-sheet.css";
const printStyle = `@page{size:A4 landscape;margin:12mm}body{font-family:Tahoma,Arial,sans-serif;direction:rtl;color:#172033;margin:0}.balance-paper header{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #68b9e6;padding-bottom:12px;margin-bottom:16px}.balance-paper header img{width:95px;height:65px;object-fit:contain}.balance-paper h2{margin:5px 0}.balance-paper p{font-size:12px}.balance-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.balance-side{border:1px solid #cbd5e1;break-inside:auto}.balance-side h3{margin:0;padding:10px;background:#d8efff;text-align:center;font-size:15px}.balance-scroll{overflow:visible!important;max-height:none!important;min-height:0!important}.balance-paper table{border-collapse:collapse;width:100%;font-size:10px}.balance-paper th,.balance-paper td{border:1px solid #cbd5e1;padding:8px 5px;text-align:right}.balance-paper th{background:#edf7fd}.balance-paper tfoot{font-weight:bold;background:#edf7fd}.balance-paper thead{display:table-header-group}.balance-paper tr{break-inside:avoid}.balance-note{font-size:11px;color:#475569}.balance-single .balance-grid{grid-template-columns:1fr}.balance-print-controls{display:none!important}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}`;
export function DealerBalanceSheetResult({
  data,
}: {
  data: { date1: string; date2: string; lines: BalanceLine[] };
}) {
  const sides = balanceSheetSides(data.lines),
    paper = useRef<HTMLDivElement>(null);
  const brand = trpc.oracleOperations.branding.useQuery(undefined, {
    retry: false,
  });
  const [printing, setPrinting] = useState(false),
    [error, setError] = useState("");
  async function print(side?: "assets" | "liabilities") {
    if (!paper.current) return;
    setPrinting(true);
    setError("");
    const content = paper.current.cloneNode(true) as HTMLElement;
    if (side) {
      content
        .querySelector(
          `[data-balance-side="${side === "assets" ? "liabilities" : "assets"}"]`
        )
        ?.remove();
      content.classList.add("balance-single");
    }
    const frame = document.createElement("iframe");
    frame.title = "طباعة الميزانية";
    frame.style.cssText =
      "position:fixed;left:-10000px;top:0;width:297mm;height:210mm;border:0";
    document.body.appendChild(frame);
    const cleanup = () => {
      frame.remove();
      setPrinting(false);
    };
    try {
      const doc = frame.contentDocument!;
      doc.open();
      doc.write(
        '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>الميزانية</title><style>' +
          printStyle +
          "</style></head><body>" +
          content.outerHTML +
          "</body></html>"
      );
      doc.close();
      await Promise.all(
        Array.from(doc.images).map(img => img.decode().catch(() => {}))
      );
      await doc.fonts.ready;
      const w = frame.contentWindow!;
      w.addEventListener("afterprint", cleanup, { once: true });
      w.focus();
      w.print();
      setPrinting(false);
      setTimeout(() => frame.remove(), 60000);
    } catch {
      cleanup();
      setError("تعذرت الطباعة؛ أعد المحاولة");
    }
  }
  return (
    <section className="oracle-panel p-4 sm:p-6" dir="rtl">
      <div className="flex justify-end mb-4">
        <Button
          variant="outline"
          disabled={printing}
          onClick={() => void print()}
        >
          <Printer size={16} />
          طباعة الميزانية
        </Button>
      </div>
      {error && (
        <p role="alert" className="text-red-600 mb-3">
          {error}
        </p>
      )}
      <div ref={paper} className="balance-paper">
        <header>
          <div>
            <h2>{brand.data?.name || "الميزانية"}</h2>
            <p>
              الميزانية · الفترة من {data.date1} إلى {data.date2}
            </p>
          </div>
          {brand.data?.logo && (
            <img src={brand.data.logo} alt={brand.data.name} />
          )}
        </header>
        <div className="balance-grid">
          {(
            [
              { key: "assets", title: "الأصول", data: sides.assets },
              {
                key: "liabilities",
                title: "الخصوم وحقوق الملكية",
                data: sides.liabilities,
              },
            ] as const
          ).map(side => (
            <section
              key={side.key}
              data-balance-side={side.key}
              className="balance-side"
              aria-label={side.title}
            >
              <h3>{side.title}</h3>
              <div className="balance-scroll">
                <table>
                  <thead>
                    <tr>
                      {[
                        "الحساب الرئيسي",
                        "الحساب",
                        "مجموع المدين",
                        "مجموع الدائن",
                        "الرصيد",
                      ].map(h => (
                        <th key={h}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {side.data.rows.map(r => (
                      <tr key={`${r.main}:${r.account}:${r.name}`}>
                        <td>
                          <span>{r.mainName}</span>
                          <small>{r.main}</small>
                        </td>
                        <td>
                          <span>{r.name}</span>
                          <small>{r.account ?? "—"}</small>
                        </td>
                        <td>{money(r.debit)}</td>
                        <td>{money(r.credit)}</td>
                        <td className="balance-value">{money(r.balance)}</td>
                      </tr>
                    ))}
                    {side.data.rows.length === 0 && (
                      <tr>
                        <td colSpan={5} className="balance-empty">
                          لا توجد حركات خلال الفترة المحددة
                        </td>
                      </tr>
                    )}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colSpan={2}>إجمالي {side.title}</td>
                      <td>{money(side.data.debit)}</td>
                      <td>{money(side.data.credit)}</td>
                      <td>{money(side.data.balance)}</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
              <div className="balance-print-controls">
                <Button
                  variant="outline"
                  disabled={printing}
                  onClick={() => void print(side.key)}
                >
                  <Printer size={16} />
                  طباعة {side.title}
                </Button>
              </div>
            </section>
          ))}
        </div>
        <p className="balance-note">
          رصيد الأصول = المدين − الدائن. رصيد الخصوم وحقوق الملكية = الدائن −
          المدين. الأرقام تمثل حركات الفترة المحددة.
        </p>
      </div>
    </section>
  );
}
