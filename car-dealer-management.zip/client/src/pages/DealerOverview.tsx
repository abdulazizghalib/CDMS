import { PurchaseAccountSettings } from "@/components/PurchaseAccountSettings";
import { UpcomingActivities } from "./DealerActivities";
import { BrandingSettings } from "@/components/DealerBranding";
import { SalesAccountSettings } from "@/components/SalesAccountSettings";
import {
  Car,
  Wallet,
  ReceiptText,
  FileText,
  UsersRound,
  ArrowUpLeft,
  ChevronLeft,
  CalendarDays,
  TriangleAlert,
  Landmark,
  RefreshCw,
  BookOpen,
  ShieldCheck,
  Settings2,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  number,
  money,
  postingLabel,
  type NavigateDealer,
} from "@/lib/dealerPresentation";
import { VehicleCard } from "./DealerInventory";
export function DealerStats() {
  const query = trpc.oracleWorkspace.summary.useQuery(undefined, {
    retry: false,
  });
  const totals = query.data?.totals;
  const items = [
    {
      key: "VEHICLES",
      label: "السيارات المسجلة",
      unit: "سيارة",
      icon: Car,
      tone: "blue",
    },
    {
      key: "PURCHASE_VALUE",
      label: "قيمة الشراء المسجلة",
      unit: "ر.س",
      icon: Wallet,
      tone: "purple",
    },
    {
      key: "SALES_TOTAL",
      label: "إجمالي فواتير البيع",
      unit: "ر.س",
      icon: ReceiptText,
      tone: "gold",
    },
    {
      key: "CONTRACTS",
      label: "عقود المبايعة",
      unit: "عقد",
      icon: FileText,
      tone: "teal",
    },
  ];
  return (
    <div className="dealer-stats oracle-stat-grid">
      {items.map(({ key, label, unit, icon: Icon, tone }) => (
        <div className={"dealer-stat oracle-stat " + tone} key={key}>
          <span className="dealer-stat-icon">
            <Icon size={21} />
          </span>
          <div>
            <span>{label}</span>
            <strong>
              {query.isLoading
                ? "…"
                : query.isError
                  ? "—"
                  : number(totals?.[key])}
            </strong>
            <small>{unit}</small>
          </div>
          <p>
            {query.isError ? "تعذر تحديث المؤشر" : "من سجلات المعرض"}
            <span className="dealer-live-dot" />
          </p>
        </div>
      ))}
    </div>
  );
}
export function SalesCharts() {
  const query = trpc.oracleWorkspace.summary.useQuery(undefined, {
    retry: false,
  });
  if (query.isError)
    return (
      <div className="oracle-panel p-5" role="alert">
        تعذر تحميل المؤشرات{" "}
        <Button onClick={() => void query.refetch()}>إعادة المحاولة</Button>
      </div>
    );
  const monthly = [...(query.data?.monthly ?? [])]
    .reverse()
    .map(r => ({ month: String(r.MONTH), total: Number(r.TOTAL) || 0 }));
  const states = (query.data?.states ?? []).map(r => ({
    name: postingLabel(r.STATUS),
    value: Number(r.TOTAL) || 0,
  }));
  const colors = ["#08a9a4", "#d4a63e", "#747d99", "#94a3b8"];
  return (
    <div className="dealer-chart-grid">
      <section className="oracle-panel dealer-chart">
        <div className="dealer-panel-title">
          <h2>نظرة عامة على المبيعات</h2>
          <span>آخر الأشهر المسجلة</span>
        </div>
        <div className="dealer-chart-total">
          <strong>{money(query.data?.totals.SALES_TOTAL)}</strong>
          <small>إجمالي الفواتير · لا يمثل صافي الربح</small>
        </div>
        <div className="dealer-area-chart" dir="ltr">
          {query.isLoading ? (
            <div className="dealer-loading">جاري التحميل…</div>
          ) : !monthly.length ? (
            <p>لا توجد فواتير مؤرخة</p>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={monthly}
                margin={{ top: 10, right: 16, left: 4, bottom: 0 }}
              >
                <defs>
                  <linearGradient id="salesFill" x1="0" x2="0" y1="0" y2="1">
                    <stop offset="0%" stopColor="#0ba5a5" stopOpacity={0.2} />
                    <stop offset="100%" stopColor="#0ba5a5" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 4"
                  vertical={false}
                  stroke="#e9eef4"
                />
                <XAxis
                  dataKey="month"
                  tick={{ fontSize: 10, fill: "#8090a5" }}
                  axisLine={false}
                  tickLine={false}
                  minTickGap={25}
                />
                <YAxis
                  width={48}
                  tickFormatter={v =>
                    v >= 1e6
                      ? (v / 1e6).toFixed(1) + "m"
                      : v >= 1000
                        ? Math.round(v / 1000) + "k"
                        : String(v)
                  }
                  tick={{ fontSize: 10, fill: "#8090a5" }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip formatter={v => [money(v), "فواتير البيع"]} />
                <Area
                  type="monotone"
                  dataKey="total"
                  stroke="#0ba5a5"
                  strokeWidth={2}
                  fill="url(#salesFill)"
                  isAnimationActive={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>
      <section className="oracle-panel dealer-chart">
        <div className="dealer-panel-title">
          <h2>توزيع حالة الترحيل</h2>
          <BookOpen size={17} />
        </div>
        <div className="dealer-donut-wrap">
          <div className="dealer-donut">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={states}
                  dataKey="value"
                  innerRadius="67%"
                  outerRadius="88%"
                  paddingAngle={2}
                  stroke="none"
                  isAnimationActive={false}
                >
                  {states.map((s, i) => (
                    <Cell key={s.name} fill={colors[i % colors.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={v => [number(v), "سيارة"]} />
              </PieChart>
            </ResponsiveContainer>
            <div className="dealer-donut-label">
              <strong>
                {query.isLoading ? "…" : number(query.data?.totals.VEHICLES)}
              </strong>
              <small>سيارة مسجلة</small>
            </div>
          </div>
          <ul className="dealer-legend">
            {states.map((s, i) => (
              <li key={s.name}>
                <i style={{ background: colors[i % colors.length] }} />
                {s.name}
                <strong>{number(s.value)}</strong>
              </li>
            ))}
          </ul>
        </div>
        <p className="dealer-panel-note">
          حالة الترحيل مستقلة عن البيع والسداد.
        </p>
      </section>
    </div>
  );
}
export function DealerOverview({ navigate }: { navigate: NavigateDealer }) {
  const vehicles = trpc.oracleWorkspace.table.useQuery(
    { dataset: "inventory", pageSize: 10 },
    { retry: false }
  );
  const customers = trpc.oracleWorkspace.table.useQuery(
    { dataset: "customers", pageSize: 8 },
    { retry: false }
  );
  const summary = trpc.oracleWorkspace.summary.useQuery(undefined, {
    retry: false,
  });
  const total = summary.data?.totals;
  return (
    <div className="dealer-dashboard">
      <div className="dealer-dashboard-main">
        <DealerStats />
        <section className="oracle-panel dealer-showcase">
          <div className="dealer-panel-title">
            <h2>
              <Car size={18} /> مخزون السيارات
            </h2>
            <button
              onClick={() => navigate("inventory")}
              className="dealer-text-link"
            >
              عرض الكل <ChevronLeft size={14} />
            </button>
          </div>
          <p className="dealer-photo-note">
            الصور توضيحية مولّدة · بيانات السيارات من سجلات المعرض
          </p>
          <div className="dealer-showcase-cars">
            {vehicles.isLoading ? (
              <p className="dealer-loading">جاري تحميل السيارات…</p>
            ) : vehicles.isError ? (
              <p role="alert">
                تعذر تحميل السيارات{" "}
                <button onClick={() => void vehicles.refetch()}>
                  إعادة المحاولة
                </button>
              </p>
            ) : (
              vehicles.data?.rows
                .slice(0, 5)
                .map(row => (
                  <VehicleCard
                    compact
                    key={row.ID}
                    row={row}
                    onOpen={() =>
                      navigate("inventory", { vehicleId: Number(row.ID) })
                    }
                  />
                ))
            )}
          </div>
        </section>
        <SalesCharts />
        <section className="dealer-quick-actions oracle-panel">
          <h2>إجراءات سريعة</h2>
          <div>
            {[
              { label: "تصفح السيارات", icon: Car, view: "inventory" as const },
              {
                label: "عقود المبايعة",
                icon: FileText,
                view: "contracts" as const,
              },
              {
                label: "عرض التقارير",
                icon: Landmark,
                view: "reports" as const,
              },
              {
                label: "سجل العمليات",
                icon: ShieldCheck,
                view: "history" as const,
              },
            ].map(({ label, icon: Icon, view }) => (
              <button key={view} onClick={() => navigate(view)}>
                <Icon size={22} />
                <span>{label}</span>
                <ArrowUpLeft size={15} />
              </button>
            ))}
          </div>
        </section>
      </div>
      <aside className="dealer-dashboard-aside">
        <section className="oracle-panel">
          <div className="dealer-panel-title">
            <h2>
              <UsersRound size={17} />
              عملاء المعرض
            </h2>
            <span>{number(customers.data?.total)}</span>
          </div>
          <div className="dealer-customer-list">
            {customers.data?.rows.slice(0, 5).map((r, i) => (
              <button key={i} onClick={() => navigate("customers")}>
                <span className={"dealer-avatar avatar-" + i}>
                  {String(r.CUSTOMER ?? "ع").slice(0, 1)}
                </span>
                <span>
                  <strong>{String(r.CUSTOMER ?? "غير مسجل")}</strong>
                  <small>{number(r.INVOICE_COUNT)} فاتورة</small>
                </span>
                <ChevronLeft size={13} />
              </button>
            ))}
          </div>
          <button
            className="dealer-panel-link"
            onClick={() => navigate("customers")}
          >
            عرض جميع العملاء <ChevronLeft size={13} />
          </button>
        </section>
        <section className="oracle-panel">
          <div className="dealer-panel-title">
            <h2>
              <CalendarDays size={17} />
              الحركة المالية
            </h2>
          </div>
          <div className="dealer-finance-list">
            <button onClick={() => navigate("purchases")}>
              <span>
                فواتير الشراء<small>{number(total?.PURCHASES)} فاتورة</small>
              </span>
              <strong>{money(total?.PURCHASE_TOTAL)}</strong>
            </button>
            <button onClick={() => navigate("receipts")}>
              <span>
                سندات القبض<small>المسجلة في النظام</small>
              </span>
              <strong>{number(total?.RECEIPTS)}</strong>
            </button>
            <button onClick={() => navigate("expenses")}>
              <span>
                سندات الصرف<small>المسجلة في النظام</small>
              </span>
              <strong>{number(total?.PAYOUTS)}</strong>
            </button>
          </div>
          <button
            className="dealer-panel-link"
            onClick={() => navigate("ledger")}
          >
            عرض دفتر الأستاذ <ChevronLeft size={13} />
          </button>
        </section>
        <UpcomingActivities navigate={navigate} />
        <section className="oracle-panel dealer-alerts">
          <div className="dealer-panel-title">
            <h2>
              <TriangleAlert size={17} />
              تنبيهات مهمة
            </h2>
          </div>
          {summary.isError ? (
            <p>تعذر تحديث التنبيهات</p>
          ) : (
            <>
              <p>
                <i />
                {number(total?.DISABLED_TRIGGERS)} مشغلاً معطلًا يحتاج مراجعة
              </p>
              {total?.MAIN_ACCOUNTS === 0 && (
                <p>
                  <i />
                  دليل الحسابات يحتاج استكمالًا
                </p>
              )}
              <p>
                <i />
                راجع الحجوزات ومواعيد المتابعة القادمة
              </p>
            </>
          )}
          <button
            className="dealer-panel-link"
            onClick={() => navigate("audit")}
          >
            عرض حالة النظام <ChevronLeft size={13} />
          </button>
        </section>
      </aside>
    </div>
  );
}
export function DealerReports({ navigate }: { navigate: NavigateDealer }) {
  return (
    <div className="dealer-report-page">
      <DealerStats />
      <SalesCharts />
      <div className="dealer-hub-grid">
        {[
          {
            label: "تقرير الحضور والغياب والتأخير",
            description: "حضور الموظفين حسب الفرع والوردية والفترة",
            view: "attendanceReport" as const,
            icon: UsersRound,
          },
          {
            label: "الميزانية",
            description: "حركات الحسابات الرئيسية من 1000 إلى 1004",
            view: "balanceSheet" as const,
            icon: BookOpen,
          },
          {
            label: "قائمة الدخل",
            description: "حركات الحسابات الرئيسية 1005 و1006 وصافي الفترة",
            view: "incomeStatement" as const,
            icon: BookOpen,
          },
          {
            label: "ميزان المراجعة",
            description: "أرصدة حركات الفترة حسب مستويات الحسابات",
            view: "trialBalance" as const,
            icon: BookOpen,
          },
          {
            label: "دفتر اليومية",
            description: "جميع الحركات المحاسبية خلال فترة محددة",
            view: "dailyJournal" as const,
            icon: BookOpen,
          },
          {
            label: "كشف حساب",
            description: "حركات حساب خلال فترة مع الأرصدة والإجماليات",
            view: "accountStatement" as const,
            icon: FileText,
          },
          {
            label: "دفتر الأستاذ",
            description: "الحركات المحاسبية المسجلة",
            view: "ledger" as const,
            icon: Landmark,
          },
          {
            label: "حركة المخزون",
            description: "الدخول والخروج المسجل للسيارات",
            view: "stock" as const,
            icon: Car,
          },
          {
            label: "تقرير العمليات",
            description: "من أضاف وعدّل وحذف · متاح للمدير",
            view: "history" as const,
            icon: ShieldCheck,
          },
          {
            label: "سندات القيد",
            description: "تفاصيل طرفي القيد المحاسبي",
            view: "journal" as const,
            icon: BookOpen,
          },
        ].map(({ label, description, view, icon: Icon }) => (
          <button
            className="oracle-panel dealer-hub-card"
            key={view}
            onClick={() => navigate(view)}
          >
            <Icon />
            <strong>{label}</strong>
            <p>{description}</p>
            <ChevronLeft size={16} />
          </button>
        ))}
      </div>
    </div>
  );
}
export function DealerSettings({ navigate }: { navigate: NavigateDealer }) {
  return (
    <div className="dealer-hub-grid">
      <BrandingSettings />
      <SalesAccountSettings />
      <PurchaseAccountSettings />
      {[
        {
          label: "الورديات وإسناد الموظفين",
          description: "الموقع ونطاق الحضور ووقت السماح وإسناد الموظفين",
          view: "attendanceSettings" as const,
          icon: CalendarDays,
        },
        {
          label: "المستخدمون والصلاحيات",
          description: "حساب مستقل لكل موظف وحساب تجريبي محدد المدة",
          view: "users" as const,
          icon: UsersRound,
        },
        {
          label: "دليل الحسابات",
          description: "الحسابات الرئيسية والفرعية",
          view: "accountDirectory" as const,
          icon: BookOpen,
        },
        {
          label: "حسابات المستوى الأول",
          description: "تعريف الحسابات الرئيسية",
          view: "mainAccounts" as const,
          icon: Landmark,
        },
        {
          label: "حسابات المستوى الثاني",
          description: "الحسابات التابعة للمستوى الأول",
          view: "branchAccounts" as const,
          icon: Landmark,
        },
        {
          label: "حسابات المستوى الثالث",
          description: "تفاصيل الحسابات وبيانات الاتصال",
          view: "subAccounts" as const,
          icon: Landmark,
        },
        {
          label: "مراكز التكلفة",
          description: "إدارة مراكز التكلفة المسجلة",
          view: "costCenters" as const,
          icon: Settings2,
        },
        {
          label: "سلامة قاعدة البيانات",
          description: "فحص الربط وحالة المشغلات",
          view: "audit" as const,
          icon: ShieldCheck,
        },
        {
          label: "تقرير العمليات",
          description: "سجل الإضافة والتعديل والحذف",
          view: "history" as const,
          icon: FileText,
        },
      ].map(({ label, description, view, icon: Icon }) => (
        <button
          className="oracle-panel dealer-hub-card"
          key={view}
          onClick={() => navigate(view)}
        >
          <Icon />
          <strong>{label}</strong>
          <p>{description}</p>
          <ChevronLeft size={16} />
        </button>
      ))}
    </div>
  );
}
