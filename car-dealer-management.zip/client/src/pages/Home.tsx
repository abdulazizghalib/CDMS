import { useRef, useState } from "react";
import type { FormEvent } from "react";
import type { Vehicle } from "../../../drizzle/schema";
import {
  AlertTriangle,
  Bell,
  Car,
  ChevronLeft,
  CircleDollarSign,
  ClipboardList,
  FileBarChart,
  FileText,
  Gauge,
  ImagePlus,
  LayoutDashboard,
  LogOut,
  Menu,
  MoreHorizontal,
  Package,
  PanelRight,
  Plus,
  Search,
  Settings,
  ShieldCheck,
  ShoppingCart,
  Store,
  TrendingUp,
  UserRound,
  UsersRound,
  Wrench,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { OracleAuditPanel } from "@/components/OracleAuditPanel";
import { filterPurchases, summarizePurchases } from "@/lib/purchases";
import { filterSales, summarizeSales } from "@/lib/sales";
import { filterCustomers } from "@/lib/customers";
import { filterExpenses, summarizeExpenses } from "@/lib/expenses";

const nav = [
  { id: "dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
  { id: "inventory", label: "مخزون السيارات", icon: Car },
  { id: "sales", label: "المبيعات والعقود", icon: FileText },
  { id: "customers", label: "العملاء والمتابعة", icon: UsersRound },
  { id: "purchases", label: "المشتريات والموردون", icon: ShoppingCart },
  { id: "expenses", label: "المصروفات والتجهيز", icon: Wrench },
  { id: "reports", label: "التقارير والربحية", icon: FileBarChart },
  { id: "settings", label: "الإعدادات والصلاحيات", icon: Settings },
];

function LogoMark({ logo, compact = false }: { logo: string | null; compact?: boolean }) {
  return logo ? <img src={logo} alt="شعار المعرض" className={`${compact ? "h-9 w-9" : "h-12 w-12"} rounded-xl object-contain bg-white p-1`} /> : (
    <div className={`${compact ? "h-9 w-9" : "h-12 w-12"} flex items-center justify-center rounded-2xl bg-[#f3c563] text-[#09233e] shadow-lg`}>
      <Car className={compact ? "h-5 w-5" : "h-7 w-7"} strokeWidth={2.2} />
    </div>
  );
}

export default function Home() {
  const [active, updateActive] = useState(() => { const view = new URLSearchParams(window.location.search).get("view"); return nav.some(item => item.id === view) ? view! : "dashboard"; });
  const setActive = (view: string) => { updateActive(view); setSelectedVehicle(null); setQuery(""); if (window.innerWidth < 1024) setSidebarOpen(false); const url = new URL(window.location.href); url.searchParams.set("view", view); window.history.replaceState(null, "", url); };
  const currentUser = trpc.auth.me.useQuery();
  const logout = trpc.auth.logout.useMutation({ onSuccess: () => window.location.reload(), onError: () => toast.error("تعذر تسجيل الخروج") });
  const [query, setQuery] = useState("");
  const [logo, setLogo] = useState<string | null>(() => localStorage.getItem("dealer-logo"));
  const [logoOpen, setLogoOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(() => window.innerWidth >= 1024);
  const [branch, setBranch] = useState("الفرع الرئيسي");
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const logoInput = useRef<HTMLInputElement>(null);

  const activeLabel = nav.find((item) => item.id === active)?.label ?? "لوحة التحكم";

  const handleLogo = (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast.error("يرجى اختيار ملف صورة صالح"); return; }
    const reader = new FileReader();
    reader.onload = () => { const value = String(reader.result); localStorage.setItem("dealer-logo", value); setLogo(value); toast.success("تم تحديث شعار النظام"); };
    reader.readAsDataURL(file);
  };
  const removeLogo = () => { localStorage.removeItem("dealer-logo"); setLogo(null); toast.success("تمت إزالة الشعار المخصص"); };

  return (
    <div dir="rtl" className="dealer-app min-h-screen bg-[#f7f9fc] text-[#102b46]">
      {sidebarOpen && <button aria-label="إغلاق القائمة" onClick={() => setSidebarOpen(false)} className="fixed inset-0 z-30 bg-slate-950/45 backdrop-blur-sm lg:hidden" />}
      <aside aria-label="التنقل الرئيسي" className={`fixed inset-y-0 right-0 z-40 flex w-[278px] flex-col bg-[#09233e] text-white shadow-2xl transition-transform duration-300 ${sidebarOpen ? "translate-x-0" : "translate-x-full"}`}>
        <div className="flex items-center justify-between border-b border-white/10 px-5 py-5">
          <div className="flex items-center gap-3"><LogoMark logo={logo} /><div><p className="text-sm font-bold">معرض النخبة للسيارات</p><p className="mt-1 text-[11px] text-[#a9c1d0]">إدارة المعرض</p></div></div>
          <button onClick={() => setSidebarOpen(false)} className="rounded-lg p-2 text-white/60 hover:bg-white/10 hover:text-white"><X className="h-4 w-4" /></button>
        </div>
        <div className="px-4 pt-5"><p className="mb-3 px-3 text-[10px] font-bold tracking-[.18em] text-[#7593a8]">القائمة الرئيسية</p>{nav.slice(0, 7).map((item) => { const Icon = item.icon; return <button key={item.id} onClick={() => setActive(item.id)} className={`mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-3 text-right text-[13px] transition ${active === item.id ? "bg-[#f0bd55] font-bold text-[#09233e] shadow-lg shadow-[#f0bd55]/10" : "text-[#d6e4ec] hover:bg-white/10"}`}><Icon className="h-[18px] w-[18px]" />{item.label}</button>; })}</div>
        <div className="mt-5 border-t border-white/10 px-4 pt-5"><p className="mb-3 px-3 text-[10px] font-bold tracking-[.18em] text-[#7593a8]">الإدارة</p><button onClick={() => setActive("settings")} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-right text-[13px] ${active === "settings" ? "bg-[#f0bd55] font-bold text-[#09233e]" : "text-[#d6e4ec] hover:bg-white/10"}`}><Settings className="h-[18px] w-[18px]" />الإعدادات والصلاحيات</button></div>
        <div className="mt-auto p-4"><div className="rounded-2xl border border-[#f0bd55]/20 bg-[#123a5b] p-4"><div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#f0bd55] text-[#09233e] font-bold">م</div><div><p className="text-xs font-bold">مدير المعرض</p><p className="text-[10px] text-[#a9c1d0]">حسب الحساب المسجل</p></div><MoreHorizontal className="mr-auto h-4 w-4 text-[#a9c1d0]" /></div><button onClick={() => logout.mutate()} className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg border border-white/10 py-2 text-xs text-[#d6e4ec] hover:bg-white/10"><LogOut className="h-3.5 w-3.5" />تسجيل الخروج</button></div></div>
      </aside>
      {!sidebarOpen && <button onClick={() => setSidebarOpen(true)} className="fixed right-5 top-5 z-30 rounded-xl bg-[#09233e] p-3 text-white shadow-lg"><Menu className="h-5 w-5" /></button>}
      <main className={`min-h-screen transition-[margin] duration-300 ${sidebarOpen ? "lg:mr-[278px]" : "mr-0"}`}>
        <header className="sticky top-0 z-20 flex h-[82px] items-center justify-between border-b border-[#e3eaf0] bg-white/90 px-4 lg:px-7 backdrop-blur-xl">
          <div className="flex items-center gap-5"><button onClick={() => setSidebarOpen(!sidebarOpen)} className="rounded-xl p-2 text-[#587186] hover:bg-[#f0f4f7]"><PanelRight className="h-5 w-5" /></button><div className="relative hidden w-[240px] xl:block"><Search className="absolute right-3 top-3 h-4 w-4 text-[#8ca1af]" /><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="بحث في المخزون بالاسم أو رقم الهيكل" onFocus={() => { if (active !== "inventory") setActive("inventory"); }} className="h-10 rounded-xl border-[#e0e8ee] bg-[#f7f9fc] pr-10 text-right text-xs" /></div></div>
          <div className="flex items-center gap-5"><div className="hidden items-center gap-3 md:flex"><div className="text-left"><p className="text-[11px] text-[#7b8d9b]">{new Date().toLocaleDateString("ar-SA", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}</p><p className="mt-1 text-xs font-bold text-[#102b46]">نظرة عامة على أداء المعرض اليوم</p></div><select aria-label="الفرع النشط" value={branch} onChange={(e) => setBranch(e.target.value)} className="rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 py-2 text-[10px] font-semibold text-[#31536d]"><option>الفرع الرئيسي</option><option>فرع الشمال</option><option>فرع المطار</option></select></div><div aria-label="التنبيهات غير مرتبطة بعد" className="relative rounded-xl bg-[#f5f8fa] p-2.5 text-[#31536d]"><Bell className="h-5 w-5" /><span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#e9b84f] px-1 text-[9px] font-bold text-[#09233e]">—</span></div><div className="flex items-center gap-3 border-r border-[#e5ecf1] pr-5"><div className="hidden text-right sm:block"><p className="text-xs font-bold">{currentUser.data?.name || "حساب المستخدم"}</p><p className="mt-1 text-[10px] text-[#8294a0]">مدير المعرض</p></div><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e8f3f6] text-sm font-bold text-[#167f82]">أح</div></div></div>
        </header>
        <div className="workspace-content p-4 lg:p-7">
          <div className="mb-7 flex flex-wrap items-end justify-between gap-4"><div><p className="mb-2 text-xs font-bold text-[#159d99]">{active === "dashboard" ? "مرحباً بك" : "إدارة المعرض"}</p><h1 className="text-2xl font-extrabold tracking-tight text-[#09233e]">{activeLabel}</h1><p className="mt-2 text-xs text-[#7890a0]">كل ما تحتاجه لإدارة معرضك من مكان واحد.</p></div><div className="flex gap-2"><Button onClick={() => active === "settings" ? setLogoOpen(true) : setActive("purchases")} className="gap-2 rounded-xl bg-[#0c3958] text-xs hover:bg-[#09233e]"><Plus className="h-4 w-4" />{active === "settings" ? "تغيير الشعار" : "المشتريات وإضافة السيارات"}</Button></div></div>
          {selectedVehicle ? <VehicleDetail car={selectedVehicle} onBack={() => setSelectedVehicle(null)} /> : null}
          {!selectedVehicle && active === "dashboard" && <Dashboard branch={branch} onOpenInventory={() => setActive("inventory")} onOpenVehicle={setSelectedVehicle} />}
          {!selectedVehicle && active === "inventory" && <Inventory branch={branch} query={query} onAdd={() => setActive("purchases")} onOpenVehicle={setSelectedVehicle} />}

          {active === "sales" && <Sales />}
          {active === "customers" && <Customers />}
          {active === "purchases" && <Purchases />}
          {active === "expenses" && <Expenses />}
          {active === "reports" && <Reports />}
          {active === "settings" && <><OracleAuditPanel /><SettingsPanel logo={logo} onUpload={() => logoInput.current?.click()} onRemove={removeLogo} /></>}
        </div>
      </main>
      <input ref={logoInput} type="file" accept="image/*" className="hidden" onChange={(e) => handleLogo(e.target.files?.[0])} />
      <Dialog open={logoOpen} onOpenChange={setLogoOpen}><DialogContent dir="rtl" className="max-w-md"><DialogHeader><DialogTitle>تغيير شعار النظام</DialogTitle></DialogHeader><div className="space-y-4"><div className="flex min-h-32 items-center justify-center rounded-2xl border-2 border-dashed border-[#d6e3ea] bg-[#f8fafc]">{logo ? <img src={logo} alt="الشعار الحالي" className="h-24 w-24 object-contain" /> : <ImagePlus className="h-10 w-10 text-[#9bb0bd]" />}</div><p className="text-center text-xs text-[#6d8290]">اختر صورة الشعار بصيغة PNG أو JPG. سيتم تطبيقها على جميع أجزاء النظام.</p><div className="flex gap-2"><Button onClick={() => logoInput.current?.click()} className="flex-1 bg-[#0c3958]">رفع شعار جديد</Button>{logo && <Button onClick={removeLogo} variant="outline" className="text-red-600">إزالة</Button>}</div></div></DialogContent></Dialog>
    </div>
  );
}

function Dashboard({ branch, onOpenInventory, onOpenVehicle }: { branch: string; onOpenInventory: () => void; onOpenVehicle: (car: Vehicle) => void }) {
  const summaryQuery = trpc.reports.getSummary.useQuery();
  const vehiclesQuery = trpc.vehicles.list.useQuery({ branch });
  const branchVehicles = (vehiclesQuery.data ?? []).filter(vehicle => vehicle.branch === branch);
  const data = summaryQuery.data;
  if (summaryQuery.isError || vehiclesQuery.isError) return <QueryFailure retry={() => { void summaryQuery.refetch(); void vehiclesQuery.refetch(); }} />;
  if (summaryQuery.isLoading || vehiclesQuery.isLoading) return <p role="status">جاري تحميل لوحة التحكم...</p>;

  const stats = [
    { label: "قيمة المخزون", value: (data?.inventoryValue ?? 0).toLocaleString(), suffix: "ر.س", trend: "من السجلات الحالية", icon: CircleDollarSign, tone: "blue" },
    { label: "إجمالي المبيعات", value: (data?.totalSales ?? 0).toLocaleString(), suffix: "ر.س", trend: "من السجلات الحالية", icon: TrendingUp, tone: "teal" },
    { label: "فرق المبيعات والتكاليف", value: ((data?.totalSales ?? 0) - (data?.totalPurchases ?? 0) - (data?.totalExpenses ?? 0)).toLocaleString(), suffix: "ر.س", trend: "قبل تسوية التحصيل والمدفوعات", icon: Gauge, tone: "gold" },
    { label: "السيارات المتاحة", value: String(branchVehicles.filter(v => v.status === "available").length ?? 0), suffix: "سيارة", trend: "من المخزون", icon: ClipboardList, tone: "rose" }
  ];

  return (
    <div className="space-y-5">
      <div className="grid gap-4 xl:grid-cols-4 md:grid-cols-2">
        {stats.map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="group rounded-2xl border border-[#e2eaf0] bg-white p-5 shadow-[0_8px_25px_rgba(22,55,78,.04)] transition hover:-translate-y-0.5 hover:shadow-lg">
              <div className="mb-4 flex items-center justify-between">
                <p className="text-xs font-semibold text-[#718796]">{item.label}</p>
                <div className={`rounded-xl p-2.5 ${item.tone === "teal" ? "bg-[#e8f5f2] text-[#159d99]" : item.tone === "gold" ? "bg-[#fff4d9] text-[#c9972f]" : item.tone === "rose" ? "bg-[#fdebed] text-[#e66b71]" : "bg-[#eaf2fa] text-[#4b8fba]"}`}>
                  <Icon className="h-5 w-5" />
                </div>
              </div>
              <p className="text-2xl font-extrabold tracking-tight text-[#09233e]">{item.value} <span className="text-[11px] font-normal text-[#7890a0]">{item.suffix}</span></p>
              <div className="mt-4 flex items-center gap-1 text-[10px] text-[#159d70]"><TrendingUp className="h-3 w-3" />{item.trend}</div>
            </div>
          );
        })}
      </div>
      <div className="grid gap-5 xl:grid-cols-[1.5fr_1fr]">
        <section className="rounded-2xl border border-[#e2eaf0] bg-white p-5 shadow-[0_8px_25px_rgba(22,55,78,.04)]">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#09233e]">مخزون السيارات</h2>
              <p className="mt-1 text-[10px] text-[#81939f]">السيارات المعروضة حاليًا داخل {branch}</p>
            </div>
            <button onClick={onOpenInventory} className="flex items-center gap-1 text-[11px] font-bold text-[#178e91]">عرض الكل <ChevronLeft className="h-3.5 w-3.5" /></button>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {branchVehicles.slice(0, 4).map((car) => (
              <button key={car.id} onClick={() => onOpenVehicle(car)} className="rounded-2xl border border-[#e2eaf0] bg-white p-3 text-right shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
                <div className="relative h-24 overflow-hidden rounded-xl bg-[#f0f4f8] flex items-center justify-center">
                  <Car className="h-8 w-8 text-[#9bb0bd]" />
                </div>
                <div className="p-1 pt-2">
                  <h3 className="text-[11px] font-bold truncate">{car.make} {car.model}</h3>
                  <p className="mt-0.5 text-[9px] text-[#8296a2]">{car.year}</p>
                  <p className="mt-1 text-[10px] font-bold text-[#159d99]">{(car.askingPrice ?? 0).toLocaleString()} ر.س</p>
                </div>
              </button>
            ))}
            {(!vehiclesQuery.data || vehiclesQuery.data.length === 0) && (
              <div className="col-span-full py-10 text-center text-xs text-[#81939f]">لا توجد سيارات للعرض</div>
            )}
          </div>
        </section><section className="rounded-2xl border border-[#e2eaf0] bg-white p-5 shadow-[0_8px_25px_rgba(22,55,78,.04)]"><div className="mb-3 flex items-center justify-between"><div><h2 className="text-sm font-bold text-[#09233e]">متابعة العملاء اليوم</h2><p className="mt-1 text-[10px] text-[#81939f]">5 مواعيد تحتاج إلى متابعة</p></div><UsersRound className="h-5 w-5 text-[#159d99]" /></div>{[["أحمد العتيبي","استفسار عن لاندكروزر","10:30 ص","متابعة"],["محمد الشهري","طلب عرض سعر","11:15 ص","جديد"],["سارة الحربي","استفسار عن توسان","12:00 م","متابعة"],["فهد الدوسري","حجز مبدئي","01:30 م","جديد"]].map(([name, note, time, status]) => <div key={name} className="flex items-center gap-3 border-b border-[#eef2f5] py-3 last:border-0"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#edf5f5] text-xs font-bold text-[#178e91]">{name[0]}</div><div className="min-w-0 flex-1"><p className="text-xs font-bold">{name}</p><p className="mt-1 truncate text-[10px] text-[#81939f]">{note}</p></div><div className="text-left"><Badge className={status === "جديد" ? "bg-[#e8f4ea] text-[#159d70] hover:bg-[#e8f4ea]" : "bg-[#eaf2fa] text-[#4580ad] hover:bg-[#eaf2fa]"}>{status}</Badge><p className="mt-1 text-[9px] text-[#9aa9b2]">{time}</p></div></div>)}</section>
      </div>
      <section className="rounded-2xl border bg-white p-6"><h2 className="text-sm font-bold">متابعة بيانات المعرض</h2><p className="mt-3 text-sm leading-7 text-slate-500">تُعرض مؤشرات الأداء والتنبيهات بعد اكتمال ربط بيانات المعرض. يمكنك مراجعة حالة Oracle من الإعدادات.</p></section>
    </div>
  );
}

function QueryFailure({ retry }: { retry: () => void }) { return <div role="alert" className="rounded-2xl border border-amber-200 bg-amber-50 p-5 text-sm text-amber-900"><p className="font-bold">تعذر تحميل البيانات</p><p className="mt-2">تحقق من اتصال قاعدة البيانات وتسجيل الدخول. لا تعني هذه الحالة أن السجلات فارغة.</p><Button variant="outline" className="mt-3" onClick={retry}>إعادة المحاولة</Button></div>; }

function VehicleDetail({ car, onBack }: { car: Vehicle; onBack: () => void }) {
 const labels: Record<string,string> = { available: "متاحة", reserved: "محجوزة", sold: "مباعة", maintenance: "صيانة" };
 return <section className="rounded-2xl border bg-white p-6"><Button variant="outline" onClick={onBack}>العودة إلى المخزون</Button><div className="mt-6 flex flex-wrap items-center justify-between gap-4"><h2 className="text-2xl font-bold">{car.make} {car.model}</h2><Badge>{labels[car.status]}</Badge></div><div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[["رقم الهيكل", car.vin || "غير مسجل"], ["سنة الصنع", car.year], ["المسافة", (car.mileage ?? 0).toLocaleString() + " كم"], ["الفرع", car.branch], ["اللون", car.color || "غير مسجل"], ["سعر العرض", (car.askingPrice ?? 0).toLocaleString() + " ر.س"], ["سعر الشراء", (car.purchasePrice ?? 0).toLocaleString() + " ر.س"]].map(([label,value]) => <div key={String(label)} className="rounded-xl bg-slate-50 p-4"><p className="text-xs text-slate-500">{label}</p><p className="mt-2 break-words font-semibold">{value}</p></div>)}</div>{car.description && <p className="mt-5 text-sm leading-7">{car.description}</p>}</section>;
}

function Inventory({ onOpenVehicle, branch, query, onAdd }: { onOpenVehicle: (car: Vehicle) => void; branch: string; query: string; onAdd: () => void }) {
  const [statusFilter, setStatusFilter] = useState("all");
  const vehiclesQuery = trpc.vehicles.list.useQuery({ branch });
  
  const statusLabel: Record<string, string> = { 
    available: "متاحة", reserved: "محجوزة", sold: "مباعة", maintenance: "صيانة" 
  };

  const list = (vehiclesQuery.data ?? []).filter(v => v.branch === branch && [v.make, v.model, v.vin, String(v.year)].join(" ").toLowerCase().includes(query.trim().toLowerCase()));
  const filtered = statusFilter === "all" ? list : list.filter(v => v.status === statusFilter);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-[#e2eaf0] bg-white p-4">
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 py-2 text-xs">
          <option value="all">كل الحالات</option>
          {Object.entries(statusLabel).map(([val, lab]) => <option key={val} value={val}>{lab}</option>)}
        </select>
        <Button onClick={onAdd} className="mr-auto gap-2 rounded-xl bg-[#0c3958] text-xs">
          <Plus className="h-4 w-4" />إضافة سيارة
        </Button>
      </div>

      {vehiclesQuery.isError ? <QueryFailure retry={() => vehiclesQuery.refetch()} /> : vehiclesQuery.isLoading ? (
        <div className="flex min-h-52 items-center justify-center text-xs text-[#81939f]">جاري تحميل المخزون...</div>
      ) : filtered.length === 0 ? (
        <div className="flex min-h-52 flex-col items-center justify-center text-center rounded-2xl border border-[#e2eaf0] bg-white">
          <Car className="h-8 w-8 text-[#159d99] mb-4" />
          <h3 className="text-sm font-bold">لا توجد سيارات في المخزون</h3>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {filtered.map((car) => (
            <button key={car.id} onClick={() => onOpenVehicle(car)} className="rounded-2xl border border-[#e2eaf0] bg-white p-3 text-right shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
              <div className="relative h-40 overflow-hidden rounded-xl bg-[#f0f4f8] flex items-center justify-center">
                <Car className="h-12 w-12 text-[#9bb0bd]" />
                <Badge className={`absolute left-3 top-3 text-[10px] ${car.status === "available" ? "bg-[#e6f5ef] text-[#168c5d]" : "bg-[#fff4d9] text-[#a87518]"}`}>
                  {statusLabel[car.status]}
                </Badge>
              </div>
              <div className="p-2 pt-3">
                <h3 className="text-sm font-bold">{car.make} {car.model}</h3>
                <p className="mt-1 text-[10px] text-[#8296a2]">{car.year} · {(car.mileage ?? 0).toLocaleString()} كم</p>
                <div className="mt-4 grid grid-cols-2 gap-2 border-t border-[#eef2f5] pt-3 text-[10px]">
                  <span className="text-[#8396a2]">سعر البيع<strong className="mt-1 block text-xs text-[#102b46]">{(car.askingPrice ?? 0).toLocaleString()} ر.س</strong></span>
                  <span className="text-[#8396a2]">الفرع<strong className="mt-1 block text-xs text-[#159d99]">{car.branch}</strong></span>
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function EmptyWorkspace({ icon: Icon, title, description, action }: { icon: typeof Store; title: string; description: string; action: string }) { return <div className="flex min-h-[430px] flex-col items-center justify-center rounded-2xl border border-[#e2eaf0] bg-white text-center"><div className="mb-4 rounded-2xl bg-[#eaf5f4] p-4 text-[#159d99]"><Icon className="h-8 w-8" /></div><h2 className="text-lg font-bold text-[#09233e]">{title}</h2><p className="mt-2 max-w-md text-xs leading-6 text-[#7c919f]">{description}</p><Button className="mt-5 gap-2 rounded-xl bg-[#0c3958] text-xs"><Plus className="h-4 w-4" />{action}</Button></div>; }
function DataShell({ icon: Icon, title, description, action, headers, rows }: { icon: typeof Store; title: string; description: string; action: string; headers: string[]; rows: string[][] }) { return <div className="space-y-4"><div className="flex items-center justify-between rounded-2xl border border-[#e2eaf0] bg-white p-5"><div className="flex items-center gap-3"><div className="rounded-xl bg-[#eaf5f4] p-3 text-[#159d99]"><Icon className="h-5 w-5" /></div><div><h2 className="text-sm font-bold">{title}</h2><p className="mt-1 text-[10px] text-[#81939f]">{description}</p></div></div><Button onClick={() => toast.success(`تم فتح نموذج ${action}`)} className="gap-2 rounded-xl bg-[#0c3958] text-xs"><Plus className="h-4 w-4" />{action}</Button></div><div className="overflow-hidden rounded-2xl border border-[#e2eaf0] bg-white"><div className="border-b border-[#eef2f5] p-4"><div className="relative max-w-sm"><Search className="absolute right-3 top-3 h-4 w-4 text-[#8ca1af]" /><Input placeholder="بحث في السجلات..." className="h-10 rounded-xl bg-[#f8fafc] pr-10 text-xs" /></div></div><div className="overflow-x-auto"><table className="w-full text-right text-xs"><thead className="bg-[#f8fafc] text-[10px] text-[#718796]"><tr>{headers.map((header) => <th key={header} className="whitespace-nowrap px-5 py-4 font-semibold">{header}</th>)}</tr></thead><tbody>{rows.map((row, index) => <tr key={index} className="border-t border-[#eef2f5] hover:bg-[#fbfdfe]">{row.map((cell, cellIndex) => <td key={cellIndex} className={`whitespace-nowrap px-5 py-4 ${cellIndex === 0 ? "font-bold text-[#102b46]" : "text-[#6e8492]"}`}>{cellIndex === row.length - 1 ? <Badge className="bg-[#e6f5ef] text-[9px] text-[#168c5d] hover:bg-[#e6f5ef]">{cell}</Badge> : cell}</td>)}</tr>)}</tbody></table></div></div></div>; }
function Sales() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [paymentFilter, setPaymentFilter] = useState("all");
  const [branchFilter, setBranchFilter] = useState("all");
  
  const salesQuery = trpc.sales.list.useQuery();
  const vehiclesQuery = trpc.vehicles.list.useQuery({ status: "available" });
  const customersQuery = trpc.customers.list.useQuery();
  const utils = trpc.useUtils();

  const createSale = trpc.sales.create.useMutation({
    onSuccess: async () => {
      await utils.sales.list.invalidate();
      await utils.vehicles.list.invalidate();
      setOpen(false);
      toast.success("تم تسجيل عملية البيع بنجاح");
    },
    onError: (error) => toast.error(error.message),
  });

  const rows = filterSales(salesQuery.data ?? [], { query, paymentStatus: paymentFilter, branch: branchFilter });
  const { totalSales, paidCount, unpaidCount } = summarizeSales(rows);

  const paymentLabel: Record<string, string> = { unpaid: "غير مدفوعة", partial: "مدفوعة جزئيًا", paid: "مدفوعة" };

  return (
    <div className="space-y-5">
      <div className="grid gap-4 md:grid-cols-3">
        {[
          ["إجمالي قيمة المبيعات", `${totalSales.toLocaleString()} ر.س`, "قيمة الصفقات المنفذة", "bg-[#eaf5f4] text-[#159d99]"],
          ["عمليات مكتملة السداد", String(paidCount), "تم تحصيلها بالكامل", "bg-[#eaf2fa] text-[#4b8fba]"],
          ["مبالغ تحت التحصيل", String(unpaidCount), "دفعات جزئية أو آجلة", "bg-[#fdebed] text-[#e66b71]"]
        ].map(([label, value, note, tone]) => (
          <div key={label} className="rounded-2xl border border-[#e2eaf0] bg-white p-5 shadow-[0_8px_25px_rgba(22,55,78,.04)]">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-semibold text-[#718796]">{label}</p>
                <p className="mt-3 text-xl font-extrabold text-[#09233e]">{value}</p>
                <p className="mt-2 text-[10px] text-[#81939f]">{note}</p>
              </div>
              <div className={`rounded-xl p-3 ${tone}`}><FileText className="h-5 w-5" /></div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#e2eaf0] bg-white p-5">
        <div>
          <h2 className="text-sm font-bold">المبيعات وعقود المبايعة</h2>
          <p className="mt-1 text-[10px] text-[#81939f]">إدارة العمليات التجارية وعقود البيع والتحصيل.</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 rounded-xl bg-[#0c3958] text-xs hover:bg-[#09233e]">
          <Plus className="h-4 w-4" />إنشاء عقد بيع
        </Button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-[#e2eaf0] bg-white">
        <div className="border-b border-[#eef2f5] p-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-[250px] flex-1">
              <Search className="absolute right-3 top-3 h-4 w-4 text-[#8ca1af]" />
              <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ابحث برقم الفاتورة أو ملاحظات..." className="h-10 rounded-xl bg-[#f8fafc] pr-10 text-xs" />
            </div>
            <select aria-label="حالة السداد" value={paymentFilter} onChange={(e) => setPaymentFilter(e.target.value)} className="h-10 rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-[11px] text-[#587186]">
              <option value="all">كل حالات السداد</option>
              <option value="unpaid">غير مدفوعة</option>
              <option value="partial">مدفوعة جزئيًا</option>
              <option value="paid">مدفوعة</option>
            </select>
            <select aria-label="الفرع" value={branchFilter} onChange={(e) => setBranchFilter(e.target.value)} className="h-10 rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-[11px] text-[#587186]">
              <option value="all">كل الفروع</option>
              <option value="الفرع الرئيسي">الفرع الرئيسي</option>
              <option value="فرع الشمال">فرع الشمال</option>
              <option value="فرع المطار">فرع المطار</option>
            </select>
          </div>
        </div>
        
        {salesQuery.isError ? <QueryFailure retry={() => salesQuery.refetch()} /> : salesQuery.isLoading ? (
          <div className="flex min-h-52 items-center justify-center text-xs text-[#81939f]">جاري تحميل سجل المبيعات...</div>
        ) : rows.length === 0 ? (
          <div className="flex min-h-52 flex-col items-center justify-center text-center">
            <div className="rounded-2xl bg-[#eaf5f4] p-4 text-[#159d99]"><FileText className="h-7 w-7" /></div>
            <h3 className="mt-4 text-sm font-bold text-[#09233e]">لا توجد عمليات بيع بعد</h3>
            <Button onClick={() => setOpen(true)} className="mt-4 rounded-xl bg-[#0c3958] text-xs">إنشاء أول عقد</Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-[#f8fafc] text-[10px] text-[#718796]">
                <tr>
                  {["رقم الفاتورة", "العميل", "قيمة الصفقة", "تاريخ البيع", "السداد", "الفرع"].map((header) => (
                    <th key={header} className="whitespace-nowrap px-5 py-4 font-semibold">{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((sale) => (
                  <tr key={sale.id} className="border-t border-[#eef2f5] hover:bg-[#fbfdfe]">
                    <td className="whitespace-nowrap px-5 py-4 font-bold text-[#102b46]">{sale.invoiceNumber}</td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">عميل رقم {sale.customerId}</td>
                    <td className="whitespace-nowrap px-5 py-4 font-extrabold text-[#159d99]">{sale.totalAmount.toLocaleString()} ر.س</td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{new Date(sale.saleDate).toLocaleDateString("ar-SA")}</td>
                    <td className="whitespace-nowrap px-5 py-4">
                      <Badge className={`text-[9px] ${sale.paymentStatus === "paid" ? "bg-[#e6f5ef] text-[#168c5d]" : "bg-[#fff4d9] text-[#a87518]"}`}>
                        {paymentLabel[sale.paymentStatus]}
                      </Badge>
                    </td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{sale.branch}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent dir="rtl" className="max-w-2xl">
          <DialogHeader><DialogTitle>إنشاء عقد بيع جديد</DialogTitle></DialogHeader>
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            createSale.mutate({
              invoiceNumber: `INV-${Date.now()}`,
              vehicleId: Number(formData.get("vehicleId")),
              customerId: Number(formData.get("customerId")),
              salePrice: Number(formData.get("salePrice")),
              discount: Number(formData.get("discount")) || 0,
              tax: Number(formData.get("tax")) || 0,
              paymentStatus: formData.get("paymentStatus") as any,
              paymentMethod: formData.get("paymentMethod") as any,
              branch: formData.get("branch") as string,
              notes: formData.get("notes") as string,
            });
          }} className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <label className="space-y-1 text-[11px] font-bold">
                <span>اختر السيارة *</span>
                <select name="vehicleId" required className="h-10 w-full rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-xs">
                  {vehiclesQuery.data?.map(v => <option key={v.id} value={v.id}>{v.make} {v.model} ({v.year})</option>)}
                </select>
              </label>
              <label className="space-y-1 text-[11px] font-bold">
                <span>اختر العميل *</span>
                <select name="customerId" required className="h-10 w-full rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-xs">
                  {customersQuery.data?.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </label>
              <label className="space-y-1 text-[11px] font-bold">
                <span>سعر البيع *</span>
                <Input name="salePrice" type="number" required />
              </label>
              <label className="space-y-1 text-[11px] font-bold">
                <span>الخصم</span>
                <Input name="discount" type="number" defaultValue="0" />
              </label>
              <label className="space-y-1 text-[11px] font-bold">
                <span>حالة السداد</span>
                <select name="paymentStatus" className="h-10 w-full rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-xs">
                  <option value="unpaid">غير مدفوعة</option>
                  <option value="partial">مدفوعة جزئيًا</option>
                  <option value="paid">مدفوعة</option>
                </select>
              </label>
              <label className="space-y-1 text-[11px] font-bold">
                <span>طريقة الدفع</span>
                <select name="paymentMethod" className="h-10 w-full rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-xs">
                  <option value="cash">نقدي</option>
                  <option value="bank_transfer">تحويل بنكي</option>
                  <option value="finance">تمويل</option>
                  <option value="check">شيك</option>
                </select>
              </label>
            </div>
            <Button type="submit" disabled={createSale.isPending} className="w-full bg-[#0c3958]">
              {createSale.isPending ? "جاري الحفظ..." : "حفظ عقد البيع"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
function Customers() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const customersQuery = trpc.customers.list.useQuery();
  const utils = trpc.useUtils();

  const createCustomer = trpc.customers.create.useMutation({
    onSuccess: async () => {
      await utils.customers.list.invalidate();
      setOpen(false);
      toast.success("تمت إضافة العميل بنجاح");
    },
    onError: (error) => toast.error(error.message),
  });

  const rows = filterCustomers(customersQuery.data ?? [], query);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#e2eaf0] bg-white p-5">
        <div>
          <h2 className="text-sm font-bold">العملاء والمتابعة</h2>
          <p className="mt-1 text-[10px] text-[#81939f]">إدارة بيانات العملاء والتواصل المستقبلي.</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 rounded-xl bg-[#0c3958] text-xs hover:bg-[#09233e]">
          <Plus className="h-4 w-4" />إضافة عميل جديد
        </Button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-[#e2eaf0] bg-white">
        <div className="border-b border-[#eef2f5] p-4">
          <div className="relative max-w-sm">
            <Search className="absolute right-3 top-3 h-4 w-4 text-[#8ca1af]" />
            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="بحث باسم العميل أو الهاتف..." className="h-10 rounded-xl bg-[#f8fafc] pr-10 text-xs" />
          </div>
        </div>

        {customersQuery.isError ? <QueryFailure retry={() => customersQuery.refetch()} /> : customersQuery.isLoading ? (
          <div className="flex min-h-52 items-center justify-center text-xs text-[#81939f]">جاري تحميل قائمة العملاء...</div>
        ) : rows.length === 0 ? (
          <div className="flex min-h-52 flex-col items-center justify-center text-center">
            <div className="rounded-2xl bg-[#eaf5f4] p-4 text-[#159d99]"><UsersRound className="h-7 w-7" /></div>
            <h3 className="mt-4 text-sm font-bold text-[#09233e]">لا يوجد عملاء مسجلون</h3>
            <Button onClick={() => setOpen(true)} className="mt-4 rounded-xl bg-[#0c3958] text-xs">إضافة أول عميل</Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-[#f8fafc] text-[10px] text-[#718796]">
                <tr>
                  {["اسم العميل", "رقم الهاتف", "البريد الإلكتروني", "رقم الهوية", "تاريخ التسجيل"].map((header) => (
                    <th key={header} className="whitespace-nowrap px-5 py-4 font-semibold">{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((customer) => (
                  <tr key={customer.id} className="border-t border-[#eef2f5] hover:bg-[#fbfdfe]">
                    <td className="whitespace-nowrap px-5 py-4 font-bold text-[#102b46]">{customer.name}</td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{customer.phone}</td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{customer.email || "-"}</td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{customer.idNumber || "-"}</td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{new Date(customer.createdAt).toLocaleDateString("ar-SA")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader><DialogTitle>إضافة عميل جديد</DialogTitle></DialogHeader>
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            createCustomer.mutate({
              name: formData.get("name") as string,
              phone: formData.get("phone") as string,
              email: formData.get("email") as string,
              idNumber: formData.get("idNumber") as string,
              address: formData.get("address") as string,
              notes: formData.get("notes") as string,
            });
          }} className="space-y-4">
            <label className="space-y-1 text-[11px] font-bold">
              <span>اسم العميل *</span>
              <Input name="name" required />
            </label>
            <label className="space-y-1 text-[11px] font-bold">
              <span>رقم الهاتف *</span>
              <Input name="phone" required />
            </label>
            <label className="space-y-1 text-[11px] font-bold">
              <span>البريد الإلكتروني</span>
              <Input name="email" type="email" />
            </label>
            <label className="space-y-1 text-[11px] font-bold">
              <span>رقم الهوية / السجل</span>
              <Input name="idNumber" />
            </label>
            <Button type="submit" disabled={createCustomer.isPending} className="w-full bg-[#0c3958]">
              {createCustomer.isPending ? "جاري الحفظ..." : "حفظ بيانات العميل"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
type PurchaseFormState = {
  vehicleName: string;
  vin: string;
  vehicleYear: string;
  supplierName: string;
  sourceType: "supplier" | "auction" | "trade_in" | "other";
  purchaseDate: string;
  purchaseCost: string;
  preparationCost: string;
  transportCost: string;
  registrationCost: string;
  paymentStatus: "unpaid" | "partial" | "paid";
  status: "draft" | "received" | "preparing" | "ready" | "cancelled";
  branchName: string;
  notes: string;
};

const emptyPurchaseForm = (): PurchaseFormState => ({
  vehicleName: "",
  vin: "",
  vehicleYear: String(new Date().getFullYear()),
  supplierName: "",
  sourceType: "supplier",
  purchaseDate: new Date().toISOString().slice(0, 10),
  purchaseCost: "",
  preparationCost: "0",
  transportCost: "0",
  registrationCost: "0",
  paymentStatus: "unpaid",
  status: "received",
  branchName: "الفرع الرئيسي",
  notes: "",
});

function Purchases() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [paymentFilter, setPaymentFilter] = useState("all");
  const [branchFilter, setBranchFilter] = useState("all");
  const [form, setForm] = useState<PurchaseFormState>(() => emptyPurchaseForm());
  const purchasesQuery = trpc.purchases.list.useQuery();
  const utils = trpc.useUtils();
  const createPurchase = trpc.purchases.create.useMutation({
    onSuccess: async () => {
      await Promise.all([utils.purchases.list.invalidate(), utils.vehicles.list.invalidate(), utils.reports.invalidate()]);
      setOpen(false);
      setForm(emptyPurchaseForm());
      toast.success("تم حفظ فاتورة الشراء وتحديث السجل");
    },
    onError: (error) => toast.error(error.message || "تعذر حفظ فاتورة الشراء"),
  });

  const rows = filterPurchases(purchasesQuery.data ?? [], { query, paymentStatus: paymentFilter, branchName: branchFilter });
  const { totalCost, unpaidCount } = summarizePurchases(rows);
  const formTotal = [form.purchaseCost, form.preparationCost, form.transportCost, form.registrationCost].reduce((sum, value) => sum + (Number(value) || 0), 0);

  const setField = <K extends keyof PurchaseFormState>(field: K, value: PurchaseFormState[K]) => setForm((current) => ({ ...current, [field]: value }));
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    createPurchase.mutate({
      invoiceNumber: `PUR-${Date.now().toString().slice(-6)}`,
      vehicleName: form.vehicleName,
      vin: form.vin,
      vehicleYear: Number(form.vehicleYear),
      supplierName: form.supplierName,
      purchaseDate: new Date(form.purchaseDate),
      purchaseCost: Number(form.purchaseCost),
      preparationCost: Number(form.preparationCost) || 0,
      transportCost: Number(form.transportCost) || 0,
      registrationCost: Number(form.registrationCost) || 0,
      paymentStatus: form.paymentStatus,
      status: form.status === "draft" ? "received" : form.status,
      branchName: form.branchName,
      notes: form.notes,
    });
  };
  const paymentLabel: Record<string, string> = { unpaid: "غير مدفوعة", partial: "مدفوعة جزئيًا", paid: "مدفوعة" };

  return <div className="space-y-5">
    <div className="grid gap-4 md:grid-cols-2">
      {[["إجمالي تكلفة المشتريات", `${totalCost.toLocaleString()} ر.س`, "قيمة السجلات الظاهرة", "bg-[#eaf2fa] text-[#4b8fba]"], ["دفعات تحتاج متابعة", String(unpaidCount), "غير مكتملة السداد", "bg-[#fdebed] text-[#e66b71]"]].map(([label, value, note, tone]) => <div key={label} className="rounded-2xl border border-[#e2eaf0] bg-white p-5 shadow-[0_8px_25px_rgba(22,55,78,.04)]"><div className="flex items-start justify-between"><div><p className="text-xs font-semibold text-[#718796]">{label}</p><p className="mt-3 text-xl font-extrabold text-[#09233e]">{value}</p><p className="mt-2 text-[10px] text-[#81939f]">{note}</p></div><div className={`rounded-xl p-3 ${tone}`}><ShoppingCart className="h-5 w-5" /></div></div></div>)}
    </div>
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#e2eaf0] bg-white p-5"><div><h2 className="text-sm font-bold">فواتير المشتريات</h2><p className="mt-1 text-[10px] text-[#81939f]">إدارة فواتير شراء السيارات (Master) وتفاصيل التكاليف المرتبطة.</p></div><Button onClick={() => setOpen(true)} className="gap-2 rounded-xl bg-[#0c3958] text-xs hover:bg-[#09233e]"><Plus className="h-4 w-4" />إنشاء فاتورة شراء</Button></div>
    <div className="overflow-hidden rounded-2xl border border-[#e2eaf0] bg-white"><div className="border-b border-[#eef2f5] p-4"><div className="flex flex-wrap items-center gap-2"><div className="relative min-w-[250px] flex-1"><Search className="absolute right-3 top-3 h-4 w-4 text-[#8ca1af]" /><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث برقم الفاتورة أو المورد..." className="h-10 rounded-xl bg-[#f8fafc] pr-10 text-xs" /></div><select aria-label="حالة السداد" value={paymentFilter} onChange={(event) => setPaymentFilter(event.target.value)} className="h-10 rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-[11px] text-[#587186]"><option value="all">كل حالات السداد</option><option value="unpaid">غير مدفوعة</option><option value="partial">مدفوعة جزئيًا</option><option value="paid">مدفوعة</option></select><select aria-label="الفرع" value={branchFilter} onChange={(event) => setBranchFilter(event.target.value)} className="h-10 rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-[11px] text-[#587186]"><option value="all">كل الفروع</option><option value="الفرع الرئيسي">الفرع الرئيسي</option><option value="فرع الشمال">فرع الشمال</option><option value="فرع المطار">فرع المطار</option></select></div></div>{purchasesQuery.isError ? <QueryFailure retry={() => purchasesQuery.refetch()} /> : purchasesQuery.isLoading ? <div className="flex min-h-52 items-center justify-center text-xs text-[#81939f]">جاري تحميل الفواتير...</div> : rows.length === 0 ? <div className="flex min-h-52 flex-col items-center justify-center text-center"><div className="rounded-2xl bg-[#eaf5f4] p-4 text-[#159d99]"><ShoppingCart className="h-7 w-7" /></div><h3 className="mt-4 text-sm font-bold text-[#09233e]">لا توجد فواتير بعد</h3><Button onClick={() => setOpen(true)} className="mt-4 rounded-xl bg-[#0c3958] text-xs">إنشاء أول فاتورة</Button></div> : <div className="overflow-x-auto"><table className="w-full text-right text-xs"><thead className="bg-[#f8fafc] text-[10px] text-[#718796]"><tr>{["رقم الفاتورة", "المورد", "تاريخ الشراء", "القيمة الإجمالية", "السداد", "الفرع"].map((header) => <th key={header} className="whitespace-nowrap px-5 py-4 font-semibold">{header}</th>)}</tr></thead><tbody>{rows.map((purchase) => <tr key={purchase.id} className="border-t border-[#eef2f5] hover:bg-[#fbfdfe]"><td className="whitespace-nowrap px-5 py-4 font-bold text-[#102b46]">{purchase.invoiceNumber}</td><td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{purchase.supplierName}</td><td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{new Date(purchase.purchaseDate).toLocaleDateString("ar-SA")}</td><td className="whitespace-nowrap px-5 py-4 font-extrabold text-[#159d99]">{purchase.totalAmount.toLocaleString()} ر.س</td><td className="whitespace-nowrap px-5 py-4"><Badge className={`text-[9px] ${purchase.paymentStatus === "paid" ? "bg-[#e6f5ef] text-[#168c5d]" : "bg-[#fff4d9] text-[#a87518]"}`}>{paymentLabel[purchase.paymentStatus]}</Badge></td><td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{purchase.branchName}</td></tr>)}</tbody></table></div>}</div>
    <Dialog open={open} onOpenChange={setOpen}><DialogContent dir="rtl" className="max-h-[92vh] max-w-3xl overflow-y-auto"><DialogHeader><DialogTitle>إنشاء فاتورة شراء جديدة</DialogTitle></DialogHeader><form onSubmit={submit} className="space-y-5"><div className="rounded-2xl bg-[#f8fafc] p-4"><p className="mb-3 text-xs font-bold text-[#102b46]">بيانات السيارة والمصدر</p><div className="grid gap-3 md:grid-cols-2"><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>اسم السيارة *</span><Input required value={form.vehicleName} onChange={(event) => setField("vehicleName", event.target.value)} placeholder="مثال: لكزس GX 550" /></label><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>رقم الهيكل VIN</span><Input value={form.vin} onChange={(event) => setField("vin", event.target.value)} placeholder="اختياري" /></label><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>سنة الصنع *</span><Input required type="number" min="1900" max="2100" value={form.vehicleYear} onChange={(event) => setField("vehicleYear", event.target.value)} /></label><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>المورد *</span><Input required value={form.supplierName} onChange={(event) => setField("supplierName", event.target.value)} placeholder="شركة أو مزاد أو عميل" /></label><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>تاريخ الشراء *</span><Input required type="date" value={form.purchaseDate} onChange={(event) => setField("purchaseDate", event.target.value)} /></label></div></div><div className="rounded-2xl bg-[#f8fafc] p-4"><p className="mb-3 text-xs font-bold text-[#102b46]">تفاصيل التكلفة</p><div className="grid gap-3 md:grid-cols-4"><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>سعر الشراء *</span><Input required min="0" type="number" value={form.purchaseCost} onChange={(event) => setField("purchaseCost", event.target.value)} /></label><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>التجهيز</span><Input min="0" type="number" value={form.preparationCost} onChange={(event) => setField("preparationCost", event.target.value)} /></label><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>النقل</span><Input min="0" type="number" value={form.transportCost} onChange={(event) => setField("transportCost", event.target.value)} /></label><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>التسجيل</span><Input min="0" type="number" value={form.registrationCost} onChange={(event) => setField("registrationCost", event.target.value)} /></label></div><div className="mt-4 flex items-center justify-between rounded-xl bg-white px-4 py-3"><span className="text-xs font-semibold text-[#718796]">إجمالي الفاتورة المحسوب</span><strong className="text-lg text-[#159d99]">{formTotal.toLocaleString()} ر.س</strong></div></div><div className="grid gap-3 md:grid-cols-3"><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>حالة السداد</span><select value={form.paymentStatus} onChange={(event) => setField("paymentStatus", event.target.value as PurchaseFormState["paymentStatus"])} className="h-10 w-full rounded-xl border border-[#e3ebf0] bg-white px-3 text-xs"><option value="unpaid">غير مدفوعة</option><option value="partial">مدفوعة جزئيًا</option><option value="paid">مدفوعة</option></select></label><label className="space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>الفرع</span><select value={form.branchName} onChange={(event) => setField("branchName", event.target.value)} className="h-10 w-full rounded-xl border border-[#e3ebf0] bg-white px-3 text-xs"><option>الفرع الرئيسي</option><option>فرع الشمال</option><option>فرع المطار</option></select></label></div><label className="block space-y-1.5 text-[11px] font-semibold text-[#587186]"><span>ملاحظات</span><textarea value={form.notes} onChange={(event) => setField("notes", event.target.value)} rows={3} className="w-full rounded-xl border border-[#e3ebf0] bg-white px-3 py-2 text-xs outline-none focus:border-[#159d99]" placeholder="تفاصيل إضافية للفاتورة" /></label><div className="flex justify-end gap-2 border-t border-[#eef2f5] pt-4"><Button type="button" variant="outline" onClick={() => setOpen(false)} className="rounded-xl text-xs">إلغاء</Button><Button type="submit" disabled={createPurchase.isPending} className="gap-2 rounded-xl bg-[#0c3958] text-xs hover:bg-[#09233e]">{createPurchase.isPending ? "جاري الحفظ..." : "حفظ الفاتورة"}</Button></div></form></DialogContent></Dialog>
  </div>;
}
function Expenses() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [branchFilter, setBranchFilter] = useState("all");
  
  const expensesQuery = trpc.expenses.list.useQuery();
  const utils = trpc.useUtils();

  const createExpense = trpc.expenses.create.useMutation({
    onSuccess: async () => {
      await utils.expenses.list.invalidate();
      setOpen(false);
      toast.success("تم تسجيل المصروف بنجاح");
    },
    onError: (error) => toast.error(error.message),
  });

  const rows = filterExpenses(expensesQuery.data ?? [], { query, category: categoryFilter, branch: branchFilter });
  const { totalAmount, byCategory } = summarizeExpenses(rows);

  const categoryLabel: Record<string, string> = { 
    rent: "إيجار", utilities: "مرافق", salaries: "رواتب", 
    marketing: "تسويق", maintenance: "صيانة", other: "أخرى" 
  };

  return (
    <div className="space-y-5">
      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-[#e2eaf0] bg-white p-5 shadow-[0_8px_25px_rgba(22,55,78,.04)]">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold text-[#718796]">إجمالي المصروفات</p>
              <p className="mt-3 text-xl font-extrabold text-[#09233e]">{totalAmount.toLocaleString()} ر.س</p>
            </div>
            <div className="rounded-xl bg-[#fdebed] text-[#e66b71] p-3"><Wrench className="h-5 w-5" /></div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-[#e2eaf0] bg-white p-5">
        <div>
          <h2 className="text-sm font-bold">المصروفات والتجهيز</h2>
          <p className="mt-1 text-[10px] text-[#81939f]">تتبع المصاريف التشغيلية والإدارية للمعرض.</p>
        </div>
        <Button onClick={() => setOpen(true)} className="gap-2 rounded-xl bg-[#0c3958] text-xs hover:bg-[#09233e]">
          <Plus className="h-4 w-4" />إضافة مصروف
        </Button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-[#e2eaf0] bg-white">
        <div className="border-b border-[#eef2f5] p-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-[250px] flex-1">
              <Search className="absolute right-3 top-3 h-4 w-4 text-[#8ca1af]" />
              <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="بحث في المصروفات..." className="h-10 rounded-xl bg-[#f8fafc] pr-10 text-xs" />
            </div>
            <select aria-label="الفئة" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} className="h-10 rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-[11px] text-[#587186]">
              <option value="all">كل الفئات</option>
              {Object.entries(categoryLabel).map(([val, lab]) => <option key={val} value={val}>{lab}</option>)}
            </select>
          </div>
        </div>

        {expensesQuery.isError ? <QueryFailure retry={() => expensesQuery.refetch()} /> : expensesQuery.isLoading ? (
          <div className="flex min-h-52 items-center justify-center text-xs text-[#81939f]">جاري تحميل المصروفات...</div>
        ) : rows.length === 0 ? (
          <div className="flex min-h-52 flex-col items-center justify-center text-center">
            <div className="rounded-2xl bg-[#fdebed] p-4 text-[#e66b71]"><Wrench className="h-7 w-7" /></div>
            <h3 className="mt-4 text-sm font-bold text-[#09233e]">لا توجد مصروفات مسجلة</h3>
            <Button onClick={() => setOpen(true)} className="mt-4 rounded-xl bg-[#0c3958] text-xs">إضافة أول مصروف</Button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead className="bg-[#f8fafc] text-[10px] text-[#718796]">
                <tr>
                  {["البيان", "الفئة", "القيمة", "التاريخ", "الفرع"].map((header) => (
                    <th key={header} className="whitespace-nowrap px-5 py-4 font-semibold">{header}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((expense) => (
                  <tr key={expense.id} className="border-t border-[#eef2f5] hover:bg-[#fbfdfe]">
                    <td className="whitespace-nowrap px-5 py-4 font-bold text-[#102b46]">{expense.title}</td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{categoryLabel[expense.category]}</td>
                    <td className="whitespace-nowrap px-5 py-4 font-extrabold text-[#e66b71]">{expense.amount.toLocaleString()} ر.س</td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{new Date(expense.expenseDate).toLocaleDateString("ar-SA")}</td>
                    <td className="whitespace-nowrap px-5 py-4 text-[#6e8492]">{expense.branch}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader><DialogTitle>إضافة مصروف جديد</DialogTitle></DialogHeader>
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            createExpense.mutate({
              title: formData.get("title") as string,
              amount: Number(formData.get("amount")),
              category: formData.get("category") as any,
              branch: formData.get("branch") as string,
              notes: formData.get("notes") as string,
            });
          }} className="space-y-4">
            <label className="space-y-1 text-[11px] font-bold">
              <span>البيان / الوصف *</span>
              <Input name="title" required />
            </label>
            <label className="space-y-1 text-[11px] font-bold">
              <span>القيمة *</span>
              <Input name="amount" type="number" required />
            </label>
            <label className="space-y-1 text-[11px] font-bold">
              <span>الفئة *</span>
              <select name="category" required className="h-10 w-full rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-xs">
                {Object.entries(categoryLabel).map(([val, lab]) => <option key={val} value={val}>{lab}</option>)}
              </select>
            </label>
            <label className="space-y-1 text-[11px] font-bold">
              <span>الفرع</span>
              <select name="branch" className="h-10 w-full rounded-xl border border-[#e3ebf0] bg-[#f8fafc] px-3 text-xs">
                <option value="الفرع الرئيسي">الفرع الرئيسي</option>
                <option value="فرع الشمال">فرع الشمال</option>
                <option value="فرع المطار">فرع المطار</option>
              </select>
            </label>
            <Button type="submit" disabled={createExpense.isPending} className="w-full bg-[#0c3958]">
              {createExpense.isPending ? "جاري الحفظ..." : "حفظ المصروف"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
function Reports() {
  const summaryQuery = trpc.reports.getSummary.useQuery();
  if (summaryQuery.isError) return <QueryFailure retry={() => summaryQuery.refetch()} />;
  if (summaryQuery.isLoading) return <p role="status">جاري تحميل التقرير...</p>;
  
  const data = summaryQuery.data;

  return (
    <div className="space-y-5">
      <div className="grid gap-4 md:grid-cols-4">
        {[
          ["إجمالي المبيعات", `${(data?.totalSales ?? 0).toLocaleString()} ر.س`, "قيمة العقود المبرمة", "bg-[#eaf5f4] text-[#159d99]"],
          ["قيمة المخزون", `${(data?.inventoryValue ?? 0).toLocaleString()} ر.س`, "تكلفة الشراء الحالية", "bg-[#eaf2fa] text-[#4b8fba]"],
          ["إجمالي المصروفات", `${(data?.totalExpenses ?? 0).toLocaleString()} ر.س`, "تكاليف تشغيلية وإدارية", "bg-[#fdebed] text-[#e66b71]"],
          ["فرق المبيعات والتكاليف", `${((data?.totalSales ?? 0) - (data?.totalPurchases ?? 0) - (data?.totalExpenses ?? 0)).toLocaleString()} ر.س`, "ليس رصيداً نقدياً أو ربحاً صافياً", "bg-[#fff4d9] text-[#c9972f]"]
        ].map(([label, value, note, tone]) => (
          <div key={label} className="rounded-2xl border border-[#e2eaf0] bg-white p-5 shadow-[0_8px_25px_rgba(22,55,78,.04)]">
            <p className="text-xs font-semibold text-[#718796]">{label}</p>
            <p className="mt-3 text-xl font-extrabold text-[#09233e]">{value}</p>
            <p className="mt-2 text-[10px] text-[#81939f]">{note}</p>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border bg-white p-6 text-sm leading-7 text-slate-600">يتطلب حساب الربح الصافي والتدفق النقدي ربط تكلفة السيارة المباعة والتحصيلات والمدفوعات الفعلية.</div>
    </div>
  );
}
function SettingsPanel({ logo, onUpload, onRemove }: { logo: string | null; onUpload: () => void; onRemove: () => void }) { return <section className="rounded-2xl border bg-white p-6"><h2 className="text-lg font-bold">هوية النظام</h2><p className="mt-2 text-sm text-slate-500">تخصيص الشعار على هذا المتصفح.</p><div className="mt-5 flex flex-wrap items-center gap-4"><LogoMark logo={logo} /><Button onClick={onUpload} variant="outline">رفع أو استبدال الشعار</Button>{logo && <Button onClick={onRemove} variant="outline">إزالة الشعار</Button>}</div><p className="mt-6 rounded-xl bg-slate-50 p-4 text-sm leading-7 text-slate-600">إدارة المستخدمين والصلاحيات تتطلب مطابقة حسابات Oracle القديمة وأدوارها. لم يتم ربط هذه الإدارة بعد.</p></section>; }
