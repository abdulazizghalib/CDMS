import { DealerBalanceSheetResult } from "./DealerBalanceSheetResult";
import { useState } from "react";
import { Scale, Search } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { money } from "@/lib/dealerPresentation";
import { journalReportInput } from "@shared/accountStatement";
export function DealerTrialBalance({
  income = false,
  balanceSheet = false,
}: {
  income?: boolean;
  balanceSheet?: boolean;
}) {
  const title = balanceSheet
    ? "الميزانية"
    : income
      ? "قائمة الدخل"
      : "ميزان المراجعة";
  const today = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Riyadh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
  const [date1, setDate1] = useState(today.slice(0, 7) + "-01"),
    [date2, setDate2] = useState(today),
    [error, setError] = useState("");
  const [request, setRequest] = useState<{ date1: string; date2: string }>({
    date1: today.slice(0, 7) + "-01",
    date2: today,
  });
  const trialQuery = trpc.oracleOperations.trialBalance.useQuery(
    request ?? { date1: today, date2: today },
    { enabled: !income && !balanceSheet && !!request, retry: false }
  );
  const incomeQuery = trpc.oracleOperations.incomeStatement.useQuery(request, {
    enabled: income && !balanceSheet,
    retry: false,
  });
  const balanceQuery = trpc.oracleOperations.balanceSheet.useQuery(request, {
    enabled: balanceSheet,
    retry: false,
  });
  const query = balanceSheet ? balanceQuery : income ? incomeQuery : trialQuery;
  const data = query.data;
  return (
    <div className="space-y-5" dir="rtl">
      <section className="oracle-panel p-6">
        <h2 className="font-bold text-xl flex items-center gap-2">
          <Scale className="text-amber-600" />
          {title}
        </h2>
        <p className="text-sm text-slate-500 mt-2 mb-5">
          {balanceSheet
            ? "حركات حسابات الميزانية الرئيسية من 1000 إلى 1004 خلال الفترة المحددة."
            : income
              ? "حركات حسابات قائمة الدخل الرئيسية 1005 و1006 خلال الفترة المحددة."
              : "تجميع حركات الفترة حسب الحساب الرئيسي والفرعي والتفصيلي."}
        </p>
        <form
          aria-label={"فترة " + title}
          className="grid sm:grid-cols-3 gap-4 items-end"
          onSubmit={e => {
            e.preventDefault();
            const parsed = journalReportInput.safeParse({ date1, date2 });
            if (!parsed.success) {
              setError(parsed.error.issues[0].message);
              return;
            }
            setError("");
            setRequest(parsed.data);
            if (JSON.stringify(request) === JSON.stringify(parsed.data))
              void query.refetch();
          }}
        >
          <label className="block space-y-2">
            من تاريخ
            <Input
              type="date"
              required
              dir="ltr"
              value={date1}
              onChange={e => setDate1(e.target.value)}
            />
          </label>
          <label className="block space-y-2">
            إلى تاريخ
            <Input
              type="date"
              required
              dir="ltr"
              value={date2}
              onChange={e => setDate2(e.target.value)}
            />
          </label>
          <Button disabled={query.isFetching}>
            <Search size={16} />
            {query.isFetching ? "جارٍ التحميل…" : "عرض " + title}
          </Button>
        </form>
        {(error || query.isError) && (
          <p role="alert" className="mt-4 text-red-600">
            {error || query.error?.message}
          </p>
        )}
      </section>
      {balanceSheet && data && !query.isError && (
        <DealerBalanceSheetResult data={data} />
      )}
      {data && !query.isError && !balanceSheet && (
        <>
          <section className="oracle-panel p-5">
            <h3 className="font-bold">
              الفترة: {data.date1} إلى {data.date2}
            </h3>
            <h4 className="font-bold mt-5 text-amber-800">الإجمالي والصافي</h4>
            <div className="grid sm:grid-cols-4 gap-4 mt-4">
              {[
                ["عدد صفوف الحسابات", data.lines.length],
                ["إجمالي المدين", data.debit],
                ["إجمالي الدائن", data.credit],
                ["الصافي (دائن − مدين)", data.balance],
              ].map(([label, v], i) => (
                <div key={String(label)} className="rounded-xl bg-slate-50 p-4">
                  <small className="text-slate-500">{label}</small>
                  <strong className="block text-lg mt-2">
                    {i === 0 ? String(v) : money(v)}
                  </strong>
                </div>
              ))}
            </div>
            <p className="text-xs text-slate-500 mt-3">
              الرصيد = الدائن − المدين. الموجب دائن والسالب مدين. يشمل التقرير
              حركات الفترة المحددة فقط.
            </p>
          </section>
          <section className="oracle-panel overflow-auto max-h-[65vh]">
            <table className="w-full text-sm text-right">
              <thead className="sticky top-0 bg-slate-100">
                <tr>
                  {[
                    "#",
                    "رقم الرئيسي",
                    "الحساب الرئيسي",
                    "رقم الفرعي",
                    "الحساب الفرعي",
                    "رقم التفصيلي",
                    "الحساب التفصيلي",
                    "مدين",
                    "دائن",
                    "الرصيد",
                  ].map(h => (
                    <th key={h} className="p-3 whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.lines.map((r, i) => (
                  <tr key={i} className="border-b odd:bg-slate-50">
                    <td className="p-3">{i + 1}</td>
                    <td className="p-3">{r.AL_MAIN_NUM ?? "—"}</td>
                    <td className="p-3 min-w-32">{r.AC_NAM ?? "—"}</td>
                    <td className="p-3">{r.AL_BAR_NUM ?? "—"}</td>
                    <td className="p-3 min-w-32">{r.BRANSHACNAM ?? "—"}</td>
                    <td className="p-3">{r.AL_ACC_NO ?? "—"}</td>
                    <td className="p-3 min-w-40">{r.AL_ACC_NAME ?? "—"}</td>
                    <td className="p-3 whitespace-nowrap">{money(r.DEPIT)}</td>
                    <td className="p-3 whitespace-nowrap">{money(r.CREDIT)}</td>
                    <td className="p-3 whitespace-nowrap font-semibold">
                      {money(r.BALANCE)}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-100 font-bold">
                <tr>
                  <td colSpan={7} className="p-3">
                    الإجمالي
                  </td>
                  <td className="p-3 whitespace-nowrap">{money(data.debit)}</td>
                  <td className="p-3 whitespace-nowrap">
                    {money(data.credit)}
                  </td>
                  <td className="p-3 whitespace-nowrap">
                    {money(data.balance)}
                  </td>
                </tr>
              </tfoot>
            </table>
            {data.lines.length === 0 && (
              <p className="text-center py-8 text-slate-500">
                لا توجد حركات خلال الفترة المحددة
              </p>
            )}
          </section>
          <section
            aria-label={
              balanceSheet
                ? "الإجمالي والصافي للميزانية"
                : income
                  ? "الإجمالي والصافي لقائمة الدخل"
                  : "الإجمالي والصافي لميزان المراجعة"
            }
            className="oracle-panel border-amber-200 bg-amber-50 p-5"
          >
            <h3 className="font-bold text-amber-900 mb-4">الإجمالي والصافي</h3>
            <div className="grid sm:grid-cols-3 gap-4">
              <div>
                <small>إجمالي المدين</small>
                <strong className="block mt-2 text-lg">
                  {money(data.debit)}
                </strong>
              </div>
              <div>
                <small>إجمالي الدائن</small>
                <strong className="block mt-2 text-lg">
                  {money(data.credit)}
                </strong>
              </div>
              <div>
                <small>الصافي (إجمالي الدائن − إجمالي المدين)</small>
                <strong className="block mt-2 text-lg">
                  {money(data.balance)}
                </strong>
                <span className="text-xs">
                  {data.balance === 0
                    ? "متوازن"
                    : data.balance > 0
                      ? "دائن"
                      : "مدين"}
                </span>
              </div>
            </div>
          </section>
        </>
      )}
      {!request && (
        <p className="oracle-panel p-12 text-center text-slate-500">
          حدد الفترة ثم اضغط «عرض ميزان المراجعة»
        </p>
      )}
    </div>
  );
}
