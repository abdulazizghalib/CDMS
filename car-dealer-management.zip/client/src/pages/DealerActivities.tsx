import { useState } from "react";
import { CalendarDays, Plus, Search, Check, X, Car } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import type { NavigateDealer } from "@/lib/dealerPresentation";
const labels = {
  active: "نشط",
  completed: "مكتمل",
  cancelled: "ملغي",
  expired: "انتهى الحجز",
};
const dateLabel = (v: string) =>
  new Intl.DateTimeFormat("ar-SA", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Asia/Riyadh",
    calendar: "gregory",
  }).format(new Date(v + ":00+03:00"));
export function DealerActivities({
  kind,
  initialVehicleId,
}: {
  kind: "reservation" | "followup";
  initialVehicleId?: number;
}) {
  const [open, setOpen] = useState(Boolean(initialVehicleId));
  const [customer, setCustomer] = useState("");
  const [phone, setPhone] = useState("");
  const [vehicle, setVehicle] = useState(
    initialVehicleId ? String(initialVehicleId) : ""
  );
  const [scheduled, setScheduled] = useState("");
  const [notes, setNotes] = useState("");
  const [search, setSearch] = useState("");
  const [carSearch, setCarSearch] = useState("");
  const [status, setStatus] = useState("active");
  const [closing, setClosing] = useState<{
    id: number;
    status: "completed" | "cancelled";
  } | null>(null);
  const q = trpc.oracleOperations.activities.useQuery(undefined, {
    retry: false,
    refetchInterval: 60000,
  });
  const actor = trpc.oracleOperations.session.useQuery().data?.actor;
  const canWrite = actor?.ROLE === "admin" || actor?.ROLE === "editor";
  const cars = trpc.oracleOperations.activityVehicles.useQuery(kind, {
    enabled: open && canWrite,
    retry: false,
  });
  const utils = trpc.useUtils();
  const refresh = () => {
    void utils.oracleOperations.activities.invalidate();
    void utils.oracleOperations.activityVehicles.invalidate();
    void utils.oracleOperations.salesInvoiceOptions.invalidate();
  };
  const save = trpc.oracleOperations.createActivity.useMutation({
    onSuccess() {
      refresh();
      setOpen(false);
      setCustomer("");
      setPhone("");
      setVehicle("");
      setScheduled("");
      setNotes("");
      toast.success(
        kind === "reservation" ? "تم حفظ الحجز" : "تم حفظ موعد المتابعة"
      );
    },
    onError(e) {
      toast.error(e.message);
      refresh();
    },
  });
  const finish = trpc.oracleOperations.finishActivity.useMutation({
    onSuccess() {
      refresh();
      setClosing(null);
      toast.success("تم تحديث الحالة");
    },
    onError(e) {
      toast.error(e.message);
      refresh();
    },
  });
  const rows = (q.data ?? [])
    .filter(
      r =>
        r.KIND === kind &&
        (status === "all" || r.STATUS === status) &&
        [r.CUSTOMER, r.PHONE, r.CAR, r.MODEL, r.PLATE]
          .join(" ")
          .toLowerCase()
          .includes(search.toLowerCase())
    )
    .sort((a, b) => a.SCHEDULED_AT.localeCompare(b.SCHEDULED_AT));
  const reservation = kind === "reservation";
  return (
    <section className="oracle-panel p-5 space-y-5" dir="rtl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2">
            <CalendarDays className="text-amber-600" />
            {reservation ? "حجوزات السيارات" : "مواعيد المتابعة"}
          </h2>
          <p className="text-sm text-slate-500 mt-2">
            {reservation
              ? "تابع حجوزات العملاء ومدة صلاحيتها"
              : "نظم اتصالات العملاء والزيارات القادمة"}{" "}
            · جميع المواعيد بتوقيت الرياض
          </p>
        </div>
        {canWrite && (
          <Button onClick={() => setOpen(true)}>
            <Plus size={16} />
            {reservation ? "حجز سيارة" : "إضافة موعد"}
          </Button>
        )}
      </div>
      <div className="flex flex-wrap gap-3">
        <div className="flex items-center gap-2 flex-1 min-w-48">
          <Search size={18} />
          <Input
            aria-label="بحث الحجوزات والمواعيد"
            placeholder="بحث بالعميل أو الهاتف أو السيارة أو اللوحة"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <select
          aria-label="تصفية الحالة"
          className="border rounded-md px-3 py-2 bg-white"
          value={status}
          onChange={e => setStatus(e.target.value)}
        >
          <option value="active">النشطة</option>
          <option value="all">جميع الحالات</option>
          <option value="completed">المكتملة</option>
          <option value="cancelled">الملغاة</option>
          {reservation && <option value="expired">المنتهية</option>}
        </select>
        <Button variant="outline" onClick={() => q.refetch()}>
          تحديث
        </Button>
      </div>
      {q.isError ? (
        <p role="alert" className="text-red-600">
          {q.error.message}
        </p>
      ) : q.isLoading ? (
        <p>جارٍ تحميل البيانات…</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-right">
            <thead className="bg-slate-50">
              <tr>
                {[
                  "#",
                  "العميل",
                  "السيارة",
                  reservation ? "انتهاء الحجز" : "الموعد",
                  "الحالة",
                  "الملاحظات",
                  "الإجراءات",
                ].map(t => (
                  <th key={t} className="p-3 whitespace-nowrap">
                    {t}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.ID} className="border-b">
                  <td className="p-3">{i + 1}</td>
                  <td className="p-3">
                    <strong>{r.CUSTOMER}</strong>
                    <div dir="ltr" className="text-right text-slate-500">
                      {r.PHONE}
                    </div>
                  </td>
                  <td className="p-3">
                    {r.CAR ? (
                      <>
                        {r.CAR} {r.MODEL}
                        <div className="text-slate-500">{r.PLATE}</div>
                      </>
                    ) : (
                      "—"
                    )}
                  </td>
                  <td className="p-3 whitespace-nowrap">
                    {dateLabel(r.SCHEDULED_AT)}
                    {!reservation &&
                      r.STATUS === "active" &&
                      new Date(r.SCHEDULED_AT + ":00+03:00").getTime() <
                        Date.now() && (
                        <div className="text-red-600">متأخر ويحتاج متابعة</div>
                      )}
                  </td>
                  <td className="p-3">
                    <span
                      className={
                        "rounded-full px-3 py-1 text-xs " +
                        (r.STATUS === "active"
                          ? "bg-amber-100 text-amber-800"
                          : "bg-slate-100 text-slate-600")
                      }
                    >
                      {labels[r.STATUS]}
                    </span>
                  </td>
                  <td className="p-3 max-w-60 whitespace-pre-wrap break-words">
                    {r.NOTES || "—"}
                    <small className="block text-slate-400">
                      {r.CREATED_BY}
                    </small>
                  </td>
                  <td className="p-3">
                    {canWrite && r.STATUS === "active" && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            setClosing({ id: r.ID, status: "completed" })
                          }
                        >
                          <Check size={14} />
                          إكمال
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            setClosing({ id: r.ID, status: "cancelled" })
                          }
                        >
                          <X size={14} />
                          إلغاء
                        </Button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {rows.length === 0 && (
            <p className="py-12 text-center text-slate-500">
              لا توجد سجلات مطابقة. {canWrite ? "أضف سجلاً جديدًا للبدء." : ""}
            </p>
          )}
        </div>
      )}
      <Dialog
        open={open && canWrite}
        onOpenChange={v => {
          if (!save.isPending) setOpen(v);
        }}
      >
        <DialogContent
          className="sm:max-w-xl max-h-[90vh] overflow-y-auto"
          dir="rtl"
        >
          <DialogHeader className="text-right sm:text-right">
            <DialogTitle>
              {reservation ? "حجز سيارة" : "موعد متابعة جديد"}
            </DialogTitle>
            <DialogDescription>
              {reservation
                ? "اختر السيارة وحدد العميل ووقت انتهاء الحجز. الحجز يمنع اختيار السيارة في فاتورة المبيعات حتى إكماله أو إلغائه أو انتهاء مدته، ولا ينشئ سند قبض."
                : "حدد العميل ووقت الاتصال أو الزيارة. ربط السيارة اختياري."}
            </DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={e => {
              e.preventDefault();
              save.mutate({
                kind,
                customer,
                phone,
                vehicleId: vehicle ? Number(vehicle) : null,
                scheduledAt: scheduled,
                notes,
              });
            }}
          >
            <div className="grid sm:grid-cols-2 gap-4">
              <label className="space-y-2 block">
                اسم العميل
                <Input
                  required
                  minLength={2}
                  maxLength={100}
                  value={customer}
                  onChange={e => setCustomer(e.target.value)}
                />
              </label>
              <label className="space-y-2 block">
                رقم الهاتف
                <Input
                  required
                  minLength={5}
                  maxLength={30}
                  dir="ltr"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                />
              </label>
            </div>
            <label className="space-y-2 block">
              {reservation ? "انتهاء الحجز" : "تاريخ ووقت المتابعة"} (الرياض)
              <Input
                required
                type="datetime-local"
                dir="ltr"
                value={scheduled}
                onChange={e => setScheduled(e.target.value)}
              />
            </label>
            <div className="bg-slate-50 rounded-xl p-4 space-y-3">
              <label className="flex items-center gap-2">
                <Car size={17} />
                {reservation
                  ? "السيارة من المخزون المتاح"
                  : "السيارة (اختياري)"}
              </label>
              <Input
                aria-label="بحث السيارة"
                placeholder="بحث باللوحة أو الموديل أو السنة"
                value={carSearch}
                onChange={e => setCarSearch(e.target.value)}
              />
              <select
                aria-label="اختيار السيارة"
                required={reservation}
                disabled={cars.isLoading || cars.isError}
                className="w-full border rounded-md p-2 bg-white"
                value={vehicle}
                onChange={e => setVehicle(e.target.value)}
              >
                <option value="">
                  {cars.isLoading ? "جارٍ تحميل السيارات…" : "اختر السيارة"}
                </option>
                {cars.data
                  ?.filter(
                    v =>
                      String(v.ID) === vehicle ||
                      [v.CAR, v.MODEL, v.PLATE]
                        .join(" ")
                        .toLowerCase()
                        .includes(carSearch.toLowerCase())
                  )
                  .map((v, i) => (
                    <option key={v.ID} value={v.ID}>
                      {i + 1}. {v.CAR} {v.MODEL} — {v.PLATE}
                    </option>
                  ))}
              </select>
              {cars.isError && (
                <p className="text-red-600">{cars.error.message}</p>
              )}{" "}
              {!cars.isLoading && cars.data?.length === 0 && (
                <p className="text-sm text-slate-500">
                  لا توجد سيارات متاحة غير محجوزة
                </p>
              )}
            </div>
            <label className="block space-y-2">
              ملاحظات
              <textarea
                className="w-full border rounded-md p-3"
                maxLength={500}
                rows={3}
                value={notes}
                onChange={e => setNotes(e.target.value)}
              />
            </label>
            <div className="flex gap-3 justify-end">
              <Button
                type="button"
                variant="outline"
                disabled={save.isPending}
                onClick={() => setOpen(false)}
              >
                رجوع
              </Button>
              <Button
                disabled={
                  save.isPending ||
                  (reservation && (!vehicle || cars.isLoading || cars.isError))
                }
              >
                {save.isPending ? "جارٍ الحفظ…" : "حفظ"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
      <Dialog
        open={Boolean(closing)}
        onOpenChange={v => {
          if (!v && !finish.isPending) setClosing(null);
        }}
      >
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>
              {closing?.status === "cancelled" ? "إلغاء السجل" : "إكمال السجل"}
            </DialogTitle>
            <DialogDescription>
              سيتم إغلاق السجل وحفظ العملية في سجل التدقيق.
              {reservation ? " إكمال الحجز لا ينشئ فاتورة مبيعات." : ""}
            </DialogDescription>
          </DialogHeader>
          <Button
            disabled={finish.isPending}
            onClick={() => closing && finish.mutate(closing)}
          >
            {finish.isPending ? "جارٍ التحديث…" : "تأكيد"}
          </Button>
        </DialogContent>
      </Dialog>
    </section>
  );
}
export function UpcomingActivities({ navigate }: { navigate: NavigateDealer }) {
  const q = trpc.oracleOperations.activities.useQuery(undefined, {
    retry: false,
    refetchInterval: 60000,
  });
  const active = (q.data ?? [])
    .filter(r => r.STATUS === "active")
    .sort((a, b) => a.SCHEDULED_AT.localeCompare(b.SCHEDULED_AT));
  return (
    <section className="oracle-panel p-5">
      <div className="flex flex-wrap justify-between gap-3 mb-4">
        <h2 className="font-bold flex items-center gap-2">
          <CalendarDays size={18} />
          الحجز ومواعيد المتابعة
        </h2>
        <div className="flex gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={() => navigate("reservations")}
          >
            الحجوزات
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={() => navigate("followups")}
          >
            مواعيد المتابعة
          </Button>
        </div>
      </div>
      {q.isError ? (
        <p className="text-red-600">تعذر تحميل المواعيد</p>
      ) : q.isLoading ? (
        <p>جارٍ تحميل المواعيد…</p>
      ) : active.length === 0 ? (
        <p className="text-sm text-slate-500">لا توجد حجوزات أو مواعيد نشطة</p>
      ) : (
        active.slice(0, 5).map(r => (
          <button
            key={r.ID}
            className="w-full text-right border-b py-3 flex flex-wrap justify-between gap-2"
            onClick={() =>
              navigate(r.KIND === "reservation" ? "reservations" : "followups")
            }
          >
            <span>
              <strong>{r.CUSTOMER}</strong>
              <small className="block text-slate-500">
                {r.KIND === "reservation" ? "حجز سيارة" : "متابعة"} · {r.CAR}{" "}
                {r.PLATE}
              </small>
            </span>
            <span className="text-sm">{dateLabel(r.SCHEDULED_AT)}</span>
          </button>
        ))
      )}
    </section>
  );
}
