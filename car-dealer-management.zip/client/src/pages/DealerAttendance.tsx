import { useEffect, useState } from "react";
import {
  MapPin,
  Fingerprint,
  Clock,
  Building2,
  CheckCircle2,
  Plus,
  UsersRound,
  Search,
} from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  shiftInput,
  attendanceReportInput,
  attendanceWindow,
  locationAllowed,
  type AttendanceShift,
} from "@shared/attendance";
import type { z } from "zod";
function locate(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!window.isSecureContext) {
      reject(new Error("الموقع يتطلب فتح النظام عبر اتصال HTTPS على الجوال"));
      return;
    }
    if (!navigator.geolocation) {
      reject(new Error("الجهاز لا يدعم تحديد الموقع"));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      resolve,
      e =>
        reject(
          new Error(
            e.code === 1
              ? "اسمح بالوصول إلى الموقع لتسجيل الحضور"
              : e.code === 2
                ? "تعذر تحديد موقعك؛ فعّل خدمة الموقع"
                : "انتهت مهلة تحديد الموقع؛ أعد المحاولة"
          )
        ),
      { enableHighAccuracy: true, maximumAge: 0, timeout: 20000 }
    );
  });
}
const today = () =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Riyadh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
export function EmployeeAttendance() {
  const q = trpc.attendance.mine.useQuery(undefined, {
    retry: false,
    refetchInterval: 30000,
  });
  const [position, setPosition] = useState<z.infer<
      typeof import("@shared/attendance").checkInInput
    > | null>(null),
    [locating, setLocating] = useState(false),
    [error, setError] = useState(""),
    [tick, setTick] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setTick(Date.now()), 5000);
    return () => clearInterval(t);
  }, []);
  const state = q.data,
    shift = state?.shift,
    record = state?.checked,
    openRecord = !!record && !record.CHECKED_OUT_AT,
    finished = !!record?.CHECKED_OUT_AT;
  const now = state
    ? state.now + Math.max(0, tick - q.dataUpdatedAt)
    : Date.now();
  const windowState = shift ? attendanceWindow(shift, now) : null;
  const site = openRecord
    ? {
        LATITUDE: record!.SHIFT_LATITUDE,
        LONGITUDE: record!.SHIFT_LONGITUDE,
        RADIUS: record!.SHIFT_RADIUS,
      }
    : shift;
  const location = site && position ? locationAllowed(site, position) : null;
  const fresh = position && tick - Date.parse(position.capturedAt) < 60000;
  const ready =
    !!fresh &&
    !!location?.accurate &&
    !!location?.inside &&
    (openRecord || (!!shift?.ACTIVE && !!windowState?.allowed && !record));
  const onSuccess = () => {
    toast.success(openRecord ? "تم تسجيل الانصراف" : "تم تسجيل الحضور");
    void q.refetch();
  };
  const mutation = trpc.attendance.checkIn.useMutation({
    onSuccess,
    onError(e) {
      setError(e.message);
      void q.refetch();
    },
  });
  const checkout = trpc.attendance.checkOut.useMutation({
    onSuccess,
    onError(e) {
      setError(e.message);
      void q.refetch();
    },
  });
  const busy = mutation.isPending || checkout.isPending;
  async function refreshLocation(submit = false) {
    setLocating(true);
    setError("");
    try {
      const p = await locate(),
        value = {
          latitude: p.coords.latitude,
          longitude: p.coords.longitude,
          accuracy: p.coords.accuracy,
          capturedAt: new Date(p.timestamp).toISOString(),
        };
      setPosition(value);
      setTick(Date.now());
      if (submit) (openRecord ? checkout : mutation).mutate(value);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLocating(false);
    }
  }
  return (
    <section className="oracle-panel max-w-xl mx-auto p-6 space-y-6" dir="rtl">
      <div className="text-center">
        <div className="w-16 h-16 mx-auto bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center">
          <Fingerprint size={36} />
        </div>
        <h2 className="font-bold text-2xl mt-4">الحضور والانصراف</h2>
        <p className="text-sm text-slate-500 mt-2">
          سجّل حضورك وانصرافك من موقع الوردية
        </p>
      </div>
      {q.isLoading ? (
        <p>جارٍ تحميل الوردية…</p>
      ) : q.isError ? (
        <p role="alert" className="text-red-600">
          {q.error.message}
        </p>
      ) : (
        <>
          <div className="rounded-xl bg-slate-50 p-4 space-y-3">
            <p className="font-bold flex items-center gap-2">
              <UsersRound size={17} />
              {state?.employeeName}
            </p>
            <p className="flex items-center gap-2">
              <Building2 size={17} />
              {record?.BRANCH ?? shift?.BRANCH ?? "لم يتم إسناد وردية"}
            </p>
            {shift && (
              <>
                <p>الوردية: {shift.NAME}</p>
                <p className="flex items-center gap-2">
                  <Clock size={17} />
                  الدوام:{" "}
                  <span dir="ltr">
                    {shift.WORK_START} – {shift.WORK_END}
                  </span>{" "}
                  (الرياض)
                </p>
                <p className="text-sm">
                  السماح بالحضور:{" "}
                  <span dir="ltr">
                    {shift.START_TIME} – {shift.END_TIME}
                  </span>
                </p>
                <p className="text-sm text-slate-500">
                  نطاق الحضور: {site?.RADIUS} متر · سماح التأخير:{" "}
                  {shift.LATE_GRACE} دقيقة
                </p>
              </>
            )}
          </div>
          {record && (
            <div className="p-5 bg-emerald-50 rounded-xl text-emerald-800 text-center">
              <CheckCircle2 className="mx-auto mb-3" />
              <strong>
                {finished ? "تم تسجيل الحضور والانصراف" : "تم تسجيل حضورك"}
              </strong>
              <p className="text-sm mt-2">
                الحضور: <span dir="ltr">{record.CHECKED_AT}</span>
              </p>
              {record.CHECKED_OUT_AT && (
                <p className="text-sm">
                  الانصراف: <span dir="ltr">{record.CHECKED_OUT_AT}</span>
                </p>
              )}
              {record.LATE_MINUTES > 0 && (
                <p className="text-sm text-amber-700 mt-2">
                  التأخير: {record.LATE_MINUTES} دقيقة
                </p>
              )}
            </div>
          )}
          {!finished && (openRecord || shift) && (
            <>
              <div className="rounded-xl border p-4 space-y-3">
                <p
                  className={
                    openRecord || windowState?.allowed
                      ? "text-emerald-700"
                      : "text-amber-700"
                  }
                >
                  {openRecord
                    ? "يمكنك تسجيل الانصراف من موقع الوردية حتى بعد نهاية السماح بالحضور"
                    : !shift?.ACTIVE
                      ? "الوردية غير مفعلة"
                      : windowState?.allowed
                        ? "وقت السماح بالحضور متاح الآن"
                        : "تسجيل الحضور مغلق خارج وقت السماح"}
                </p>
                {position && location && (
                  <>
                    <p className="text-sm">
                      المسافة: {Math.round(location.distance)} متر · دقة الموقع:{" "}
                      {Math.round(position.accuracy)} متر
                    </p>
                    <p
                      className={
                        location.inside && location.accurate && fresh
                          ? "text-emerald-700 text-sm"
                          : "text-amber-700 text-sm"
                      }
                    >
                      {!fresh
                        ? "حدّث موقعك قبل التسجيل"
                        : !location.accurate
                          ? "دقة الموقع غير كافية؛ فعّل الموقع الدقيق"
                          : !location.inside
                            ? "أنت خارج النطاق المسموح أو قريب من حدوده"
                            : "أنت داخل الموقع المسموح"}
                    </p>
                  </>
                )}
                <Button
                  className="w-full"
                  variant="outline"
                  disabled={locating || busy}
                  onClick={() => refreshLocation()}
                >
                  <MapPin size={17} />
                  {locating ? "جارٍ تحديد الموقع…" : "تحديد / تحديث موقعي"}
                </Button>
              </div>
              <Button
                className="w-full h-16 text-lg"
                disabled={!ready || locating || busy || q.isFetching}
                onClick={() => refreshLocation(true)}
              >
                <Fingerprint size={28} />
                {busy
                  ? "جارٍ التسجيل…"
                  : openRecord
                    ? "تسجيل انصرافي"
                    : "تسجيل حضوري"}
              </Button>
            </>
          )}
          {!record && !shift && (
            <p className="text-center text-slate-500">
              اطلب من المدير إسناد حسابك إلى وردية
            </p>
          )}
          {error && (
            <p role="alert" className="text-red-600">
              {error}
            </p>
          )}
        </>
      )}
      <Button className="w-full" variant="ghost" onClick={() => q.refetch()}>
        تحديث حالة الحضور
      </Button>
    </section>
  );
}
export function AttendanceSettings() {
  const actor = trpc.oracleOperations.session.useQuery().data?.actor;
  const q = trpc.attendance.settings.useQuery(undefined, {
    enabled: actor?.ROLE === "admin",
    retry: false,
  });
  const [edit, setEdit] = useState<AttendanceShift | null | undefined>(),
    [assign, setAssign] = useState<AttendanceShift | null>(null);
  if (actor?.ROLE !== "admin")
    return (
      <p className="oracle-panel p-8">
        إعدادات الورديات وإسناد الموظفين متاحة للمدير.
      </p>
    );
  return (
    <div className="space-y-5" dir="rtl">
      <section className="oracle-panel p-6">
        <div className="flex flex-wrap justify-between gap-3">
          <div>
            <h2 className="text-xl font-bold">الورديات وإسناد الموظفين</h2>
            <p className="text-sm text-slate-500 mt-2">
              حدد موقع الفرع ونطاقه ووقت السماح بالحضور، ثم اختر الموظفين من
              حسابات النظام
            </p>
          </div>
          <Button onClick={() => setEdit(null)}>
            <Plus size={16} />
            إضافة وردية
          </Button>
        </div>
      </section>
      {q.isError && (
        <p role="alert" className="text-red-600">
          {q.error.message}
        </p>
      )}
      {q.isLoading ? (
        <p>جارٍ التحميل…</p>
      ) : (
        <div className="grid md:grid-cols-2 gap-5">
          {q.data?.shifts.map(s => (
            <section key={s.ID} className="oracle-panel p-5 space-y-4">
              <div className="flex justify-between">
                <h3 className="font-bold text-lg">{s.NAME}</h3>
                <span
                  className={
                    s.ACTIVE
                      ? "text-emerald-700 text-xs"
                      : "text-slate-500 text-xs"
                  }
                >
                  {s.ACTIVE ? "مفعلة" : "معطلة"}
                </span>
              </div>
              <p className="flex items-center gap-2">
                <Building2 size={16} />
                {s.BRANCH}
              </p>
              <p>
                <span dir="ltr">
                  {s.START_TIME} – {s.END_TIME}
                </span>{" "}
                بتوقيت الرياض
              </p>
              <p className="text-sm text-slate-500" dir="ltr">
                {s.LATITUDE}, {s.LONGITUDE} · {s.RADIUS} m
              </p>
              <p className="text-sm">
                الموظفون المسندون:{" "}
                {q.data?.employees.filter(e => e.SHIFT_ID === s.ID).length}
              </p>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setEdit(s)}>
                  تعديل الإعدادات
                </Button>
                <Button disabled={!s.ACTIVE} onClick={() => setAssign(s)}>
                  <UsersRound size={16} />
                  إسناد الموظفين
                </Button>
              </div>
            </section>
          ))}
        </div>
      )}
      {q.data?.shifts.length === 0 && (
        <p className="oracle-panel p-10 text-center text-slate-500">
          أضف أول وردية وحدد موقع الحضور
        </p>
      )}
      {edit !== undefined && (
        <ShiftForm
          shift={edit}
          close={() => setEdit(undefined)}
          saved={() => {
            setEdit(undefined);
            void q.refetch();
          }}
        />
      )}
      {assign && q.data && (
        <AssignmentForm
          shift={assign}
          employees={q.data.employees}
          close={() => setAssign(null)}
          saved={() => {
            setAssign(null);
            void q.refetch();
          }}
        />
      )}
    </div>
  );
}
function ShiftForm({
  shift,
  close,
  saved,
}: {
  shift: AttendanceShift | null;
  close: () => void;
  saved: () => void;
}) {
  const [name, setName] = useState(shift?.NAME ?? ""),
    [branch, setBranch] = useState(shift?.BRANCH ?? ""),
    [lat, setLat] = useState(shift ? String(shift.LATITUDE) : ""),
    [lon, setLon] = useState(shift ? String(shift.LONGITUDE) : ""),
    [radius, setRadius] = useState(String(shift?.RADIUS ?? 100)),
    [start, setStart] = useState(shift?.START_TIME ?? "07:00"),
    [end, setEnd] = useState(shift?.END_TIME ?? "17:00"),
    [active, setActive] = useState(shift ? !!shift.ACTIVE : true),
    [error, setError] = useState(""),
    [locating, setLocating] = useState(false);
  const [workStart, setWorkStart] = useState(shift?.WORK_START ?? "07:00"),
    [workEnd, setWorkEnd] = useState(shift?.WORK_END ?? "17:00"),
    [grace, setGrace] = useState(String(shift?.LATE_GRACE ?? 0));
  const utils = trpc.useUtils();
  const mutation = trpc.attendance.saveShift.useMutation({
    onSuccess() {
      void utils.attendance.invalidate();
      toast.success("تم حفظ الوردية");
      saved();
    },
    onError(e) {
      setError(e.message);
    },
  });
  return (
    <Dialog
      open
      onOpenChange={v => {
        if (!v && !mutation.isPending) close();
      }}
    >
      <DialogContent
        dir="rtl"
        className="sm:max-w-2xl max-h-[90vh] overflow-auto"
      >
        <DialogHeader>
          <DialogTitle>{shift ? "تعديل الوردية" : "إضافة وردية"}</DialogTitle>
          <DialogDescription>
            الحضور متاح ضمن نطاق الموقع وفي الفترة المحددة، بتوقيت الرياض.
            الورديات تعمل يوميًا وتدعم الفترات التي تمتد بعد منتصف الليل.
          </DialogDescription>
        </DialogHeader>
        <form
          className="space-y-4"
          onSubmit={e => {
            e.preventDefault();
            const r = shiftInput.safeParse({
              id: shift?.ID,
              name,
              branch,
              latitude: Number(lat),
              longitude: Number(lon),
              radius: Number(radius),
              workStart,
              workEnd,
              lateGrace: Number(grace),
              startTime: start,
              endTime: end,
              active,
            });
            if (!r.success) {
              setError(r.error.issues[0].message);
              return;
            }
            setError("");
            mutation.mutate(r.data);
          }}
        >
          <fieldset
            disabled={mutation.isPending}
            className="grid sm:grid-cols-2 gap-4"
          >
            <label>
              اسم الوردية
              <Input
                required
                maxLength={100}
                value={name}
                onChange={e => setName(e.target.value)}
              />
            </label>
            <label>
              الفرع
              <Input
                required
                maxLength={100}
                value={branch}
                onChange={e => setBranch(e.target.value)}
              />
            </label>
            <label>
              خط العرض
              <Input
                required
                type="number"
                dir="ltr"
                min={-90}
                max={90}
                step="any"
                value={lat}
                onChange={e => setLat(e.target.value)}
              />
            </label>
            <label>
              خط الطول
              <Input
                required
                type="number"
                dir="ltr"
                min={-180}
                max={180}
                step="any"
                value={lon}
                onChange={e => setLon(e.target.value)}
              />
            </label>
            <Button
              type="button"
              variant="outline"
              className="sm:col-span-2"
              disabled={locating}
              onClick={async () => {
                setLocating(true);
                try {
                  const p = await locate();
                  setLat(String(p.coords.latitude));
                  setLon(String(p.coords.longitude));
                  setError("");
                } catch (e) {
                  setError((e as Error).message);
                } finally {
                  setLocating(false);
                }
              }}
            >
              <MapPin size={16} />
              {locating ? "جارٍ تحديد الموقع…" : "استخدام موقعي الحالي للوردية"}
            </Button>
            <label>
              النطاق المسموح (متر)
              <Input
                required
                type="number"
                min={20}
                max={5000}
                value={radius}
                onChange={e => setRadius(e.target.value)}
              />
            </label>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={active}
                onChange={e => setActive(e.target.checked)}
              />
              وردية مفعلة
            </label>
            <label>
              بداية السماح بالدخول
              <Input
                required
                type="time"
                dir="ltr"
                value={start}
                onChange={e => setStart(e.target.value)}
              />
            </label>
            <label>
              نهاية السماح بالدخول
              <Input
                required
                type="time"
                dir="ltr"
                value={end}
                onChange={e => setEnd(e.target.value)}
              />
            </label>
            <label>
              بداية الدوام
              <Input
                required
                type="time"
                dir="ltr"
                value={workStart}
                onChange={e => setWorkStart(e.target.value)}
              />
            </label>
            <label>
              نهاية الدوام
              <Input
                required
                type="time"
                dir="ltr"
                value={workEnd}
                onChange={e => setWorkEnd(e.target.value)}
              />
            </label>
            <label>
              سماح التأخير (دقائق)
              <Input
                required
                type="number"
                min={0}
                max={120}
                value={grace}
                onChange={e => setGrace(e.target.value)}
              />
            </label>
          </fieldset>
          {error && (
            <p role="alert" className="text-red-600">
              {error}
            </p>
          )}
          <div className="flex justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={close}
              disabled={mutation.isPending}
            >
              إلغاء
            </Button>
            <Button disabled={mutation.isPending}>
              {mutation.isPending ? "جارٍ الحفظ…" : "حفظ الوردية"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
function AssignmentForm({
  shift,
  employees,
  close,
  saved,
}: {
  shift: AttendanceShift;
  employees: {
    ID: number;
    DISPLAY_NAME: string;
    USERNAME: string;
    SHIFT_ID: number | null;
  }[];
  close: () => void;
  saved: () => void;
}) {
  const [selected, setSelected] = useState(
      employees.filter(e => e.SHIFT_ID === shift.ID).map(e => e.ID)
    ),
    [search, setSearch] = useState("");
  const utils = trpc.useUtils();
  const mutation = trpc.attendance.assignShift.useMutation({
    onSuccess() {
      void utils.attendance.invalidate();
      toast.success("تم حفظ إسناد الموظفين");
      saved();
    },
  });
  return (
    <Dialog
      open
      onOpenChange={v => {
        if (!v && !mutation.isPending) close();
      }}
    >
      <DialogContent dir="rtl" className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>إسناد الموظفين — {shift.NAME}</DialogTitle>
          <DialogDescription>
            كل موظف يُسند إلى وردية واحدة. اختيار موظف مسند لوردية أخرى ينقله
            إلى هذه الوردية، وإزالة الاختيار تلغي إسناده إليها.
          </DialogDescription>
        </DialogHeader>
        <Input
          aria-label="بحث الموظفين"
          placeholder="بحث باسم الموظف"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <div className="max-h-80 overflow-auto border rounded-xl divide-y">
          {employees
            .filter(e => `${e.DISPLAY_NAME} ${e.USERNAME}`.includes(search))
            .map(e => (
              <label key={e.ID} className="flex gap-3 items-center p-3">
                <input
                  type="checkbox"
                  disabled={mutation.isPending}
                  checked={selected.includes(e.ID)}
                  onChange={v =>
                    setSelected(old =>
                      v.target.checked
                        ? [...old, e.ID]
                        : old.filter(id => id !== e.ID)
                    )
                  }
                />
                <span>
                  {e.DISPLAY_NAME}
                  <small className="block text-slate-500">
                    {e.USERNAME}
                    {e.SHIFT_ID && e.SHIFT_ID !== shift.ID
                      ? " · مسند لوردية أخرى"
                      : ""}
                  </small>
                </span>
              </label>
            ))}
        </div>
        <p className="text-sm text-slate-500">المحددون: {selected.length}</p>
        {mutation.isError && (
          <p className="text-red-600" role="alert">
            {mutation.error.message}
          </p>
        )}
        <Button
          disabled={mutation.isPending}
          onClick={() =>
            mutation.mutate({ shiftId: shift.ID, employeeIds: selected })
          }
        >
          {mutation.isPending ? "جارٍ الحفظ…" : "حفظ الإسناد"}
        </Button>
      </DialogContent>
    </Dialog>
  );
}
const statusNames = {
  present: "حاضر",
  late: "متأخر",
  absent: "غائب",
  pending: "لم يسجل بعد",
};
export function AttendanceReport() {
  const actor = trpc.oracleOperations.session.useQuery().data?.actor;
  const [date1, setDate1] = useState(today()),
    [date2, setDate2] = useState(today()),
    [request, setRequest] = useState({ date1: today(), date2: today() }),
    [search, setSearch] = useState(""),
    [status, setStatus] = useState("all"),
    [error, setError] = useState("");
  const allowed = actor?.ROLE === "admin" || actor?.ROLE === "editor";
  const q = trpc.attendance.report.useQuery(request, {
    enabled: allowed,
    retry: false,
    refetchInterval: 30000,
  });
  const matching = (q.data ?? []).filter(r =>
    `${r.EMPLOYEE_NAME} ${r.BRANCH} ${r.SHIFT_NAME}`.includes(search)
  );
  const rows = matching.filter(r => status === "all" || r.STATUS === status);
  if (!allowed)
    return (
      <p className="oracle-panel p-8">تقرير الحضور متاح للمدير والمحرر.</p>
    );
  return (
    <div className="space-y-5" dir="rtl">
      <section className="oracle-panel p-6">
        <h2 className="font-bold text-xl">تقرير الحضور والغياب والتأخير</h2>
        <p className="text-sm text-slate-500 mt-2">
          أوقات الحضور والانصراف بتوقيت الرياض. يحتسب الغياب بعد نهاية وقت
          السماح بالحضور، للموظفين المسندين إلى وردية. المتأخر محسوب ضمن
          الحاضرين.
        </p>
        <form
          className="grid sm:grid-cols-3 gap-4 items-end mt-5"
          onSubmit={e => {
            e.preventDefault();
            const r = attendanceReportInput.safeParse({ date1, date2 });
            if (!r.success) {
              setError(r.error.issues[0].message);
              return;
            }
            setError("");
            setRequest(r.data);
            if (request.date1 === date1 && request.date2 === date2)
              void q.refetch();
          }}
        >
          <label>
            من تاريخ
            <Input
              type="date"
              required
              value={date1}
              onChange={e => setDate1(e.target.value)}
            />
          </label>
          <label>
            إلى تاريخ
            <Input
              type="date"
              required
              value={date2}
              onChange={e => setDate2(e.target.value)}
            />
          </label>
          <Button disabled={q.isFetching}>
            <Search size={16} />
            عرض التقرير
          </Button>
        </form>
        <div className="flex flex-wrap gap-3 mt-4">
          <Input
            className="flex-1 min-w-48"
            aria-label="بحث تقرير الحضور"
            placeholder="بحث بالموظف أو الفرع أو الوردية"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <select
            aria-label="حالة الحضور"
            className="border rounded-md p-2"
            value={status}
            onChange={e => setStatus(e.target.value)}
          >
            <option value="all">كل الحالات</option>
            {Object.entries(statusNames).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </select>
        </div>
        <div className="grid sm:grid-cols-4 gap-3 mt-5">
          {[
            [
              "الحاضرون",
              matching.filter(
                r => r.STATUS === "present" || r.STATUS === "late"
              ).length,
            ],
            ["المتأخرون", matching.filter(r => r.STATUS === "late").length],
            ["الغائبون", matching.filter(r => r.STATUS === "absent").length],
            [
              "لم يسجلوا بعد",
              matching.filter(r => r.STATUS === "pending").length,
            ],
          ].map(([l, v]) => (
            <div key={String(l)} className="bg-slate-50 rounded-xl p-4">
              <small>{l}</small>
              <strong className="block text-xl mt-2">{v}</strong>
            </div>
          ))}
        </div>
        {(error || q.isError) && (
          <p role="alert" className="text-red-600 mt-3">
            {error || q.error?.message}
          </p>
        )}
      </section>
      <section className="oracle-panel overflow-auto max-h-[65vh]">
        <table className="w-full text-sm text-right">
          <thead className="bg-slate-50 sticky top-0">
            <tr>
              {[
                "#",
                "اسم الموظف",
                "الفرع",
                "الوردية",
                "يوم الوردية",
                "الحالة",
                "الحضور",
                "الانصراف",
                "التأخير (دقيقة)",
                "مدة الحضور (دقيقة)",
                "بداية الدوام",
                "نهاية الدوام",
              ].map(h => (
                <th key={h} className="p-3 whitespace-nowrap">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r.USER_ID + ":" + r.WORK_DATE} className="border-b">
                <td className="p-3">{i + 1}</td>
                <td className="p-3 font-semibold whitespace-nowrap">
                  {r.EMPLOYEE_NAME}
                </td>
                <td className="p-3 whitespace-nowrap">{r.BRANCH}</td>
                <td className="p-3 whitespace-nowrap">{r.SHIFT_NAME}</td>
                <td className="p-3" dir="ltr">
                  {r.WORK_DATE}
                </td>
                <td className="p-3 whitespace-nowrap">
                  <span
                    className={
                      "rounded-full px-3 py-1 text-xs " +
                      (r.STATUS === "absent"
                        ? "bg-red-50 text-red-700"
                        : r.STATUS === "late"
                          ? "bg-amber-50 text-amber-700"
                          : r.STATUS === "present"
                            ? "bg-emerald-50 text-emerald-700"
                            : "bg-slate-100 text-slate-500")
                    }
                  >
                    {statusNames[r.STATUS]}
                  </span>
                </td>
                <td className="p-3 whitespace-nowrap" dir="ltr">
                  {r.CHECKED_AT ?? "—"}
                </td>
                <td className="p-3 whitespace-nowrap" dir="ltr">
                  {r.CHECKED_OUT_AT ??
                    (r.CHECKED_AT ? "لم يسجل الانصراف" : "—")}
                </td>
                <td className="p-3">{r.CHECKED_AT ? r.LATE_MINUTES : "—"}</td>
                <td className="p-3">{r.DURATION_MINUTES ?? "—"}</td>
                <td className="p-3 whitespace-nowrap" dir="ltr">
                  {r.EXPECTED_START ?? "—"}
                </td>
                <td className="p-3 whitespace-nowrap" dir="ltr">
                  {r.EXPECTED_END ?? "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {q.isLoading ? (
          <p className="p-8 text-center">جارٍ التحميل…</p>
        ) : (
          !q.isError &&
          rows.length === 0 && (
            <p className="p-10 text-center text-slate-500">
              لا توجد سجلات أو ورديات مسندة ضمن الفترة المحددة
            </p>
          )
        )}
      </section>
    </div>
  );
}
