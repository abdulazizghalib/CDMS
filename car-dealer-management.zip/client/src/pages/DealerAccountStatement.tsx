﻿import { useState } from "react";
import { FileText, Search } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { money } from "@/lib/dealerPresentation";
import { accountStatementInput } from "@shared/accountStatement";
export function DealerAccountStatement() {
  const today = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Riyadh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
  const [account, setAccount] = useState("");
  const [date1, setDate1] = useState(today.slice(0, 7) + "-01"),
    [date2, setDate2] = useState(today);
  const [filter, setFilter] = useState("");
  const [error, setError] = useState("");
  const [request, setRequest] = useState<{
    accountNo: number;
    date1: string;
    date2: string;
  }>();
  const accounts = trpc.oracleOperations.statementAccounts.useQuery(undefined, {
    retry: false,
  });
  const query = trpc.oracleOperations.accountStatement.useQuery(
    request ?? { accountNo: 1, date1: today, date2: today },
    { enabled: !!request, retry: false }
  );
  const data = query.data;
  return (
    <div className="space-y-5" dir="rtl">
      <section className="oracle-panel p-6">
        <h2 className="font-bold text-xl flex items-center gap-2">
          <FileText className="text-amber-600" />
          كشف حساب
        </h2>
        <p className="text-sm text-slate-500 mt-2 mb-5">
          حركات الحساب خلال الفترة المحددة، مع الرصيد السابق والرصيد بعد كل
          حركة.
        </p>
        <form
          className="grid md:grid-cols-4 gap-4 items-end"
          onSubmit={e => {
            e.preventDefault();
            const parsed = accountStatementInput.safeParse({
              accountNo: Number(account),
              date1,
              date2,
            });
            if (!parsed.success) {
              setError(parsed.error.issues[0].message);
              return;
            }
            setError("");
            setRequest(parsed.data);
            if (JSON.stringify(request) === JSON.stringify(parsed.data))
              void query.refetch();
          }}
        >
          <label className="block space-y-2">
            الحساب
            <Input
              aria-label="بحث الحساب"
              placeholder="بحث برقم الحساب أو اسمه"
              value={filter}
              onChange={e => setFilter(e.target.value)}
            />
            <select
              aria-label="الحساب"
              required
              className="w-full border rounded-md p-2 bg-white"
              value={account}
              onChange={e => setAccount(e.target.value)}
            >
              <option value="">اختر الحساب</option>
              {accounts.data
                ?.filter(
                  a =>
                    String(a.ID) === account ||
                    `${a.ID} ${a.NAME}`.includes(filter)
                )
                .map(a => (
                  <option key={a.ID} value={a.ID}>
                    {a.ID} — {a.NAME}
                  </option>
                ))}
            </select>
          </label>
          <label className="block space-y-2">
            من تاريخ
            <Input
              type="date"
              required
              dir="ltr"
              value={date1}
              onChange={e => setDate1(e.target.value)}
            />
          </label>
          <label className="block space-y-2">
            إلى تاريخ
            <Input
              type="date"
              required
              dir="ltr"
              value={date2}
              onChange={e => setDate2(e.target.value)}
            />
          </label>
          <Button disabled={query.isFetching || accounts.isLoading}>
            <Search size={16} />
            {query.isFetching ? "جارٍ التحميل…" : "عرض كشف الحساب"}
          </Button>
        </form>
        {(error || accounts.isError || query.isError) && (
          <p role="alert" className="mt-4 text-red-600">
            {error || accounts.error?.message || query.error?.message}
          </p>
        )}
      </section>
      {data && !query.isError && (
        <>
          <section className="oracle-panel p-5">
            <h3 className="font-bold">
              {accounts.data?.find(a => a.ID === data.accountNo)?.NAME} · حساب{" "}
              {data.accountNo}
            </h3>
            <p className="text-sm text-slate-500 mt-2">
              الفترة: {data.date1} إلى {data.date2} · {data.lines.length} حركة
            </p>
            <div className="grid sm:grid-cols-4 gap-4 mt-5">
              {[
                ["الرصيد السابق", data.opening],
                ["إجمالي المدين", data.debit],
                ["إجمالي الدائن", data.credit],
                ["الرصيد الختامي", data.closing],
              ].map(([label, v]) => (
                <div key={String(label)} className="rounded-xl bg-slate-50 p-4">
                  <small className="text-slate-500">{label}</small>
                  <strong className="block text-lg mt-2">{money(v)}</strong>
                </div>
              ))}
            </div>
            <p className="text-xs text-slate-500 mt-3">
              الرصيد = المدين − الدائن. الرصيد الموجب مدين والسالب دائن.
            </p>
          </section>
          <section className="oracle-panel overflow-auto max-h-[65vh]">
            <table className="w-full text-sm text-right">
              <thead className="sticky top-0 bg-slate-100">
                <tr>
                  {[
                    "#",
                    "التاريخ",
                    "المستند",
                    "نوع المستند",
                    "البيان",
                    "مدين",
                    "دائن",
                    "الرصيد",
                  ].map(h => (
                    <th className="p-3 whitespace-nowrap" key={h}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className="bg-amber-50">
                  <td className="p-3" colSpan={7}>
                    الرصيد السابق قبل {data.date1}
                  </td>
                  <td className="p-3 whitespace-nowrap">
                    {money(data.opening)}
                  </td>
                </tr>
                {data.lines.map((r, i) => (
                  <tr key={r.ID} className="border-b odd:bg-slate-50">
                    <td className="p-3">{i + 1}</td>
                    <td className="p-3 whitespace-nowrap" dir="ltr">
                      {r.DATE}
                    </td>
                    <td className="p-3">{r.DOCUMENT ?? "—"}</td>
                    <td className="p-3">{r.DOCUMENT_TYPE ?? "—"}</td>
                    <td className="p-3 min-w-40">{r.NOTES ?? "—"}</td>
                    <td className="p-3 whitespace-nowrap">{money(r.DEBIT)}</td>
                    <td className="p-3 whitespace-nowrap">{money(r.CREDIT)}</td>
                    <td className="p-3 font-semibold whitespace-nowrap">
                      {money(r.BALANCE)}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-slate-100 font-bold">
                <tr>
                  <td colSpan={5} className="p-3">
                    الإجمالي / الرصيد الختامي
                  </td>
                  <td className="p-3">{money(data.debit)}</td>
                  <td className="p-3">{money(data.credit)}</td>
                  <td className="p-3">{money(data.closing)}</td>
                </tr>
              </tfoot>
            </table>
            {data.lines.length === 0 && (
              <p className="text-center py-8 text-slate-500">
                لا توجد حركات لهذا الحساب خلال الفترة المحددة
              </p>
            )}
          </section>
        </>
      )}
      {!request && (
        <p className="oracle-panel p-12 text-center text-slate-500">
          اختر الحساب والفترة ثم اضغط «عرض كشف الحساب»
        </p>
      )}
    </div>
  );
}
