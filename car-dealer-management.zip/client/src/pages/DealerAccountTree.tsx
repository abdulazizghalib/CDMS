import "./dealer-account-tree.css";
import { useMemo, useState } from "react";
import {
  BookOpen,
  ChevronLeft,
  ChevronDown,
  Folder,
  FileText,
  Search,
  Settings2,
  RefreshCw,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SalesAccountSettings } from "@/components/SalesAccountSettings";
import { OracleEditButtons } from "./OracleOperations";
import {
  buildAccountTree,
  filterAccountTree,
  type AccountNode,
} from "@shared/accountTree";
const datasets = {
  1: "mainAccounts",
  2: "branchAccounts",
  3: "subAccounts",
} as const;
export function DealerAccountTree() {
  const query = trpc.oracleOperations.accountTree.useQuery(undefined, {
    retry: false,
  });
  const actor = trpc.oracleOperations.session.useQuery().data?.actor;
  const canWrite = actor?.ROLE === "admin" || actor?.ROLE === "editor";
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [selectedKey, setSelectedKey] = useState<string>();
  const [settings, setSettings] = useState(false);
  const tree = useMemo(() => buildAccountTree(query.data ?? []), [query.data]);
  const roots = filterAccountTree(tree.roots, search),
    orphans = filterAccountTree(tree.orphans, search);
  const selected = query.data?.find(n => `${n.LEVEL}:${n.ID}` === selectedKey);
  const refresh = () => {
    void query.refetch();
  };
  const toggle = (key: string) =>
    setExpanded(old => {
      const next = new Set(old);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  function node(n: AccountNode) {
    const isOpen = Boolean(search.trim()) || expanded.has(n.key);
    return (
      <li key={n.key} className="account-tree-node">
        <div
          className={
            "account-tree-row account-level-" +
            n.LEVEL +
            " " +
            (selectedKey === n.key ? "is-selected" : "")
          }
        >
          {n.children.length ? (
            <button
              className="account-tree-toggle"
              aria-label={(isOpen ? "طي " : "توسيع ") + n.NAME}
              aria-expanded={isOpen}
              onClick={() => toggle(n.key)}
            >
              {isOpen ? <ChevronDown size={16} /> : <ChevronLeft size={16} />}
            </button>
          ) : (
            <span className="account-tree-spacer" />
          )}
          {n.LEVEL === 3 ? (
            <FileText
              size={17}
              className="account-node-icon account-icon-leaf"
            />
          ) : (
            <Folder
              size={18}
              className="account-node-icon account-icon-folder"
            />
          )}
          <button
            className="account-tree-select"
            onClick={() => setSelectedKey(n.key)}
            aria-pressed={selectedKey === n.key}
          >
            <span dir="ltr" className="account-number">
              {n.ID}
            </span>
            <span className={n.LEVEL === 1 ? "font-bold" : "font-medium"}>
              {n.NAME || "حساب بدون اسم"}
            </span>
            <small className="account-node-meta">
              المستوى {n.LEVEL}
              {n.children.length ? ` · ${n.children.length} حساب` : ""}
            </small>
          </button>
        </div>
        {isOpen && n.children.length > 0 && (
          <ul className="account-tree-children">{n.children.map(node)}</ul>
        )}
      </li>
    );
  }
  return (
    <div className="account-directory" dir="rtl">
      <section className="account-directory-header">
        <div className="account-directory-hero">
          <div>
            <span className="account-eyebrow">
              الإدارة المالية / دليل الحسابات
            </span>
            <h2 className="text-xl font-bold flex items-center gap-2">
              <BookOpen className="text-amber-600" />
              دليل الحسابات
            </h2>
            <p className="text-slate-500 text-sm mt-2">
              تسلسل الحسابات الرئيسية والفرعية · اختر الحساب لعرض تفاصيله
              وإدارته
            </p>
          </div>
          <Button
            variant={settings ? "default" : "outline"}
            onClick={() => setSettings(v => !v)}
          >
            <Settings2 size={16} />
            {settings ? "إغلاق الإعدادات" : "إعدادات دليل الحسابات"}
          </Button>
        </div>
        <div className="account-level-stats">
          {([1, 2, 3] as const).map(level => (
            <div
              className={"account-level-stat stat-level-" + level}
              key={level}
            >
              <span className="account-stat-label">
                {level === 1
                  ? "الحسابات الرئيسية"
                  : level === 2
                    ? "الحسابات الفرعية"
                    : "الحسابات التفصيلية"}
              </span>
              <strong className="block text-xl mt-1">
                {query.data?.filter(n => n.LEVEL === level).length ?? "—"}
              </strong>
              <small>المستوى {level}</small>
            </div>
          ))}
        </div>
        <div className="account-tree-toolbar">
          <Search size={17} />
          <Input
            className="flex-1 min-w-48"
            aria-label="بحث دليل الحسابات"
            placeholder="ابحث برقم الحساب أو اسمه"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <Button
            variant="outline"
            onClick={() =>
              setExpanded(
                new Set((query.data ?? []).map(n => `${n.LEVEL}:${n.ID}`))
              )
            }
          >
            توسيع الكل
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              setExpanded(new Set());
              setSearch("");
            }}
          >
            طي الكل
          </Button>
          <Button
            variant="outline"
            aria-label="تحديث دليل الحسابات"
            onClick={refresh}
          >
            <RefreshCw size={16} />
          </Button>
        </div>
      </section>
      {settings && (
        <>
          <section className="oracle-panel p-5">
            <h3 className="font-bold mb-3">إدارة مستويات الحسابات</h3>
            <p className="text-sm text-slate-500 mb-4">
              الحساب في المستوى الثاني يرتبط بحساب رئيسي، والحساب في المستوى
              الثالث يرتبط بحساب من المستوى الثاني. اختر حسابًا من الشجرة
              لتعديله.{!canWrite ? " صلاحيتك تتيح عرض الحسابات فقط." : ""}
            </p>
            <div className="grid sm:grid-cols-3 gap-4">
              {([1, 2, 3] as const).map(level => (
                <div key={level} className="border rounded-xl p-4 space-y-3">
                  <h4 className="font-bold">إضافة حساب مستوى {level}</h4>
                  {canWrite ? (
                    <OracleEditButtons
                      dataset={datasets[level]}
                      onSaved={refresh}
                    />
                  ) : (
                    <p className="text-sm text-slate-500">
                      متاح للمدير والمحرر
                    </p>
                  )}
                </div>
              ))}
            </div>
          </section>
          <SalesAccountSettings />
        </>
      )}
      <div className="account-directory-workspace">
        <section className="account-tree-panel" aria-label="شجرة دليل الحسابات">
          <div className="account-tree-panel-heading">
            <div>
              <Folder size={18} />
              <h3>شجرة الحسابات</h3>
              <span>{query.data?.length ?? "—"} حساب</span>
            </div>
            <small>اختر الحساب لعرض التفاصيل</small>
          </div>
          <div className="account-tree-scroll">
            {query.isLoading ? (
              <p className="p-8 text-center">جارٍ تحميل الحسابات…</p>
            ) : query.isError ? (
              <p className="p-8 text-red-600" role="alert">
                {query.error.message}
              </p>
            ) : (
              <>
                <ul className="account-tree-roots">{roots.map(node)}</ul>
                {orphans.length > 0 && (
                  <div className="account-orphans">
                    <h3 className="font-bold text-amber-700 mb-2">
                      حسابات تحتاج ربطًا بالحساب الأب
                    </h3>
                    <ul>{orphans.map(node)}</ul>
                  </div>
                )}
                {roots.length === 0 && orphans.length === 0 && (
                  <p className="p-8 text-center text-slate-500">
                    لا توجد حسابات مطابقة
                  </p>
                )}
              </>
            )}
          </div>
        </section>
        <aside className="account-details-panel">
          <div className="account-details-heading">
            <FileText size={17} />
            <h3>تفاصيل الحساب</h3>
          </div>
          {selected ? (
            <>
              <div className="account-details-identity">
                <span className="account-detail-icon">
                  <BookOpen size={26} />
                </span>
                <small>المستوى {selected.LEVEL}</small>
                <h3>{selected.NAME}</h3>
                <span dir="ltr" className="account-detail-code">
                  {selected.ID}
                </span>
              </div>
              <span className="account-detail-badge">
                #{selected.ID} · المستوى {selected.LEVEL}
              </span>
              <dl className="account-details-fields">
                {[
                  [
                    "الحساب الأب",
                    selected.PARENT_ID === null
                      ? "حساب رئيسي"
                      : (query.data?.find(
                          a =>
                            a.LEVEL === selected.LEVEL - 1 &&
                            a.ID === selected.PARENT_ID
                        )?.NAME ?? `غير موجود (${selected.PARENT_ID})`),
                  ],
                  ["رقم الحساب الأب", selected.PARENT_ID],
                  ["رمز طبيعة الحساب", selected.NATURE],
                  ["الهاتف", selected.PHONE],
                  ["رمز التفعيل", selected.ACTIVE],
                  ["الملاحظات", selected.NOTES],
                ].map(([label, value]) => (
                  <div key={String(label)}>
                    <dt className="text-slate-500">{label}</dt>
                    <dd className="mt-1 whitespace-pre-wrap break-words">
                      {value == null || value === "" ? "—" : String(value)}
                    </dd>
                  </div>
                ))}
              </dl>
              <OracleEditButtons
                key={selectedKey}
                dataset={datasets[selected.LEVEL]}
                id={selected.ID}
                onSaved={refresh}
              />
            </>
          ) : (
            <div className="account-details-empty">
              <BookOpen className="mx-auto mb-3" />
              <p>اختر حسابًا من الشجرة لعرض التفاصيل</p>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
