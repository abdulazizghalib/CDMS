import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Clock } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { editDefinitions } from "@shared/oracleMutation";
import {
  oracleDatasets,
  oracleTableScreens,
  type OracleDataset,
} from "@shared/oracleWorkspace";
const roles = { admin: "مدير", editor: "محرر", viewer: "قارئ" };
function ErrorText({ message }: { message?: string }) {
  return message ? (
    <p role="alert" className="text-red-700 p-2">
      {message}
    </p>
  ) : null;
}
export function OracleAccount() {
  const utils = trpc.useUtils();
  const session = trpc.oracleOperations.session.useQuery(undefined, {
    retry: false,
  });
  const [username, setUsername] = useState(""),
    [displayName, setDisplayName] = useState(""),
    [password, setPassword] = useState("");
  const refresh = async () => {
    setPassword("");
    await utils.oracleOperations.invalidate();
  };
  const login = trpc.oracleOperations.login.useMutation({ onSuccess: refresh });
  const setup = trpc.oracleOperations.bootstrap.useMutation({
    onSuccess: refresh,
  });
  const logout = trpc.oracleOperations.logout.useMutation({
    onSuccess: refresh,
  });
  if (session.isLoading) return <p>جاري التحقق من الجلسة…</p>;
  if (session.isError)
    return (
      <ErrorText message="تعذر تحميل الدخول. يلزم تثبيت جداول إدارة العمليات والاتصال بـ Oracle." />
    );
  const actor = session.data?.actor;
  if (actor)
    return (
      <div className="flex flex-wrap gap-3 items-center">
        <strong>{actor.DISPLAY_NAME}</strong>
        <span>{roles[actor.ROLE]}</span>
        {actor.EXPIRES_AT && (
          <span className="dealer-trial-badge tone-trial">
            <Clock size={12} aria-hidden="true" />
            حساب تجريبي حتى {actor.EXPIRES_AT}
          </span>
        )}
        <Button
          variant="outline"
          onClick={() => logout.mutate()}
          disabled={logout.isPending}
        >
          تسجيل الخروج
        </Button>
        <ErrorText message={logout.error?.message} />
      </div>
    );
  const bootstrap = session.data?.canBootstrap;
  return (
    <form
      className="oracle-panel p-4 grid gap-3"
      onSubmit={e => {
        e.preventDefault();
        if (bootstrap) setup.mutate({ username, displayName, password });
        else login.mutate({ username, password });
      }}
    >
      <h2 className="font-bold">
        {bootstrap ? "إنشاء أول مدير للنظام" : "تسجيل الدخول لإدارة البيانات"}
      </h2>
      <p>
        {bootstrap
          ? "اختر حسابًا شخصيًا للمدير، ثم أضف حسابًا منفصلًا لكل موظف."
          : "تُنسب العمليات إلى حساب المستخدم المسجل دخوله."}
      </p>
      <div className="grid gap-3 sm:grid-cols-3">
        <label>
          اسم المستخدم
          <Input
            dir="ltr"
            autoComplete="username"
            required
            minLength={3}
            maxLength={50}
            value={username}
            onChange={e => setUsername(e.target.value)}
          />
        </label>
        {bootstrap && (
          <label>
            الاسم الظاهر
            <Input
              required
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              maxLength={100}
            />
          </label>
        )}
        <label>
          كلمة المرور
          <Input
            type="password"
            autoComplete={bootstrap ? "new-password" : "current-password"}
            required
            minLength={bootstrap ? 12 : 1}
            maxLength={128}
            value={password}
            onChange={e => setPassword(e.target.value)}
          />
        </label>
      </div>
      <ErrorText message={setup.error?.message ?? login.error?.message} />
      <Button
        className="w-fit"
        type="submit"
        disabled={login.isPending || setup.isPending}
      >
        {bootstrap ? "إنشاء حساب المدير" : "دخول"}
      </Button>
      {bootstrap && (
        <small>
          كلمة المرور 12 حرفًا على الأقل. لا تستخدم كلمة مرور قاعدة البيانات.
        </small>
      )}
    </form>
  );
}
/** Days granted by the standard admin-issued trial account. */
const trialDays = 30;
function trialState(u: { EXPIRES_AT?: string | null; EXPIRED?: number }) {
  if (!u.EXPIRES_AT) return { tone: "permanent", label: "دائم" };
  if (u.EXPIRED) return { tone: "expired", label: "منتهٍ " + u.EXPIRES_AT };
  return { tone: "trial", label: "تجريبي حتى " + u.EXPIRES_AT };
}
export function OracleUsers() {
  const utils = trpc.useUtils();
  const session = trpc.oracleOperations.session.useQuery();
  const users = trpc.oracleOperations.users.useQuery(undefined, {
    enabled: session.data?.actor?.ROLE === "admin",
    retry: false,
  });
  const [username, setUsername] = useState(""),
    [displayName, setDisplayName] = useState(""),
    [password, setPassword] = useState(""),
    [role, setRole] = useState<"admin" | "editor" | "viewer">("editor"),
    [accountType, setAccountType] = useState<"standard" | "trial">("standard"),
    [days, setDays] = useState(String(trialDays));
  const create = trpc.oracleOperations.addUser.useMutation({
    onSuccess: async () => {
      setUsername("");
      setDisplayName("");
      setPassword("");
      await utils.oracleOperations.users.invalidate();
    },
  });
  const active = trpc.oracleOperations.setUserActive.useMutation({
    onSuccess: () => utils.oracleOperations.users.invalidate(),
  });
  const trial = trpc.oracleOperations.setUserTrial.useMutation({
    onSuccess: () => utils.oracleOperations.users.invalidate(),
  });
  if (session.data?.actor?.ROLE !== "admin")
    return <p className="oracle-panel p-5">هذه الشاشة متاحة للمدير فقط.</p>;
  return (
    <section className="oracle-panel dealer-users p-5 space-y-4">
      <h2>المستخدمون والصلاحيات</h2>
      <div className="dealer-user-stats">
        {[
          ["إجمالي المستخدمين", users.data?.length],
          ["المديرون", users.data?.filter(u => u.ROLE === "admin").length],
          ["المحررون", users.data?.filter(u => u.ROLE === "editor").length],
          ["القراء", users.data?.filter(u => u.ROLE === "viewer").length],
        ].map(([label, value]) => (
          <div key={String(label)}>
            <span>{label}</span>
            <strong>{value ?? "—"}</strong>
          </div>
        ))}
      </div>
      <p>
        المدير: جميع العمليات والتقرير. المحرر: إضافة وتعديل. القارئ: عرض فقط.
      </p>
      <form
        onSubmit={e => {
          e.preventDefault();
          create.mutate({
            username,
            displayName,
            password,
            role,
            accountType,
            trialDays:
              accountType === "trial" ? Number(days) || trialDays : trialDays,
          });
        }}
        className="grid sm:grid-cols-2 gap-3"
      >
        <label>
          اسم المستخدم
          <Input
            required
            value={username}
            onChange={e => setUsername(e.target.value)}
            minLength={3}
            maxLength={50}
          />
        </label>
        <label>
          الاسم الظاهر
          <Input
            required
            value={displayName}
            onChange={e => setDisplayName(e.target.value)}
            maxLength={100}
          />
        </label>
        <label>
          كلمة المرور
          <Input
            type="password"
            autoComplete="new-password"
            required
            minLength={12}
            maxLength={128}
            value={password}
            onChange={e => setPassword(e.target.value)}
          />
        </label>
        <label>
          الصلاحية
          <select
            className="border rounded p-2 w-full"
            value={role}
            onChange={e => setRole(e.target.value as typeof role)}
          >
            {Object.entries(roles).map(([v, l]) => (
              <option key={v} value={v}>
                {l}
              </option>
            ))}
          </select>
        </label>
        <label>
          نوع الحساب
          <select
            className="border rounded p-2 w-full"
            value={accountType}
            onChange={e => setAccountType(e.target.value as typeof accountType)}
          >
            <option value="standard">دائم (بدون انتهاء)</option>
            <option value="trial">تجريبي محدد المدة</option>
          </select>
        </label>
        {accountType === "trial" && (
          <label>
            مدة التجربة (أيام)
            <Input
              type="number"
              min={1}
              max={365}
              step={1}
              required
              value={days}
              onChange={e => setDays(e.target.value)}
            />
          </label>
        )}
        <div className="flex items-end">
          <Button disabled={create.isPending}>
            {accountType === "trial" ? "إضافة حساب تجريبي" : "إضافة المستخدم"}
          </Button>
        </div>
      </form>
      <p className="dealer-trial-hint">
        <Clock size={14} aria-hidden="true" />
        ينتهي الحساب التجريبي تلقائيًا بعد المدة المحددة ({trialDays} يومًا
        افتراضيًا)، ويُرفض دخوله بعد ذلك حتى يجدده المدير من الجدول أدناه.
      </p>
      <ErrorText
        message={
          create.error?.message ??
          active.error?.message ??
          trial.error?.message ??
          users.error?.message
        }
      />
      <div className="oracle-table-scroll">
        <table>
          <thead>
            <tr>
              <th>الاسم</th>
              <th>المستخدم</th>
              <th>الصلاحية</th>
              <th>نوع الحساب</th>
              <th>الحالة</th>
              <th>الإجراء</th>
            </tr>
          </thead>
          <tbody>
            {users.data?.map(u => {
              const state = trialState(u);
              const busy =
                active.isPending ||
                trial.isPending ||
                u.ID === session.data?.actor?.ID;
              return (
                <tr key={u.ID}>
                  <td>{u.DISPLAY_NAME}</td>
                  <td>{u.USERNAME}</td>
                  <td>{roles[u.ROLE]}</td>
                  <td>
                    <span className={"dealer-trial-badge tone-" + state.tone}>
                      {state.label}
                    </span>
                  </td>
                  <td>{u.ACTIVE ? "نشط" : "معطل"}</td>
                  <td>
                    <div className="dealer-row-actions">
                      {u.EXPIRES_AT ? (
                        <>
                          <Button
                            variant="outline"
                            disabled={busy}
                            onClick={() =>
                              trial.mutate({ id: u.ID, days: trialDays })
                            }
                          >
                            تجديد {trialDays} يومًا
                          </Button>
                          <Button
                            variant="outline"
                            disabled={busy}
                            onClick={() => trial.mutate({ id: u.ID, days: 0 })}
                          >
                            جعله دائمًا
                          </Button>
                        </>
                      ) : (
                        <Button
                          variant="outline"
                          disabled={busy}
                          onClick={() =>
                            trial.mutate({ id: u.ID, days: trialDays })
                          }
                        >
                          تحويل إلى تجريبي
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        disabled={busy}
                        onClick={() =>
                          active.mutate({ id: u.ID, active: !u.ACTIVE })
                        }
                      >
                        {u.ACTIVE ? "تعطيل" : "تفعيل"}
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
export function OracleEditButtons({
  dataset,
  id,
  onSaved,
}: {
  dataset: OracleDataset;
  id?: number;
  onSaved: () => void;
}) {
  const session = trpc.oracleOperations.session.useQuery(undefined, {
    retry: false,
  });
  const def = editDefinitions[dataset];
  const actor = session.data?.actor;
  const [open, setOpen] = useState<"insert" | "update" | "delete" | null>(null);
  if (!def || !actor || actor.ROLE === "viewer") return null;
  return (
    <>
      <div className="flex gap-2">
        {id ? (
          <>
            <Button variant="outline" onClick={() => setOpen("update")}>
              تعديل
            </Button>
            {actor.ROLE === "admin" && (
              <Button variant="destructive" onClick={() => setOpen("delete")}>
                حذف
              </Button>
            )}
          </>
        ) : (
          <Button onClick={() => setOpen("insert")}>إضافة سجل</Button>
        )}
      </div>
      {open && (
        <Editor
          key={open + String(id)}
          dataset={dataset}
          id={id}
          action={open}
          close={() => setOpen(null)}
          saved={() => {
            setOpen(null);
            onSaved();
          }}
        />
      )}
    </>
  );
}
function Editor({
  dataset,
  id,
  action,
  close,
  saved,
}: {
  dataset: OracleDataset;
  id?: number;
  action: "insert" | "update" | "delete";
  close: () => void;
  saved: () => void;
}) {
  const def = editDefinitions[dataset];
  const parentLevel =
    dataset === "branchAccounts" ? 1 : dataset === "subAccounts" ? 2 : null;
  const parents = trpc.oracleOperations.accountTree.useQuery(undefined, {
    enabled: parentLevel !== null && action !== "delete",
    retry: false,
  });
  const [recordId, setRecordId] = useState(id ? String(id) : "");
  const [values, setValues] = useState<Record<string, string>>({}),
    [version, setVersion] = useState<string>(),
    [ready, setReady] = useState(action === "insert");
  const data = trpc.oracleOperations.record.useQuery(
    { dataset, id: id ?? 1 },
    {
      enabled: action !== "insert",
      retry: false,
      refetchOnMount: "always",
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
    }
  );
  const utils = trpc.useUtils();
  const mutation = trpc.oracleOperations.write.useMutation({
    onSuccess: async () => {
      await utils.oracleWorkspace.invalidate();
      await utils.oracleOperations.invalidate();
      saved();
    },
  });
  useEffect(() => {
    if (data.data && !data.isFetching && !ready) {
      setValues(
        Object.fromEntries(
          def.fields.map(f => [f.key, String(data.data.record[f.key] ?? "")])
        )
      );
      setVersion(data.data.version);
      setReady(true);
    }
  }, [data.data, data.isFetching, def, ready]);
  const labels = { insert: "إضافة", update: "تعديل", delete: "حذف" };
  return (
    <Dialog
      open
      onOpenChange={v => {
        if (!v && !mutation.isPending) close();
      }}
    >
      <DialogContent
        dir="rtl"
        className="dealer-record-dialog max-h-[90vh] overflow-y-auto sm:max-w-4xl"
      >
        <DialogHeader>
          <DialogTitle>
            {labels[action]} · {oracleDatasets[dataset].title} {id ?? ""}
          </DialogTitle>
          <DialogDescription>
            تُحفظ العملية باسم حسابك في سجل العمليات. الحقول بعلامة * مطلوبة.
          </DialogDescription>
        </DialogHeader>
        <form
          onSubmit={e => {
            e.preventDefault();
            if (!ready || mutation.isPending) return;
            mutation.mutate({
              dataset,
              action,
              id: recordId ? Number(recordId) : undefined,
              version,
              values: action === "delete" ? {} : values,
            });
          }}
          className="space-y-4"
        >
          {action === "delete" ? (
            <div>
              <p className="font-bold text-red-700">
                تأكيد حذف السجل رقم {id}؟
              </p>
              <p>
                سيبقى أثر الحذف والقيم السابقة في تقرير العمليات. يمنع النظام
                حذف السجلات ذات الارتباطات المحمية.
              </p>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {action === "insert" && def.manualId && (
                <label>
                  رقم الحساب *
                  <Input
                    type="number"
                    min={1}
                    step={1}
                    required
                    value={recordId}
                    onChange={e => setRecordId(e.target.value)}
                  />
                </label>
              )}
              {def.fields.map(f => (
                <label key={f.key}>
                  {f.label}
                  {f.required ? " *" : ""}
                  {parentLevel !== null &&
                  f.key === (parentLevel === 1 ? "AC_NUM" : "BAR_NUM") ? (
                    <>
                      <select
                        className="w-full border rounded-md p-2 bg-white"
                        aria-label={f.label}
                        required
                        value={values[f.key] ?? ""}
                        onChange={e =>
                          setValues(v => ({ ...v, [f.key]: e.target.value }))
                        }
                        disabled={
                          !ready ||
                          mutation.isPending ||
                          parents.isLoading ||
                          parents.isError
                        }
                      >
                        <option value="">اختر الحساب الأب</option>
                        {values[f.key] &&
                          !parents.data?.some(
                            p =>
                              p.LEVEL === parentLevel &&
                              String(p.ID) === values[f.key]
                          ) && (
                            <option value={values[f.key]}>
                              الحساب الحالي غير موجود: {values[f.key]}
                            </option>
                          )}
                        {parents.data
                          ?.filter(p => p.LEVEL === parentLevel)
                          .map(p => (
                            <option key={p.ID} value={p.ID}>
                              {p.ID} — {p.NAME}
                            </option>
                          ))}
                      </select>
                      {parents.isError && (
                        <p className="text-red-600 text-sm">
                          تعذر تحميل الحسابات الأب. أغلق النموذج وأعد المحاولة.
                        </p>
                      )}
                    </>
                  ) : (
                    <Input
                      type={f.type === "text" ? "text" : f.type}
                      step={
                        f.type === "number"
                          ? f.integer
                            ? 1
                            : "any"
                          : undefined
                      }
                      required={f.required}
                      value={values[f.key] ?? ""}
                      onChange={e =>
                        setValues(v => ({ ...v, [f.key]: e.target.value }))
                      }
                      disabled={!ready || mutation.isPending}
                    />
                  )}
                </label>
              ))}
            </div>
          )}
          <ErrorText message={data.error?.message ?? mutation.error?.message} />
          <div className="flex gap-2">
            <Button
              type="submit"
              variant={action === "delete" ? "destructive" : "default"}
              disabled={
                !ready ||
                mutation.isPending ||
                data.isError ||
                (parentLevel !== null &&
                  action !== "delete" &&
                  (parents.isLoading || parents.isError))
              }
            >
              {mutation.isPending
                ? "جاري الحفظ…"
                : action === "delete"
                  ? "تأكيد الحذف"
                  : "حفظ"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={close}
              disabled={mutation.isPending}
            >
              إلغاء
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
const tableLabels: Record<string, string> = {
  ...oracleTableScreens,
  TRAIL_BALANCE: "ميزان المراجعة",
  YOMIA_LEDGER: "دفتر اليومية",
  APP_USERS: "المستخدمون",
};
const actions: Record<string, string> = {
  INSERT: "إضافة",
  UPDATE: "تعديل",
  DELETE: "حذف",
};
export function OracleHistory() {
  const session = trpc.oracleOperations.session.useQuery();
  const [filters, setFilters] = useState({
    actor: "",
    table: "",
    recordId: "",
    action: "" as "" | "INSERT" | "UPDATE" | "DELETE",
    from: "",
    to: "",
  });
  const [applied, setApplied] = useState(filters),
    [page, setPage] = useState(1),
    [selected, setSelected] = useState<number | null>(null);
  const query = trpc.oracleOperations.history.useQuery(
    {
      ...applied,
      from: applied.from || undefined,
      to: applied.to || undefined,
      page,
    },
    { enabled: session.data?.actor?.ROLE === "admin", retry: false }
  );
  const detail = trpc.oracleOperations.historyDetail.useQuery(
    { id: selected ?? 1 },
    { enabled: selected !== null, retry: false }
  );
  if (session.data?.actor?.ROLE !== "admin")
    return (
      <p className="oracle-panel p-5">
        سجل الدخول بحساب مدير لعرض تقرير العمليات.
      </p>
    );
  const keys = Array.from(
    new Set([
      ...Object.keys(detail.data?.before ?? {}),
      ...Object.keys(detail.data?.after ?? {}),
    ])
  );
  return (
    <section className="oracle-panel dealer-history p-5 space-y-4">
      <h2 className="font-bold">تقرير الإضافة والتعديل والحذف</h2>
      <p>
        يشمل العمليات منذ تفعيل التدقيق. التوقيت: الرياض. العمليات من خارج
        التطبيق تعرض حساب قاعدة البيانات، ولا تثبت هوية الموظف.
      </p>
      <form
        className="grid gap-3 sm:grid-cols-3"
        onSubmit={e => {
          e.preventDefault();
          setApplied({ ...filters });
          setPage(1);
        }}
      >
        <label>
          المستخدم أو رقمه
          <Input
            value={filters.actor}
            onChange={e => setFilters({ ...filters, actor: e.target.value })}
          />
        </label>
        <label>
          العملية
          <select
            className="border rounded p-2 w-full"
            value={filters.action}
            onChange={e =>
              setFilters({
                ...filters,
                action: e.target.value as typeof filters.action,
              })
            }
          >
            <option value="">الكل</option>
            {Object.entries(actions).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </label>
        <label>
          الشاشة
          <select
            className="border rounded p-2 w-full"
            value={filters.table}
            onChange={e => setFilters({ ...filters, table: e.target.value })}
          >
            <option value="">كل الشاشات</option>
            {Object.entries(tableLabels).map(([key, label]) => (
              <option key={key} value={key}>
                {label}
              </option>
            ))}
          </select>
        </label>
        <label>
          رقم السجل
          <Input
            value={filters.recordId}
            onChange={e => setFilters({ ...filters, recordId: e.target.value })}
          />
        </label>
        <label>
          من تاريخ
          <Input
            type="date"
            value={filters.from}
            onChange={e => setFilters({ ...filters, from: e.target.value })}
          />
        </label>
        <label>
          إلى تاريخ
          <Input
            type="date"
            value={filters.to}
            onChange={e => setFilters({ ...filters, to: e.target.value })}
          />
        </label>
        <Button>عرض التقرير</Button>
        <Button
          type="button"
          variant="outline"
          onClick={() => void query.refetch()}
        >
          تحديث
        </Button>
      </form>
      <ErrorText message={query.error?.message} />
      <div className="oracle-table-scroll">
        <table>
          <thead>
            <tr>
              {[
                "الوقت",
                "المستخدم",
                "العملية",
                "الجدول",
                "السجل",
                "المصدر",
                "التفاصيل",
              ].map(x => (
                <th key={x}>{x}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {query.data?.rows.map(r => (
              <tr key={r.ID}>
                <td dir="ltr">{r.EVENT_AT}</td>
                <td>
                  {r.ACTOR_NAME} {r.ACTOR_ID ? "#" + r.ACTOR_ID : ""}
                </td>
                <td>{actions[String(r.ACTION)] ?? r.ACTION}</td>
                <td>{tableLabels[String(r.TABLE_NAME)] ?? r.TABLE_NAME}</td>
                <td>{r.RECORD_ID}</td>
                <td>
                  {r.SOURCE === "DEALER_WEB"
                    ? "النظام"
                    : "اتصال مباشر: " + r.DB_USER}
                </td>
                <td>
                  <Button
                    variant="outline"
                    onClick={() => setSelected(Number(r.ID))}
                  >
                    قبل / بعد
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!query.isLoading && !query.isError && !query.data?.total && (
        <p>لا توجد عمليات مطابقة.</p>
      )}
      <div className="flex gap-3 items-center">
        <span>
          {query.data?.total ?? 0} عملية · صفحة {page}
        </span>
        <Button
          variant="outline"
          disabled={page === 1 || query.isFetching}
          onClick={() => setPage(p => p - 1)}
        >
          السابق
        </Button>
        <Button
          variant="outline"
          disabled={page * 25 >= (query.data?.total ?? 0) || query.isFetching}
          onClick={() => setPage(p => p + 1)}
        >
          التالي
        </Button>
      </div>
      <Dialog
        open={selected !== null}
        onOpenChange={v => !v && setSelected(null)}
      >
        <DialogContent
          dir="rtl"
          className="dealer-record-dialog max-h-[90vh] overflow-y-auto sm:max-w-5xl"
        >
          <DialogHeader>
            <DialogTitle>تفاصيل العملية {selected}</DialogTitle>
            <DialogDescription>
              القيم المخزنة قبل العملية وبعدها؛ حقول المرفقات الثنائية غير
              مشمولة.
            </DialogDescription>
          </DialogHeader>
          <ErrorText message={detail.error?.message} />
          {detail.isLoading ? (
            <p>جاري التحميل…</p>
          ) : (
            <div className="oracle-table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>الحقل</th>
                    <th>قبل</th>
                    <th>بعد</th>
                  </tr>
                </thead>
                <tbody>
                  {keys.map(k => (
                    <tr
                      key={k}
                      className={
                        JSON.stringify(detail.data?.before?.[k]) !==
                        JSON.stringify(detail.data?.after?.[k])
                          ? "bg-amber-50"
                          : ""
                      }
                    >
                      <td>
                        {Object.values(editDefinitions)
                          .flatMap(d => d.fields)
                          .find(f => f.key === k)?.label ?? k}
                      </td>
                      <td>{String(detail.data?.before?.[k] ?? "—")}</td>
                      <td>{String(detail.data?.after?.[k] ?? "—")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
