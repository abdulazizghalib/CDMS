import { useState } from "react";
import { BookOpen, Search } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { money } from "@/lib/dealerPresentation";
import { journalReportInput } from "@shared/accountStatement";
export function DealerDailyJournal() {
  const today = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Riyadh",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
  const [date1, setDate1] = useState(today.slice(0, 7) + "-01"),
    [date2, setDate2] = useState(today),
    [error, setError] = useState("");
  const [request, setRequest] = useState<{ date1: string; date2: string }>({
    date1: today.slice(0, 7) + "-01",
    date2: today,
  });
  const query = trpc.oracleOperations.dailyJournal.useQuery(
    request ?? { date1: today, date2: today },
    { enabled: !!request, retry: false }
  );
  const data = query.data;
  return (
    <div className="space-y-5" dir="rtl">
      <section className="oracle-panel p-6">
        <h2 className="font-bold text-xl flex items-center gap-2">
          <BookOpen className="text-amber-600" />
          دفتر اليومية
        </h2>
        <p className="text-sm text-slate-500 mt-2 mb-5">
          جميع الحركات المحاسبية للحسابات خلال الفترة المحددة، مرتبة بالتاريخ
          ورقم الحركة.
        </p>
        <form
          aria-label="فترة دفتر اليومية"
          className="grid sm:grid-cols-3 gap-4 items-end"
          onSubmit={e => {
            e.preventDefault();
            const parsed = journalReportInput.safeParse({ date1, date2 });
            if (!parsed.success) {
              setError(parsed.error.issues[0].message);
              return;
            }
            setError("");
            setRequest(parsed.data);
            if (JSON.stringify(request) === JSON.stringify(parsed.data))
              void query.refetch();
          }}
        >
          <label className="block space-y-2">
            من تاريخ
            <Input
              type="date"
              required
              dir="ltr"
              value={date1}
              onChange={e => setDate1(e.target.value)}
            />
          </label>
          <label className="block space-y-2">
            إلى تاريخ
            <Input
              type="date"
              required
              dir="ltr"
              value={date2}
              onChange={e => setDate2(e.target.value)}
            />
          </label>
          <Button disabled={query.isFetching}>
            <Search size={16} />
            {query.isFetching ? "جارٍ التحميل…" : "عرض دفتر اليومية"}
          </Button>
        </form>
        {(error || query.isError) && (
          <p role="alert" className="mt-4 text-red-600">
            {error || query.error?.message}
          </p>
        )}
      </section>
      {data && !query.isError && (
        <>
          <section className="oracle-panel p-5">
            <h3 className="font-bold">
              الفترة: {data.date1} إلى {data.date2}
            </h3>
            <h4 className="font-bold mt-5 text-amber-800">الإجمالي والصافي</h4>
            <div className="grid sm:grid-cols-4 gap-4 mt-4">
              {[
                ["عدد الحركات", data.lines.length],
                ["إجمالي المدين", data.debit],
                ["إجمالي الدائن", data.credit],
                ["الصافي (مدين − دائن)", data.difference],
              ].map(([label, v], i) => (
                <div key={String(label)} className="rounded-xl bg-slate-50 p-4">
                  <small className="text-slate-500">{label}</small>
                  <strong className="block text-lg mt-2">
                    {i === 0 ? String(v) : money(v)}
                  </strong>
                </div>
              ))}
            </div>
          </section>
          <section className="oracle-panel overflow-auto max-h-[65vh]">
            <table className="w-full text-sm text-right">
              <thead className="sticky top-0 bg-slate-100">
                <tr>
                  {[
                    "#",
                    "رقم الحركة",
                    "التاريخ",
                    "رقم الحساب",
                    "اسم الحساب",
                    "البيان",
                    "المصدر",
                    "مدين",
                    "دائن",
                    "نوع المستند",
                    "رقم المستند",
                  ].map(h => (
                    <th key={h} className="p-3 whitespace-nowrap">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.lines.map((r, i) => (
                  <tr key={r.AL_ID} className="border-b odd:bg-slate-50">
                    <td className="p-3">{i + 1}</td>
                    <td className="p-3">{r.AL_ID}</td>
                    <td className="p-3 whitespace-nowrap" dir="ltr">
                      {r.AL_DATE}
                    </td>
                    <td className="p-3">{r.AL_ACC_NO ?? "—"}</td>
                    <td className="p-3 min-w-40">{r.AL_ACC_NAME ?? "—"}</td>
                    <td className="p-3 min-w-64">{r.AL_EXP ?? "—"}</td>
                    <td className="p-3 whitespace-nowrap">
                      {r.AL_SOURCE ?? "—"}
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      {money(r.AL_DEPIT_MOUNT)}
                    </td>
                    <td className="p-3 whitespace-nowrap">
                      {money(r.AL_CREDIT_MOUNT)}
                    </td>
                    <td className="p-3">{r.AL_DOC_TYPE ?? "—"}</td>
                    <td className="p-3">{r.AL_DOC_ID ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="sticky bottom-0 bg-slate-100 font-bold">
                <tr>
                  <td colSpan={7} className="p-3">
                    الإجمالي
                  </td>
                  <td className="p-3 whitespace-nowrap">{money(data.debit)}</td>
                  <td className="p-3 whitespace-nowrap">
                    {money(data.credit)}
                  </td>
                  <td colSpan={2} />
                </tr>
                <tr className="bg-amber-50 border-t border-amber-200">
                  <td colSpan={7} className="p-3">
                    الصافي (إجمالي المدين − إجمالي الدائن)
                  </td>
                  <td
                    colSpan={4}
                    className="p-3 whitespace-nowrap text-amber-900"
                  >
                    {money(data.difference)}
                    <span className="text-xs font-normal mr-2">
                      {data.difference === 0
                        ? "متوازن"
                        : data.difference > 0
                          ? "مدين"
                          : "دائن"}
                    </span>
                  </td>
                </tr>
              </tfoot>
            </table>
            {data.lines.length === 0 && (
              <p className="text-center py-8 text-slate-500">
                لا توجد حركات خلال الفترة المحددة
              </p>
            )}
          </section>
          <section
            aria-label="الإجمالي والصافي لدفتر اليومية"
            className="oracle-panel border-amber-200 bg-amber-50 p-5"
          >
            <h3 className="font-bold text-amber-900 mb-4">الإجمالي والصافي</h3>
            <div className="grid sm:grid-cols-3 gap-4">
              <div>
                <small>إجمالي المدين</small>
                <strong className="block mt-2 text-lg">
                  {money(data.debit)}
                </strong>
              </div>
              <div>
                <small>إجمالي الدائن</small>
                <strong className="block mt-2 text-lg">
                  {money(data.credit)}
                </strong>
              </div>
              <div>
                <small>الصافي (مدين − دائن)</small>
                <strong className="block mt-2 text-lg">
                  {money(data.difference)}
                </strong>
                <span className="text-xs">
                  {data.difference === 0
                    ? "متوازن"
                    : data.difference > 0
                      ? "مدين"
                      : "دائن"}
                </span>
              </div>
            </div>
          </section>
        </>
      )}
      {!request && (
        <p className="oracle-panel p-12 text-center text-slate-500">
          حدد الفترة ثم اضغط «عرض دفتر اليومية»
        </p>
      )}
    </div>
  );
}
