import { useState, type ReactNode } from "react";
import {
  Car,
  Search,
  SlidersHorizontal,
  Grid2X2,
  List,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Copy,
  CalendarDays,
  Palette,
  Hash,
  ShoppingCart,
  FileText,
  RefreshCw,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { OracleRow } from "@shared/oracleWorkspace";
import {
  carImage,
  postingLabel,
  number,
  money,
  type NavigateDealer,
} from "@/lib/dealerPresentation";
export function VehicleCard({
  row,
  onOpen,
  compact = false,
}: {
  row: OracleRow;
  onOpen: () => void;
  compact?: boolean;
}) {
  return (
    <button
      type="button"
      className={"dealer-car-card" + (compact ? " compact" : "")}
      onClick={onOpen}
      aria-label={"عرض السيارة " + row.ID}
    >
      <div className="dealer-car-image">
        <img
          src={carImage(row)}
          alt="صورة سيارة توضيحية مولّدة"
          loading="lazy"
          width={1536}
          height={1024}
        />
        <span
          className={
            "dealer-car-status " +
            (String(row.STATUS).trim().toLowerCase() === "posted"
              ? "posted"
              : "unposted")
          }
        >
          {postingLabel(row.STATUS)}
        </span>
        <span className="dealer-photo-badge">صورة توضيحية</span>
      </div>
      <div className="dealer-car-body">
        <h3>
          {row.CAR ?? "سيارة"} <span>{row.MODEL}</span>
        </h3>
        <p className="dealer-car-meta">
          <span>
            <CalendarDays size={12} />
            {row.MODEL ?? "—"}
          </span>
          <span>
            <Palette size={12} />
            {row.COLOR ?? "غير مسجل"}
          </span>
        </p>
        <div className="dealer-car-prices">
          <span>
            <small>تكلفة الشراء</small>
            <strong>{money(row.PURCHASE_COST)}</strong>
          </span>
          {!compact && (
            <span>
              <small>سعر البيع المسجل</small>
              <strong className="teal-text">{money(row.SALE_PRICE)}</strong>
            </span>
          )}
        </div>
        <div className="dealer-car-footer">
          <span>{row.PLATE ?? "لوحة غير مسجلة"}</span>
          <small>#{row.ID}</small>
        </div>
      </div>
    </button>
  );
}
export function VehicleDetail({
  row,
  onBack,
  navigate,
}: {
  row: OracleRow;
  onBack: () => void;
  navigate: NavigateDealer;
}) {
  const actor = trpc.oracleOperations.session.useQuery().data?.actor;
  const [tab, setTab] = useState("specs"),
    [copied, setCopied] = useState(false),
    [copyError, setCopyError] = useState("");
  const fields =
    tab === "specs"
      ? [
          ["نوع السيارة", row.CAR],
          ["الموديل", row.MODEL],
          ["اللون", row.COLOR],
          ["اللوحة", row.PLATE],
          ["رقم الهيكل", row.VIN],
          ["تاريخ الدخول", row.DATE],
        ]
      : tab === "financial"
        ? [
            ["فاتورة الشراء", row.PURCHASE_INVOICE_ID],
            ["المورد", row.SUPPLIER],
            ["تكلفة الشراء", money(row.PURCHASE_COST)],
            ["سعر البيع المسجل", money(row.SALE_PRICE)],
            ["بنود البيع المرتبطة", row.SOLD_LINES],
            ["حالة الترحيل", postingLabel(row.STATUS)],
          ]
        : [["ملاحظات السيارة", row.NOTES]];
  return (
    <section className="dealer-vehicle-detail">
      <div className="dealer-detail-heading">
        <div>
          <span>مخزون السيارات / تفاصيل السيارة</span>
          <h2>
            {row.CAR ?? "تفاصيل السيارة"} {row.MODEL}
          </h2>
        </div>
        <Button variant="outline" onClick={onBack}>
          <ArrowRight size={16} />
          عودة إلى القائمة
        </Button>
      </div>
      <div className="dealer-detail-hero">
        <div className="dealer-detail-facts oracle-panel">
          <div className="dealer-panel-title">
            <h3>
              {row.CAR} {row.MODEL}
            </h3>
            <span className="dealer-pill">{postingLabel(row.STATUS)}</span>
          </div>
          <p>
            {row.COLOR ?? "لون غير مسجل"} · السيارة #{row.ID}
          </p>
          <dl>
            {[
              ["الموديل", row.MODEL, CalendarDays],
              ["اللوحة", row.PLATE, Hash],
              ["رقم الهيكل", row.VIN, Car],
              ["تاريخ الدخول", row.DATE, CalendarDays],
              ["تكلفة الشراء", money(row.PURCHASE_COST), ShoppingCart],
              ["سعر البيع المسجل", money(row.SALE_PRICE), FileText],
            ].map(([label, value, Icon]) => {
              const FieldIcon = Icon as typeof Car;
              return (
                <div key={String(label)}>
                  <dt>
                    <FieldIcon size={15} />
                    {String(label)}
                  </dt>
                  <dd>{value == null ? "غير مسجل" : String(value)}</dd>
                </div>
              );
            })}
          </dl>
          <div className="dealer-detail-actions">
            {(actor?.ROLE === "admin" || actor?.ROLE === "editor") &&
              row.STATUS === "unposted" &&
              !Number(row.SOLD_LINES) && (
                <Button
                  onClick={() =>
                    navigate("reservations", { vehicleId: Number(row.ID) })
                  }
                >
                  <CalendarDays size={15} />
                  حجز السيارة
                </Button>
              )}
            <Button
              className="dealer-gold-button"
              onClick={() =>
                navigate("purchases", {
                  search: String(row.PURCHASE_INVOICE_ID ?? ""),
                })
              }
            >
              <ShoppingCart size={15} />
              عرض فاتورة الشراء
            </Button>
            <Button
              variant="outline"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(window.location.href);
                  setCopied(true);
                  setCopyError("");
                } catch {
                  setCopyError("تعذر النسخ؛ يمكنك نسخ الرابط من شريط العنوان.");
                }
              }}
            >
              <Copy size={15} />
              {copied ? "تم نسخ الرابط" : "نسخ رابط السيارة"}
            </Button>
          </div>
          {copyError && <p role="status">{copyError}</p>}
        </div>
        <figure className="dealer-detail-photo">
          <img
            src={carImage(row)}
            alt="صورة توضيحية مولّدة للعرض وليست صورة السيارة المسجلة"
          />
          <figcaption>
            صورة توضيحية مولّدة · ليست صورة السيارة المسجلة
          </figcaption>
        </figure>
      </div>
      <section className="oracle-panel">
        <div className="dealer-tabs" role="tablist" aria-label="تفاصيل السيارة">
          {[
            ["specs", "المواصفات"],
            ["financial", "الشراء والبيع"],
            ["notes", "الملاحظات"],
          ].map(([key, label]) => (
            <button
              id={"vehicle-tab-" + key}
              role="tab"
              aria-selected={tab === key}
              aria-controls="vehicle-tab-panel"
              key={key}
              className={tab === key ? "active" : ""}
              onClick={() => setTab(key)}
            >
              {label}
            </button>
          ))}
        </div>
        <dl
          className="dealer-spec-grid"
          id="vehicle-tab-panel"
          role="tabpanel"
          aria-labelledby={"vehicle-tab-" + tab}
        >
          {fields.map(([label, value]) => (
            <div key={String(label)}>
              <dt>{label}</dt>
              <dd>
                {value == null || value === "" ? "غير مسجل" : String(value)}
              </dd>
            </div>
          ))}
        </dl>
      </section>
    </section>
  );
}
export function DealerInventory({
  navigate,
  initialSearch = "",
  initialVehicleId,
}: {
  navigate: NavigateDealer;
  initialSearch?: string;
  initialVehicleId?: number;
}) {
  const [search, setSearch] = useState(initialSearch),
    [draft, setDraft] = useState(initialSearch),
    [page, setPage] = useState(1),
    [layout, setLayout] = useState<"grid" | "table">("grid");
  const [vehicleType, setVehicleType] = useState(""),
    [model, setModel] = useState(""),
    [posting, setPosting] = useState<"" | "posted" | "unposted">(""),
    [sort, setSort] = useState<"newest" | "costAsc" | "costDesc">("newest"),
    [selectedId, setSelectedId] = useState<number | null>(
      initialVehicleId ?? null
    );
  const options = trpc.oracleWorkspace.inventoryOptions.useQuery(undefined, {
    retry: false,
  });
  const summary = trpc.oracleWorkspace.summary.useQuery(undefined, {
    retry: false,
  });
  const query = trpc.oracleWorkspace.table.useQuery(
    {
      dataset: "inventory",
      search,
      page,
      pageSize: layout === "grid" ? 8 : 25,
      vehicleType: vehicleType || undefined,
      model: model || undefined,
      posting: posting || undefined,
      inventorySort: sort,
    },
    { retry: false }
  );
  const detail = trpc.oracleWorkspace.table.useQuery(
    { dataset: "inventory", recordId: selectedId ?? undefined, pageSize: 8 },
    { enabled: selectedId !== null, retry: false }
  );
  const select = (id: number | null) => {
    setSelectedId(id);
    const url = new URL(window.location.href);
    if (id) url.searchParams.set("vehicleId", String(id));
    else url.searchParams.delete("vehicleId");
    window.history.replaceState(null, "", url);
    window.scrollTo({ top: 0, behavior: "instant" });
  };
  if (selectedId !== null) {
    if (detail.isLoading)
      return (
        <div className="oracle-panel dealer-loading">
          جاري تحميل بيانات السيارة…
        </div>
      );
    if (detail.isError || !detail.data?.rows[0])
      return (
        <div className="oracle-panel p-5" role="alert">
          <p>تعذر تحميل السيارة أو لم تعد موجودة.</p>
          <Button onClick={() => select(null)}>عودة للمخزون</Button>
        </div>
      );
    return (
      <VehicleDetail
        key={selectedId}
        row={detail.data.rows[0]}
        onBack={() => select(null)}
        navigate={navigate}
      />
    );
  }
  const total = query.data?.total ?? 0,
    size = layout === "grid" ? 8 : 25,
    pages = Math.max(1, Math.ceil(total / size));
  const stateTotal = (value: string) =>
    summary.data?.states
      .filter(r => r.STATUS === value)
      .reduce((a, r) => a + Number(r.TOTAL), 0) ?? 0;
  return (
    <section className="dealer-inventory">
      <div className="dealer-inventory-overview">
        <div>
          <span>
            <Car size={17} />
            إجمالي السيارات
          </span>
          <strong>{number(summary.data?.totals.VEHICLES)}</strong>
        </div>
        <div>
          <span>
            <i className="dealer-dot teal" />
            مرحّل
          </span>
          <strong>{number(stateTotal("posted"))}</strong>
        </div>
        <div>
          <span>
            <i className="dealer-dot gold" />
            غير مرحّل
          </span>
          <strong>{number(stateTotal("unposted"))}</strong>
        </div>
        <Button onClick={() => navigate("purchases")}>
          <ShoppingCart size={16} />
          عرض المشتريات
        </Button>
      </div>
      <div className="oracle-panel dealer-inventory-content">
        <form
          className="dealer-inventory-filters"
          onSubmit={e => {
            e.preventDefault();
            setSearch(draft.trim());
            setPage(1);
          }}
        >
          <label className="dealer-input-icon">
            <Search size={16} />
            <Input
              aria-label="البحث في مخزون السيارات"
              placeholder="ابحث عن سيارة أو لوحة…"
              value={draft}
              onChange={e => setDraft(e.target.value)}
            />
          </label>
          <select
            aria-label="نوع السيارة"
            value={vehicleType}
            onChange={e => {
              setVehicleType(e.target.value);
              setPage(1);
            }}
          >
            <option value="">كل الأنواع</option>
            {options.data?.types.map(v => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
          <select
            aria-label="الموديل"
            value={model}
            onChange={e => {
              setModel(e.target.value);
              setPage(1);
            }}
          >
            <option value="">كل الموديلات</option>
            {options.data?.models.map(v => (
              <option key={v} value={v}>
                {v}
              </option>
            ))}
          </select>
          <select
            aria-label="حالة الترحيل"
            value={posting}
            onChange={e => {
              setPosting(e.target.value as typeof posting);
              setPage(1);
            }}
          >
            <option value="">كل حالات الترحيل</option>
            <option value="posted">مرحّل</option>
            <option value="unposted">غير مرحّل</option>
          </select>
          <select
            aria-label="ترتيب السيارات"
            value={sort}
            onChange={e => {
              setSort(e.target.value as typeof sort);
              setPage(1);
            }}
          >
            <option value="newest">الأحدث أولًا</option>
            <option value="costAsc">التكلفة: الأقل أولًا</option>
            <option value="costDesc">التكلفة: الأعلى أولًا</option>
          </select>
          <Button type="submit">
            <SlidersHorizontal size={15} />
            بحث
          </Button>
        </form>
        <div className="dealer-inventory-tools">
          <p>الصور توضيحية مولّدة · حالة الترحيل لا تعني اكتمال البيع</p>
          <div>
            <button
              title="تحديث"
              aria-label="تحديث المخزون"
              onClick={() => void query.refetch()}
            >
              <RefreshCw size={16} />
            </button>
            <button
              title="مسح المرشحات"
              onClick={() => {
                setDraft("");
                setSearch("");
                setVehicleType("");
                setModel("");
                setPosting("");
                setSort("newest");
                setPage(1);
              }}
            >
              مسح المرشحات
            </button>
            <button
              aria-label="عرض البطاقات"
              aria-pressed={layout === "grid"}
              onClick={() => {
                setLayout("grid");
                setPage(1);
              }}
            >
              <Grid2X2 size={16} />
            </button>
            <button
              aria-label="عرض الجدول"
              aria-pressed={layout === "table"}
              onClick={() => {
                setLayout("table");
                setPage(1);
              }}
            >
              <List size={16} />
            </button>
          </div>
        </div>
        {query.isLoading ? (
          <div className="dealer-loading">جاري تحميل السيارات…</div>
        ) : query.isError ? (
          <div role="alert" className="dealer-loading">
            تعذر تحميل المخزون{" "}
            <Button onClick={() => void query.refetch()}>إعادة المحاولة</Button>
          </div>
        ) : total === 0 ? (
          <div className="oracle-empty">
            <Car size={36} />
            <h3>لا توجد نتائج مطابقة</h3>
            <p>جرّب اسمًا آخر أو امسح المرشحات.</p>
          </div>
        ) : layout === "grid" ? (
          <div className="dealer-inventory-grid">
            {query.data?.rows.map(row => (
              <VehicleCard
                key={row.ID}
                row={row}
                onOpen={() => select(Number(row.ID))}
              />
            ))}
          </div>
        ) : (
          <div className="oracle-table-scroll dealer-inventory-table">
            <table>
              <thead>
                <tr>
                  {[
                    "السيارة",
                    "الموديل",
                    "اللوحة",
                    "تكلفة الشراء",
                    "الترحيل",
                    "التفاصيل",
                  ].map(v => (
                    <th key={v}>{v}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {query.data?.rows.map(row => (
                  <tr key={row.ID}>
                    <td>
                      <div className="dealer-table-car">
                        <img src={carImage(row)} alt="صورة توضيحية مولّدة" />
                        {row.CAR}
                      </div>
                    </td>
                    <td>{row.MODEL}</td>
                    <td>{row.PLATE}</td>
                    <td>{money(row.PURCHASE_COST)}</td>
                    <td>{postingLabel(row.STATUS)}</td>
                    <td>
                      <button
                        className="oracle-row-action"
                        onClick={() => select(Number(row.ID))}
                      >
                        عرض <ChevronLeft size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <div className="oracle-pagination">
          <span>
            {total
              ? (page - 1) * size + 1 + " – " + Math.min(page * size, total)
              : 0}{" "}
            من {number(total)} سيارة
          </span>
          <div>
            <Button
              variant="outline"
              aria-label="الصفحة السابقة"
              disabled={page === 1 || query.isFetching}
              onClick={() => setPage(p => p - 1)}
            >
              <ChevronRight size={16} />
            </Button>
            <span>
              {page} / {pages}
            </span>
            <Button
              variant="outline"
              aria-label="الصفحة التالية"
              disabled={page >= pages || query.isFetching}
              onClick={() => setPage(p => p + 1)}
            >
              <ChevronLeft size={16} />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
