import {
  EmployeeAttendance,
  AttendanceSettings,
  AttendanceReport,
} from "./DealerAttendance";
import { VoucherButton } from "@/components/OracleVoucherForm";
import { DealerTrialBalance } from "./DealerTrialBalance";
import { DealerDailyJournal } from "./DealerDailyJournal";
import { DealerAccountStatement } from "./DealerAccountStatement";
import { DealerAccountTree } from "./DealerAccountTree";
import { DealerActivities } from "./DealerActivities";
import { DealerLogo, DealerName } from "@/components/DealerBranding";
import { InvoicePrintButton } from "@/components/InvoicePrint";
import { PurchaseInvoiceButton } from "@/components/PurchaseInvoiceForm";
import { SalesInvoiceButton } from "@/components/SalesInvoiceForm";
import {
  OracleAccount,
  OracleUsers,
  OracleHistory,
  OracleEditButtons,
} from "./OracleOperations";
import { useState, useEffect, useRef, type ReactNode } from "react";
import {
  DealerOverview,
  DealerReports,
  DealerSettings,
} from "./DealerOverview";
import { DealerInventory } from "./DealerInventory";
import {
  number,
  carImage,
  type DealerView,
  type NavigateDealer,
} from "@/lib/dealerPresentation";
import {
  Wrench,
  ChartNoAxesCombined,
  Settings2,
  Shield,
  Bell,
  ChevronDown,
  CalendarDays,
  UserRound,
} from "lucide-react";
import {
  Car,
  LayoutDashboard,
  ShoppingCart,
  ReceiptText,
  UsersRound,
  BookOpen,
  ArrowDownToLine,
  ArrowUpFromLine,
  ShieldCheck,
  Search,
  RefreshCw,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  Database,
  FileText,
  Landmark,
  Truck,
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import {
  oracleDatasets,
  type OracleDataset,
  type OracleRow,
} from "@shared/oracleWorkspace";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
type View = DealerView;
const navigation: {
  id: View;
  label: string;
  icon: typeof Car;
  group: string;
}[] = [
  {
    id: "attendanceSettings",
    label: "الورديات وإسناد الموظفين",
    icon: CalendarDays,
    group: "النظام",
  },
  {
    id: "attendanceReport",
    label: "تقرير الحضور",
    icon: UsersRound,
    group: "التقارير",
  },
  { id: "balanceSheet", label: "الميزانية", icon: BookOpen, group: "التقارير" },
  {
    id: "incomeStatement",
    label: "قائمة الدخل",
    icon: BookOpen,
    group: "التقارير",
  },
  {
    id: "trialBalance",
    label: "ميزان المراجعة",
    icon: BookOpen,
    group: "التقارير",
  },
  {
    id: "dailyJournal",
    label: "دفتر اليومية",
    icon: BookOpen,
    group: "التقارير",
  },
  {
    id: "accountStatement",
    label: "كشف حساب",
    icon: FileText,
    group: "التقارير",
  },
  {
    id: "history",
    label: "تقرير العمليات",
    icon: ShieldCheck,
    group: "النظام",
  },
  {
    id: "users",
    label: "المستخدمون والصلاحيات",
    icon: UsersRound,
    group: "النظام",
  },
  {
    id: "mainAccounts",
    label: "حسابات المستوى الأول",
    icon: BookOpen,
    group: "تعريفات النظام",
  },
  {
    id: "branchAccounts",
    label: "حسابات المستوى الثاني",
    icon: BookOpen,
    group: "تعريفات النظام",
  },
  {
    id: "subAccounts",
    label: "حسابات المستوى الثالث",
    icon: BookOpen,
    group: "تعريفات النظام",
  },
  {
    id: "accountDirectory",
    label: "دليل الحسابات",
    icon: BookOpen,
    group: "تعريفات النظام",
  },
  {
    id: "costCenters",
    label: "مراكز التكلفة",
    icon: BookOpen,
    group: "تعريفات النظام",
  },
  {
    id: "dashboard",
    label: "نظرة عامة",
    icon: LayoutDashboard,
    group: "إدارة المعرض",
  },
  {
    id: "inventory",
    label: "مخزون السيارات",
    icon: Car,
    group: "إدارة المعرض",
  },
  {
    id: "reservations",
    label: "حجوزات السيارات",
    icon: CalendarDays,
    group: "إدارة المعرض",
  },
  {
    id: "followups",
    label: "مواعيد المتابعة",
    icon: CalendarDays,
    group: "إدارة المعرض",
  },
  { id: "sales", label: "المبيعات", icon: ReceiptText, group: "إدارة المعرض" },
  {
    id: "purchases",
    label: "المشتريات",
    icon: ShoppingCart,
    group: "إدارة المعرض",
  },
  {
    id: "customers",
    label: "العملاء",
    icon: UsersRound,
    group: "إدارة المعرض",
  },
  { id: "suppliers", label: "الموردون", icon: Truck, group: "إدارة المعرض" },
  { id: "contracts", label: "العقود", icon: FileText, group: "إدارة المعرض" },
  {
    id: "entries",
    label: "دخول السيارات",
    icon: ArrowDownToLine,
    group: "حركة السيارات",
  },
  {
    id: "deliveries",
    label: "خروج السيارات",
    icon: ArrowUpFromLine,
    group: "حركة السيارات",
  },
  { id: "stock", label: "سجل المخزون", icon: Car, group: "حركة السيارات" },
  {
    id: "expenses",
    label: "سندات الصرف",
    icon: ArrowUpFromLine,
    group: "الحسابات",
  },
  {
    id: "receipts",
    label: "سندات القبض",
    icon: ArrowDownToLine,
    group: "الحسابات",
  },
  { id: "journal", label: "سندات القيد", icon: BookOpen, group: "الحسابات" },
  { id: "ledger", label: "دفتر الأستاذ", icon: Landmark, group: "الحسابات" },
  {
    id: "audit",
    label: "سلامة قاعدة البيانات",
    icon: ShieldCheck,
    group: "النظام",
  },
];
const moneyKeys = new Set([
  "TOTAL",
  "VAT",
  "COST",
  "PURCHASE_COST",
  "PRICE",
  "PAID",
  "REMAINING",
  "DEBIT",
  "CREDIT",
  "PRICE_IN",
  "PRICE_OUT",
  "AMOUNT",
]);
function display(value: string | number | null | undefined, key = "") {
  if (value === null || value === undefined || value === "") return "غير مسجل";
  if (typeof value === "number")
    return (
      new Intl.NumberFormat("ar-SA", { maximumFractionDigits: 2 }).format(
        value
      ) + (moneyKeys.has(key) ? " ر.س" : "")
    );
  return value;
}
function Failure({ retry }: { retry: () => void }) {
  return (
    <div className="oracle-empty" role="alert">
      <Database size={32} />
      <h3>تعذر تحميل البيانات</h3>
      <p>تحقق من اتصال Oracle أو صلاحية الوصول. يمكنك المحاولة مجدداً.</p>
      <Button variant="outline" onClick={retry}>
        إعادة المحاولة
      </Button>
    </div>
  );
}
function Loading() {
  return (
    <div className="oracle-empty" role="status">
      <RefreshCw className="animate-spin" size={26} />
      <p>جاري قراءة السجلات…</p>
    </div>
  );
}
const primaryNavigation: { id: View; label: string; icon: typeof Car }[] = [
  { id: "dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
  { id: "inventory", label: "مخزون السيارات", icon: Car },
  { id: "reservations", label: "حجوزات السيارات", icon: CalendarDays },
  { id: "followups", label: "مواعيد المتابعة", icon: CalendarDays },
  { id: "sales", label: "المبيعات", icon: ReceiptText },
  { id: "customers", label: "العملاء", icon: UsersRound },
  { id: "purchases", label: "المشتريات", icon: ShoppingCart },
  { id: "attendance", label: "الحضور والانصراف", icon: CalendarDays },
  { id: "vouchers", label: "السندات", icon: FileText },
  { id: "reports", label: "التقارير", icon: ChartNoAxesCombined },
  { id: "settings", label: "الإعدادات", icon: Settings2 },
];
const children: Partial<Record<View, View[]>> = {
  inventory: ["entries", "deliveries", "stock"],
  sales: ["contracts"],
  purchases: ["suppliers"],
  vouchers: ["receipts", "expenses", "journal"],
  reports: [
    "attendanceReport",
    "balanceSheet",
    "incomeStatement",
    "trialBalance",
    "dailyJournal",
    "accountStatement",
    "ledger",
    "history",
  ],
  settings: [
    "attendanceSettings",
    "costCenters",
    "users",
    "accountDirectory",
    "mainAccounts",
    "branchAccounts",
    "subAccounts",
    "audit",
  ],
};
const extraTitles: Partial<Record<View, string>> = {
  balanceSheet: "الميزانية",
  incomeStatement: "قائمة الدخل",
  trialBalance: "ميزان المراجعة",
  dailyJournal: "دفتر اليومية",
  accountStatement: "كشف حساب",
  vouchers: "السندات",
  attendance: "الحضور والانصراف",
  attendanceSettings: "الورديات وإسناد الموظفين",
  attendanceReport: "تقرير الحضور والغياب والتأخير",
  dashboard: "لوحة التحكم",
  reports: "التقارير والمؤشرات",
  settings: "الإعدادات",
};
export default function OracleWorkspace() {
  const initial = new URLSearchParams(window.location.search);
  const [view, setView] = useState<View>(() => {
    const value = initial.get("view");
    return primaryNavigation.some(n => n.id === value) ||
      navigation.some(n => n.id === value)
      ? (value as View)
      : "dashboard";
  });
  const [options, setOptions] = useState<{
    search?: string;
    vehicleId?: number;
  }>(() => ({
    search: initial.get("search") ?? "",
    vehicleId: Number(initial.get("vehicleId")) || undefined,
  }));
  const [menu, setMenu] = useState(false),
    [accountOpen, setAccountOpen] = useState(false),
    [headerSearch, setHeaderSearch] = useState("");
  const session = trpc.oracleOperations.session.useQuery(undefined, {
    retry: false,
  });
  const actor = session.data?.actor;
  const previousActor = useRef(actor?.ID);
  useEffect(() => {
    if (actor?.ID && actor.ID !== previousActor.current) setAccountOpen(false);
    previousActor.current = actor?.ID;
  }, [actor?.ID]);
  const navigate: NavigateDealer = (next, nextOptions = {}) => {
    setView(next);
    setOptions(nextOptions);
    setMenu(false);
    const url = new URL(window.location.href);
    url.searchParams.set("view", next);
    url.searchParams.delete("search");
    url.searchParams.delete("vehicleId");
    if (nextOptions.search) url.searchParams.set("search", nextOptions.search);
    if (nextOptions.vehicleId)
      url.searchParams.set("vehicleId", String(nextOptions.vehicleId));
    window.history.replaceState(null, "", url);
    window.scrollTo({ top: 0, behavior: "instant" });
  };
  const activePrimary =
    primaryNavigation.find(n => n.id === view)?.id ??
    (Object.entries(children).find(([, values]) =>
      values?.includes(view)
    )?.[0] as View) ??
    "settings";
  const title =
    extraTitles[view] ??
    navigation.find(n => n.id === view)?.label ??
    "بيانات المعرض";
  const description =
    view === "dashboard"
      ? "نظرة شاملة على المخزون والمبيعات وأعمال المعرض"
      : view === "inventory"
        ? "إدارة ومتابعة السيارات المسجلة في المعرض"
        : view === "reports"
          ? "مؤشرات وتقارير من السجلات الفعلية"
          : view === "settings"
            ? "تعريفات النظام والحسابات وصلاحيات فريق العمل"
            : view in oracleDatasets
              ? oracleDatasets[view as OracleDataset].description
              : "متابعة البيانات والعمليات المسجلة";
  return (
    <div className={"oracle-workspace dealer-brochure view-" + view} dir="rtl">
      {menu && (
        <button
          className="oracle-backdrop"
          aria-label="إغلاق القائمة"
          onClick={() => setMenu(false)}
        />
      )}
      <aside
        className={"oracle-sidebar " + (menu ? "is-open" : "")}
        aria-label="التنقل الرئيسي"
      >
        <div className="oracle-brand">
          <div className="dealer-emblem">
            <DealerLogo
              className="h-full w-full object-contain p-1"
              fallback={
                <>
                  <Shield size={64} strokeWidth={1.3} />
                  <Car size={34} strokeWidth={1.6} />
                </>
              }
            />
          </div>
          <strong>
            <DealerName />
          </strong>
          <span>إدارة المعرض</span>
          <button
            className="oracle-mobile-close"
            onClick={() => setMenu(false)}
            aria-label="إغلاق القائمة"
          >
            <X size={20} />
          </button>
        </div>
        <nav>
          {primaryNavigation.map(n => (
            <div className="oracle-nav-group" key={n.id}>
              <button
                onClick={() => navigate(n.id)}
                aria-current={view === n.id ? "page" : undefined}
                className={activePrimary === n.id ? "active" : ""}
              >
                <n.icon size={18} />
                <span>{n.label}</span>
              </button>
              {activePrimary === n.id &&
                children[n.id]?.map(id => (
                  <button
                    className={
                      "dealer-subnav " + (view === id ? "selected" : "")
                    }
                    aria-current={view === id ? "page" : undefined}
                    key={id}
                    onClick={() => navigate(id)}
                  >
                    <span className="dealer-subnav-dot" />
                    <span>
                      {navigation.find(v => v.id === id)?.label ?? id}
                    </span>
                  </button>
                ))}
            </div>
          ))}
        </nav>
        <button
          className="oracle-sidebar-foot"
          onClick={() => navigate("audit")}
        >
          <ShieldCheck size={25} />
          <span>
            <strong>سلامة النظام</strong>
            <small>متابعة الربط والعمليات</small>
          </span>
        </button>
      </aside>
      <main className="oracle-main">
        <header className="oracle-topbar">
          <div className="dealer-top-title">
            <button
              className="oracle-menu"
              onClick={() => setMenu(true)}
              aria-label="فتح القائمة"
            >
              <Menu size={22} />
            </button>
            <div>
              <strong>{title}</strong>
              <small>مرحبًا بك في إدارة المعرض</small>
            </div>
          </div>
          <time className="dealer-top-date">
            <CalendarDays size={15} />
            {new Date().toLocaleDateString("ar-SA", {
              calendar: "gregory",
              weekday: "long",
              day: "numeric",
              month: "long",
              year: "numeric",
            })}
          </time>
          <form
            className="dealer-global-search"
            onSubmit={e => {
              e.preventDefault();
              navigate("inventory", { search: headerSearch.trim() });
            }}
          >
            <Search size={16} />
            <input
              aria-label="البحث العام عن سيارة"
              placeholder="ابحث عن سيارة، لوحة أو رقم هيكل…"
              value={headerSearch}
              onChange={e => setHeaderSearch(e.target.value)}
            />
          </form>
          <div className="dealer-top-actions">
            <button
              className="dealer-bell"
              aria-label="تنبيهات النظام"
              onClick={() => navigate("audit")}
            >
              <Bell size={19} />
            </button>
            <button
              className="dealer-account-button"
              aria-label="فتح حساب المستخدم"
              onClick={() => setAccountOpen(true)}
            >
              <span className="dealer-avatar">
                {actor?.DISPLAY_NAME?.slice(0, 1) ?? "م"}
              </span>
              <span>{actor?.DISPLAY_NAME ?? "تسجيل الدخول"}</span>
              <ChevronDown size={13} />
            </button>
          </div>
        </header>
        <div className="oracle-content">
          <div className="oracle-page-heading">
            <div>
              <span className="oracle-eyebrow">
                الرئيسية {view !== "dashboard" ? " / " + title : ""}
              </span>
              <h1>{title}</h1>
              <p>{description}</p>
            </div>
            <span className="dealer-connection">
              <i />
              متصل بالمعرض
            </span>
          </div>
          {["sales", "purchases", "expenses", "receipts", "journal"].includes(
            view
          ) && (
            <div className="dealer-context-note">
              <ShieldCheck size={15} />
              {actor?.ROLE === "viewer"
                ? "صلاحيتك تتيح عرض السجلات والتقارير."
                : "إضافة الفواتير والسندات متاحة، وتُسجّل عمليات الحفظ باسم حسابك مع الترحيل المحاسبي."}
            </div>
          )}
          {view === "dashboard" ? (
            <DealerOverview navigate={navigate} />
          ) : view === "inventory" ? (
            <DealerInventory
              key={options.search + String(options.vehicleId)}
              navigate={navigate}
              initialSearch={options.search}
              initialVehicleId={options.vehicleId}
            />
          ) : view === "reservations" || view === "followups" ? (
            <DealerActivities
              key={view + String(options.vehicleId)}
              kind={view === "reservations" ? "reservation" : "followup"}
              initialVehicleId={options.vehicleId}
            />
          ) : view === "vouchers" ? (
            <div className="dealer-hub-grid">
              {(
                [
                  ["receipts", "سندات القبض", "إضافة وعرض سندات التحصيل"],
                  ["expenses", "سندات الصرف", "إضافة وعرض سندات الدفع"],
                  ["journal", "سندات القيد", "إضافة وعرض القيود المحاسبية"],
                ] as const
              ).map(([id, label, description]) => (
                <button
                  key={id}
                  className="oracle-panel dealer-hub-card"
                  onClick={() => navigate(id)}
                >
                  <FileText />
                  <strong>{label}</strong>
                  <p>{description}</p>
                  <ChevronLeft size={16} />
                </button>
              ))}
            </div>
          ) : view === "reports" ? (
            <DealerReports navigate={navigate} />
          ) : view === "settings" ? (
            <DealerSettings navigate={navigate} />
          ) : view === "balanceSheet" ? (
            <DealerTrialBalance key="balance" balanceSheet />
          ) : view === "incomeStatement" ? (
            <DealerTrialBalance key="income" income />
          ) : view === "trialBalance" ? (
            <DealerTrialBalance key="trial" />
          ) : view === "dailyJournal" ? (
            <DealerDailyJournal />
          ) : view === "accountStatement" ? (
            <DealerAccountStatement />
          ) : view === "accountDirectory" ? (
            <DealerAccountTree />
          ) : view === "attendance" ? (
            <EmployeeAttendance />
          ) : view === "attendanceSettings" ? (
            <AttendanceSettings />
          ) : view === "attendanceReport" ? (
            <AttendanceReport />
          ) : view === "history" ? (
            <OracleHistory />
          ) : view === "users" ? (
            <OracleUsers />
          ) : view === "audit" ? (
            <Audit />
          ) : (
            <DealerSection dataset={view} navigate={navigate}>
              <DataView
                key={view + options.search}
                dataset={view}
                initialSearch={options.search}
              />
            </DealerSection>
          )}
          <footer className="oracle-footer">
            إدارة معرض السيارات <span>·</span> بيانات مباشرة من سجلات المعرض
          </footer>
        </div>
      </main>
      <nav className="dealer-bottom-nav" aria-label="التنقل على الجوال">
        {[
          { id: "dashboard", label: "الرئيسية", icon: LayoutDashboard },
          { id: "inventory", label: "المخزون", icon: Car },
          { id: "reservations", label: "حجوزات السيارات", icon: CalendarDays },
          { id: "followups", label: "مواعيد المتابعة", icon: CalendarDays },
          { id: "sales", label: "المبيعات", icon: ChartNoAxesCombined },
          { id: "customers", label: "العملاء", icon: UsersRound },
          { id: "settings", label: "الحساب", icon: UserRound },
        ].map(n => (
          <button
            key={n.id}
            className={activePrimary === n.id ? "active" : ""}
            aria-current={activePrimary === n.id ? "page" : undefined}
            onClick={() => navigate(n.id as View)}
          >
            <n.icon size={20} />
            <span>{n.label}</span>
          </button>
        ))}
      </nav>
      <Dialog open={accountOpen} onOpenChange={setAccountOpen}>
        <DialogContent dir="rtl" className="dealer-account-dialog sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>حساب المستخدم</DialogTitle>
            <DialogDescription>الدخول والصلاحيات الشخصية</DialogDescription>
          </DialogHeader>
          <OracleAccount />
        </DialogContent>
      </Dialog>
    </div>
  );
}
function DealerSection({
  dataset,
  navigate,
  children: content,
}: {
  dataset: OracleDataset;
  navigate: NavigateDealer;
  children: ReactNode;
}) {
  const summary = trpc.oracleWorkspace.summary.useQuery(undefined, {
    retry: false,
  });
  if (["receipts", "expenses", "journal"].includes(dataset))
    return (
      <div className="space-y-4">
        <div className="flex flex-wrap gap-2" aria-label="أنواع السندات">
          {(
            [
              ["receipts", "سندات القبض"],
              ["expenses", "سندات الصرف"],
              ["journal", "سندات القيد"],
            ] as const
          ).map(([id, label]) => (
            <Button
              key={id}
              variant={dataset === id ? "default" : "outline"}
              onClick={() => navigate(id)}
            >
              {label}
            </Button>
          ))}
        </div>
        {content}
      </div>
    );
  const isSales = ["sales", "contracts"].includes(dataset),
    isPurchase = ["purchases", "suppliers"].includes(dataset),
    isExpense = dataset === "expenses";
  if (!isSales && !isPurchase && !isExpense) return <>{content}</>;
  const items = isSales
    ? [
        ["فواتير المبيعات", "SALES"],
        ["عقود المبايعة", "CONTRACTS"],
        ["سندات القبض", "RECEIPTS"],
        ["إجمالي البيع", "SALES_TOTAL"],
      ]
    : isPurchase
      ? [
          ["فواتير الشراء", "PURCHASES"],
          ["السيارات المسجلة", "VEHICLES"],
          ["إجمالي المشتريات", "PURCHASE_TOTAL"],
        ]
      : [
          ["سندات الصرف", "PAYOUTS"],
          ["سندات القبض", "RECEIPTS"],
          ["فواتير الشراء", "PURCHASES"],
        ];
  const links = isSales
    ? [
        ["sales", "فواتير المبيعات"],
        ["contracts", "عقود المبايعة"],
        ["receipts", "سندات القبض"],
      ]
    : isPurchase
      ? [
          ["purchases", "فواتير الشراء"],
          ["suppliers", "الموردون"],
          ["entries", "دخول السيارات"],
        ]
      : [
          ["expenses", "سندات الصرف"],
          ["costCenters", "مراكز التكلفة"],
          ["ledger", "دفتر الأستاذ"],
        ];
  return (
    <div className="dealer-section">
      <div className="dealer-section-stats">
        {items.map(([label, key], i) => (
          <div className="oracle-panel" key={key}>
            <span className={"dealer-stat-icon tone-" + i}>
              <FileText size={20} />
            </span>
            <span>
              {label}
              <strong>
                {number(summary.data?.totals[key])}
                {key.includes("TOTAL") && <small> ر.س</small>}
              </strong>
            </span>
          </div>
        ))}
      </div>
      <div className="dealer-section-layout">
        <aside className="dealer-action-panel">
          <h2>
            {isSales
              ? "المبيعات وعقود المبايعة"
              : isPurchase
                ? "المشتريات والموردون"
                : "الحسابات والمصروفات"}
          </h2>
          <p>انتقل إلى السجل المطلوب لإدارة بياناته.</p>
          {links.map(([view, label]) => (
            <button
              key={view}
              className={dataset === view ? "active" : ""}
              onClick={() => navigate(view as View)}
            >
              <FileText size={17} />
              {label}
              <ChevronLeft size={14} />
            </button>
          ))}
          <div className="dealer-action-summary">
            <span>سجل العمليات</span>
            <p>تتبع الإضافة والتعديل والحذف من حساب المدير.</p>
            <button onClick={() => navigate("history")}>
              عرض التقرير <ChevronLeft size={14} />
            </button>
          </div>
        </aside>
        <div className="dealer-section-data">{content}</div>
      </div>
    </div>
  );
}
function DataView({
  dataset,
  documentId,
  initialSearch = "",
}: {
  dataset: OracleDataset;
  documentId?: number;
  initialSearch?: string;
}) {
  const [search, setSearch] = useState(initialSearch);
  const [draft, setDraft] = useState(initialSearch);
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<OracleRow | null>(null);
  const meta = oracleDatasets[dataset];
  const columns = Object.entries(meta.columns);
  const query = trpc.oracleWorkspace.table.useQuery(
    { dataset, search, page, pageSize: 25, documentId },
    { retry: false }
  );
  const total = query.data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / 25));
  const customer =
    dataset === "customers" ? (selected ?? query.data?.rows[0]) : null;
  const detailDataset =
    dataset === "sales"
      ? "salesLines"
      : dataset === "purchases"
        ? "purchaseLines"
        : null;
  return (
    <section
      className={
        "oracle-panel oracle-data-panel" +
        (dataset === "customers" ? " dealer-customers" : "")
      }
    >
      {dataset === "customers" && (
        <>
          <div className="dealer-customer-summary">
            <UsersRound size={24} />
            <div>
              <span>عملاء المعرض</span>
              <strong>{query.isLoading ? "…" : number(total)}</strong>
            </div>
            <p>عرض بيانات التواصل وإجمالي الفواتير لكل اسم ورقم هاتف مسجل.</p>
          </div>
          <aside
            className="dealer-customer-profile"
            aria-label="ملف العميل"
            aria-live="polite"
          >
            {customer ? (
              <>
                <div className="dealer-profile-heading">
                  <span className="dealer-avatar">
                    {String(customer.CUSTOMER ?? "؟").slice(0, 2)}
                  </span>
                  <div>
                    <h2>{display(customer.CUSTOMER)}</h2>
                    <span>عميل فواتير البيع</span>
                  </div>
                </div>
                <dl>
                  <div>
                    <dt>رقم الهاتف</dt>
                    <dd dir="ltr">{display(customer.PHONE)}</dd>
                  </div>
                  <div>
                    <dt>عدد الفواتير</dt>
                    <dd>{number(customer.INVOICE_COUNT)}</dd>
                  </div>
                  <div>
                    <dt>إجمالي الفواتير</dt>
                    <dd>{number(customer.TOTAL)} ر.س</dd>
                  </div>
                  <div>
                    <dt>آخر فاتورة</dt>
                    <dd>{display(customer.LAST_DATE)}</dd>
                  </div>
                </dl>
                {customer.PHONE &&
                  /^[+\d\s()-]{5,25}$/.test(String(customer.PHONE)) && (
                    <a
                      className="dealer-gold-button"
                      href={
                        "tel:" + String(customer.PHONE).replace(/[^+\d]/g, "")
                      }
                    >
                      اتصال بالعميل
                    </a>
                  )}
                <div className="dealer-profile-note">
                  <FileText size={20} />
                  <h3>ملف المبيعات</h3>
                  <p>
                    البيانات مجمعة من الفواتير حسب الاسم والهاتف. اختر عميلاً من
                    الجدول لعرض ملفه هنا.
                  </p>
                </div>
              </>
            ) : (
              <p>لا يوجد عميل لعرض بياناته.</p>
            )}
          </aside>
        </>
      )}
      <div className="oracle-table-toolbar">
        {(dataset === "receipts" ||
          dataset === "expenses" ||
          dataset === "journal") && (
          <VoucherButton kind={dataset} onSaved={() => void query.refetch()} />
        )}
        {dataset === "purchases" && (
          <PurchaseInvoiceButton onSaved={() => void query.refetch()} />
        )}
        {dataset === "sales" && (
          <SalesInvoiceButton onSaved={() => void query.refetch()} />
        )}
        <OracleEditButtons
          dataset={dataset}
          onSaved={() => void query.refetch()}
        />
        <form
          onSubmit={e => {
            e.preventDefault();
            setSearch(draft.trim());
            setPage(1);
            setSelected(null);
          }}
        >
          <label className="oracle-search">
            <Search size={18} />
            <Input
              aria-label={"البحث في " + meta.title}
              value={draft}
              onChange={e => setDraft(e.target.value)}
              placeholder="ابحث بالاسم أو الرقم أو اللوحة…"
            />
          </label>
          <Button type="submit">بحث</Button>
        </form>
        <Button
          variant="outline"
          onClick={() => void query.refetch()}
          disabled={query.isFetching}
        >
          <RefreshCw size={16} /> تحديث
        </Button>
      </div>
      {query.isLoading ? (
        <Loading />
      ) : query.isError ? (
        <Failure retry={() => void query.refetch()} />
      ) : query.data?.rows.length === 0 ? (
        <div className="oracle-empty">
          <Database size={32} />
          <h3>{search ? "لا توجد نتائج مطابقة" : "لا توجد سجلات"}</h3>
          <p>
            {search
              ? "جرّب اسماً أو رقماً آخر."
              : "الجدول متصل، لكنه لا يحتوي سجلات لهذا العرض."}
          </p>
        </div>
      ) : (
        <div className="oracle-table-scroll">
          <table>
            <thead>
              <tr>
                {columns.map(([key, label]) => (
                  <th key={key} scope="col">
                    {label}
                  </th>
                ))}
                <th scope="col">التفاصيل</th>
              </tr>
            </thead>
            <tbody>
              {query.data?.rows.map((row, index) => (
                <tr
                  key={index}
                  className={
                    dataset === "customers" && customer === row
                      ? "dealer-selected-row"
                      : undefined
                  }
                >
                  {columns.map(([key]) => (
                    <td key={key}>
                      {key === "CUSTOMER" || key === "SUPPLIER" ? (
                        <div className="dealer-person-cell">
                          <span
                            className={"dealer-avatar avatar-" + (index % 5)}
                          >
                            {String(row[key] ?? "؟").slice(0, 1)}
                          </span>
                          <span>{display(row[key])}</span>
                        </div>
                      ) : key === "CAR" ? (
                        <div className="dealer-table-car">
                          <img
                            src={carImage(row)}
                            alt="صورة توضيحية مولّدة"
                            loading="lazy"
                          />
                          {display(row[key])}
                        </div>
                      ) : key === "STATUS" ? (
                        <span className="oracle-status">
                          {display(row[key])}
                        </span>
                      ) : (
                        display(row[key], key)
                      )}
                    </td>
                  ))}
                  <td>
                    {(dataset === "sales" || dataset === "purchases") &&
                      row.ID && (
                        <InvoicePrintButton
                          kind={dataset}
                          id={Number(row.ID)}
                        />
                      )}
                    <button
                      className="oracle-row-action"
                      onClick={() => setSelected(row)}
                      aria-label={
                        "عرض تفاصيل السجل " + String(row.ID ?? index + 1)
                      }
                    >
                      عرض <ChevronLeft size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className="oracle-pagination">
        <span>
          {query.isError ? "تعذر قراءة العدد" : display(total) + " سجل"}
          {query.isFetching && " · جاري التحديث"}
        </span>
        <div>
          <Button
            variant="outline"
            aria-label="الصفحة السابقة"
            disabled={page === 1 || query.isFetching}
            onClick={() => setPage(p => p - 1)}
          >
            <ChevronRight size={16} />
          </Button>
          <span>
            {page} / {pages}
          </span>
          <Button
            variant="outline"
            aria-label="الصفحة التالية"
            disabled={page >= pages || query.isFetching}
            onClick={() => setPage(p => p + 1)}
          >
            <ChevronLeft size={16} />
          </Button>
        </div>
      </div>
      <Dialog
        open={!!selected && dataset !== "customers"}
        onOpenChange={open => !open && setSelected(null)}
      >
        <DialogContent
          dir="rtl"
          className="dealer-record-dialog max-h-[90vh] overflow-y-auto sm:max-w-5xl"
        >
          <DialogHeader>
            <DialogTitle>
              {meta.title} {selected?.ID ? " · " + selected.ID : ""}
            </DialogTitle>
            <DialogDescription>
              الحقول المسجلة في قاعدة Oracle
            </DialogDescription>
          </DialogHeader>
          {selected?.ID && (
            <OracleEditButtons
              dataset={dataset}
              id={Number(selected.ID)}
              onSaved={() => {
                setSelected(null);
                void query.refetch();
              }}
            />
          )}
          {selected?.ID && (dataset === "sales" || dataset === "purchases") && (
            <InvoicePrintButton kind={dataset} id={Number(selected.ID)} />
          )}
          <dl className="oracle-detail-grid">
            {columns.map(([key, label]) => (
              <div key={key}>
                <dt>{label}</dt>
                <dd>{display(selected?.[key], key)}</dd>
              </div>
            ))}
          </dl>
          {selected && detailDataset && (
            <DataView
              key={dataset + selected.ID}
              dataset={detailDataset}
              documentId={Number(selected.ID)}
            />
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
function Audit() {
  const query = trpc.oracleWorkspace.audit.useQuery(undefined, {
    retry: false,
  });
  if (query.isLoading) return <Loading />;
  if (query.isError) return <Failure retry={() => void query.refetch()} />;
  const data = query.data!;
  const triggers = data.snapshot.triggerDetails ?? [];
  return (
    <div className="oracle-audit">
      <div className="oracle-stat-grid">
        {[
          ["الجداول", data.snapshot.tables.length],
          ["العروض", data.snapshot.views.length],
          ["المشغلات", triggers.length],
          ["معطلة أو غير صالحة", data.mapping.unhealthyTriggers.length],
        ].map(([label, value]) => (
          <div className="oracle-stat" key={String(label)}>
            <span>{label}</span>
            <strong>{display(Number(value))}</strong>
          </div>
        ))}
      </div>
      <section className="oracle-panel">
        <div className="oracle-section-heading">
          <div>
            <h2>حالة المشغلات</h2>
            <p>فحص التفعيل والترجمة، دون تشغيل معاملات تجريبية</p>
          </div>
          <Button variant="outline" onClick={() => void query.refetch()}>
            <RefreshCw size={16} /> إعادة الفحص
          </Button>
        </div>
        <div className="oracle-table-scroll">
          <table>
            <thead>
              <tr>
                <th>المشغل</th>
                <th>الجدول</th>
                <th>التفعيل</th>
                <th>الصلاحية</th>
                <th>الحدث</th>
              </tr>
            </thead>
            <tbody>
              {triggers.map(t => (
                <tr key={t.TRIGGER_NAME}>
                  <td dir="ltr">{t.TRIGGER_NAME}</td>
                  <td dir="ltr">{t.TABLE_NAME}</td>
                  <td>
                    <span
                      className={
                        t.STATUS === "ENABLED" ? "oracle-good" : "oracle-bad"
                      }
                    >
                      {t.STATUS}
                    </span>
                  </td>
                  <td>
                    <span
                      className={
                        t.OBJECT_STATUS === "VALID"
                          ? "oracle-good"
                          : "oracle-bad"
                      }
                    >
                      {t.OBJECT_STATUS}
                    </span>
                  </td>
                  <td>{t.TRIGGERING_EVENT}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="oracle-panel">
        <div className="oracle-section-heading">
          <div>
            <h2>مصادر الشاشات</h2>
            <p>الجداول المستخدمة فعلياً في هذه الواجهة</p>
          </div>
        </div>
        <div className="oracle-table-scroll">
          <table>
            <thead>
              <tr>
                <th>الشاشة</th>
                <th>المصدر والعلاقة</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(oracleDatasets).map(([key, meta]) => (
                <tr key={key}>
                  <td>{meta.title}</td>
                  <td dir="ltr">{meta.source}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section className="oracle-panel">
        <div className="oracle-section-heading">
          <h2>أخطاء ترجمة المشغلات ({data.mapping.triggerErrors.length})</h2>
        </div>
        {data.mapping.triggerErrors.length === 0 ? (
          <p className="p-5">لا توجد أخطاء ترجمة مسجلة.</p>
        ) : (
          data.mapping.triggerErrors.map((error, i) => (
            <pre className="oracle-code-error" dir="ltr" key={i}>
              {error.NAME +
                " · " +
                error.LINE +
                ":" +
                error.POSITION +
                "\n" +
                error.TEXT}
            </pre>
          ))
        )}
      </section>
      <section className="oracle-panel">
        <div className="oracle-section-heading">
          <div>
            <h2>تغطية جداول القاعدة</h2>
            <p>الجدول غير المرتبط لا يُعامل تلقائياً كمصدر شاشة تشغيلية.</p>
          </div>
        </div>
        <div className="oracle-table-scroll">
          <table>
            <thead>
              <tr>
                <th>الجدول</th>
                <th>الشاشة المرتبطة</th>
                <th>الحالة</th>
              </tr>
            </thead>
            <tbody>
              {data.tableCoverage.map(item => (
                <tr key={item.table}>
                  <td dir="ltr">{item.table}</td>
                  <td>{item.screen ?? "جدول قديم أو مساند يحتاج مطابقة"}</td>
                  <td>
                    <span
                      className={item.screen ? "oracle-good" : "oracle-bad"}
                    >
                      {item.screen ? "مرتبط للقراءة" : "غير مرتبط"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <details className="oracle-panel p-5">
        <summary className="cursor-pointer font-bold">
          كائنات غير صالحة ({data.invalidObjects.length})
        </summary>
        <div className="oracle-table-scroll">
          <table>
            <tbody>
              {data.invalidObjects.map(o => (
                <tr key={o.OBJECT_TYPE + o.OBJECT_NAME}>
                  <td dir="ltr">{o.OBJECT_NAME}</td>
                  <td>{o.OBJECT_TYPE}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </details>
    </div>
  );
}
