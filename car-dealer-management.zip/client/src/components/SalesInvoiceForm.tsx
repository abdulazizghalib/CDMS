import { Car, Search, Plus, Trash2, ReceiptText } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

export function SalesInvoiceButton({ onSaved }: { onSaved: () => void }) {
  const session = trpc.oracleOperations.session.useQuery(undefined, {
    retry: false,
  });
  const [open, setOpen] = useState(false);
  if (!session.data?.actor || session.data.actor.ROLE === "viewer") return null;
  return (
    <>
      <Button onClick={() => setOpen(true)}>إضافة فاتورة مبيعات</Button>
      {open && (
        <SalesInvoiceForm
          close={() => setOpen(false)}
          saved={() => {
            setOpen(false);
            onSaved();
          }}
        />
      )}
    </>
  );
}
function SalesInvoiceForm({
  close,
  saved,
}: {
  close: () => void;
  saved: () => void;
}) {
  const [date, setDate] = useState(() =>
    new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Riyadh",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date())
  );
  const [phone, setPhone] = useState(""),
    [branch, setBranch] = useState(""),
    [notes, setNotes] = useState("");
  const [accountId, setAccount] = useState(""),
    [paymentAccountId, setPayment] = useState(""),
    [vat, setVat] = useState("0");
  const [lines, setLines] = useState([
    { key: crypto.randomUUID(), purchaseId: "", price: "" },
  ]);
  const options = trpc.oracleOperations.salesInvoiceOptions.useQuery(
    undefined,
    { retry: false }
  );
  const utils = trpc.useUtils();
  const mutation = trpc.oracleOperations.createSalesInvoice.useMutation({
    onSuccess: async () => {
      await utils.oracleWorkspace.invalidate();
      await utils.oracleOperations.invalidate();
      saved();
    },
  });
  const [addingAccount, setAddingAccount] = useState(false);
  const [accountName, setAccountName] = useState(""),
    [accountPhone, setAccountPhone] = useState(""),
    [accountNote, setAccountNote] = useState("");
  const [createdAccount, setCreatedAccount] = useState<{
    ID: number;
    NAME: string;
    BAR_NUM: number;
  } | null>(null);
  const accountMutation =
    trpc.oracleOperations.createCollectionAccount.useMutation({
      onSuccess: account => {
        setCreatedAccount(account);
        setPayment(String(account.ID));
        if (account.phone) setPhone(account.phone);
        setAddingAccount(false);
        setAccountName("");
        setAccountPhone("");
        setAccountNote("");
        void utils.oracleOperations.salesInvoiceOptions.invalidate();
        void utils.oracleWorkspace.invalidate();
        void utils.oracleOperations.accountTree.invalidate();
      },
    });
  const accounts = [
      ...(options.data?.accounts ?? []),
      ...(createdAccount &&
      !options.data?.accounts.some(a => a.ID === createdAccount.ID)
        ? [createdAccount]
        : []),
    ],
    vehicles = options.data?.vehicles ?? [];
  const salesAccounts = accounts.filter(
    a => a.BAR_NUM === options.data?.settings.salesParent
  );
  const paymentAccounts = accounts.filter(
    a => a.BAR_NUM === options.data?.settings.paymentParent
  );
  const locked = mutation.isPending || accountMutation.isPending;
  const postingReady =
    accounts.some(a => a.ID === 3005) && accounts.some(a => a.ID === 3006);
  const total = lines.reduce(
    (n, l) => n + Math.round(Number(l.price || 0) * 100) / 100,
    0
  );
  const selectClass =
    "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm";
  return (
    <Dialog
      open
      onOpenChange={v => {
        if (!v && !locked) close();
      }}
    >
      <DialogContent
        dir="rtl"
        className="dealer-record-dialog max-h-[90vh] overflow-y-auto sm:max-w-5xl"
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <ReceiptText className="text-amber-600" size={24} />
            إضافة فاتورة مبيعات
          </DialogTitle>
          <DialogDescription>
            اختر السيارات وحساب المبيعات وحساب التحصيل. سعر كل سيارة شامل
            الضريبة، ومبلغ الضريبة جزء من الإجمالي.
          </DialogDescription>
        </DialogHeader>
        <form
          className="space-y-4"
          onSubmit={e => {
            e.preventDefault();
            if (locked || addingAccount || !options.data || addingAccount)
              return;
            mutation.mutate({
              date,
              phone,
              branch,
              notes,
              accountId: Number(accountId),
              paymentAccountId: Number(paymentAccountId),
              vat: Number(vat),
              lines: lines.map(l => ({
                purchaseId: Number(l.purchaseId),
                price: Number(l.price),
              })),
            });
          }}
        >
          <fieldset
            disabled={locked || options.isLoading}
            className="space-y-4"
          >
            <section className="rounded-xl border bg-slate-50/60 p-4 sm:p-5">
              <h3 className="mb-4 font-semibold">بيانات الفاتورة والحسابات</h3>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <label>
                  تاريخ الفاتورة *
                  <Input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                  />
                </label>
                <label>
                  الهاتف
                  <Input
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                  />
                </label>
                <label>
                  الفرع
                  <Input
                    value={branch}
                    onChange={e => setBranch(e.target.value)}
                  />
                </label>
                <label>
                  حساب المبيعات *
                  <select
                    className={selectClass}
                    required
                    value={accountId}
                    onChange={e => setAccount(e.target.value)}
                  >
                    <option value="">اختر الحساب</option>
                    {salesAccounts.map(a => (
                      <option key={a.ID} value={a.ID}>
                        {a.ID} — {a.NAME}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <label htmlFor="sales-collection-account">
                      حساب التحصيل / العميل *
                    </label>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      disabled={!options.data}
                      onClick={() => {
                        setAddingAccount(v => !v);
                        accountMutation.reset();
                      }}
                    >
                      <Plus size={14} />
                      {addingAccount ? "إغلاق الإضافة" : "إضافة حساب"}
                    </Button>
                  </div>
                  <select
                    id="sales-collection-account"
                    className={selectClass}
                    required
                    value={paymentAccountId}
                    onChange={e => setPayment(e.target.value)}
                  >
                    <option value="">اختر الحساب</option>
                    {paymentAccounts.map(a => (
                      <option key={a.ID} value={a.ID}>
                        {a.ID} — {a.NAME}
                      </option>
                    ))}
                  </select>
                </div>
                <label>
                  مبلغ الضريبة ضمن الإجمالي
                  <Input
                    type="number"
                    min="0"
                    step="0.01"
                    required
                    value={vat}
                    onChange={e => setVat(e.target.value)}
                  />
                </label>
                <label>
                  ملاحظات
                  <Input
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                  />
                </label>
              </div>
            </section>
            {addingAccount && (
              <section
                className="rounded-xl border border-amber-200 bg-amber-50/50 p-4 space-y-3"
                aria-label="إضافة حساب التحصيل / العميل"
              >
                <div>
                  <h3 className="font-semibold">إضافة حساب التحصيل / العميل</h3>
                  <p className="text-xs text-slate-600 mt-1">
                    يُنشأ حساب من المستوى الثالث تحت الحساب الأب{" "}
                    {options.data?.settings.paymentParent} المحدد في إعدادات
                    المبيعات، ويُختار في الفاتورة بعد الحفظ.
                  </p>
                </div>
                <div className="grid gap-3 sm:grid-cols-3">
                  <label>
                    اسم الحساب *
                    <Input
                      value={accountName}
                      onChange={e => setAccountName(e.target.value)}
                      placeholder="اسم العميل أو حساب التحصيل"
                    />
                  </label>
                  <label>
                    الهاتف
                    <Input
                      value={accountPhone}
                      onChange={e => setAccountPhone(e.target.value)}
                      type="tel"
                    />
                  </label>
                  <label>
                    ملاحظات الحساب
                    <Input
                      value={accountNote}
                      onChange={e => setAccountNote(e.target.value)}
                    />
                  </label>
                </div>
                {accountMutation.error && (
                  <p role="alert" className="text-sm text-red-700">
                    {accountMutation.error.message}
                  </p>
                )}
                <div className="flex flex-wrap gap-2">
                  <Button
                    type="button"
                    disabled={!accountName.trim() || locked}
                    onClick={() =>
                      accountMutation.mutate({
                        name: accountName,
                        phone: accountPhone,
                        notes: accountNote,
                      })
                    }
                  >
                    {accountMutation.isPending
                      ? "جارٍ الحفظ…"
                      : "حفظ الحساب واختياره"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setAddingAccount(false)}
                  >
                    إلغاء إضافة الحساب
                  </Button>
                </div>
                <p className="text-xs text-slate-500">
                  يُحفظ الحساب في دليل الحسابات بشكل مستقل عن حفظ الفاتورة.
                </p>
              </section>
            )}
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="flex items-center gap-2 font-bold">
                  <Car size={19} /> سيارات الفاتورة
                </h3>
                <span className="rounded-full bg-slate-100 px-3 py-1 text-sm">
                  {lines.length} سيارة
                </span>
              </div>
              {lines.map((line, i) => (
                <SaleVehicleLine
                  key={line.key}
                  number={i + 1}
                  purchaseId={line.purchaseId}
                  price={line.price}
                  vehicles={vehicles}
                  usedIds={lines
                    .filter(l => l.key !== line.key)
                    .map(l => l.purchaseId)}
                  removable={lines.length > 1}
                  onChange={changes =>
                    setLines(rows =>
                      rows.map(r =>
                        r.key === line.key ? { ...r, ...changes } : r
                      )
                    )
                  }
                  onRemove={() =>
                    setLines(rows => rows.filter(r => r.key !== line.key))
                  }
                />
              ))}

              <Button
                type="button"
                variant="outline"
                disabled={lines.length >= 100}
                onClick={() =>
                  setLines(rows => [
                    ...rows,
                    { key: crypto.randomUUID(), purchaseId: "", price: "" },
                  ])
                }
              >
                <Plus size={16} /> إضافة سيارة
              </Button>
            </section>
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-5">
              <p className="text-sm text-slate-600">الأسعار شاملة الضريبة</p>
              <p className="mt-1 text-xl font-bold">
                إجمالي الفاتورة:{" "}
                {total.toLocaleString("ar-SA", { minimumFractionDigits: 2 })}{" "}
                ر.س
              </p>
            </div>
            {options.data && !postingReady && (
              <p role="alert" className="text-red-700">
                يلزم إعداد حسابي تكلفة المبيعات والمخزون 3005 و3006 في دليل
                الحسابات قبل حفظ الفاتورة.
              </p>
            )}
            {options.data && vehicles.length === 0 && (
              <p>لا توجد سيارات متاحة للبيع في المخزون.</p>
            )}
          </fieldset>
          {(options.error || mutation.error) && (
            <p role="alert" className="text-red-700">
              {options.error?.message ?? mutation.error?.message}
            </p>
          )}
          <div className="sticky bottom-0 flex justify-end gap-3 border-t bg-background py-4">
            <Button
              type="submit"
              disabled={
                locked ||
                addingAccount ||
                !options.data ||
                !postingReady ||
                vehicles.length === 0
              }
            >
              {locked ? "جارٍ الحفظ…" : "حفظ الفاتورة"}
            </Button>
            <Button
              type="button"
              variant="outline"
              disabled={locked}
              onClick={close}
            >
              إلغاء
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function SaleVehicleLine({
  number,
  purchaseId,
  price,
  vehicles,
  usedIds,
  removable,
  onChange,
  onRemove,
}: {
  number: number;
  purchaseId: string;
  price: string;
  vehicles: { ID: number; CAR: string; MODEL: string; PLATE: string }[];
  usedIds: string[];
  removable: boolean;
  onChange: (changes: { purchaseId?: string; price?: string }) => void;
  onRemove: () => void;
}) {
  const [search, setSearch] = useState("");
  const normalize = (value: string) =>
    value
      .toLowerCase()
      .replace(/[٠-٩]/g, d => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
      .replace(/[۰-۹]/g, d => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
      .replace(/\s+/g, "");
  const query = normalize(search);
  const available = vehicles
    .map((v, index) => ({ ...v, position: index + 1 }))
    .filter(v => !usedIds.includes(String(v.ID)));
  const matches = available.filter(v =>
    normalize(`${v.PLATE ?? ""} ${v.MODEL ?? ""} ${v.CAR ?? ""}`).includes(
      query
    )
  );
  const choices = available.filter(
    v => String(v.ID) === purchaseId || matches.some(m => m.ID === v.ID)
  );
  const selected = vehicles.find(v => String(v.ID) === purchaseId);
  return (
    <div className="rounded-xl border bg-white p-4 shadow-sm sm:p-5">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-900 text-sm font-bold text-white">
            {number}
          </span>
          <strong>{selected?.CAR || "اختر السيارة"}</strong>
        </div>
        <Button
          type="button"
          variant="ghost"
          className="text-red-600"
          disabled={!removable}
          aria-label={"إزالة السيارة " + number}
          onClick={onRemove}
        >
          <Trash2 size={16} /> إزالة
        </Button>
      </div>
      <div className="grid gap-4 sm:grid-cols-[1fr_180px]">
        <div className="space-y-3">
          <label
            className="block text-sm font-medium"
            htmlFor={"vehicle-search-" + number}
          >
            البحث باللوحة أو الموديل أو السنة
          </label>
          <div className="relative">
            <Search
              className="absolute right-3 top-3 text-slate-400"
              size={16}
            />
            <Input
              id={"vehicle-search-" + number}
              className="pr-9"
              placeholder="مثال: 2026 أو رقم اللوحة"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <label className="block text-sm font-medium">
            السيارة *
            <select
              className="mt-2 flex h-11 w-full rounded-md border bg-background px-3 text-sm"
              required
              value={purchaseId}
              onChange={e => onChange({ purchaseId: e.target.value })}
            >
              <option value="">اختر سيارة من المخزون</option>
              {choices.map(v => (
                <option key={v.ID} value={v.ID}>
                  {v.position}. {v.CAR} — {v.MODEL || "بدون موديل"} — {v.PLATE}
                </option>
              ))}
            </select>
          </label>
          <p className="text-xs text-slate-500" aria-live="polite">
            {matches.length
              ? `${matches.length} سيارة مطابقة`
              : "لا توجد سيارات مطابقة للبحث"}
          </p>
        </div>
        <label className="text-sm font-medium">
          سعر البيع (ر.س) *
          <Input
            className="mt-2 h-11"
            type="number"
            min="0"
            step="0.01"
            required
            value={price}
            onChange={e => onChange({ price: e.target.value })}
          />
          <span className="mt-2 block text-xs font-normal text-slate-500">
            شامل الضريبة
          </span>
        </label>
      </div>
      {selected && (
        <div className="mt-4 flex flex-wrap gap-2 border-t pt-3 text-xs">
          <span className="rounded-md bg-slate-100 px-3 py-2">
            اللوحة: {selected.PLATE}
          </span>
          <span className="rounded-md bg-slate-100 px-3 py-2">
            الموديل / السنة: {selected.MODEL || "—"}
          </span>
          <span className="rounded-md bg-emerald-50 px-3 py-2 text-emerald-700">
            متاحة للبيع
          </span>
        </div>
      )}
    </div>
  );
}
