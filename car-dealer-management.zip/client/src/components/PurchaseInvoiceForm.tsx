import { ShoppingCart, Download, Upload, Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  purchaseColumns,
  readPurchaseExcel,
  downloadPurchaseTemplate,
} from "@/lib/purchaseExcel";
const blank = () => ({
  car: "",
  model: "",
  color: "",
  plate: "",
  price: "",
  vin: "",
  notes: "",
});
export function PurchaseInvoiceButton({ onSaved }: { onSaved: () => void }) {
  const actor = trpc.oracleOperations.session.useQuery(undefined, {
    retry: false,
  }).data?.actor;
  const [open, setOpen] = useState(false);
  if (!actor || actor.ROLE === "viewer") return null;
  return (
    <>
      <Button onClick={() => setOpen(true)}>إضافة فاتورة مشتريات</Button>
      {open && (
        <PurchaseInvoiceForm
          close={() => setOpen(false)}
          saved={() => {
            setOpen(false);
            onSaved();
          }}
        />
      )}
    </>
  );
}
function PurchaseInvoiceForm({
  close,
  saved,
}: {
  close: () => void;
  saved: () => void;
}) {
  const [date, setDate] = useState(() =>
    new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Riyadh",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date())
  );
  const [supplier, setSupplier] = useState(""),
    [payment, setPayment] = useState(""),
    [owner, setOwner] = useState(""),
    [notes, setNotes] = useState(""),
    [branch, setBranch] = useState("");
  const [lines, setLines] = useState([blank()]),
    [fileError, setFileError] = useState(""),
    [importing, setImporting] = useState(false);
  const options = trpc.oracleOperations.purchaseInvoiceOptions.useQuery(
    undefined,
    { retry: false }
  );
  const utils = trpc.useUtils();
  const mutation = trpc.oracleOperations.createPurchaseInvoice.useMutation({
    onSuccess: async () => {
      await utils.oracleWorkspace.invalidate();
      saved();
    },
  });
  const [addingOwner, setAddingOwner] = useState(false);
  const [ownerName, setOwnerName] = useState(""),
    [ownerPhone, setOwnerPhone] = useState(""),
    [ownerNote, setOwnerNote] = useState("");
  const [createdOwner, setCreatedOwner] = useState<{
    ID: number;
    NAME: string;
    BAR_NUM: number;
  } | null>(null);
  const ownerMutation = trpc.oracleOperations.createOwnerAccount.useMutation({
    onSuccess: account => {
      setCreatedOwner(account);
      setOwner(String(account.ID));
      setAddingOwner(false);
      setOwnerName("");
      setOwnerPhone("");
      setOwnerNote("");
      void utils.oracleOperations.purchaseInvoiceOptions.invalidate();
      void utils.oracleWorkspace.invalidate();
      void utils.oracleOperations.accountTree.invalidate();
    },
  });
  const owners = [
    ...(options.data?.owners ?? []),
    ...(createdOwner &&
    !options.data?.owners.some(a => a.ID === createdOwner.ID)
      ? [createdOwner]
      : []),
  ];
  const locked = mutation.isPending || importing || ownerMutation.isPending;
  const selectClass = "flex h-10 w-full rounded-md border bg-background px-3";
  const total = lines.reduce(
    (n, l) => n + Math.round(Number(l.price || 0) * 100) / 100,
    0
  );
  return (
    <Dialog
      open
      onOpenChange={v => {
        if (!v && !locked) close();
      }}
    >
      <DialogContent
        dir="rtl"
        className="dealer-record-dialog max-h-[90vh] overflow-y-auto sm:max-w-6xl"
      >
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3 text-2xl">
            <span className="rounded-xl bg-amber-50 p-3 text-amber-700">
              <ShoppingCart size={24} />
            </span>
            إضافة فاتورة مشتريات
          </DialogTitle>
          <DialogDescription>
            رقم الفاتورة والمستخدم يحددان عند الحفظ. أضف السيارات يدوياً أو ارفع
            ملف Excel ثم راجع التفاصيل قبل الحفظ.
          </DialogDescription>
        </DialogHeader>
        <form
          className="space-y-4"
          onSubmit={e => {
            e.preventDefault();
            if (locked || !options.data || addingOwner) return;
            mutation.mutate({
              date,
              supplierId: Number(supplier),
              paymentId: Number(payment),
              ownerId: Number(owner),
              branch,
              notes,
              lines: lines.map(l => ({ ...l, price: Number(l.price) })),
            });
          }}
        >
          <fieldset
            disabled={locked || options.isLoading}
            className="space-y-4"
          >
            <section className="rounded-xl border bg-slate-50/60 p-5">
              <h3 className="mb-4 font-semibold">بيانات الفاتورة والمورد</h3>
              <div className="grid gap-4 sm:grid-cols-2">
                <label>
                  التاريخ *
                  <Input
                    required
                    type="date"
                    value={date}
                    onChange={e => setDate(e.target.value)}
                  />
                </label>
                {[
                  {
                    label: "مخزون المعرض",
                    value: payment,
                    set: setPayment,
                    accounts: options.data?.accounts,
                  },
                  {
                    label: "المورد",
                    value: supplier,
                    set: setSupplier,
                    accounts: options.data?.suppliers,
                  },
                  {
                    label: "المالك",
                    value: owner,
                    set: setOwner,
                    accounts: owners,
                  },
                ].map(f => (
                  <div key={f.label} className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <label htmlFor={"purchase-account-" + f.label}>
                        {f.label} *
                      </label>
                      {f.label === "المالك" && (
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          disabled={!options.data}
                          onClick={() => {
                            setAddingOwner(v => !v);
                            ownerMutation.reset();
                          }}
                        >
                          <Plus size={14} />
                          {addingOwner ? "إغلاق الإضافة" : "إضافة مالك"}
                        </Button>
                      )}
                    </div>
                    <select
                      id={"purchase-account-" + f.label}
                      required
                      className={selectClass}
                      value={f.value}
                      onChange={e => f.set(e.target.value)}
                    >
                      <option value="">اختر {f.label}</option>
                      {f.accounts?.map(a => (
                        <option key={a.ID} value={a.ID}>
                          {a.ID} — {a.NAME}
                        </option>
                      ))}
                    </select>
                    {f.accounts?.length === 0 && (
                      <span className="text-xs text-amber-700">
                        لا توجد حسابات ضمن الربط المحدد؛ راجع إعدادات المشتريات.
                      </span>
                    )}
                  </div>
                ))}
                <label>
                  الفرع
                  <Input
                    value={branch}
                    onChange={e => setBranch(e.target.value)}
                  />
                </label>
                <label className="sm:col-span-2">
                  ملاحظات
                  <Input
                    value={notes}
                    onChange={e => setNotes(e.target.value)}
                  />
                </label>
              </div>
            </section>
            {addingOwner && (
              <section
                className="rounded-xl border border-amber-200 bg-amber-50/50 p-4 space-y-3"
                aria-label="إضافة مالك"
              >
                <div>
                  <h3 className="font-semibold">إضافة مالك</h3>
                  <p className="text-xs text-slate-600 mt-1">
                    يُحفظ حساب المالك تحت الحساب الأب{" "}
                    {options.data?.settings.ownerParent} المحدد في إعدادات
                    المشتريات، ويُختار مباشرة في الفاتورة.
                  </p>
                </div>
                <div className="grid gap-3 sm:grid-cols-3">
                  <label>
                    اسم المالك *
                    <Input
                      value={ownerName}
                      onChange={e => setOwnerName(e.target.value)}
                      placeholder="اسم المالك"
                    />
                  </label>
                  <label>
                    الهاتف
                    <Input
                      type="tel"
                      value={ownerPhone}
                      onChange={e => setOwnerPhone(e.target.value)}
                    />
                  </label>
                  <label>
                    ملاحظات الحساب
                    <Input
                      value={ownerNote}
                      onChange={e => setOwnerNote(e.target.value)}
                    />
                  </label>
                </div>
                {ownerMutation.error && (
                  <p role="alert" className="text-sm text-red-700">
                    {ownerMutation.error.message}
                  </p>
                )}
                <div className="flex flex-wrap gap-2">
                  <Button
                    type="button"
                    disabled={!ownerName.trim() || locked}
                    onClick={() =>
                      ownerMutation.mutate({
                        name: ownerName,
                        phone: ownerPhone,
                        notes: ownerNote,
                      })
                    }
                  >
                    {ownerMutation.isPending
                      ? "جارٍ الحفظ…"
                      : "حفظ المالك واختياره"}
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setAddingOwner(false)}
                  >
                    إلغاء إضافة المالك
                  </Button>
                </div>
                <p className="text-xs text-slate-500">
                  يُحفظ حساب المالك في دليل الحسابات بشكل مستقل عن حفظ الفاتورة.
                </p>
              </section>
            )}
            <section className="rounded-xl border border-dashed border-amber-200 bg-amber-50/40 p-5">
              <h3 className="mb-3 flex items-center gap-2 font-semibold">
                <Upload size={18} /> استيراد السيارات من Excel
              </h3>
              <div className="flex flex-wrap items-center gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setImporting(true);
                    setFileError("");
                    void downloadPurchaseTemplate()
                      .catch(e => setFileError(e.message))
                      .finally(() => setImporting(false));
                  }}
                >
                  <Download size={16} /> تنزيل قالب Excel
                </Button>
                <label>
                  رفع المشتريات من Excel
                  <Input
                    type="file"
                    accept=".xlsx"
                    onChange={async e => {
                      const f = e.target.files?.[0];
                      e.target.value = "";
                      if (!f) return;
                      setImporting(true);
                      setFileError("");
                      try {
                        const imported = await readPurchaseExcel(f);
                        const current = lines.filter(l =>
                          Object.values(l).some(v => v !== "")
                        );
                        if (current.length + imported.length > 500)
                          throw new Error("الحد الأقصى 500 سيارة");
                        setLines([
                          ...current,
                          ...imported.map(l => ({
                            ...l,
                            price: String(l.price),
                          })),
                        ]);
                      } catch (error) {
                        setFileError(
                          error instanceof Error
                            ? error.message
                            : "تعذر قراءة الملف"
                        );
                      } finally {
                        setImporting(false);
                      }
                    }}
                  />
                </label>
              </div>
              <p className="text-sm">
                صيغة .xlsx، الورقة الأولى، بحد أقصى 500 سيارة. تُضاف الصفوف
                المرفوعة إلى الجدول للمراجعة. استخدم القالب وأدخل اللوحة والهيكل
                كنص.
              </p>
            </section>
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">تفاصيل السيارات</h3>
                <span className="rounded-full bg-slate-100 px-3 py-1 text-sm">
                  {lines.length} سيارة
                </span>
              </div>
              <div className="max-h-[360px] overflow-auto rounded-xl border">
                <table className="w-full border-collapse text-sm">
                  <thead className="sticky top-0 z-10 bg-slate-100 text-slate-700">
                    <tr>
                      <th className="p-3 text-right">#</th>
                      {purchaseColumns.map(c => (
                        <th
                          className="p-3 text-right whitespace-nowrap"
                          key={c.key}
                        >
                          {c.label}
                        </th>
                      ))}
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {lines.map((line, i) => (
                      <tr
                        key={i}
                        className="border-b odd:bg-white even:bg-slate-50/60"
                      >
                        <td className="p-3 text-center font-semibold text-slate-500">
                          {i + 1}
                        </td>
                        {purchaseColumns.map(c => (
                          <td className="p-2" key={c.key}>
                            <Input
                              aria-label={c.label + " " + (i + 1)}
                              className="min-w-[120px]"
                              type={c.key === "price" ? "number" : "text"}
                              min={c.key === "price" ? 0 : undefined}
                              step={c.key === "price" ? "0.01" : undefined}
                              required={["car", "plate", "price"].includes(
                                c.key
                              )}
                              value={line[c.key]}
                              onChange={e =>
                                setLines(rows =>
                                  rows.map((r, j) =>
                                    j === i
                                      ? { ...r, [c.key]: e.target.value }
                                      : r
                                  )
                                )
                              }
                            />
                          </td>
                        ))}
                        <td>
                          <Button
                            type="button"
                            variant="outline"
                            disabled={lines.length === 1}
                            onClick={() =>
                              setLines(rows => rows.filter((_, j) => j !== i))
                            }
                          >
                            <Trash2 size={15} />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Button
                type="button"
                variant="outline"
                disabled={lines.length >= 500}
                onClick={() => setLines(rows => [...rows, blank()])}
              >
                <Plus size={16} /> إضافة سيارة
              </Button>
            </section>
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-5">
              <p className="mb-2 text-sm text-slate-600">ملخص الفاتورة</p>
              <p className="text-xl font-bold">
                الإجمالي:{" "}
                {total.toLocaleString("ar-SA", { minimumFractionDigits: 2 })}{" "}
                ر.س — عدد السيارات: {lines.length}
              </p>
            </div>
          </fieldset>
          {(fileError || options.error || mutation.error) && (
            <p role="alert" className="whitespace-pre-line text-red-700">
              {fileError || options.error?.message || mutation.error?.message}
            </p>
          )}
          <div className="sticky bottom-0 flex justify-end gap-3 border-t bg-background py-4">
            <Button
              type="submit"
              disabled={locked || addingOwner || !options.data}
            >
              {importing
                ? "جارٍ قراءة الملف…"
                : mutation.isPending
                  ? "جارٍ الحفظ…"
                  : "حفظ الفاتورة"}
            </Button>
            <Button
              type="button"
              variant="outline"
              disabled={locked}
              onClick={close}
            >
              إلغاء
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
