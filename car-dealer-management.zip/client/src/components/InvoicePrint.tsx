import { useRef, useState } from "react";
import { Printer } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
const printStyles = `.invoice-paper{box-sizing:border-box;font-family:Tahoma,Arial,sans-serif;color:#172033;background:white;direction:rtl} .invoice-paper{padding:24px;background:white}.invoice-letterhead{display:flex;justify-content:space-between;align-items:center;gap:24px;border-bottom:3px solid #b58a32;padding-bottom:20px;margin-bottom:24px}.invoice-letterhead img{width:120px;height:80px;object-fit:contain}.invoice-letterhead h1{font-size:24px;margin:0 0 8px}.invoice-letterhead h2{font-size:19px;margin:0}.invoice-meta{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:22px}.invoice-meta div{border-bottom:1px solid #e2e8f0;padding:10px 0;overflow-wrap:anywhere}.invoice-meta strong{color:#64748b;font-size:12px;margin-left:12px}.invoice-paper table{width:100%;border-collapse:collapse;font-size:11px;table-layout:fixed}.invoice-paper th{background:#f1f5f9;text-align:right}.invoice-paper th,.invoice-paper td{padding:10px 5px;border:1px solid #e2e8f0;overflow-wrap:anywhere}.invoice-paper th:first-child{width:30px}.invoice-paper th:last-child{width:90px}.invoice-paper thead{display:table-header-group}.invoice-paper tr{break-inside:avoid}.invoice-totals{margin-top:20px;margin-right:auto;width:280px;border:1px solid #cbd5e1;padding:16px;break-inside:avoid}.invoice-totals div{display:flex;justify-content:space-between;margin:8px 0}.invoice-totals .grand-total{border-top:1px solid #cbd5e1;padding-top:12px;font-size:18px;font-weight:bold}.invoice-notes{margin-top:22px;white-space:pre-wrap;overflow-wrap:anywhere}.invoice-footer{margin-top:28px;border-top:1px solid #e2e8f0;padding-top:14px;color:#64748b;font-size:11px;display:flex;justify-content:space-between}@page{size:A4;margin:12mm}@media print{.invoice-paper{padding:0}body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}`;
export function InvoicePrintButton({
  kind,
  id,
}: {
  kind: "sales" | "purchases";
  id: number;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <Button type="button" variant="outline" onClick={() => setOpen(true)}>
        <Printer size={16} />
        طباعة
      </Button>
      {open && (
        <InvoicePrintPreview kind={kind} id={id} close={() => setOpen(false)} />
      )}
    </>
  );
}
function InvoicePrintPreview({
  kind,
  id,
  close,
}: {
  kind: "sales" | "purchases";
  id: number;
  close: () => void;
}) {
  const query = trpc.oracleOperations.invoiceForPrint.useQuery(
    { kind, id },
    { retry: false, refetchOnMount: "always" }
  );
  const paper = useRef<HTMLDivElement>(null);
  const [printing, setPrinting] = useState(false),
    [error, setError] = useState("");
  const money = (n: number | null | undefined) =>
    Number(n ?? 0).toLocaleString("ar-SA", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  async function print() {
    if (!paper.current) return;
    setPrinting(true);
    setError("");
    const frame = document.createElement("iframe");
    frame.title = "طباعة الفاتورة";
    frame.style.cssText =
      "position:fixed;left:-10000px;top:0;width:210mm;height:297mm;border:0";
    document.body.appendChild(frame);
    const cleanup = () => {
      frame.remove();
      setPrinting(false);
    };
    try {
      const doc = frame.contentDocument!;
      doc.open();
      doc.write(
        '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>Invoice ' +
          id +
          "</title><style>" +
          printStyles +
          "</style></head><body>" +
          paper.current.outerHTML +
          "</body></html>"
      );
      doc.close();
      await Promise.all(
        Array.from(doc.images).map(img => img.decode().catch(() => {}))
      );
      await doc.fonts.ready;
      const w = frame.contentWindow!;
      w.addEventListener("afterprint", cleanup, { once: true });
      w.focus();
      w.print();
      setPrinting(false);
      setTimeout(() => frame.remove(), 60000);
    } catch {
      cleanup();
      setError("تعذرت الطباعة؛ أعد المحاولة");
    }
  }
  const d = query.data;
  return (
    <Dialog
      open
      onOpenChange={v => {
        if (!v && !printing) close();
      }}
    >
      <DialogContent
        dir="rtl"
        className="max-h-[90vh] overflow-y-auto sm:max-w-5xl"
      >
        <DialogHeader className="text-right sm:text-right">
          <DialogTitle>
            معاينة {kind === "sales" ? "فاتورة مبيعات" : "فاتورة مشتريات"} #{id}
          </DialogTitle>
          <DialogDescription>
            يمكنك الطباعة أو الحفظ بصيغة PDF من نافذة الطباعة.
          </DialogDescription>
        </DialogHeader>
        <div className="flex justify-end gap-2">
          <Button disabled={!d || printing} onClick={() => void print()}>
            <Printer size={16} />
            {printing ? "جارٍ تجهيز الطباعة…" : "طباعة الفاتورة"}
          </Button>
          <Button variant="outline" onClick={close} disabled={printing}>
            إغلاق
          </Button>
        </div>
        {(query.error || error) && (
          <p role="alert" className="text-red-700">
            {error || query.error?.message}
          </p>
        )}
        {query.isLoading && <p>جارٍ تحميل الفاتورة…</p>}
        {d && (
          <>
            <style>{printStyles}</style>
            <div ref={paper} className="invoice-paper" dir="rtl">
              <header className="invoice-letterhead">
                <div>
                  <h1>{d.branding.name}</h1>
                  <h2>
                    {kind === "sales" ? "فاتورة مبيعات" : "فاتورة مشتريات"}
                  </h2>
                </div>
                {d.branding.logo && (
                  <img src={d.branding.logo} alt={d.branding.name} />
                )}
              </header>
              <div className="invoice-meta">
                <div>
                  <strong>رقم الفاتورة</strong>
                  {d.invoice.ID}
                </div>
                <div>
                  <strong>التاريخ</strong>
                  <span dir="ltr">{d.invoice.DOC_DATE || "—"}</span>
                </div>
                <div>
                  <strong>{kind === "sales" ? "العميل" : "المورد"}</strong>
                  {d.invoice.PARTY || "—"}
                </div>
                <div>
                  <strong>الفرع</strong>
                  {d.invoice.BRANCH || "—"}
                </div>
                {kind === "purchases" && (
                  <>
                    <div>
                      <strong>مخزون المعرض</strong>
                      {d.invoice.STOCK_NAME || "—"}
                    </div>
                    <div>
                      <strong>المالك</strong>
                      {d.invoice.OWNER_NAME || "—"}
                    </div>
                  </>
                )}
                {d.invoice.PHONE && (
                  <div>
                    <strong>الهاتف</strong>
                    {d.invoice.PHONE}
                  </div>
                )}
              </div>
              <table>
                <thead>
                  <tr>
                    {[
                      "#",
                      "السيارة",
                      "الموديل",
                      "اللون",
                      "اللوحة",
                      "الهيكل",
                      "القيمة (ر.س)",
                    ].map(h => (
                      <th key={h}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {d.lines.map((l, i) => (
                    <tr key={i}>
                      <td>{i + 1}</td>
                      <td>{l.CAR || "—"}</td>
                      <td>{l.MODEL || "—"}</td>
                      <td>{l.COLOR || "—"}</td>
                      <td>{l.PLATE || "—"}</td>
                      <td>{l.VIN || "—"}</td>
                      <td>{money(l.PRICE)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="invoice-totals">
                <div>
                  <span>عدد السيارات</span>
                  <strong>{d.lines.length}</strong>
                </div>
                {kind === "sales" && d.invoice.VAT != null && (
                  <div>
                    <span>الضريبة ضمن الإجمالي</span>
                    <strong>{money(d.invoice.VAT)}</strong>
                  </div>
                )}
                <div className="grand-total">
                  <span>الإجمالي</span>
                  <span>{money(d.invoice.TOTAL)} ر.س</span>
                </div>
              </div>
              {d.invoice.NOTES && (
                <p className="invoice-notes">
                  <strong>ملاحظات: </strong>
                  {d.invoice.NOTES}
                </p>
              )}
              <footer className="invoice-footer">
                <span>{d.branding.name}</span>
                <span>المستخدم: {d.invoice.ENTERED_BY || "—"}</span>
              </footer>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
