﻿import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
export function PurchaseAccountSettings() {
  const actor = trpc.oracleOperations.session.useQuery(undefined, {
    retry: false,
  }).data?.actor;
  const query = trpc.oracleOperations.purchaseAccountSettings.useQuery(
    undefined,
    { enabled: !!actor && actor.ROLE !== "viewer", retry: false }
  );
  const [values, setValues] = useState({
    stockParent: "",
    ownerParent: "",
    supplierParent: "",
  });
  const [dirty, setDirty] = useState(false),
    [saved, setSaved] = useState(false);
  useEffect(() => {
    if (query.data && !dirty)
      setValues({
        stockParent: String(query.data.stockParent),
        ownerParent: String(query.data.ownerParent),
        supplierParent: String(query.data.supplierParent),
      });
  }, [query.data, dirty]);
  const utils = trpc.useUtils();
  const mutation =
    trpc.oracleOperations.savePurchaseAccountSettings.useMutation({
      onSuccess: async () => {
        setDirty(false);
        setSaved(true);
        await utils.oracleOperations.purchaseAccountSettings.invalidate();
        await utils.oracleOperations.purchaseInvoiceOptions.invalidate();
      },
    });
  if (!actor || actor.ROLE === "viewer") return null;
  const disabled = actor.ROLE !== "admin" || mutation.isPending || !query.data;
  const fields = [
    { key: "stockParent", label: "مخزون المعرض" },
    { key: "ownerParent", label: "المالك" },
    { key: "supplierParent", label: "الموردين" },
  ] as const;
  return (
    <section
      className="oracle-panel p-6"
      style={{ gridColumn: "1 / -1" }}
      dir="rtl"
    >
      <h2 className="text-xl font-bold">إعدادات حسابات فواتير المشتريات</h2>
      <p className="my-3 text-sm text-muted-foreground">
        حدد الحساب الأب لكل حقل. تعرض الفاتورة حسابات المستوى الثالث التابعة له،
        ويظهر الحساب الرئيسي في مسار الحساب.
      </p>
      <form
        className="space-y-4"
        onSubmit={e => {
          e.preventDefault();
          setSaved(false);
          mutation.mutate({
            stockParent: Number(values.stockParent),
            ownerParent: Number(values.ownerParent),
            supplierParent: Number(values.supplierParent),
          });
        }}
      >
        <fieldset disabled={disabled} className="grid gap-4 sm:grid-cols-3">
          {fields.map(f => (
            <label key={f.key} className="space-y-2">
              <span className="font-medium">{f.label}</span>
              <select
                required
                className="flex h-11 w-full rounded-md border bg-background px-3"
                value={values[f.key]}
                onChange={e => {
                  setValues(v => ({ ...v, [f.key]: e.target.value }));
                  setDirty(true);
                  setSaved(false);
                }}
              >
                <option value="">اختر الحساب الأب</option>
                {query.data?.parents.map(a => (
                  <option key={a.ID} value={a.ID}>
                    {a.MAIN_NUM} ← {a.ID} — {a.NAME}
                  </option>
                ))}
              </select>
            </label>
          ))}
        </fieldset>
        {(query.error || mutation.error) && (
          <p role="alert" className="text-red-700">
            {query.error?.message ?? mutation.error?.message}
          </p>
        )}
        {saved && (
          <p role="status" className="text-green-700">
            تم حفظ إعدادات حسابات المشتريات.
          </p>
        )}
        {actor.ROLE === "admin" ? (
          <Button type="submit" disabled={disabled || !dirty}>
            {mutation.isPending ? "جارٍ الحفظ…" : "حفظ إعدادات الحسابات"}
          </Button>
        ) : (
          <p>تعديل هذه الإعدادات متاح للمدير.</p>
        )}
      </form>
    </section>
  );
}
