import { DealerLogo, DealerName } from "@/components/DealerBranding";
import { startLogin } from "@/const";
import { checkLoginReadiness } from "@/lib/authGate";
import { Car, LogIn, ShieldCheck } from "lucide-react";

/**
 * Shared brand pane for the login surfaces (Manus OAuth login and the workspace
 * operator login). Keeps the dealership identity consistent across both.
 */
export function DealerBrandPane() {
  return (
    <section className="dealer-login-brand">
      <p className="dealer-login-eyebrow">منصة رقمية متكاملة لمعارض السيارات</p>
      <div className="dealer-login-mark">
        <span className="dealer-login-emblem" aria-hidden="true">
          <DealerLogo
            className="h-full w-full object-contain p-1"
            fallback={<Car size={26} strokeWidth={2.2} />}
          />
        </span>
        <div className="dealer-login-mark-text">
          <strong><DealerName/></strong>
          <span>Car Dealer Management</span>
        </div>
      </div>
      <h1>إدارة المعرض بذكاء واحترافية</h1>
      <span className="dealer-login-rule" aria-hidden="true" />
      <p className="dealer-login-lead">
        من تسجيل السيارة واحتساب تكلفتها إلى العرض والحجز وعقد المبايعة
        والتحصيل، منصة واحدة تمنح الإدارة رؤية كاملة وتمنح فريق المبيعات سرعة
        أكبر.
      </p>
    </section>
  );
}

/** Ambient gold/teal glows used by the login surfaces. */
export function DealerLoginGlows() {
  return (
    <>
      <span
        className="dealer-login-glow dealer-login-glow-gold"
        aria-hidden="true"
      />
      <span
        className="dealer-login-glow dealer-login-glow-teal"
        aria-hidden="true"
      />
    </>
  );
}

/**
 * Branded Arabic login screen — the first surface an unauthenticated visitor
 * sees. It only *starts* the Manus OAuth flow from a click handler, because
 * `startLogin()` has side effects (mints a one-time nonce + writes the state
 * cookie) and must not run during render.
 */
export function LoginScreen() {
  const readiness = checkLoginReadiness({
    VITE_OAUTH_PORTAL_URL: import.meta.env.VITE_OAUTH_PORTAL_URL,
    VITE_APP_ID: import.meta.env.VITE_APP_ID,
  });

  return (
    <div className="dealer-login">
      <DealerLoginGlows />

      <div className="dealer-login-shell">
        <DealerBrandPane />

        <section
          className="dealer-login-card"
          aria-labelledby="dealer-login-title"
        >
          <div className="dealer-login-card-head">
            <span className="dealer-login-badge">
              <ShieldCheck size={14} />
              دخول مصرّح به
            </span>
            <h2 id="dealer-login-title">تسجيل الدخول</h2>
            <p>
              الوصول إلى مساحة عمل المعرض متاح للمستخدمين المصرّح لهم فقط. تابع
              لتسجيل الدخول عبر حسابك.
            </p>
          </div>

          {!readiness.ready && (
            <p className="dealer-login-alert" role="alert">
              {readiness.message}
            </p>
          )}

          <button
            type="button"
            className="dealer-login-provider"
            onClick={() => startLogin()}
            disabled={!readiness.ready}
          >
            <LogIn size={18} />
            {readiness.ready
              ? "الدخول عبر حساب Manus"
              : "تسجيل الدخول غير مُهيأ"}
          </button>

          <p className="dealer-login-note">
            لا تُنشأ الحسابات من هذه الشاشة؛ تُدار الصلاحيات والأدوار من قبل
            مدير النظام.
          </p>
          <p className="dealer-login-foot">
            منصة إدارة معارض السيارات — نسخة المعرض
          </p>
        </section>
      </div>
    </div>
  );
}

/**
 * Branded splash shown while the session is still being resolved, so the login
 * screen (not a flash of the workspace) is the first thing a visitor sees.
 */
export function AuthGateSplash() {
  return (
    <div className="dealer-login-splash" role="status" aria-live="polite">
      <span className="dealer-login-emblem" aria-hidden="true">
        <DealerLogo
          className="h-full w-full object-contain p-1"
          fallback={<Car size={26} strokeWidth={2.2} />}
        />
      </span>
      <p>جاري التحقق من الجلسة...</p>
    </div>
  );
}
