﻿import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
export function SalesAccountSettings() {
  const session = trpc.oracleOperations.session.useQuery(undefined, {
    retry: false,
  });
  const actor = session.data?.actor;
  const query = trpc.oracleOperations.salesAccountSettings.useQuery(undefined, {
    enabled: !!actor && actor.ROLE !== "viewer",
    retry: false,
  });
  const [sales, setSales] = useState(""),
    [payment, setPayment] = useState(""),
    [dirty, setDirty] = useState(false),
    [saved, setSaved] = useState(false);
  useEffect(() => {
    if (query.data && !dirty) {
      setSales(String(query.data.salesParent));
      setPayment(String(query.data.paymentParent));
    }
  }, [query.data, dirty]);
  const utils = trpc.useUtils();
  const mutation = trpc.oracleOperations.saveSalesAccountSettings.useMutation({
    onSuccess: async () => {
      setDirty(false);
      setSaved(true);
      await utils.oracleOperations.salesAccountSettings.invalidate();
      await utils.oracleOperations.salesInvoiceOptions.invalidate();
    },
  });
  if (!actor || actor.ROLE === "viewer") return null;
  const disabled = actor.ROLE !== "admin" || mutation.isPending || !query.data;
  return (
    <section
      className="oracle-panel p-6"
      style={{ gridColumn: "1 / -1" }}
      dir="rtl"
    >
      <h2 className="text-xl font-bold">إعدادات حسابات فواتير المبيعات</h2>
      <p className="my-3">
        اختر الحساب الأب من المستوى الثاني. تعرض الفاتورة حسابات المستوى الثالث
        التابعة له، ويؤخذ اسم العميل من حساب التحصيل المختار.
      </p>
      <form
        className="space-y-4"
        onSubmit={e => {
          e.preventDefault();
          setSaved(false);
          mutation.mutate({
            salesParent: Number(sales),
            paymentParent: Number(payment),
          });
        }}
      >
        <fieldset disabled={disabled} className="grid gap-4 sm:grid-cols-2">
          {[
            {
              label: "الحساب الأب لقائمة حساب المبيعات",
              value: sales,
              set: setSales,
            },
            {
              label: "الحساب الأب لقائمة التحصيل / العميل",
              value: payment,
              set: setPayment,
            },
          ].map(f => (
            <label key={f.label}>
              {f.label}
              <select
                className="flex h-10 w-full rounded-md border bg-background px-3"
                required
                value={f.value}
                onChange={e => {
                  f.set(e.target.value);
                  setDirty(true);
                  setSaved(false);
                }}
              >
                <option value="">اختر حساب المستوى الثاني</option>
                {query.data?.parents.map(a => (
                  <option key={a.ID} value={a.ID}>
                    {a.ID} — {a.NAME}
                  </option>
                ))}
              </select>
            </label>
          ))}
        </fieldset>
        {(query.error || mutation.error) && (
          <p role="alert" className="text-red-700">
            {query.error?.message ?? mutation.error?.message}
          </p>
        )}
        {saved && <p role="status">تم حفظ إعدادات الحسابات.</p>}
        {actor.ROLE === "admin" ? (
          <Button disabled={disabled || !dirty} type="submit">
            {mutation.isPending ? "جارٍ الحفظ…" : "حفظ إعدادات الحسابات"}
          </Button>
        ) : (
          <p>تعديل هذه الإعدادات متاح للمدير.</p>
        )}
      </form>
    </section>
  );
}
