﻿import { useState } from "react";
import { Plus, ReceiptText } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import type { z } from "zod";
import { voucherKind, voucherInput } from "@shared/oracleVoucher";
import { money } from "@/lib/dealerPresentation";
const titles = { receipts: "سند قبض", expenses: "سند صرف", journal: "سند قيد" };
export function VoucherButton({
  kind,
  onSaved,
}: {
  kind: z.infer<typeof voucherKind>;
  onSaved: () => void;
}) {
  const actor = trpc.oracleOperations.session.useQuery().data?.actor;
  const [open, setOpen] = useState(false);
  if (!actor || actor.ROLE === "viewer") return null;
  return (
    <>
      <Button onClick={() => setOpen(true)}>
        <Plus size={16} />
        إضافة {titles[kind]}
      </Button>
      {open && (
        <VoucherForm
          kind={kind}
          close={() => setOpen(false)}
          saved={() => {
            setOpen(false);
            onSaved();
          }}
        />
      )}
    </>
  );
}
function AccountChoice({
  label,
  value,
  onChange,
  accounts,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  accounts: { ID: number; NAME: string }[];
}) {
  const [search, setSearch] = useState("");
  return (
    <label className="block space-y-2">
      <span className="font-semibold text-sm">{label}</span>
      <Input
        aria-label={"بحث " + label}
        placeholder="بحث برقم الحساب أو اسمه"
        value={search}
        onChange={e => setSearch(e.target.value)}
      />
      <select
        aria-label={label}
        required
        className="w-full border rounded-md p-2 bg-white text-sm"
        value={value}
        onChange={e => onChange(e.target.value)}
      >
        <option value="">اختر الحساب</option>
        {accounts
          .filter(
            a => String(a.ID) === value || `${a.ID} ${a.NAME}`.includes(search)
          )
          .map(a => (
            <option key={a.ID} value={a.ID}>
              {a.ID} — {a.NAME}
            </option>
          ))}
      </select>
    </label>
  );
}
function VoucherForm({
  kind,
  close,
  saved,
}: {
  kind: z.infer<typeof voucherKind>;
  close: () => void;
  saved: () => void;
}) {
  const [date, setDate] = useState(
    new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Riyadh",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date())
  );
  const [amount, setAmount] = useState(""),
    [debit, setDebit] = useState(""),
    [credit, setCredit] = useState(""),
    [notes, setNotes] = useState(""),
    [error, setError] = useState("");
  const accounts = trpc.oracleOperations.voucherAccounts.useQuery(undefined, {
    retry: false,
  });
  const utils = trpc.useUtils();
  const mutation = trpc.oracleOperations.createVoucher.useMutation({
    onSuccess(r) {
      void utils.oracleWorkspace.invalidate();
      void utils.oracleOperations.invalidate();
      toast.success(`تم حفظ ${titles[kind]} رقم ${r.id}`);
      saved();
    },
    onError(e) {
      setError(e.message);
    },
  });
  const debitLabel =
    kind === "receipts"
      ? "حساب التحصيل (مدين)"
      : kind === "expenses"
        ? "حساب المستفيد / المصروف (مدين)"
        : "الحساب المدين";
  const creditLabel =
    kind === "receipts"
      ? "حساب العميل / المقابل (دائن)"
      : kind === "expenses"
        ? "حساب الدفع (دائن)"
        : "الحساب الدائن";
  return (
    <Dialog
      open
      onOpenChange={v => {
        if (!v && !mutation.isPending) close();
      }}
    >
      <DialogContent
        dir="rtl"
        className="sm:max-w-2xl max-h-[90vh] overflow-y-auto"
      >
        <DialogHeader className="text-right sm:text-right">
          <DialogTitle className="flex items-center gap-2">
            <ReceiptText className="text-amber-600" />
            إضافة {titles[kind]}
          </DialogTitle>
          <DialogDescription>
            اختر الحسابين من المستوى الثالث. يُحفظ السند ويُرحّل طرفاه
            المحاسبيان بمبلغ متساوٍ، مع تسجيل العملية باسم المستخدم.
          </DialogDescription>
        </DialogHeader>
        <form
          className="space-y-5"
          onSubmit={e => {
            e.preventDefault();
            const r = voucherInput.safeParse({
              kind,
              date,
              amount: Number(amount),
              debitAccount: Number(debit),
              creditAccount: Number(credit),
              notes,
            });
            if (!r.success) {
              setError(r.error.issues[0].message);
              return;
            }
            setError("");
            mutation.mutate(r.data);
          }}
        >
          <fieldset disabled={mutation.isPending} className="space-y-5">
            <div className="grid sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl">
              <label className="block space-y-2">
                تاريخ السند
                <Input
                  required
                  type="date"
                  dir="ltr"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                />
              </label>
              <label className="block space-y-2">
                المبلغ (ر.س)
                <Input
                  required
                  type="number"
                  dir="ltr"
                  min="0.01"
                  max="999999999.99"
                  step="0.01"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                />
              </label>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <AccountChoice
                label={debitLabel}
                value={debit}
                onChange={setDebit}
                accounts={accounts.data ?? []}
              />
              <AccountChoice
                label={creditLabel}
                value={credit}
                onChange={setCredit}
                accounts={accounts.data ?? []}
              />
            </div>
            {accounts.isLoading && <p>جارٍ تحميل الحسابات…</p>}
            {accounts.isError && (
              <p className="text-red-600" role="alert">
                {accounts.error.message}
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => accounts.refetch()}
                >
                  إعادة المحاولة
                </Button>
              </p>
            )}
            <label className="block space-y-2">
              البيان
              <textarea
                required
                minLength={2}
                maxLength={400}
                rows={3}
                className="border rounded-md p-3 w-full"
                value={notes}
                onChange={e => setNotes(e.target.value)}
              />
            </label>
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-4 flex flex-wrap justify-between gap-3 text-sm">
              <span>
                المدين: <strong>{money(Number(amount))}</strong>
              </span>
              <span>
                الدائن: <strong>{money(Number(amount))}</strong>
              </span>
              <span className="text-teal-700">سند متوازن</span>
            </div>
          </fieldset>
          {error && (
            <p role="alert" className="text-red-600">
              {error}
            </p>
          )}
          <div className="flex justify-end gap-3">
            <Button
              type="button"
              variant="outline"
              disabled={mutation.isPending}
              onClick={close}
            >
              إلغاء
            </Button>
            <Button
              disabled={
                mutation.isPending || accounts.isLoading || accounts.isError
              }
            >
              {mutation.isPending ? "جارٍ الحفظ…" : "حفظ " + titles[kind]}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
