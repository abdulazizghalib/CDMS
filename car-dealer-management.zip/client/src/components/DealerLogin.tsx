import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { resolveDealerLogin } from "@/lib/authGate";
import {
  AuthGateSplash,
  DealerBrandPane,
  DealerLoginGlows,
} from "@/components/LoginScreen";
import { KeyRound, LogIn, ShieldCheck, UserPlus } from "lucide-react";

/**
 * Gates the dealer workspace behind its own operator login (Oracle APP_USERS).
 *
 * This is the FIRST screen of the system: before any workspace data is shown,
 * the operator must sign in with their personal account. When the operators
 * table is still empty on a local machine, the same screen bootstraps the first
 * administrator instead.
 */
export function DealerLoginGate({ children }: { children: React.ReactNode }) {
  const session = trpc.oracleOperations.session.useQuery(undefined, {
    retry: false,
  });
  const view = resolveDealerLogin({
    loading: session.isLoading,
    hasError: session.isError,
    hasActor: Boolean(session.data?.actor),
  });

  if (view === "loading") return <AuthGateSplash />;
  if (view === "login")
    return (
      <DealerLoginForm canBootstrap={Boolean(session.data?.canBootstrap)} />
    );
  return <>{children}</>;
}

function DealerLoginForm({ canBootstrap }: { canBootstrap: boolean }) {
  const utils = trpc.useUtils();
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");

  const refresh = async () => {
    setPassword("");
    await utils.oracleOperations.invalidate();
  };
  const login = trpc.oracleOperations.login.useMutation({ onSuccess: refresh });
  const setup = trpc.oracleOperations.bootstrap.useMutation({
    onSuccess: refresh,
  });

  const pending = login.isPending || setup.isPending;
  const error = setup.error?.message ?? login.error?.message;

  return (
    <div className="dealer-login">
      <DealerLoginGlows />

      <div className="dealer-login-shell">
        <DealerBrandPane />

        <section
          className="dealer-login-card"
          aria-labelledby="dealer-login-title"
        >
          <div className="dealer-login-card-head">
            <span className="dealer-login-badge">
              <ShieldCheck size={14} />
              {canBootstrap ? "تهيئة أول مرة" : "دخول مصرّح به"}
            </span>
            <h2 id="dealer-login-title">
              {canBootstrap ? "إنشاء أول مدير للنظام" : "تسجيل الدخول"}
            </h2>
            <p>
              {canBootstrap
                ? "اختر حسابًا شخصيًا للمدير، ثم أضف حسابًا منفصلًا لكل موظف من شاشة المستخدمين والصلاحيات."
                : "الوصول إلى مساحة عمل المعرض متاح للمستخدمين المصرّح لهم فقط. سجّل الدخول للمتابعة."}
            </p>
          </div>

          <form
            className="dealer-login-form"
            onSubmit={event => {
              event.preventDefault();
              if (pending) return;
              if (canBootstrap)
                setup.mutate({ username, displayName, password });
              else login.mutate({ username, password });
            }}
          >
            <label className="dealer-login-field">
              <span>اسم المستخدم</span>
              <input
                className="dealer-login-input"
                dir="ltr"
                autoComplete="username"
                required
                minLength={3}
                maxLength={50}
                placeholder="username"
                value={username}
                onChange={event => setUsername(event.target.value)}
              />
            </label>

            {canBootstrap && (
              <label className="dealer-login-field">
                <span>الاسم الظاهر</span>
                <input
                  className="dealer-login-input"
                  required
                  maxLength={100}
                  placeholder="الاسم الكامل للمدير"
                  value={displayName}
                  onChange={event => setDisplayName(event.target.value)}
                />
              </label>
            )}

            <label className="dealer-login-field">
              <span>كلمة المرور</span>
              <input
                className="dealer-login-input"
                type="password"
                autoComplete={canBootstrap ? "new-password" : "current-password"}
                required
                minLength={canBootstrap ? 12 : 1}
                maxLength={128}
                placeholder="••••••••"
                value={password}
                onChange={event => setPassword(event.target.value)}
              />
            </label>

            {error && (
              <p className="dealer-login-alert" role="alert">
                {error}
              </p>
            )}

            <button
              type="submit"
              className="dealer-login-provider"
              disabled={pending}
            >
              {canBootstrap ? <UserPlus size={18} /> : <LogIn size={18} />}
              {pending
                ? "جارٍ التحقق..."
                : canBootstrap
                  ? "إنشاء حساب المدير"
                  : "دخول"}
            </button>

            <p className="dealer-login-hint">
              {canBootstrap
                ? "كلمة المرور 12 حرفًا على الأقل. لا تستخدم كلمة مرور قاعدة البيانات."
                : "تُنسب كل عمليات الحفظ والتعديل والحذف إلى حساب المستخدم المسجّل دخوله."}
            </p>
          </form>

          <p className="dealer-login-foot">
            <KeyRound size={12} aria-hidden="true" /> منصة إدارة معارض السيارات —
            نسخة المعرض
          </p>
        </section>
      </div>
    </div>
  );
}
