import { useEffect, useState, type ReactNode } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Car, ImagePlus } from "lucide-react";
export function DealerLogo({
  className = "h-16 w-24 object-contain",
  fallback,
}: {
  className?: string;
  fallback?: ReactNode;
}) {
  const brand = trpc.oracleOperations.branding.useQuery(undefined, {
    retry: false,
    staleTime: 60000,
  });
  const [failed, setFailed] = useState<string | null>(null);
  return brand.data?.logo && failed !== brand.data.logo ? (
    <img
      src={brand.data.logo}
      alt={brand.data.name}
      className={className}
      onError={() => setFailed(brand.data!.logo)}
    />
  ) : (
    <>{fallback ?? <Car size={26} />}</>
  );
}
export function BrandingSettings() {
  const actor = trpc.oracleOperations.session.useQuery().data?.actor;
  const query = trpc.oracleOperations.branding.useQuery(undefined, {
    retry: false,
  });
  const utils = trpc.useUtils();
  const [name, setName] = useState(""),
    [logo, setLogo] = useState<string | null>(null),
    [dirty, setDirty] = useState(false),
    [error, setError] = useState(""),
    [saved, setSaved] = useState(false),
    [reading, setReading] = useState(false);
  useEffect(() => {
    if (query.data && !dirty) {
      setName(query.data.name);
      setLogo(query.data.logo);
    }
  }, [query.data, dirty]);
  const mutation = trpc.oracleOperations.saveBranding.useMutation({
    onSuccess: async () => {
      await utils.oracleOperations.branding.invalidate();
      await utils.oracleOperations.invoiceForPrint.invalidate();
      setDirty(false);
      setSaved(true);
    },
  });
  if (!actor || actor.ROLE !== "admin") return null;
  const locked = reading || mutation.isPending || !query.data;
  return (
    <section
      className="oracle-panel p-6"
      style={{ gridColumn: "1 / -1" }}
      dir="rtl"
    >
      <h2 className="flex items-center gap-2 text-xl font-bold">
        <ImagePlus size={22} />
        هوية المعرض والشعار
      </h2>
      <p className="my-3 text-sm text-slate-600">
        يظهر الشعار في النظام وشاشة تسجيل الدخول وطباعة فواتير البيع والشراء.
      </p>
      <form
        className="space-y-4"
        onSubmit={e => {
          e.preventDefault();
          setSaved(false);
          setError("");
          mutation.mutate({ name, logo });
        }}
      >
        <fieldset
          disabled={locked}
          className="grid items-center gap-5 sm:grid-cols-[160px_1fr]"
        >
          <div className="flex h-32 items-center justify-center rounded-xl border bg-slate-50">
            {logo ? (
              <img
                src={logo}
                alt="معاينة الشعار"
                className="max-h-28 max-w-36 object-contain"
              />
            ) : (
              <Car size={48} className="text-slate-400" />
            )}
          </div>
          <div className="space-y-3">
            <label className="block">
              اسم المعرض
              <Input
                required
                minLength={2}
                maxLength={100}
                value={name}
                onChange={e => {
                  setName(e.target.value);
                  setDirty(true);
                  setSaved(false);
                }}
              />
            </label>
            <label className="block">
              رفع الشعار
              <Input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={async e => {
                  const file = e.target.files?.[0];
                  e.target.value = "";
                  if (!file) return;
                  setError("");
                  setSaved(false);
                  setReading(true);
                  try {
                    if (file.size > 512 * 1024)
                      throw new Error("حجم الشعار يجب ألا يتجاوز 512 كيلوبايت");
                    if (
                      !["image/png", "image/jpeg", "image/webp"].includes(
                        file.type
                      )
                    )
                      throw new Error("اختر صورة PNG أو JPEG أو WebP");
                    const image = await createImageBitmap(file);
                    if (image.width > 4096 || image.height > 4096) {
                      image.close();
                      throw new Error("أبعاد الشعار يجب ألا تتجاوز 4096 بكسل");
                    }
                    image.close();
                    const data = await new Promise<string>(
                      (resolve, reject) => {
                        const reader = new FileReader();
                        reader.onload = () => resolve(String(reader.result));
                        reader.onerror = () =>
                          reject(new Error("تعذر قراءة الصورة"));
                        reader.readAsDataURL(file);
                      }
                    );
                    setLogo(data);
                    setDirty(true);
                  } catch (err) {
                    setError(
                      err instanceof Error ? err.message : "صورة غير صحيحة"
                    );
                  } finally {
                    setReading(false);
                  }
                }}
              />
            </label>
            <p className="text-xs text-slate-500">
              PNG أو JPEG أو WebP، حتى 512 كيلوبايت.
            </p>
            {logo && (
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setLogo(null);
                  setDirty(true);
                  setSaved(false);
                }}
              >
                إزالة الشعار
              </Button>
            )}
          </div>
        </fieldset>
        {(error || query.error || mutation.error) && (
          <p role="alert" className="text-red-700">
            {error || query.error?.message || mutation.error?.message}
          </p>
        )}
        {saved && (
          <p role="status" className="text-emerald-700">
            تم تحديث هوية المعرض.
          </p>
        )}
        <Button type="submit" disabled={locked || !dirty}>
          {mutation.isPending ? "جارٍ الحفظ…" : "حفظ الشعار والهوية"}
        </Button>
      </form>
    </section>
  );
}

export function DealerName() {
  const branding = trpc.oracleOperations.branding.useQuery(undefined, {
    retry: false,
    staleTime: 60000,
  });
  return <>{branding.data?.name || "إدارة معرض السيارات"}</>;
}
