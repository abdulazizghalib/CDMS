import { describe, expect, it, vi } from "vitest";
import { clearDealerLogo, saveDealerLogo, selectBranch } from "./branding";

describe("branding and branch helpers", () => {
  it("saves and clears the dealer logo", () => {
    const storage = { setItem: vi.fn(), removeItem: vi.fn() };
    expect(saveDealerLogo(storage, "data:image/png;base64,logo")).toContain("data:image/png");
    expect(storage.setItem).toHaveBeenCalledWith("dealer-logo", "data:image/png;base64,logo");
    clearDealerLogo(storage);
    expect(storage.removeItem).toHaveBeenCalledWith("dealer-logo");
  });

  it("keeps a valid branch and falls back for an unknown branch", () => {
    expect(selectBranch("فرع الشمال", ["الفرع الرئيسي", "فرع الشمال"])).toBe("فرع الشمال");
    expect(selectBranch("غير موجود", ["الفرع الرئيسي"])).toBe("الفرع الرئيسي");
  });
});
