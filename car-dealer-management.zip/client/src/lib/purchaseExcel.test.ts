﻿import { describe, it, expect } from "vitest";
import Excel from "exceljs";
import { readPurchaseExcel, purchaseColumns } from "./purchaseExcel";
async function file(rows: unknown[][], name = "purchases.xlsx") {
  const book = new Excel.Workbook();
  const sheet = book.addWorksheet("Cars");
  sheet.addRows(rows);
  const bytes = await book.xlsx.writeBuffer();
  return new File([new Uint8Array(bytes)], name);
}
const headers = purchaseColumns.map(c => c.label);
describe("purchase Excel import", () => {
  it("reads Arabic headers, prices and text plate/VIN with leading zeros", async () => {
    const rows = await readPurchaseExcel(
      await file([
        headers,
        [
          "Car",
          "2026",
          "White",
          "00123",
          12000.5,
          "000123456789012345",
          "Notes",
        ],
      ])
    );
    expect(rows).toEqual([
      {
        car: "Car",
        model: "2026",
        color: "White",
        plate: "00123",
        price: 12000.5,
        vin: "000123456789012345",
        notes: "Notes",
      },
    ]);
  });
  it("reports missing required columns and invalid prices with row numbers", async () => {
    await expect(
      readPurchaseExcel(await file([["Car"], ["A"]]))
    ).rejects.toThrow("الأعمدة");
    await expect(
      readPurchaseExcel(
        await file([headers, ["Car", "", "", "ABC", "not a price", "", ""]])
      )
    ).rejects.toThrow("السطر 2");
  });
  it("rejects formula prices and numeric VINs to avoid importing stale or rounded values", async () => {
    await expect(
      readPurchaseExcel(
        await file([
          headers,
          ["Car", "", "", "ABC", { formula: "1+1", result: 2 }, "VIN", ""],
        ])
      )
    ).rejects.toThrow("المعادلة");
    await expect(
      readPurchaseExcel(
        await file([headers, ["Car", "", "", "ABC", 2, 1234567890, ""]])
      )
    ).rejects.toThrow("كنص");
  });
  it("rejects unsupported formats and an empty workbook", async () => {
    await expect(
      readPurchaseExcel(await file([headers], "old.xls"))
    ).rejects.toThrow(".xlsx");
    await expect(readPurchaseExcel(await file([headers]))).rejects.toThrow(
      "لا توجد سيارات"
    );
  });
});
