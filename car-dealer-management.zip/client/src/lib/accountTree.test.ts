import { describe, it, expect } from "vitest";
import {
  buildAccountTree,
  filterAccountTree,
  type AccountEntry,
} from "@shared/accountTree";
const account = (
  ID: number,
  LEVEL: 1 | 2 | 3,
  PARENT_ID: number | null,
  NAME = "حساب"
): AccountEntry => ({ ID, LEVEL, PARENT_ID, NAME, NATURE: null, NOTES: null });
describe("account tree", () => {
  it("retains empty accounts, sorts numerically and connects three levels", () => {
    const { roots, orphans } = buildAccountTree([
      account(30, 3, 20),
      account(20, 2, 2),
      account(10, 1, null),
      account(2, 1, null),
    ]);
    expect(roots.map(n => n.ID)).toEqual([2, 10]);
    expect(roots[0].children[0].children[0].ID).toBe(30);
    expect(roots[1].children).toEqual([]);
    expect(orphans).toEqual([]);
  });
  it("does not merge matching numbers across account levels", () => {
    const { roots } = buildAccountTree([
      account(1, 1, null),
      account(1, 2, 1),
      account(1, 3, 1),
    ]);
    expect(roots[0].children[0].children[0].key).toBe("3:1");
  });
  it("shows disconnected accounts and their children", () => {
    const { orphans } = buildAccountTree([
      account(20, 2, 999),
      account(30, 3, 20),
      account(40, 3, null),
    ]);
    expect(orphans.map(n => n.ID)).toEqual([20, 40]);
    expect(orphans[0].children[0].ID).toBe(30);
  });
  it("search retains ancestors, accepts Arabic digits and preserves all children of matching parents", () => {
    const { roots } = buildAccountTree([
      account(1, 1, null, "الأصول"),
      account(2001, 2, 1, "الصناديق"),
      account(3001, 3, 2001, "صندوق"),
      account(3002, 3, 2001, "البنك"),
    ]);
    expect(
      filterAccountTree(roots, "٣٠٠٢")[0].children[0].children.map(n => n.ID)
    ).toEqual([3002]);
    expect(
      filterAccountTree(roots, "الصناديق")[0].children[0].children.length
    ).toBe(2);
    expect(filterAccountTree(roots, "غير موجود")).toEqual([]);
  });
});
