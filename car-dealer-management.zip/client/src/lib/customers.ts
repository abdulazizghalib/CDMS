import type { Customer } from "../../../drizzle/schema";

export type CustomerViewRecord = Customer;

export function filterCustomers(customers: CustomerViewRecord[], query: string) {
  return customers.filter((customer) => {
    return !query || 
      customer.name.toLowerCase().includes(query.toLowerCase()) ||
      customer.phone.includes(query) ||
      (customer.email?.toLowerCase().includes(query.toLowerCase()));
  });
}
