import { describe, expect, it } from "vitest";
import { calculateExpectedProfit, filterVehicles } from "./dealer";

describe("dealer helpers", () => {
  it("calculates expected vehicle profit", () => {
    expect(calculateExpectedProfit({ price: 485000, cost: 425000 })).toBe(60000);
  });

  it("filters vehicles by name, year, or status", () => {
    const vehicles = [
      { name: "لكزس GX 550", year: "2024", price: 485000, cost: 425000, status: "متاحة" },
      { name: "BMW X5", year: "2023", price: 395000, cost: 350000, status: "محجوزة" },
    ];
    expect(filterVehicles(vehicles, "BMW")).toHaveLength(1);
    expect(filterVehicles(vehicles, "محجوزة")[0]?.name).toBe("BMW X5");
    expect(filterVehicles(vehicles, "")).toHaveLength(2);
  });
});
