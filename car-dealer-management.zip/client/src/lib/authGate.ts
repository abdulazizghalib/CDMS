/**
 * Pure helpers that decide which surface the app shell should render.
 *
 * Kept free of React / browser APIs so the login-first behaviour can be unit
 * tested without a DOM (the repo's Vitest environment is `node`).
 */

export type AuthGateView = "loading" | "login" | "app";

export type AuthGateState = {
  loading: boolean;
  isAuthenticated: boolean;
};

/**
 * The login screen must be the first surface a visitor sees: while the session
 * is still being resolved we show the branded splash, then either the login
 * screen (unauthenticated) or the dealer workspace (authenticated).
 */
export function resolveAuthGate(state: AuthGateState): AuthGateView {
  if (state.loading) return "loading";
  return state.isAuthenticated ? "app" : "login";
}

export type AuthSurface = "splash" | "login" | "app";

/**
 * Chooses the surface the app shell should render, taking the login readiness
 * into account.
 *
 * The login screen is the first surface whenever Manus OAuth is configured.
 * When it is NOT configured (typical for offline/local Oracle development,
 * where the workspace authenticates through its own operation login), the login
 * button could never complete, so we must not dead-end on it — fall through to
 * the workspace instead of blocking local access.
 */
export function resolveAuthSurface(
  state: AuthGateState,
  loginReady: boolean
): AuthSurface {
  const view = resolveAuthGate(state);
  if (view === "loading") return "splash";
  if (view === "app") return "app";
  return loginReady ? "login" : "app";
}

/** State of the workspace's own (Oracle APP_USERS) session. */
export type DealerLoginState = {
  loading: boolean;
  hasError: boolean;
  hasActor: boolean;
};

export type DealerLoginView = "loading" | "login" | "app";

/**
 * Decides whether the dealer workspace should show its own full-screen login.
 *
 * The workspace login (Oracle `APP_USERS`) is the first screen of the system
 * when there is no active operator session. While the session is being
 * resolved we keep the branded splash, and if the session query fails (Oracle
 * unreachable) we fall through so the workspace can surface its own error
 * instead of trapping the user on a login that cannot connect.
 */
export function resolveDealerLogin(state: DealerLoginState): DealerLoginView {
  if (state.loading) return "loading";
  if (state.hasError) return "app";
  return state.hasActor ? "app" : "login";
}

export type LoginReadiness =
  | { ready: true }
  | { ready: false; message: string };

export type OAuthEnv = {
  VITE_OAUTH_PORTAL_URL?: string;
  VITE_APP_ID?: string;
};

/**
 * `startLogin()` builds `new URL(`${portal}/app-auth`)`, which throws when the
 * Manus OAuth variables are absent (a common local-development mistake). Detect
 * that up-front so the login screen can explain the problem instead of failing
 * with an opaque navigation error.
 */
export function checkLoginReadiness(env: OAuthEnv): LoginReadiness {
  if (!env.VITE_OAUTH_PORTAL_URL) {
    return {
      ready: false,
      message:
        "تعذر بدء تسجيل الدخول: متغير البيئة VITE_OAUTH_PORTAL_URL غير مُهيأ على هذا التشغيل.",
    };
  }
  if (!env.VITE_APP_ID) {
    return {
      ready: false,
      message:
        "تعذر بدء تسجيل الدخول: متغير البيئة VITE_APP_ID غير مُهيأ على هذا التشغيل.",
    };
  }
  return { ready: true };
}