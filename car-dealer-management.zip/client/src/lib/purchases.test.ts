import { describe, expect, it } from "vitest";
import { filterPurchases, summarizePurchases, type PurchaseViewRecord } from "./purchases";
const records: PurchaseViewRecord[] = [{ id: 1, invoiceNumber: "PUR-00001", supplierName: "شركة المتحدة", purchaseDate: new Date("2026-08-26"), totalAmount: 432500, paymentStatus: "partial", branchName: "الفرع الرئيسي", notes: null, createdBy: null, createdAt: new Date(), updatedAt: new Date() }, { id: 2, invoiceNumber: "PUR-00002", supplierName: "مزاد الرياض", purchaseDate: new Date("2026-08-25"), totalAmount: 351800, paymentStatus: "paid", branchName: "فرع الشمال", notes: null, createdBy: null, createdAt: new Date(), updatedAt: new Date() }];
describe("purchase invoice screen helpers", () => {
 it("filters actual invoice fields and combines branch/payment criteria", () => {
 expect(filterPurchases(records, { query: "المتحدة" }).map(r=>r.id)).toEqual([1]);
 expect(filterPurchases(records, { query: "PUR-00002", branchName: "فرع الشمال", paymentStatus: "paid" }).map(r=>r.id)).toEqual([2]);
 expect(filterPurchases(records, { branchName: "فرع الشمال", paymentStatus: "partial" })).toEqual([]);
 });
 it("summarizes only visible invoices", () => {
 expect(summarizePurchases(records)).toEqual({ totalCost: 784300, unpaidCount: 1 });
 expect(summarizePurchases(filterPurchases(records,{paymentStatus:"paid"}))).toEqual({totalCost:351800,unpaidCount:0});
 });
});
