export function saveDealerLogo(storage: Pick<Storage, "setItem">, logo: string) {
  storage.setItem("dealer-logo", logo);
  return logo;
}

export function clearDealerLogo(storage: Pick<Storage, "removeItem">) {
  storage.removeItem("dealer-logo");
}

export function selectBranch(branch: string, availableBranches: string[]) {
  return availableBranches.includes(branch) ? branch : availableBranches[0] ?? "الفرع الرئيسي";
}
