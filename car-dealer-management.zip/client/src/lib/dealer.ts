export type DealerVehicle = {
  name: string;
  year: string;
  price: number;
  cost: number;
  status: string;
};

export function calculateExpectedProfit(vehicle: Pick<DealerVehicle, "price" | "cost">) {
  return vehicle.price - vehicle.cost;
}

export function filterVehicles(vehicles: DealerVehicle[], query: string) {
  const normalizedQuery = query.trim().toLocaleLowerCase();
  if (!normalizedQuery) return vehicles;
  return vehicles.filter((vehicle) =>
    `${vehicle.name} ${vehicle.year} ${vehicle.status}`.toLocaleLowerCase().includes(normalizedQuery),
  );
}
