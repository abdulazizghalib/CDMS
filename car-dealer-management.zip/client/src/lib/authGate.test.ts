import { describe, expect, it } from "vitest";
import {
  checkLoginReadiness,
  resolveAuthGate,
  resolveAuthSurface,
  resolveDealerLogin,
} from "./authGate";

describe("auth gate", () => {
  it("shows the branded splash while the session is loading", () => {
    expect(resolveAuthGate({ loading: true, isAuthenticated: false })).toBe(
      "loading"
    );
    expect(resolveAuthGate({ loading: true, isAuthenticated: true })).toBe(
      "loading"
    );
  });

  it("shows the login screen first for unauthenticated visitors", () => {
    expect(resolveAuthGate({ loading: false, isAuthenticated: false })).toBe(
      "login"
    );
  });

  it("shows the dealer workspace once authenticated", () => {
    expect(resolveAuthGate({ loading: false, isAuthenticated: true })).toBe(
      "app"
    );
  });
});

describe("login readiness", () => {
  it("accepts a fully configured OAuth environment", () => {
    expect(
      checkLoginReadiness({
        VITE_OAUTH_PORTAL_URL: "https://manus.im",
        VITE_APP_ID: "app-id",
      })
    ).toEqual({ ready: true });
  });

  it("flags a missing OAuth portal url", () => {
    const result = checkLoginReadiness({ VITE_APP_ID: "app-id" });
    expect(result.ready).toBe(false);
    if (!result.ready) expect(result.message).toContain("VITE_OAUTH_PORTAL_URL");
  });

  it("flags a missing app id", () => {
    const result = checkLoginReadiness({
      VITE_OAUTH_PORTAL_URL: "https://manus.im",
    });
    expect(result.ready).toBe(false);
    if (!result.ready) expect(result.message).toContain("VITE_APP_ID");
  });
});

describe("auth surface", () => {
  it("keeps the branded splash while loading regardless of login readiness", () => {
    expect(resolveAuthSurface({ loading: true, isAuthenticated: false }, true)).toBe(
      "splash"
    );
    expect(resolveAuthSurface({ loading: true, isAuthenticated: false }, false)).toBe(
      "splash"
    );
  });

  it("shows the workspace once authenticated", () => {
    expect(resolveAuthSurface({ loading: false, isAuthenticated: true }, false)).toBe(
      "app"
    );
  });

  it("shows the login screen first when Manus OAuth is configured", () => {
    expect(resolveAuthSurface({ loading: false, isAuthenticated: false }, true)).toBe(
      "login"
    );
  });

  it("falls through to the workspace when login can never complete", () => {
    // Local/offline Oracle development without Manus OAuth: the workspace
    // handles its own operation login, so do not dead-end on the login screen.
    expect(resolveAuthSurface({ loading: false, isAuthenticated: false }, false)).toBe(
      "app"
    );
  });
});

describe("dealer login gate", () => {
  it("keeps the branded splash while the operator session is resolving", () => {
    expect(
      resolveDealerLogin({ loading: true, hasError: false, hasActor: false })
    ).toBe("loading");
  });

  it("shows the login screen as the first screen when there is no operator", () => {
    expect(
      resolveDealerLogin({ loading: false, hasError: false, hasActor: false })
    ).toBe("login");
  });

  it("shows the workspace once an operator is signed in", () => {
    expect(
      resolveDealerLogin({ loading: false, hasError: false, hasActor: true })
    ).toBe("app");
  });

  it("falls through on session errors so the workspace can report them", () => {
    expect(
      resolveDealerLogin({ loading: false, hasError: true, hasActor: false })
    ).toBe("app");
  });
});