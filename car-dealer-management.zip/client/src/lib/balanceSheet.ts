export type BalanceLine = {
  AL_MAIN_NUM: number | null;
  AC_NAM: string | null;
  AL_BAR_NUM: number | null;
  BRANSHACNAM: string | null;
  DEPIT: number;
  CREDIT: number;
};
export function balanceSheetSides(lines: BalanceLine[]) {
  const groups = new Map<
    string,
    {
      main: number;
      mainName: string;
      account: number | null;
      name: string;
      debit: number;
      credit: number;
      balance: number;
    }
  >();
  for (const r of lines) {
    if (
      r.AL_MAIN_NUM === null ||
      ![1000, 1001, 1002, 1003, 1004].includes(r.AL_MAIN_NUM)
    )
      continue;
    const key = JSON.stringify([
      r.AL_MAIN_NUM,
      r.AL_BAR_NUM,
      r.AL_BAR_NUM === null ? r.BRANSHACNAM : null,
    ]);
    const row = groups.get(key) ?? {
      main: r.AL_MAIN_NUM,
      mainName: r.AC_NAM ?? "—",
      account: r.AL_BAR_NUM,
      name: r.BRANSHACNAM ?? "—",
      debit: 0,
      credit: 0,
      balance: 0,
    };
    row.debit += Math.round(Number(r.DEPIT) * 100);
    row.credit += Math.round(Number(r.CREDIT) * 100);
    groups.set(key, row);
  }
  const rows = Array.from(groups.values())
    .sort((a, b) => a.main - b.main || (a.account ?? 0) - (b.account ?? 0))
    .map(r => ({
      ...r,
      debit: r.debit / 100,
      credit: r.credit / 100,
      balance: (r.main <= 1001 ? r.debit - r.credit : r.credit - r.debit) / 100,
    }));
  const side = (asset: boolean) => {
    const items = rows.filter(r => r.main <= 1001 === asset);
    const debit =
        items.reduce((n, r) => n + Math.round(r.debit * 100), 0) / 100,
      credit = items.reduce((n, r) => n + Math.round(r.credit * 100), 0) / 100;
    return {
      rows: items,
      debit,
      credit,
      balance:
        Math.round((asset ? debit - credit : credit - debit) * 100) / 100,
    };
  };
  return { assets: side(true), liabilities: side(false) };
}
