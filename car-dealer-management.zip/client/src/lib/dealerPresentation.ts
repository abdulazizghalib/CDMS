import type { OracleDataset, OracleRow } from "@shared/oracleWorkspace";
export type DealerView =
  | OracleDataset
  | "balanceSheet"
  | "incomeStatement"
  | "trialBalance"
  | "dailyJournal"
  | "accountStatement"
  | "vouchers"
  | "attendance"
  | "attendanceSettings"
  | "attendanceReport"
  | "dashboard"
  | "audit"
  | "history"
  | "users"
  | "reports"
  | "settings"
  | "reservations"
  | "followups";
export type NavigateDealer = (
  view: DealerView,
  options?: { search?: string; vehicleId?: number }
) => void;
export const number = (value: unknown) =>
  value === null || value === undefined
    ? "—"
    : new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(
        Number(value) || 0
      );
export const money = (value: unknown) =>
  value === null || value === undefined ? "غير مسجل" : number(value) + " ر.س";
export function postingLabel(value: unknown) {
  const status = String(value ?? "")
    .trim()
    .toLowerCase();
  return status === "posted"
    ? "مرحّل"
    : status === "unposted"
      ? "غير مرحّل"
      : status || "غير مسجل";
}
export function carImage(row: OracleRow) {
  const name = String(row.CAR ?? "").toLowerCase();
  if (
    /هايلكس|داتسون|بيك|وانيت|غمارت|hilux|pickup|ram|silverado|f-150/.test(name)
  )
    return "/images/cars/studio-pickup.png";
  if (
    /جيب|كروزر|برادو|باترول|فورتشنر|دفع|suv|patrol|cruiser|fortuner|lexus|لكزس|تاهو|يوكن|سنتافي|سانتافي|cx|x5|gx/.test(
      name
    )
  )
    return "/images/cars/studio-suv.png";
  return "/images/cars/studio-sedan.png";
}
