import {
  purchaseCarInput,
  type PurchaseCarInput,
} from "@shared/oraclePurchaseInvoice";
export const purchaseColumns = [
  { key: "car", label: "نوع السيارة" },
  { key: "model", label: "الموديل" },
  { key: "color", label: "اللون" },
  { key: "plate", label: "رقم اللوحة" },
  { key: "price", label: "سعر الشراء" },
  { key: "vin", label: "الهيكل" },
  { key: "notes", label: "ملاحظات على السيارة" },
] as const;
const aliases: Record<string, string> = {
  "نوع السيارة": "car",
  السيارة: "car",
  car: "car",
  cp_type: "car",
  الموديل: "model",
  model: "model",
  cp_model: "model",
  اللون: "color",
  color: "color",
  cp_color: "color",
  "رقم اللوحة": "plate",
  اللوحة: "plate",
  plate: "plate",
  cp_panel: "plate",
  "سعر الشراء": "price",
  السعر: "price",
  price: "price",
  cp_purch_price: "price",
  الهيكل: "vin",
  "رقم الهيكل": "vin",
  vin: "vin",
  cp_hikl: "vin",
  "ملاحظات على السيارة": "notes",
  ملاحظات: "notes",
  notes: "notes",
  cp_car_note: "notes",
};
export async function readPurchaseExcel(
  file: File
): Promise<PurchaseCarInput[]> {
  if (!file.name.toLowerCase().endsWith(".xlsx"))
    throw new Error("اختر ملف Excel بصيغة .xlsx");
  if (file.size > 2 * 1024 * 1024)
    throw new Error("الحد الأقصى لحجم الملف 2 ميغابايت");
  const Excel = (await import("exceljs")).default;
  const book = new Excel.Workbook();
  await book.xlsx.load(await file.arrayBuffer());
  const sheet = book.worksheets[0];
  if (!sheet) throw new Error("الملف لا يحتوي ورقة عمل");
  if (sheet.rowCount > 501) throw new Error("الحد الأقصى 500 سيارة في الملف");
  const headers = new Map<string, number>();
  sheet.getRow(1).eachCell((cell, i) => {
    const key = aliases[cell.text.trim().toLowerCase()];
    if (key) {
      if (headers.has(key)) throw new Error("عمود مكرر: " + cell.text);
      headers.set(key, i);
    }
  });
  for (const k of ["car", "plate", "price"])
    if (!headers.has(k))
      throw new Error(
        "يجب أن يحتوي الملف الأعمدة: نوع السيارة، رقم اللوحة، سعر الشراء"
      );
  const lines: PurchaseCarInput[] = [];
  const errors: string[] = [];
  for (let rowIndex = 2; rowIndex <= sheet.rowCount; rowIndex++) {
    const row = sheet.getRow(rowIndex);
    const values: Record<string, string | number> = {};
    let nonempty = false;
    for (const f of purchaseColumns) {
      const cell = headers.has(f.key) ? row.getCell(headers.get(f.key)!) : null;
      const text = cell?.text.trim() ?? "";
      if (text) nonempty = true;
      if (cell?.type === Excel.ValueType.Formula) {
        errors.push(
          "السطر " + rowIndex + ": استخدم قيمة ثابتة بدلاً من المعادلة"
        );
      }
      if (f.key === "vin" && typeof cell?.value === "number")
        errors.push(
          "السطر " + rowIndex + ": أدخل رقم الهيكل كنص للحفاظ على جميع أرقامه"
        );
      values[f.key] =
        f.key === "price"
          ? text === ""
            ? NaN
            : Number(text.replace(/,/g, ""))
          : text;
    }
    if (!nonempty) continue;
    const result = purchaseCarInput.safeParse(values);
    if (!result.success) {
      errors.push(
        "السطر " +
          rowIndex +
          ": " +
          result.error.issues.map(x => x.message).join("، ")
      );
      continue;
    }
    lines.push(result.data);
  }
  if (errors.length) throw new Error(errors.slice(0, 10).join("\n"));
  if (!lines.length) throw new Error("لا توجد سيارات في الملف");
  return lines;
}
export async function downloadPurchaseTemplate() {
  const Excel = (await import("exceljs")).default;
  const book = new Excel.Workbook();
  const sheet = book.addWorksheet("المشتريات", {
    views: [{ rightToLeft: true }],
  });
  sheet.columns = purchaseColumns.map(c => ({
    header: c.label,
    key: c.key,
    width: 25,
  }));
  for (const key of ["plate", "vin", "model"])
    sheet.getColumn(key).numFmt = "@";
  sheet.getRow(1).font = { bold: true };
  const buffer = await book.xlsx.writeBuffer();
  const url = URL.createObjectURL(
    new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })
  );
  const a = document.createElement("a");
  a.href = url;
  a.download = "قالب-المشتريات.xlsx";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
