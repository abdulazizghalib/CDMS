import type { Sale } from "../../../drizzle/schema";

export type SaleViewRecord = Sale;

export interface SaleFilters {
  query: string;
  paymentStatus: string;
  branch: string;
}

export function filterSales(sales: SaleViewRecord[], filters: SaleFilters) {
  return sales.filter((sale) => {
    const matchesQuery = !filters.query || 
      sale.invoiceNumber.toLowerCase().includes(filters.query.toLowerCase()) ||
      (sale.notes?.toLowerCase().includes(filters.query.toLowerCase()));
    
    const matchesPayment = filters.paymentStatus === "all" || sale.paymentStatus === filters.paymentStatus;
    const matchesBranch = filters.branch === "all" || sale.branch === filters.branch;

    return matchesQuery && matchesPayment && matchesBranch;
  });
}

export function summarizeSales(sales: SaleViewRecord[]) {
  return {
    totalSales: sales.reduce((sum, s) => sum + s.totalAmount, 0),
    paidCount: sales.filter(s => s.paymentStatus === "paid").length,
    unpaidCount: sales.filter(s => s.paymentStatus !== "paid").length,
  };
}
