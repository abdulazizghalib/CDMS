import type { PurchaseInvoice } from "../../../drizzle/schema";

export type PurchaseViewRecord = PurchaseInvoice;

export type PurchaseFilters = {
  query?: string;
  paymentStatus?: string;
  branchName?: string;
};

export function filterPurchases(records: PurchaseViewRecord[], filters: PurchaseFilters) {
  const query = (filters.query ?? "").trim().toLowerCase();
  return records.filter((purchase) => {
    const searchable = `${purchase.invoiceNumber} ${purchase.supplierName}`.toLowerCase();
    return (!query || searchable.includes(query))
      && (!filters.paymentStatus || filters.paymentStatus === "all" || purchase.paymentStatus === filters.paymentStatus)
      && (!filters.branchName || filters.branchName === "all" || purchase.branchName === filters.branchName);
  });
}

export function summarizePurchases(records: Pick<PurchaseViewRecord, "totalAmount" | "paymentStatus">[]) {
  return {
    totalCost: records.reduce((sum, purchase) => sum + purchase.totalAmount, 0),
    unpaidCount: records.filter((purchase) => purchase.paymentStatus !== "paid").length,
  };
}
