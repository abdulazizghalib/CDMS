﻿import { describe, it, expect } from "vitest";
import { balanceSheetSides } from "./balanceSheet";
const line = (
  main: number,
  account: number,
  debit: number,
  credit: number
) => ({
  AL_MAIN_NUM: main,
  AC_NAM: "Main",
  AL_BAR_NUM: account,
  BRANSHACNAM: "Branch",
  DEPIT: debit,
  CREDIT: credit,
});
describe("Balance sheet presentation", () => {
  it("groups detail accounts by main and branch and separates both sides", () => {
    const result = balanceSheetSides([
      line(1000, 2003, 100000, 30000),
      line(1000, 2003, 0.1, 0.2),
      line(1002, 2007, 30000, 0),
      line(1004, 2010, 0, 100000),
      line(1005, 2011, 0, 15),
    ]);
    expect(result.assets.rows).toHaveLength(1);
    expect(result.liabilities.rows).toHaveLength(2);
    expect(result.assets.balance).toBe(69999.9);
    expect(result.liabilities.balance).toBe(70000);
    expect(result.liabilities.rows.map(r => r.balance)).toEqual([
      -30000, 100000,
    ]);
  });
  it("keeps branches with the same number under different main accounts distinct", () => {
    expect(
      balanceSheetSides([line(1000, 2003, 50, 0), line(1001, 2003, 75, 0)])
        .assets.rows
    ).toHaveLength(2);
  });
  it("returns zero totals for an empty period", () => {
    expect(balanceSheetSides([]).assets).toEqual({
      rows: [],
      debit: 0,
      credit: 0,
      balance: 0,
    });
  });
});
