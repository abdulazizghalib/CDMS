import type { Expense } from "../../../drizzle/schema";

export type ExpenseViewRecord = Expense;

export interface ExpenseFilters {
  query: string;
  category: string;
  branch: string;
}

export function filterExpenses(expenses: ExpenseViewRecord[], filters: ExpenseFilters) {
  return expenses.filter((expense) => {
    const matchesQuery = !filters.query || 
      expense.title.toLowerCase().includes(filters.query.toLowerCase()) ||
      (expense.notes?.toLowerCase().includes(filters.query.toLowerCase()));
    
    const matchesCategory = filters.category === "all" || expense.category === filters.category;
    const matchesBranch = filters.branch === "all" || expense.branch === filters.branch;

    return matchesQuery && matchesCategory && matchesBranch;
  });
}

export function summarizeExpenses(expenses: ExpenseViewRecord[]) {
  return {
    totalAmount: expenses.reduce((sum, e) => sum + e.amount, 0),
    byCategory: expenses.reduce((acc, e) => {
      acc[e.category] = (acc[e.category] || 0) + e.amount;
      return acc;
    }, {} as Record<string, number>),
  };
}
