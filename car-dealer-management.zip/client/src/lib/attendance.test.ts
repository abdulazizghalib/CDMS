﻿import { describe, it, expect } from "vitest";
import {
  attendanceWindow,
  locationAllowed,
  expectedTimes,
  shiftInput,
} from "@shared/attendance";
describe("attendance location and Riyadh time", () => {
  it("opens at 07:00 and closes after 17:00 in Riyadh", () => {
    const shift = { START_TIME: "07:00", END_TIME: "17:00" };
    expect(
      attendanceWindow(shift, Date.parse("2026-10-05T06:59:59+03:00")).allowed
    ).toBe(false);
    expect(
      attendanceWindow(shift, Date.parse("2026-10-05T07:00:00+03:00")).allowed
    ).toBe(true);
    expect(
      attendanceWindow(shift, Date.parse("2026-10-05T17:00:01+03:00")).allowed
    ).toBe(false);
  });
  it("uses the start date for overnight shifts and maps post-midnight work start correctly", () => {
    const shift = {
      START_TIME: "23:00",
      END_TIME: "07:00",
      WORK_START: "00:00",
      WORK_END: "08:00",
    };
    expect(
      attendanceWindow(shift, Date.parse("2026-10-06T02:00:00+03:00"))
    ).toEqual({ allowed: true, workDate: "2026-10-05" });
    expect(expectedTimes(shift, "2026-10-05").start).toBe(
      Date.parse("2026-10-06T00:00:00+03:00")
    );
  });
  it("rejects outside locations and inaccurate or boundary-uncertain readings", () => {
    const shift = { LATITUDE: 24.7, LONGITUDE: 46.7, RADIUS: 100 };
    expect(
      locationAllowed(shift, { latitude: 24.7, longitude: 46.7, accuracy: 5 })
        .inside
    ).toBe(true);
    expect(
      locationAllowed(shift, { latitude: 25, longitude: 46.7, accuracy: 5 })
        .inside
    ).toBe(false);
    expect(
      locationAllowed(shift, { latitude: 24.7, longitude: 46.7, accuracy: 150 })
        .accurate
    ).toBe(false);
    expect(
      locationAllowed(shift, {
        latitude: 24.70085,
        longitude: 46.7,
        accuracy: 20,
      }).inside
    ).toBe(false);
  });
  it("validates shift coordinates, radius and time windows", () => {
    const s = {
      name: "وردية",
      branch: "الفرع",
      latitude: 24,
      longitude: 46,
      radius: 100,
      startTime: "07:00",
      endTime: "17:00",
    };
    expect(shiftInput.safeParse(s).success).toBe(true);
    expect(shiftInput.safeParse({ ...s, latitude: 91 }).success).toBe(false);
    expect(shiftInput.safeParse({ ...s, endTime: "07:00" }).success).toBe(
      false
    );
    expect(
      shiftInput.safeParse({ ...s, workStart: "08:00", workEnd: "08:00" })
        .success
    ).toBe(false);
  });
});
