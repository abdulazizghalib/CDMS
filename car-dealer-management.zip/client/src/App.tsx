import { lazy, Suspense } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { checkLoginReadiness, resolveAuthSurface } from "@/lib/authGate";
import { trpc } from "@/lib/trpc";
import "./oracle-workspace.css";
import "./dealer-brochure.css";
import "./login-screen.css";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthGateSplash, LoginScreen } from "@/components/LoginScreen";
import { DealerLoginGate } from "@/components/DealerLogin";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

const OracleWorkspace = lazy(() => import("./pages/OracleWorkspace"));
function WorkspaceRoot() {
  const mode = trpc.oracleWorkspace.mode.useQuery(undefined, { retry: false });
  if (mode.isLoading) return <AuthGateSplash />
  if (mode.isError)
    return (
      <div className="p-10 text-center" role="alert">
        <p>تعذر الاتصال بالخادم.</p>
        <button className="mt-4 underline" onClick={() => void mode.refetch()}>
          إعادة المحاولة
        </button>
      </div>
    );
  if (mode.data?.provider === "oracle") {
    return (
      <DealerLoginGate>
        <Suspense fallback={<AuthGateSplash />}>
          <OracleWorkspace />
        </Suspense>
      </DealerLoginGate>
    );
  }
  return <Home />;
}

/**
 * Manus OAuth gate for the platform (MySQL) surface: it renders the branded
 * splash while the session resolves, the login screen for unauthenticated
 * visitors when OAuth is configured, and the workspace once authenticated.
 *
 * When OAuth is NOT configured the gate falls through — the Oracle workspace
 * has its own operator login (see `DealerLoginGate`) instead of an OAuth flow
 * that can never complete.
 */
function AuthGate({ children }: { children: React.ReactNode }) {
  const { loading, isAuthenticated } = useAuth();
  const readiness = checkLoginReadiness({
    VITE_OAUTH_PORTAL_URL: import.meta.env.VITE_OAUTH_PORTAL_URL,
    VITE_APP_ID: import.meta.env.VITE_APP_ID,
  });
  const surface = resolveAuthSurface({ loading, isAuthenticated }, readiness.ready);

  if (surface === "splash") return <AuthGateSplash />;
  if (surface === "login") return <LoginScreen />;
  return <>{children}</>;
}

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={WorkspaceRoot} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <AuthGate>
            <Router />
          </AuthGate>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
